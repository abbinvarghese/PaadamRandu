//
//  CLQuestionnaireObject.h
//  CareerLine
//
//  Created by CSG on 3/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLQuestionnaireObject : NSObject

//Smiley Rating for job suggestion..
typedef enum {
    CLQuestionnaireSmileyRatingNone = 0,
    CLQuestionnaireSmileyRatingOne=  1,
    CLQuestionnaireSmileyRatingTwo = 2,
    CLQuestionnaireSmileyRatingThree = 3,
    CLQuestionnaireSmileyRatingFour = 4,
    CLQuestionnaireSmileyRatingFive = 5,
} CLQuestionnaireSmileyRating;

@property (nonatomic, strong) NSString *questionionnaireId;
@property (nonatomic, strong) NSString *question;
@property (nonatomic, strong) NSString *answer;
@property (nonatomic, assign) CLQuestionnaireSmileyRating rating;

- (id)initWithDictionary:(NSDictionary*)dictionary;

//To submit or save questionnaire according to the status(0=submit, 1=save)..
+ (void)submitQuestionnaireforInboxId:(NSString*)inboxId withQuestionnaire:(NSString*)questJson submitStatus:(NSString*)draftStatus success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

@end
