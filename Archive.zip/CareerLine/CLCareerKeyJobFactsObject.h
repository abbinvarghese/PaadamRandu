//
//  CLCareerKeyJobFactsObject.h
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCareerKeyJobFactsObject : NSObject

@property (nonatomic, strong) NSString *jobFacts;
@property (nonatomic, strong) NSString *jobAccountabilities;
@property (nonatomic, strong) NSString *keyPerformance;

@property (nonatomic, strong) NSMutableDictionary *permanentReportDirect;
@property (nonatomic, strong) NSMutableDictionary *permanentReportInDirect;
@property (nonatomic, strong) NSMutableDictionary *tempReportDirect;
@property (nonatomic, strong) NSMutableDictionary *tempReportInDirect;
@property (nonatomic, strong) NSMutableDictionary *budgetResponsibility;

@end
