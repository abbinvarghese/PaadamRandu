//
//  CLLocationDetailsViewController.m
//  CareerLine
//
//  Created by CSG on 2/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLocationDetailsViewController.h"
#import "CLSalutationViewController.h"
#import "CLCRFObject.h"
#import "CLStatusViewController.h"
#import "CLEmploymentDetailsViewController.h"
#import "CLCRFEducationViewController.h"
#import "CLCRFAboutMeViewController.h"

#define kRelocationOptionIdKey @"RelocationOptionsIdkey"
#define kRelocationOptionTitleKey @"RelocationOptionsTitlekey"

#define kSectionHeaderTextColor [UIColor darkGrayColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont [UIFont systemFontOfSize:13]

@interface CLLocationDetailsViewController ()

//Table section index...
typedef enum {
	TableSectionIndexCurrentLocation = 1,
	TableSectionIndexRelocationOption= 0,
} TableLocationSectionIndex;

//Relocation Options...
typedef enum {
	RelocationOptionsNotMove = 1,
	RelocationOptionsSameCountry= 2,
    RelocationOptionsOtherCountry=3,
    RelocationOptionsSameOrOtherCountry=4
} RelocationOptions;

@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (strong, nonatomic) IBOutlet UIView *tblFooterSameCountry;
@property (strong, nonatomic) IBOutlet UIView *tblFooterOtherCountry;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneToolbarWithCancel;
@property (strong, nonatomic) UIPickerView *pickerView;
@property(nonatomic,strong)UITextField *txtFirstResponder;
@property(nonatomic,assign)BOOL isDataLoadedFromUserDefaults;

@property(nonatomic,strong)NSMutableArray *relocationOptionsArray;

@property(nonatomic,strong)NSMutableDictionary *selectedCurrentLocation;
@property(nonatomic,strong)NSMutableDictionary *selectedRelocationOption;
@property(nonatomic,strong)NSMutableArray *selectedSameCountryLocations;
@property(nonatomic,strong)NSMutableArray *selectedOtherCountryLocations;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property(nonatomic,strong)CLRelocationObject *relocObj;
//- (IBAction)bttnActionKeyboardDone:(id)sender;
- (IBAction)bttnActionKeyboardCancel:(id)sender;
- (IBAction)bttnActionAddWithinSameCountry:(id)sender;
- (IBAction)bttnActionAddOtherCountry:(id)sender;

@end

@implementation CLLocationDetailsViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Location", @"Profile details location page title");
    [self setRightNavButton];
    [self registerTableCellsForReuse];
    self.tableView.tableHeaderView=self.tblHeaderView;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    
    self.relocationOptionsArray= [[NSMutableArray alloc] init];
    [self loadArraysWithData];
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    self.isDataLoadedFromUserDefaults=NO;
    [self initCRFFour];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [self.txtFirstResponder resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CLSimpleTextCellDelegate Methods

//- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
//    self.txtFirstResponder=textField;
//}

#pragma mark RelocationDelegate

-(void)relocationCompletedSelectionWith:(NSMutableDictionary *)dictionary{
    self.selectedRelocationOption = dictionary;
    [self.tableView reloadData];
}

#pragma mark CLTappableCellDelegate Methods

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==TableSectionIndexCurrentLocation) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryBasedLocation;
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if (indexPath.section == TableSectionIndexRelocationOption){
        
    }
}

#pragma mark CLSelectLocationDelegate

- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    self.selectedRelocationOption = nil;
    self.selectedCurrentLocation=locDict;
    [self.selectedOtherCountryLocations removeAllObjects];
    [self.selectedSameCountryLocations removeAllObjects];
    [self.tableView reloadData];

}

- (void)selectLocationControllerDidSelectLocations:(CLSelectLocationViewController*)controller forType:(LocationListingType)type withArray:(NSMutableArray *)locArray{
    if (type==LocationListingTypeOtherCountries) {
        if([self.selectedOtherCountryLocations count]==0){
            self.selectedOtherCountryLocations=locArray;
        }
        else{
            [self.selectedOtherCountryLocations addObjectsFromArray:locArray];
        }
    }
    else if (type==LocationListingTypeSameCountry){
        if([self.selectedSameCountryLocations count]==0){
            self.selectedSameCountryLocations=locArray;
        }
        else{
            [self.selectedSameCountryLocations addObjectsFromArray:locArray];
        }
    }
    
    [self.tableView reloadData];
//    [self.tableView setAllowsSelectionDuringEditing:YES];
//    if ([self.selectedSameCountryLocations count]>0 || [self.selectedOtherCountryLocations count]>0) {
//        [self.tableView setEditing:YES animated:YES];
//    }
}

#pragma mark Utility Methods

-(void)setRightNavButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for next button title to goto next page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGotoNextPage:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
    if (self.needCustomBackButtons) {
        if (self.needCustomBackButtons) {
            UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Employment", @"Text for status page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(backClicked)];
            self.navigationItem.leftBarButtonItem=leftNavBttn;
        }
    }
}

-(void)backClicked{
    CLEmploymentDetailsViewController *newVC = [[CLEmploymentDetailsViewController alloc]init];
    CLCRFEducationViewController *newVC2 = [[CLCRFEducationViewController alloc]init];
    CLCRFAboutMeViewController *newVC3 = [[CLCRFAboutMeViewController alloc]init];
    NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [vcs insertObject:newVC atIndex:[vcs count]-1];
    [vcs insertObject:newVC2 atIndex:[vcs count]-2];
    [vcs insertObject:newVC3 atIndex:[vcs count]-3];
    [self.navigationController setViewControllers:vcs animated:NO];
    [self.navigationController popViewControllerAnimated:YES];

}

-(void)registerTableCellsForReuse{
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentLocationCellIdentifier"];
//    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"relocationCellIdentifier"];
}

-(void)loadArraysWithData{
    [self.relocationOptionsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:1],kRelocationOptionIdKey,@"Do not want to move",kRelocationOptionTitleKey, nil]];
//    [self.relocationOptionsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:2],kRelocationOptionIdKey,@"Can move within country.",kRelocationOptionTitleKey, nil]];
//    [self.relocationOptionsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:3],kRelocationOptionIdKey,@"Can move to another country.",kRelocationOptionTitleKey, nil]];
//    [self.relocationOptionsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:4],kRelocationOptionIdKey,@"Can move within or another country.",kRelocationOptionTitleKey, nil]];
}

-(CLSimpleTextCell*)getCellForFirstResponder{
    UITableViewCell *cell=nil;
    if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
        cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
    }
    
    return (CLSimpleTextCell*)cell;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    // home location validation
    if ([self.selectedCurrentLocation count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select where do you live.", @"Error Message for null home location field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if ([self.selectedRelocationOption count]!=0) {
        if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry){
            if ([self.selectedSameCountryLocations count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please add your preferred location for relocation.", @"Error Message for null Preferred location field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
        }
        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry) {
            if ([self.selectedOtherCountryLocations count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please add your preferred country for relocation.", @"Error Message for null Preferred country field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
        }
        
        else if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry){
            if ([self.selectedSameCountryLocations count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please add your preferred location for relocation.", @"Error Message for null Preferred location field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
            if ([self.selectedOtherCountryLocations count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please add your preferred country for relocation.", @"Error Message for null Preferred country field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
        }
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Relocation Expectation.", @"Error Message for null relocation expectation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(void)saveFieldValuesToUserDefaults{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *savedDataDict=[[defaults dictionaryForKey:[CLCommon sharedInstance].userName] mutableCopy];
    
    if (self.selectedCurrentLocation) {
        [savedDataDict setObject:self.selectedCurrentLocation forKey:kCLUserDefaultsProfileLocationHomeLoc];
    }
    
    if (self.selectedRelocationOption) {
        [savedDataDict setObject:self.selectedRelocationOption  forKey:kCLUserDefaultsProfileLocationRelocOption];
    }
    
    if (self.selectedSameCountryLocations) {
        [savedDataDict setObject:self.selectedSameCountryLocations forKey:kCLUserDefaultsProfileLocationRelocSameLoc];
    }
    
    if (self.selectedOtherCountryLocations) {
        [savedDataDict setObject:self.selectedOtherCountryLocations forKey:kCLUserDefaultsProfileLocationRelocOtherCountry];
    }
    
    [defaults setObject:savedDataDict forKey:[CLCommon sharedInstance].userName];
    
    [defaults synchronize];
}

-(void)loadValuesFromUserDefaults{
    NSDictionary *savedDataDict=[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName];
    
    self.selectedCurrentLocation=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationHomeLoc] mutableCopy];
    self.selectedRelocationOption=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationRelocOption] mutableCopy];
    self.selectedSameCountryLocations=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationRelocSameLoc] mutableCopy];
    self.selectedOtherCountryLocations=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationRelocOtherCountry] mutableCopy];
}

#pragma mark - IBActions

-(IBAction)bttnActionGotoNextPage:(id)sender{
    if([self isFieldsValid]){
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while loading jobs");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [progressHUD showInView:self.view];
        self.navigationItem.leftBarButtonItem.enabled = NO;
        self.navigationItem.rightBarButtonItem.enabled = NO;
        [CLCRFObject submitCRFFourForUser:[CLUserObject currentUser].email withCRFOneObj:[self creatDictForSubmit] success:^(){
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.leftBarButtonItem.enabled = YES;
            self.navigationItem.rightBarButtonItem.enabled = YES;
            CLStatusViewController *statusScreen=[[CLStatusViewController alloc] initWithNibName:@"CLStatusViewController" bundle:[NSBundle mainBundle]];
            statusScreen.isFromWelcomeScreen=YES;
            [self.navigationController pushViewController:statusScreen animated:YES];

        }failure:^(NSString *error){
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.leftBarButtonItem.enabled = YES;
            self.navigationItem.rightBarButtonItem.enabled = YES;
            [CLCommon showAlertwithTitle:nil alertString:error cancelbuttonName:@"OK"];
        }];
        
        
//        CLSalutationViewController *salutaionsView=[[CLSalutationViewController alloc] initWithNibName:@"CLSalutationViewController" bundle:[NSBundle mainBundle]];
//        [self.navigationController pushViewController:salutaionsView animated:YES];
    }
}

//- (IBAction)bttnActionKeyboardDone:(id)sender{
//    CLSimpleTextCell *cell=[self getCellForFirstResponder];
//    self.selectedRelocationOption=[self.relocationOptionsArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
//    [cell setCellText:[[self.relocationOptionsArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kRelocationOptionTitleKey]];
//    [self.tableView reloadData];
//    if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]!=RelocationOptionsNotMove){
//        [self.tableView setAllowsSelectionDuringEditing:YES];
//        if ([self.selectedSameCountryLocations count]>0 || [self.selectedOtherCountryLocations count]>0) {
//            [self.tableView setEditing:YES animated:YES];
//        }
//    }
//}

-(NSMutableDictionary*)creatDictForSubmit{
    NSMutableDictionary * mainDIct = [[NSMutableDictionary alloc]init];
    
    NSMutableDictionary *careerlineDict = [[NSMutableDictionary alloc]init];
    
    NSMutableDictionary *relocSub = [[NSMutableDictionary alloc]init];
    for (NSDictionary *dict in [[self.selectedRelocationOption objectForKey:@"RelocationOption"] objectForKey:@"WithinCountry"]) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"checked"]] isEqualToString:@"1"]) {
            [relocSub setObject:[dict objectForKey:@"id"] forKey:@"1"];
        }
    }
    
    for (NSDictionary *dict in [[self.selectedRelocationOption objectForKey:@"RelocationOption"] objectForKey:@"OutsideCountry"]) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"checked"]] isEqualToString:@"1"]) {
            [relocSub setObject:[dict objectForKey:@"id"] forKey:@"2"];
        }
    }
    [careerlineDict setObject:relocSub forKey:@"reloc_sub_exp"];
    
    NSMutableDictionary *countryStructure = [[NSMutableDictionary alloc]init];
    
    NSMutableDictionary *level6 = [[NSMutableDictionary alloc]init];
    
    NSString *string = @"";
    
    for (NSDictionary *dict in [[[[self.selectedRelocationOption objectForKey:@"RelocationOption"] objectForKey:@"WithinCountry"] objectAtIndex:2] objectForKey:@"townVillages"]) {
        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"id"]]];
    }
    [level6 setObject:string forKey:@"0"];
    if (string.length>0) {
        [level6 setObject:@"TV" forKey:@"type"];
    }
    else{
        [level6 setObject:@"" forKey:@"type"];
    }
    
    [countryStructure setObject:level6 forKey:@"Level6"];
    
    NSMutableDictionary *jobLocation = [[NSMutableDictionary alloc]init];
    
    NSString *countryString = @"";
    for (NSDictionary *dict in [[[[self.selectedRelocationOption objectForKey:@"RelocationOption"] objectForKey:@"OutsideCountry"] objectAtIndex:1]objectForKey:@"country"]) {
        countryString = [countryString stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"id"]]];
    }
    
    NSString *locString = @"";
    for (NSDictionary *dict in [[[[self.selectedRelocationOption objectForKey:@"RelocationOption"] objectForKey:@"OutsideCountry"] objectAtIndex:1]objectForKey:@"locations"]) {
        locString = [locString stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"id"]]];
    }
    [jobLocation setObject:countryString forKey:@"cl_job_country"];
    [jobLocation setObject:locString forKey:@"cl_job_locs"];
    [mainDIct setObject:careerlineDict forKey:@"careerline"];
    [mainDIct setObject:countryStructure forKey:@"countryStructure"];
    [mainDIct setObject:jobLocation forKey:@"JobLocation"];
    [CLCommon jsonStringWithPrettyPrint:YES foDict:mainDIct];
    return mainDIct;
}

- (IBAction)bttnActionKeyboardCancel:(id)sender{
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionAddWithinSameCountry:(id)sender {
    if (self.selectedCurrentLocation) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingTypeSameCountry;
        selectLocation.selectedLocations=self.selectedSameCountryLocations;
        selectLocation.countryCodeforListing=[self.selectedCurrentLocation objectForKey:kLocationCountryCode];
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select where do you live and try again.", @"Error msg shown when home location not selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert cancel button title")];
    }
}

- (IBAction)bttnActionAddOtherCountry:(id)sender {
    if (self.selectedCurrentLocation) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingTypeOtherCountries;
        selectLocation.selectedLocations=self.selectedOtherCountryLocations;
        selectLocation.countryCodeforListing=[self.selectedCurrentLocation objectForKey:kLocationCountryCode];
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select where do you live and try again.", @"Error msg shown when home location not selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert cancel button title")];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
//    if(self.selectedRelocationOption){
//        if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsNotMove){
//            return 2;
//        }
//        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry){
//            return 3;
//        }
//        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry){
//            return 4;
//        }
//    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    if(self.selectedRelocationOption){
//        if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsNotMove){
//            return 1;
//        }
//        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry){
//            if (section==2) {
//                if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry) {
//                    return [self.selectedOtherCountryLocations count];
//                }
//                else{
//                    return [self.selectedSameCountryLocations count];
//                }
//            }
//        }
//        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry){
//            if (section==2) {
//                return [self.selectedSameCountryLocations count];
//            }
//            else if (section==3){
//                return [self.selectedOtherCountryLocations count];
//            }
//        }
//        else{
//            return 2;
//        }
//    }
    if (section == 0) {
        return 2;
    }
    else{
        return 2;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section==TableSectionIndexCurrentLocation) {
        CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentLocationCellIdentifier"];
        [currLoccell setPlaceHoldrText:NSLocalizedString(@"Where Do You Live?", @"Placeholder for Where do you live field in profile")];
        currLoccell.delegate=self;
        if (self.selectedCurrentLocation) {
            [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]]];
        }
        else{
            [currLoccell setCellText:@""];
        }
        [currLoccell setCellIndexPath:indexPath];
        return currLoccell;
    }
    else if (indexPath.section==TableSectionIndexRelocationOption) {
//        CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"relocationOptionCellIdentifier"];
//        [cell setTextInputView:self.pickerView];
//        [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
//        [cell setPlaceHoldrText:NSLocalizedString(@"Relocation Expectation", @"Placeholder for employment status field in profile")];
//        if (!self.selectedRelocationOption) {
//            [cell setCellText:@""];
//        }
//        else{
//            [cell setCellText:[self.selectedRelocationOption objectForKey:kRelocationOptionTitleKey]];
//        }
//        [cell setCellIndexPath:indexPath];
//        cell.delegate=self;
//        return cell;
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"relocationCellIdentifier"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"relocationCellIdentifier"];
        }
        if ([CLCommon isOSversionLessThan8]) {
             [cell setSeparatorInset:UIEdgeInsetsMake(0, 0, 0, self.tableView.bounds .size.width)];
        }else{
             [cell setSeparatorInset:UIEdgeInsetsMake(0, 0, 0, self.tableView.bounds .size.width-15)];
        }
       
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.numberOfLines = 0;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (self.selectedRelocationOption) {
            if (indexPath.row == 0) {
                cell.textLabel.text = @"Within Country";
                cell.textLabel.textColor = ColorCode_CareerLineGreen;
                cell.detailTextLabel.text = [self textForCellLabel:indexPath];;
            }
            else{
                cell.textLabel.text = @"Outside Country";
                cell.textLabel.textColor = ColorCode_CareerLineGreen;
                cell.detailTextLabel.text = [self textForCellLabel:indexPath];
            }
        }
        else{
            if (indexPath.row == 0) {
                cell.textLabel.text = @"Within Country";
                cell.textLabel.textColor = ColorCode_CareerLineGreen;
                cell.detailTextLabel.text = @"";
            } else{
                cell.textLabel.text = @"Outside Country";
                cell.textLabel.textColor = ColorCode_CareerLineGreen;
                cell.detailTextLabel.text = @"";
            }
            
        }
        return cell;
    }
    else{
        if (indexPath.section==2) {
            if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry) {
                static NSString *CellIdentifier = @"moveSameCountryCellIdentifier";
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
                    cell.selectionStyle=UITableViewCellSelectionStyleNone;
                }
                
                cell.textLabel.text=[[self.selectedSameCountryLocations objectAtIndex:indexPath.row] objectForKey:kLocationName];
                
                return cell;
            }
            else if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry) {
                static NSString *CellIdentifier = @"moveDifferentCountryCellIdentifier";
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
                    cell.selectionStyle=UITableViewCellSelectionStyleNone;
                }
                
                cell.textLabel.text=[[self.selectedOtherCountryLocations objectAtIndex:indexPath.row] objectForKey:kLocationCountryName];
                
                return cell;
            }
        }
        else if (indexPath.section==3){
            static NSString *CellIdentifier = @"moveDifferentCountryCellIdentifier";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
            }
            
            cell.textLabel.text=[[self.selectedOtherCountryLocations objectAtIndex:indexPath.row] objectForKey:kLocationCountryName];
            
            return cell;
        }
        return nil;
    }
}

-(NSString*)textForCellLabel:(NSIndexPath*)indexPath{
    NSString *string;
    if (indexPath.row == 0) {
        NSArray *outsideCountryArray = [[NSArray alloc]initWithArray:[[self.selectedRelocationOption objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationWithinCountry]];
        for (NSMutableDictionary *dict in outsideCountryArray) {
            if ([[dict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                string = [dict objectForKey:kClRelocationBoolValueKey];
                return string;
            }
        }
    } else{
        NSArray *outsideCountryArray = [[NSArray alloc]initWithArray:[[self.selectedRelocationOption objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]];
        for (NSMutableDictionary *dict in outsideCountryArray) {
            if ([[dict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                string = [dict objectForKey:kClRelocationBoolValueKey];
                return string;
            }
        }
    }
    return @"";
}


#pragma mark - Table view delegate

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (indexPath.section==0) {
            CLRelocationViewController *relocController = [[CLRelocationViewController alloc]initWithNibName:@"CLRelocationViewController" bundle:[NSBundle mainBundle]];
            [relocController setFromTwentyField:YES];
            relocController.delegate = self;
            if (self.selectedRelocationOption) {
                CLRelocationObject *obj = [[CLRelocationObject alloc]initWithDictionary:self.selectedRelocationOption];
                [relocController setRelocObj:obj];
            }
            [relocController setCurrentLocationDictionary:self.selectedCurrentLocation];
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:relocController];
            [self.navigationController presentViewController:nav animated:YES completion:nil];
        }
        
    });
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 60;
    }
    else{
        return 44;
    }
}

//- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
////    if (indexPath.section>TableSectionIndexRelocationOption) {
////        return YES;
////    }
//    return NO;
//}

// Override to support editing the table view.
//- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        
//        if (indexPath.section==2) {
//            if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry) {
//                [self.selectedSameCountryLocations removeObjectAtIndex:indexPath.row];
//                if(indexPath.row==0 && [self.selectedSameCountryLocations count]==0){
//                    [self.tableView reloadData];
//                }
//                else{
//                    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//                }
//            }
//            else if([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry) {
//                [self.selectedOtherCountryLocations removeObjectAtIndex:indexPath.row];
//                if(indexPath.row==0 && [self.selectedOtherCountryLocations count]==0){
//                    [self.tableView reloadData];
//                }
//                else{
//                    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//                }
//            }
//        }
//        else if (indexPath.section==3){
//            [self.selectedOtherCountryLocations removeObjectAtIndex:indexPath.row];
//            if(indexPath.row==0 && [self.selectedOtherCountryLocations count]==0){
//                [self.tableView reloadData];
//            }
//            else{
//                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//            }
//        }
//    }
//}


-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section==TableSectionIndexCurrentLocation){
        return NSLocalizedString(@"Where do you live?", @"Title for current location");
    }
    else if (section==TableSectionIndexRelocationOption){
        return NSLocalizedString(@"Willing to Work Locations:", @"Title for RELOCATION EXPECTATION");
    }
    else if (section==2){
        if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry) {
            return NSLocalizedString(@"Preffered Location", @"Title for same country");
        }
        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry){
            return NSLocalizedString(@"Preffered Other country", @"Title for other country");
        }
    }
    else if (section==3){
        return NSLocalizedString(@"Preffered Country", @"Title for other country");
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if(section==2){
        if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameCountry || [[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsSameOrOtherCountry) {
            return self.tblFooterSameCountry;
        }
        else if ([[self.selectedRelocationOption objectForKey:kRelocationOptionIdKey] intValue]==RelocationOptionsOtherCountry){
            return self.tblFooterOtherCountry;
        }
    }
    else if (section==3){
        return self.tblFooterOtherCountry;
    }
    return nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section==2 || section==3){
        return 44;
    }
    return 0;
}

#pragma mark UIPickerView Methods

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [self.relocationOptionsArray count];
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// tell the picker the title for a given component
//- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
//    return [[self.relocationOptionsArray objectAtIndex:row] objectForKey:kRelocationOptionTitleKey];
//}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = ColorCode_CareerLineGreen;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:16];
    label.text=[[self.relocationOptionsArray objectAtIndex:row] objectForKey:kRelocationOptionTitleKey];
    return label;
}

-(void)initCRFFour{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    [CLCRFObject getCRFFOURDetailsForUser:[CLUserObject currentUser].email success:^(NSDictionary *FOURobj,NSMutableDictionary*currentLocationDIct){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.leftBarButtonItem.enabled = YES;
        self.navigationItem.rightBarButtonItem.enabled = YES;
//        self.relocObj = FOURobj;
        self.selectedCurrentLocation = currentLocationDIct;
        self.selectedRelocationOption = [FOURobj mutableCopy];
        [self.tableView reloadData];
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.leftBarButtonItem.enabled = YES;
        self.navigationItem.rightBarButtonItem.enabled = YES;
        [CLCommon showAlertwithTitle:nil alertString:error cancelbuttonName:@"OK"];
    }];
    
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[UIColor blackColor];
    self.activityIndicator.hudView.alpha=0.9;
}

@end
