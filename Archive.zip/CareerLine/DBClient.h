//
//  DBClient.h
//  CareerLine
//
//  Created by CSG on 2/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBClient : NSObject

////To get all the nationalities from DB except those contained in blackListString..
//+(NSMutableArray*)getAllNationalityListFromDBnotIn:(NSString*)blackListString;

//get country code for given country;

//+(NSString*)getCountryCodeForCountry :(NSString*)country;

//isd code for current location

//+(NSString*)getISDOfCurrentCountry:(NSString*)cyCode;

//To get the nationalities based on the searchString from DB except those contained in blackListString..
//+(NSMutableArray *)getNationalityListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//+(NSMutableArray*)getAllEducationListFromDBForCountry:(NSString*)cyCode;

//To get all the Career move Reasons
//+(NSMutableArray*)getAllCareerMoveListFromDB;

//To get all the ISD Code..
//+(NSMutableArray*)getAllISDCodeFromDB;

//To get all the gender list..
//+(NSMutableArray*)getAllGenderListFromDB;

//To get all the Employment status..
//+(NSMutableArray*)getAllEmpStatusFromDB;

//To get all the Employment type..
//+(NSMutableArray*)getAllEmpTypeFromDB;

//To get all the Employment contract type..
//+(NSMutableArray*)getAllEmpContractTypeFromDB;

//To get all the Employment job scope type..
//+(NSMutableArray*)getAllEmpJobScopeFromDB:(NSString*)countryCode;

//+(NSMutableArray*)getJoScopeGroupedForSector:(NSMutableDictionary*)sectorDict;

////To get the groupName
//+(NSString*)getIndustryGroupNamefrom:(NSString*)groupCode;

//to get sectionName

//+(NSString*)getIndustrySectionNameFrom:(NSString*)sectionCode;

//get nationality from countrycode

//+(NSMutableDictionary*)getNationalityFromCountryCode :(NSString*)cyCode;

//To get all the job level group..
//+(NSMutableArray*)getAllJobLevelGroupFromDB;

////To get all the job level detail group..
//+(NSMutableArray*)getAllJobLevelDetailForJobGroup:(NSDictionary*)jobGroup;

////To get all the job Function category ..
//+(NSMutableArray*)getAllJobFunctionsCategory;

////To get all the job Functions..
//+(NSMutableArray*)getAllJobFunctionsForCategory:(NSString*)catId notIn:(NSString*)blackListString;

//To get all the currency..
//+(NSMutableArray*)getAllCountryDetailsForCurrency:(NSString*)string;

////To get the JobFunctions based on the searchString from DB..
//+(NSMutableArray *)getJobFunctionsForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//To get all the Industry sectors..
//+(NSMutableArray*)getAllIndustrySectorsFromDB:(id)sender notIn:(NSString *)blackListString;

////To get all the Industries..
//+(NSMutableArray*)getAllIndustriesFromDBnotIn:(NSString*)blackListString;
//
//To get all the Industries grouped for sectors..
//+(NSMutableArray*)getIndustriesGroupedForSector:(NSMutableDictionary*)sectorDict;

//To get final industries list for the group selected..
//+(NSMutableArray*)getMainIndustriesListForGroup:(NSMutableDictionary*)groupDict notIn:(NSString*)blackListString;

////To get final industries list based on the keyword..
//+(NSMutableArray*)getMainIndustriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//To get all locations..
//+(NSMutableArray*)getAllLocationsFromDB;

//To get all locations for country code..
//+(NSMutableArray*)getAllLocationsForCountryCode:(NSString*)code notIn:(NSString*)blackListString;

//To get all locations for search string..
//+(NSMutableArray*)getLocationsForSearchString:(NSString*)keyword;

//To get all locations for country code and searchString..
//+(NSMutableArray*)getLocationsForCountryCode:(NSString*)code andSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//To get all the Countries from DB except those contained in blackListString..
//+(NSMutableArray*)getAllCountriesListFromDBnotIn:(NSString*)blackListString;

//To get the Countries based on the searchString from DB except those contained in blackListString..
//+(NSMutableArray *)getCountriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//get the salutation list..
//+(NSMutableArray *)getSalutationsListforNationality:(NSMutableString*)nationalityString;



//To get all employeement group
//+(NSMutableArray*)getAllEmpTypeGroupFromDB;

//To get all employeement group details
//+(NSMutableArray*)getAllEmpTypeDetailForGroup:(NSDictionary *)empTypeGroup;

//To get all benefits list
//+(NSMutableArray*)getAllBenefitsListFromDB;

//To get all frequency list
//+(NSMutableArray*)getAllFrequencyListFromDB;

//To get all allowance and loading list
//+(NSMutableArray*)getAllowanceAndLoadingListFromDB;

//To get all Incentive and bonus list
//+(NSMutableArray*)getIncentiveBonusListFromDB;
@end

