 //
//  CLIndustrySectorViewController.m
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLIndustrySectorViewController.h"
#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLIndustrySectorViewController ()
@property(nonatomic,strong) NSMutableArray * industrySectorArray;
@property(nonatomic,strong) NSString *blackListString;

@end

@implementation CLIndustrySectorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=NSLocalizedString(@"Industries", @"Select Industries page title");
    [self setRightNavigationButton];
    
    self.detailsArray = [[NSMutableArray alloc]init];
    
    if ([self.alreadySelectedIndustries count]>0)
    {
        NSMutableString *string=[[NSMutableString alloc] init];
        
        for (NSMutableDictionary *dict in self.alreadySelectedIndustries)
        {
            if ([[dict objectForKey:@"IndSect"] count])
            {
                NSMutableArray *result = [[dict valueForKeyPath:@"IndSect"] mutableCopy];
                [self.detailsArray addObjectsFromArray:result];
            }
            if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
            {
                NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsNewindustry] mutableCopy];
                [self.detailsArray addObjectsFromArray:result];
            }
            if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
            {
                NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsMainindustry]mutableCopy];
                
//                for(NSMutableDictionary *dict in result)
//                {
//                    [dict removeObjectForKey:kCLTargetJobsindustryGroupNameKey];
//                    [self.detailsArray addObject:dict];
//                }
                [self.detailsArray addObjectsFromArray:result];
                
                for (NSMutableDictionary *dict in result)
                {
                    if ([[dict objectForKey:kIndustryDictName] isEqualToString:@""] && ![[dict objectForKey:kIndGrpOtherFlag] boolValue])
                    {
                        [string appendString:[NSString stringWithFormat:@"%@,",[dict objectForKey:kIndSectDictCode]]];
                    }
                }
            }
            if ([[dict objectForKey:@"OtherIndustry"] count])
            {
                NSMutableArray *result = [[dict valueForKeyPath:@"OtherIndustry"]mutableCopy];
                [self.detailsArray addObjectsFromArray:result];
                
                for (NSMutableDictionary *dict in result)
                {
                    //[string appendString:[NSString stringWithFormat:@"Other - %@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
                    
                    if ([[dict objectForKey:kIndustryDictName] isEqualToString:@""] && ![[dict objectForKey:kIndGrpOtherFlag] boolValue])
                    {
                        [string appendString:[NSString stringWithFormat:@"%@,",[dict objectForKey:kIndSectDictCode]]];
                    }
                }
            }

        }

//        for (int i=0; i<[self.alreadySelectedIndustries count]; i++)
//        {
//            if ([[[self.alreadySelectedIndustries objectAtIndex:i] objectForKey:kIndustryDictName] isEqualToString:@""] && ![[[self.alreadySelectedIndustries objectAtIndex:i] objectForKey:kIndGrpOtherFlag] boolValue]) {
//                [string appendString:[NSString stringWithFormat:@"%@,",[[self.alreadySelectedIndustries objectAtIndex:i] objectForKey:kIndSectDictCode]]];
//            }
//        }
        if (![string isEqualToString:@""])
        {
            [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        }
        self.blackListString=string;
    }
    else
    {
        self.blackListString=@"";
    }
    
    self.industrySectorArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllIndustrySectorsFromDB:nil notIn:self.blackListString];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.alreadySelectedIndustries count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}
#pragma mark Utility Methods

-(void)setRightNavigationButton
{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
}
#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [self.tableView setEditing:NO animated:NO];
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
  
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSInteger retValue = 1;
    
    if ([self.alreadySelectedIndustries count]>0)
    {
        for (NSMutableDictionary *dict in self.alreadySelectedIndustries)
        {
            if ([[dict objectForKey:kCLTargetJobsNewindustry] count] || [[dict objectForKey:kCLTargetJobsMainindustry] count] || [[dict objectForKey:@"OtherIndustry"] count] || [[dict objectForKey:@"IndSect"] count])
                retValue = 2;
        }
    }else
    {
        retValue = 1;
    }
            
    return retValue;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger retValue = 0;
    
    if([self.alreadySelectedIndustries count]>0)
    {
        if(section==0)
        {
            for (NSMutableDictionary *dict in self.alreadySelectedIndustries)
            {
                if ([[dict objectForKey:kCLTargetJobsNewindustry] count] || [[dict objectForKey:kCLTargetJobsMainindustry] count] || [[dict objectForKey:@"OtherIndustry"] count] || [[dict objectForKey:@"IndSect"] count])
                {
                        return [self.detailsArray count];
                }
                else
                    return [self.industrySectorArray count];
            }
        }
        else
        {
            return [self.industrySectorArray count];
        }
    }
    else
    {
        retValue = [self.industrySectorArray count];
    }
    return retValue;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([self.detailsArray count]>0)
    {
        if(indexPath.section==0)
        {
            static NSString *CellIdentifier = @"CellSelectedIndustryIdentifier";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
                [cell.textLabel setTextColor:ColorCode_CareerLineGreen];
                [cell.textLabel setNumberOfLines:1];
            }
            
            cell.textLabel.text= [self industryText:[self.detailsArray objectAtIndex:indexPath.row]];
           
//            if ([[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndOtherFlag] boolValue]  || [[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndGrpOtherFlag] boolValue] ) {
//                NSLog(@"%@",self.alreadySelectedIndustries);
//                if ([[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndOtherFlag] boolValue]) {
//                    cell.textLabel.text= [self industryText:[self.alreadySelectedIndustries objectAtIndex:indexPath.row]];    //[NSString stringWithFormat:@"(%@) ",[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryDictName]];
//                }else{
//                    cell.textLabel.text=[NSString stringWithFormat:@"%@ ",[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryGrpDictName]];
//                }
//            }
//            else{
//                
//                if ([[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryDictName] isEqualToString:@""]) {
//                    
//                    cell.textLabel.text=[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndSectDictName];
//                    
//                }else if([[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryDictName] ==nil && ![[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryGrpDictName] isEqualToString:@""]){
//                     cell.textLabel.text=[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryGrpDictName];
//                }else{
//                     cell.textLabel.text=[[self.alreadySelectedIndustries objectAtIndex:indexPath.row] objectForKey:kIndustryDictName];
//                }
//               
//            }
            
            return cell;
        }
    }
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
            [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
            [cell.textLabel setNumberOfLines:1];
        }
        
        NSMutableDictionary *industrySectorGroup=[self.industrySectorArray objectAtIndex:indexPath.row];
        cell.textLabel.text=[industrySectorGroup objectForKey:kIndSectDictName];
        
        return cell;
   
}

-(NSString*)industryText:(NSMutableDictionary*)dictionary
{
    NSString *string = [[NSString alloc]init];

    NSString *theValue = [dictionary objectForKey:kCLTargetJobsindustryGroupNameKey];
    NSString *indusValue = [dictionary objectForKey:@"industry"];
    NSInteger isOtherVal = [[dictionary objectForKey:@"industryOther"]integerValue];
    
    if (theValue.length)
    {
        if(isOtherVal == 1)
            string = [string stringByAppendingString:[NSString stringWithFormat:@"Other - %@(%@)|",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey],[dictionary objectForKey:kCLTargetJobsindustry]]];
        else if(indusValue.length == 0)
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey]]];
        else
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey], indusValue]];
    }
    else
    {
        //otherINside
        if (![[dictionary objectForKey:kCLTargetJobsIndustryKey] isEqualToString:@""] && [[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] ) {
         string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey],[dictionary objectForKey:kCLTargetJobsIndustryKey]];
         }
         //saved outside other
         else if ([[dictionary objectForKey:kCLTargetJobsIndustryKey]isEqualToString:@""] && ![[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
         string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustrySectName],[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey]];
         }
         //simpleSelected
         else if ([dictionary objectForKey:kCLTargetJobsIndustryAll] == nil && [dictionary objectForKey:kCLTargetJobsIndustryGrpOther] == nil && [dictionary objectForKey:kCLTargetJobsindustrySectCode] == nil && [dictionary objectForKey:kCLTargetJobsindustrySectName] == nil) {
         if ([dictionary objectForKey:kCLJobPreferenceIndustryKey] == [NSNull null]) {
         string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey], [dictionary objectForKey:kCLJobPreferenceIndustryKey]];
         }
         else{
         string = [NSString stringWithFormat:@"Other - %@",[dictionary objectForKey:@"industry"]];
         }
         }
         //sectionOther
         else if ([dictionary objectForKey:kCLTargetJobsIndustryAll] == nil && [[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue] && [dictionary objectForKey:kCLTargetJobsindustrySectCode] != nil && [dictionary objectForKey:kCLTargetJobsindustrySectName] != nil){
         string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustrySectName], [dictionary objectForKey:kCLTargetJobsindustryGroupNameKey]];
         }
         //all section selected
         else if ([[dictionary objectForKey:kCLTargetJobsIndustryAll]boolValue] && ![[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] && ![[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
         string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLTargetJobsindustrySectName]];
         }
        //all group
        else if (![[dictionary objectForKey:@"industrySectName"] isEqualToString:@""] && [[dictionary objectForKey:kCLTargetJobsIndustryKey] isEqualToString:@""]){
            string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:@"industrySectName"]];
        }
         //main
         else{
         string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLTargetJobsIndustryKey]];
         }

    }
    
  /*  if ([[dictionary objectForKey:kCLTargetJobsNewindustry] count])
    {
        NSArray *result = [dictionary valueForKeyPath:kCLTargetJobsNewindustry];
        
        for (NSMutableDictionary *dict in result)
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
        }
    }
    if ([[dictionary objectForKey:kCLTargetJobsMainindustry] count])
    {
        NSArray *result = [dictionary valueForKeyPath:kCLTargetJobsMainindustry];
        
        for (NSMutableDictionary *dict in result)
        {
            //otherINside
            if (![[dict objectForKey:kCLTargetJobsindustry] isEqualToString:@""] && [[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] ) {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
            }
            else if ([[dict objectForKey:kCLTargetJobsindustry]isEqualToString:@""] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName],[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
            }
            //simpleSelected
            else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [dict objectForKey:kCLTargetJobsIndustryGrpOther] == nil && [dict objectForKey:kCLTargetJobsindustrySectCode] == nil && [dict objectForKey:kCLTargetJobsindustrySectName] == nil) {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
            }
            //sectionOther
            else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue] && [dict objectForKey:kCLTargetJobsindustrySectCode] != nil && [dict objectForKey:kCLTargetJobsindustrySectName] != nil){
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName], [dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
            }
            
            else if ([[dict objectForKey:kCLTargetJobsIndustryAll]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustrySectName]]];
            }
            //main
            else{
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
            }
            
        }
    }*/

//    if (![[dictionary objectForKey:@"industry"] isEqualToString:@""] && [[dictionary objectForKey:@"industryOther"]boolValue]) {
//        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:@"industryGroupName"], [dictionary objectForKey:@"industry"]];
//    }
//    else if ([[dictionary objectForKey:@"industry"]isEqualToString:@""] && ![[dictionary objectForKey:@"industryOther"]boolValue]){
//        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:@"industrySectName"], [dictionary objectForKey:@"industryGroupName"]];
//    }
//    
//    else if ([dictionary objectForKey:@"industryAll"] == nil){
//        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:@"industrySectName"], [dictionary objectForKey:@"industryGroupName"]];
//    }
//    
//    else{
//        string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:@"industry"]];
//    }
    
    //otherINside
/*    if (![[dictionary objectForKey:kCLTargetJobsIndustryKey] isEqualToString:@""] && [[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] ) {
        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey],[dictionary objectForKey:kCLTargetJobsIndustryKey]];
    }
    //saved outside other
    else if ([[dictionary objectForKey:kCLTargetJobsIndustryKey]isEqualToString:@""] && ![[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustrySectName],[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey]];
    }
    //simpleSelected
    else if ([dictionary objectForKey:kCLTargetJobsIndustryAll] == nil && [dictionary objectForKey:kCLTargetJobsIndustryGrpOther] == nil && [dictionary objectForKey:kCLTargetJobsindustrySectCode] == nil && [dictionary objectForKey:kCLTargetJobsindustrySectName] == nil) {
        if ([dictionary objectForKey:kCLJobPreferenceIndustryKey] == [NSNull null]) {
            string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey], [dictionary objectForKey:kCLJobPreferenceIndustryKey]];
        }
        else{
            string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustryGroupNameKey], [dictionary objectForKey:@"industry"]];
        }
    }
    //sectionOther
    else if ([dictionary objectForKey:kCLTargetJobsIndustryAll] == nil && [[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue] && [dictionary objectForKey:kCLTargetJobsindustrySectCode] != nil && [dictionary objectForKey:kCLTargetJobsindustrySectName] != nil){
        string = [NSString stringWithFormat:@"%@(%@)",[dictionary objectForKey:kCLTargetJobsindustrySectName], [dictionary objectForKey:kCLTargetJobsindustryGroupNameKey]];
    }
    //all section selected
    else if ([[dictionary objectForKey:kCLTargetJobsIndustryAll]boolValue] && ![[dictionary objectForKey:kCLTargetJobsIndustryOther]boolValue] && ![[dictionary objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
        string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLTargetJobsindustrySectName]];
    }
    //main
    else{
        string = [NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLTargetJobsIndustryKey]];
    }*/
    return string;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell.isEditing == YES)
    {
    }
    else
    {
        if([self.alreadySelectedIndustries count]>0)
        {
            if(indexPath.section==1){
                CLIndustryGroupViewController *detailViewController = [[CLIndustryGroupViewController alloc] initWithNibName:@"CLIndustryGroupViewController" bundle:[NSBundle mainBundle]];
                 detailViewController.delegate=(id<CLSelectOtherIndustryGroup>)self.delegate;
                detailViewController.selectedIndustrySectorDict=[self.industrySectorArray objectAtIndex:indexPath.row];
                detailViewController.singleSelection=self.singleSelection;
                detailViewController.enableSelectAll=self.enableSelectAll;
                detailViewController.alrdySelectedindustries=self.alreadySelectedIndustries;
                [self.navigationController pushViewController:detailViewController animated:YES];
            }
            else if(indexPath.section==0){
                CLIndustryGroupViewController *detailViewController = [[CLIndustryGroupViewController alloc] initWithNibName:@"CLIndustryGroupViewController" bundle:[NSBundle mainBundle]];
                detailViewController.delegate=(id<CLSelectOtherIndustryGroup>)self.delegate;
                detailViewController.selectedIndustrySectorDict=[self.industrySectorArray objectAtIndex:indexPath.row];
                detailViewController.singleSelection=self.singleSelection;
                detailViewController.enableSelectAll=self.enableSelectAll;
                detailViewController.alrdySelectedindustries=self.alreadySelectedIndustries;
                [self.navigationController pushViewController:detailViewController animated:YES];
            }
        }
        else{
            CLIndustryGroupViewController *detailViewController = [[CLIndustryGroupViewController alloc] initWithNibName:@"CLIndustryGroupViewController" bundle:[NSBundle mainBundle]];
            detailViewController.delegate=(id<CLSelectOtherIndustryGroup>)self.delegate;
            detailViewController.selectedIndustrySectorDict=[self.industrySectorArray objectAtIndex:indexPath.row];
            detailViewController.singleSelection=self.singleSelection;
            detailViewController.enableSelectAll=self.enableSelectAll;
           detailViewController.alrdySelectedindustries=self.alreadySelectedIndustries;
            [self.navigationController pushViewController:detailViewController animated:YES];
        }
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if([self.alreadySelectedIndustries count]>0){
        if(section==0){
            return NSLocalizedString(@"EDIT INDUSTRY", @"Title for EDIT INDUSTRY");
        }
        else{
            return NSLocalizedString(@"ADD INDUSTRY", @"Title for ADD INDUSTRY");
        }
    }
    else{
        return NSLocalizedString(@"JOB INDUSTRY", @"Title for OTHER INDUSTRY");
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if([self.detailsArray count]>0){
        if(indexPath.section==0){
            return YES;
        }
        else{
            return NO;
        }
    }
    else{
       return NO;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        NSMutableArray *theArray = [self.selectedIndustryArray mutableCopy];
        NSMutableArray *industryArray = [self.alreadySelectedIndustries mutableCopy];
        
        NSString *indGrpCode = [[self.detailsArray objectAtIndex:indexPath.row]objectForKey:kCLTargetJobsIndustryGroupCode];
        NSString *indSectCode = [[self.detailsArray objectAtIndex:indexPath.row]objectForKey:kCLTargetJobsindustrySectCode];
        NSString *indCode = [[self.detailsArray objectAtIndex:indexPath.row]objectForKey:@"industryCode"];
        
        NSInteger index = 0;
        
        for (NSMutableDictionary *dict in self.selectedIndustryArray)
        {
            if ([[dict objectForKey:kCLTargetJobsIndustryGroupCode] isEqualToString:indGrpCode])
            {
                if(indCode.length)
                {
                    if ([[dict objectForKey:@"industryCode"] isEqualToString:indCode])
                        [theArray removeObject:dict];
                }
                else
                    [theArray removeObject:dict];
                
                index++;
            }
            else
            {
                if(indSectCode.length)
                {
                    if ([[dict objectForKey:@"industrySectCode"] isEqualToString:indSectCode])
                        [theArray removeObject:dict];
                }
            }
        }
        
        [self.selectedIndustryArray removeAllObjects];
        self.selectedIndustryArray = [theArray mutableCopy];
        
            for (NSMutableDictionary *dict in self.alreadySelectedIndustries)
            {
                 if(indCode.length == 0)
                 {
                    if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
                    {
                        NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsNewindustry]mutableCopy];

                        for (NSMutableDictionary *dict in result)
                        {
                            if ([[dict objectForKey:kCLTargetJobsIndustryGroupCode] isEqualToString:indGrpCode])
                            {
                                NSMutableArray *newArr = [[[industryArray objectAtIndex:0]objectForKey:kCLTargetJobsNewindustry]mutableCopy];
                                [newArr removeObject:dict];
                                
                                NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict setValue:newArr forKey:kCLTargetJobsNewindustry];
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict];
                                break;
                                
                            }
                        }
                    }
                    else if ([[dict objectForKey:@"IndSect"] count])
                    {
                        NSMutableArray *result = [[dict valueForKeyPath:@"IndSect"]mutableCopy];
                        
                        for (NSMutableDictionary *dict in result)
                        {
                            if ([[dict objectForKey:kCLTargetJobsindustrySectCode] isEqualToString:indSectCode])
                            {
                                NSMutableArray *newArr = [[[industryArray objectAtIndex:0]objectForKey:@"IndSect"]mutableCopy];
                                [newArr removeObject:dict];
                                
                                NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict setValue:newArr forKey:@"IndSect"];
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict];
                                break;
                                
                            }
                        }
                    }

                }
                else
                {
                    if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
                    {
                        NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsMainindustry]mutableCopy];
                        
                        for (NSMutableDictionary *dict in result)
                        {
                            if ([[dict objectForKey:@"industryCode"] isEqualToString:indCode])
                            {
                                NSMutableArray *newArr = [[[industryArray objectAtIndex:0]objectForKey:kCLTargetJobsMainindustry]mutableCopy];
                                [newArr removeObject:dict];
                                
                                NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict setValue:newArr forKey:kCLTargetJobsMainindustry];
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict];
                                break;
                            }
                        }
                    }
                    else
                        if ([[dict objectForKey:@"OtherIndustry"] count])
                        {
                            NSMutableArray *result = [[dict valueForKeyPath:@"OtherIndustry"]mutableCopy];
                            
                            for (NSMutableDictionary *dict in result)
                            {
                                if ([[dict objectForKey:@"industryCode"] isEqualToString:indCode])
                                {
                                    NSMutableArray *newArr = [[[industryArray objectAtIndex:0]objectForKey:@"OtherIndustry"]mutableCopy];
                                    [newArr removeObject:dict];
                                    
                                    NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
                                    [newDict setValue:newArr forKey:@"OtherIndustry"];
                                    [industryArray removeAllObjects];
                                    [industryArray addObject:newDict];
                                    break;
                                }
                            }
                        }
                }
            }

        [self.alreadySelectedIndustries removeAllObjects];
        self.alreadySelectedIndustries = [industryArray mutableCopy];
        
//        if(indexPath.row==0 && [self.detailsArray count]==0)
//        {
//            [self.tableView setEditing:NO animated:NO];
//            [self viewDidLoad];
//            [self.tableView reloadData];
//        }
//        else
//            [self.tableView  reloadData];
        
//            [self.tableView beginUpdates];
//            
//            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//            //[self viewDidLoad];
//            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationAutomatic];
//            
//            [self.tableView endUpdates];
//        }
        
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectIndustryControllerDidDeleteIndustry:withArray: andListArray:)])
        {
            [self.alreadySelectedIndustries removeAllObjects];
            self.alreadySelectedIndustries = [industryArray mutableCopy];
            [self.delegate selectIndustryControllerDidDeleteIndustry:self withArray:industryArray andListArray:self.selectedIndustryArray];
        }
        
        [self.detailsArray removeObjectAtIndex:indexPath.row];
        if(indexPath.row==0 && [self.detailsArray count]==0)
        {
            [self.tableView setEditing:NO animated:NO];
            [self viewDidLoad];
            [self.tableView reloadData];
        }
        else
            [self.tableView  reloadData];

    }
}
@end
