//
//  CLJobScopeViewController.h
//  CareerLine
//
//  Created by Abbin on 04/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "CLJobScopeSelectionViewController.h"

@class CLJobScopeViewController;

@protocol jobScopeDelegate <NSObject>

@optional
-(void)loadSelectedJobScope:(NSMutableArray*)jobScopeDictArray;

@end


@interface CLJobScopeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong) NSMutableArray *selectedJobScopeDictArray;
@property(nonatomic,strong) NSMutableArray *selectedJobScopeDictArrayForEdit;
@property(nonatomic,strong) NSMutableDictionary *selectedJobScopeDictDictForEdit;
@property(nonatomic,strong) NSMutableDictionary *selectedCountry;
@property(nonatomic,weak)id <jobScopeDelegate> delegate;
@property(nonatomic,weak)id <JobScopeSelectionDelegate> delegateTwo;
@property(nonatomic)BOOL singleSelectionOn;

@end
