//
//  CLFrequencyViewController.h
//  CareerLine
//
//  Created by RENJITH on 18/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLFrequencyViewController;
@protocol CLFrequencyDelegate <NSObject>

@optional

- (void)frequencyController:(CLFrequencyViewController *)controller didSelect:(NSMutableDictionary *)selectedDict;

@end

@interface CLFrequencyViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,weak) id <CLFrequencyDelegate> delegate;
@property(nonatomic, retain) NSMutableDictionary *alreadySelectedFrequency;

@end
