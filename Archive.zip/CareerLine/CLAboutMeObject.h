//
//  CLAboutMeObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLInterestObject.h"
#import "CLFileObject.h"
#import "CLInfoObject.h"

@interface CLAboutMeObject : NSObject

@property (nonatomic, strong) CLInfoObject *info;

@property (nonatomic, strong) NSMutableArray *photos;    //[(CLFileObject),(CLFileObject),...]

@property (nonatomic, strong) NSMutableArray *documents; //[(CLFileObject),(CLFileObject),...]

@property (nonatomic, strong) NSMutableArray *achievements;     // [(CLAchievement),(CLAchievement),...]

@property (nonatomic, strong) NSMutableArray *mediaPresence;    // [(CLMediaPresence),(CLMediaPresence),...]

@property (nonatomic, strong) CLInterestObject *interest;


//cancel request..
+ (void)cancelAboutMePendingRequest;

//Method for getting a about me detail for a particular user...
+ (void)aboutMeDetailsForUser:(NSString *)userId success:(void (^)(CLAboutMeObject *aboutMeObj))success failure:(void (^)(NSString *error))failure;

//Method for uploading non-primary image for a particular user...
+ (void)addNonPrimaryImage:(UIImage*)image forUser:(NSString *)userId withCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for uploading document for a particular user...
+ (void)addDocument:(UIImage*)image forUser:(NSString *)userId withCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting photo for a particular user...
+ (void)deletePhoto:(NSString*)photoId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for deleting document for a particular user...
+ (void)deleteDocument:(NSString*)documentId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for set image as parimary for a particular user...
+ (void)setPrimayImage:(NSString*)fileId forUser:(NSString*)userId isPrime:(int)primary success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;
@end
