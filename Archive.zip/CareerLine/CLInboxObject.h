//
//  CLInboxObject.h
//  CareerLine
//
//  Created by CSG on 3/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLJobsObject.h"

@interface CLInboxObject : NSObject

//inbox details..
@property (nonatomic, strong) NSString *inboxId;
@property (nonatomic, strong) NSString *inboxLastMsg;
@property (nonatomic, strong) NSString *inboxEntryDate;
@property (nonatomic, assign) int inboxThreadReadStatus;
@property (nonatomic, strong) CLJobsObject *inboxJob;

@property (nonatomic, strong) NSMutableArray *msgsArray;
@property (nonatomic, strong) NSMutableArray *questionnaireArray;   //[(CLQuestionnaireObject),(CLQuestionnaireObject),..]
@property (nonatomic, assign) BOOL isQuestionnairePresent;
@property (nonatomic, assign) BOOL isQuestionnaireSubmitted;
@property (nonatomic, strong) NSString *questionnaireDueDate;


//To cancel pending requests before a new request..
+ (void)cancelInboxListingPendingRequests;
+ (void)cancelInboxDetailPendingRequests;

//Method for listing jobs for a particular user..
+ (void)listInboxForUserId:(NSString*)userId success:(void (^)(NSMutableArray *jobs, NSInteger unreadInboxCount))success failure:(void (^)(NSString *error))failure;

//Method for getting inbox detail...
+ (void)inboxDetailsForinboxId:(NSString*)inboxId success:(void (^)(CLInboxObject *inboxDetail))success failure:(void (^)(NSString *error))failure;

//Method for posting reply...
+ (void)postReplyforInboxId:(NSString*)inboxId withMessage:(NSString*)msg success:(void (^)(CLInboxObject *inboxDetail))success failure:(void (^)(NSString *error))failure;

@end
