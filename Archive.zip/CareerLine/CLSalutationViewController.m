//
//  CLSalutationViewController.m
//  CareerLine
//
//  Created by CSG on 2/24/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSalutationViewController.h"
#import "CLSideMenuViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLUserObject.h"

#define kSectionHeaderTextColor [UIColor darkGrayColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont [UIFont systemFontOfSize:13]

@interface CLSalutationViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneToolbarWithCancel;
@property (strong, nonatomic) IBOutlet UIView *tblFooterView;
@property (weak, nonatomic) IBOutlet UILabel *lblUserName;
@property (weak, nonatomic) IBOutlet UILabel *lblUsernameHeading;
@property (strong, nonatomic) UIPickerView *pickerView;
@property(nonatomic,strong)UITextField *txtFirstResponder;

@property(nonatomic,strong)NSArray *selectedNationalitiesArray;
@property(nonatomic,strong)NSString *fullNameText;
//@property(nonatomic,strong)NSMutableArray *genderArray;
//@property(nonatomic,strong)NSMutableDictionary *selectedGenderDict;
@property(nonatomic,strong)NSMutableArray *salutationArray;
@property(nonatomic,strong)NSMutableDictionary *selectedSalutationDict;

//@property(nonatomic,assign)BOOL isGenderLegal;
@property(nonatomic,assign)BOOL isDataLoadedFromUserDefaults;

- (IBAction)bttnActionKeyboardDone:(id)sender;
- (IBAction)bttnActionKeyboardCancel:(id)sender;
@end

@implementation CLSalutationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.lblUserName.font=[UIFont fontWithName:@"Variable" size:16];
    self.lblUsernameHeading.font=[UIFont fontWithName:@"Variable" size:25];
    self.title=NSLocalizedString(@"Thank You", @"Profile details salutation page title");
    [self setRightNavButton];
    [self registerTableCellsForReuse];
    self.tableView.tableHeaderView=self.tblHeaderView;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    
    //self.genderArray=[[NSMutableArray alloc] init];
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    NSDictionary *savedDataDict=[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName];
    self.selectedNationalitiesArray=[savedDataDict objectForKey:kCLUserDefaultsProfileNationalityKey];
    self.fullNameText= [NSString stringWithFormat:@"%@ %@",[savedDataDict objectForKey:kCLUserDefaultsProfileFirstName],[savedDataDict objectForKey:kCLUserDefaultsProfileLastName]];
    //[self loadArraysWithData];
    //self.isGenderLegal=[self getGenderLegalStatus];
    self.salutationArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getSalutationsListforNationality:[self selectedNationalityCodeStringFromArray:[NSArray arrayWithObjects:[savedDataDict objectForKey:kCLUserDefaultsProfileCountryKey], nil]]];
    
    self.isDataLoadedFromUserDefaults=NO;
    [self bttnActionKeyboardDone:self];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    if(!self.isDataLoadedFromUserDefaults){
        if([[[NSUserDefaults standardUserDefaults] objectForKey:[CLCommon sharedInstance].userName] objectForKey:kCLUserDefaultsProfileSalutationKey]){
            [self loadValuesFromUserDefaults];
            [self.tableView reloadData];
        }
        self.isDataLoadedFromUserDefaults=YES;
    }
    if ([self.selectedSalutationDict count]>0) {
        [self setTableFooter];
    }
    else{
        self.tableView.tableFooterView=nil;
    }
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
    [CLUserObject cancelFirstTimeLoginPendingRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    //NSIndexPath *indexPath=cell.cellIndexPath;
    //if (indexPath.section==0) {
        //self.pickerView.tag=1;
//    }
//    else{
//        self.pickerView.tag=2;
//    }
//    [self.pickerView reloadAllComponents];
}

#pragma mark Utility Methods

-(void)setRightNavButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionProfileDetailsDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
}

-(void)registerTableCellsForReuse{
    //[self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"genederCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"salutationCellIdentifier"];
}

//-(void)loadArraysWithData{
//    self.genderArray=[DBClient getAllGenderListFromDB];
//}

//-(BOOL)getGenderLegalStatus{
//    BOOL isLegal=NO;
//    for (int i=0; i<[self.selectedNationalitiesArray count]; i++) {
//        if ([[[self.selectedNationalitiesArray objectAtIndex:i] objectForKey:knationalityGenderLegal] intValue]==1) {
//            isLegal=YES;
//        }
//    }
//    return isLegal;
//}

-(void)setTableFooter{
    self.lblUserName.text=[NSString stringWithFormat:@"%@",self.fullNameText];
    self.tableView.tableFooterView=self.tblFooterView;
}

-(CLSimpleTextCell*)getCellForFirstResponder{
    UITableViewCell *cell=nil;
    if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
        cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
    }
    
    return (CLSimpleTextCell*)cell;
}

-(NSMutableString*)selectedNationalityCodeStringFromArray:(NSArray*)nationalities{
    NSMutableString *string=[[NSMutableString alloc] init];
    if ([nationalities count]>0) {
        for (int i=0; i<[nationalities count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[nationalities objectAtIndex:i] objectForKey:kLocationCountryCode]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
    }
    return string;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
//    if ([self.selectedGenderDict count]==0) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select your gender.", @"Error Message for null gender field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    
    if ([self.selectedSalutationDict count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select your salutation.", @"Error Message for null salutation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    return isValid;
}

-(void)loadValuesFromUserDefaults{
    NSDictionary *savedDataDict=[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName];
    //self.selectedGenderDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileGenderKey] mutableCopy];
    self.selectedSalutationDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileSalutationKey] mutableCopy];
    self.salutationArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getSalutationsListforNationality:[self selectedNationalityCodeStringFromArray:self.selectedNationalitiesArray]];
}

-(void)saveFieldValuesToUserDefaults{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *savedDataDict=[[defaults dictionaryForKey:[CLCommon sharedInstance].userName] mutableCopy];
    
//    if ([self.selectedGenderDict count]>0) {
//        [savedDataDict setObject:self.selectedGenderDict forKey:kCLUserDefaultsProfileGenderKey];
//    }
    if ([self.selectedSalutationDict count]>0) {
        [savedDataDict setObject:self.selectedSalutationDict forKey:kCLUserDefaultsProfileSalutationKey];
    }
    
    [defaults setObject:savedDataDict forKey:[CLCommon sharedInstance].userName];
    [defaults synchronize];
}

-(NSMutableDictionary*)getTrimmedDictionaryForWebService{
    NSMutableDictionary *savedDataDict=[[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName] mutableCopy];
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]initWithDictionary:[savedDataDict objectForKey:kCLUserDefaultsProfileLocationHomeLoc]];
    NSMutableDictionary *countryCode = [savedDataDict objectForKey:kCLUserDefaultsProfileCountryKey];
    [locDict setObject:[countryCode objectForKey:@"jobLocationCountryCode" ] forKey:@"CountryCode"];
    [savedDataDict setObject:locDict forKey:kCLUserDefaultsProfileLocationHomeLoc];
    //date..
    NSDate *bdate=[savedDataDict objectForKey:kCLUserDefaultsProfileBirthDate];
    [savedDataDict setObject:[self getStringForDate:bdate] forKey:kCLUserDefaultsProfileBirthDate];
    
    //gender..
    NSMutableDictionary * genderDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileGenderKey] mutableCopy];
    if (genderDict) {
        [genderDict removeObjectForKey:kGenderOptionTitle];
        [savedDataDict setObject:genderDict forKey:kCLUserDefaultsProfileGenderKey];
    }
    
    //Nationality..
    NSMutableArray *nationalityArray=[[savedDataDict objectForKey:kCLUserDefaultsProfileNationalityKey] mutableCopy];
    if (nationalityArray) {
        NSMutableDictionary *natDict=nil;
        for (int i=0; i<[nationalityArray count]; i++) {
            natDict=[[nationalityArray objectAtIndex:i] mutableCopy];
            [nationalityArray removeObjectAtIndex:i];
            [natDict removeObjectForKey:knationalityDictName];
            [nationalityArray insertObject:natDict atIndex:i];
        }
    }
    if ([nationalityArray count]>0) {
        [savedDataDict setObject:nationalityArray forKey:kCLUserDefaultsProfileNationalityKey];
    }
    
    //education..
    NSMutableDictionary * eduactionDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEducation] mutableCopy];
    if (eduactionDict) {
        [eduactionDict removeObjectForKey:keducationDictName];
        [savedDataDict setObject:eduactionDict forKey:kCLUserDefaultsProfileEducation];
    }
    
    //Employment Status..
    NSMutableDictionary * employmntStatusDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentStatusKey] mutableCopy];
    if (employmntStatusDict) {
        [employmntStatusDict removeObjectForKey:kemploymentStatusTitleKey];
        [savedDataDict setObject:employmntStatusDict forKey:kCLUserDefaultsProfileEmploymentStatusKey];
    }
    
    //Employment Type..
    NSMutableDictionary * employmntTypeDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentTypeKey] mutableCopy];
    if (employmntTypeDict) {
        [employmntTypeDict removeObjectForKey:kemploymentTypeNameKey];
        [savedDataDict setObject:employmntTypeDict forKey:kCLUserDefaultsProfileEmploymentTypeKey];
    }
    
    //isCompanyFound
    [savedDataDict removeObjectForKey:kCLUserDefaultsProfileEmploymentIsCompanyFound];
    
    //Employment Contract Type..
    NSMutableDictionary * employmntContractTypeDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentContractTypeKey] mutableCopy];
    if (employmntContractTypeDict) {
//        [employmntContractTypeDict removeObjectForKey:kemploymentContractTypeNameKey];
        [savedDataDict setObject:employmntContractTypeDict forKey:kCLUserDefaultsProfileEmploymentContractTypeKey];
    }
    
    //job scope..
    NSMutableDictionary * employmntScopeDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentJobScopeKey] mutableCopy];
    if (employmntScopeDict) {
        [employmntScopeDict removeObjectForKey:kemploymentJobScopeNameKey];
        [savedDataDict setObject:employmntScopeDict forKey:kCLUserDefaultsProfileEmploymentJobScopeKey];
    }
    
    //job function..
    NSMutableArray *jobFunctionArray=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentFunctionKey] mutableCopy];
    if (jobFunctionArray) {
        NSMutableDictionary *funcDict=nil;
        for (int i=0; i<[jobFunctionArray count]; i++) {
            funcDict=[[jobFunctionArray objectAtIndex:i] mutableCopy];
            [jobFunctionArray removeObjectAtIndex:i];
            [funcDict removeObjectForKey:kjobFunctionName];
            [funcDict removeObjectForKey:kjobFunctionCategoryName];
            [jobFunctionArray insertObject:funcDict atIndex:i];
        }
        [savedDataDict setObject:jobFunctionArray forKey:kCLUserDefaultsProfileEmploymentFunctionKey];
    }
    
    
    
    //job level..
    NSMutableDictionary * jobLevelDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileEmploymentJobLevelKey] mutableCopy];
    if (jobLevelDict) {
    [jobLevelDict removeObjectForKey:kjobLevelGroupDictName];
    [jobLevelDict removeObjectForKey:kjobLevelGroupDictCode];
    [jobLevelDict removeObjectForKey:jobLevelDetailDictName];
    [jobLevelDict removeObjectForKey:jobLevelDetailDictDesc];
    [jobLevelDict setObject:[jobLevelDict objectForKey:jobLevelDetailDictCode] forKey:jobLevelDetailCode];
    [savedDataDict setObject:jobLevelDict forKey:kCLUserDefaultsProfileEmploymentJobLevelKey];
    }
    
    //home location..
    NSMutableDictionary * homeLocDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationHomeLoc] mutableCopy];
    [homeLocDict removeObjectForKey:kLocationCountryCode];
    [homeLocDict removeObjectForKey:kLocationCountryName];
    [homeLocDict removeObjectForKey:kLocationName];
    [savedDataDict setObject:homeLocDict forKey:kCLUserDefaultsProfileLocationHomeLoc];
    
    
    
    //salutation..
    NSMutableDictionary * salutationDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileSalutationKey] mutableCopy];
    [salutationDict removeObjectForKey:kSalutationOptionTitle];
    [savedDataDict setObject:@"" forKey:kCLUserDefaultsProfileSalutationKey];
    
    //ReLocation within same country..
    NSMutableArray *relocArray=[[savedDataDict objectForKey:kCLUserDefaultsProfileLocationRelocSameLoc] mutableCopy];
    if (relocArray) {
        NSMutableDictionary *locDict=nil;
        for (int i=0; i<[relocArray count]; i++) {
            locDict=[[relocArray objectAtIndex:i] mutableCopy];
            [relocArray removeObjectAtIndex:i];
            [locDict removeObjectForKey:kLocationCountryCode];
            [locDict removeObjectForKey:kLocationCountryName];
            [locDict removeObjectForKey:kLocationName];
            [relocArray insertObject:locDict atIndex:i];
        }
        [savedDataDict setObject:relocArray forKey:kCLUserDefaultsProfileLocationRelocSameLoc];
    }
    
    NSDictionary *dict = [[savedDataDict objectForKey:kCLUserDefaultsProfileLocationRelocOption] mutableCopy];
    
    [savedDataDict setObject:[dict objectForKey:kCLRelocationOptionsKey] forKey:kCLUserDefaultsProfileLocationRelocOption];
    return savedDataDict;
}

-(NSString*)getStringForDate:(NSDate*)date{
    //NSString *localFormat = [NSDateFormatter dateFormatFromTemplate:@"YYYYmmdd" options:0 locale:[NSLocale currentLocale]];
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    //[dateFormatter setLocale:[NSLocale currentLocale]];
    dateFormatter.dateStyle=NSDateFormatterLongStyle;
    //dateFormatter.dateFormat=localFormat;
    //[dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateString=[dateFormatter stringFromDate:date];
    return dateString;
}

-(void)sendWebServiceRequestForSavingDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while logging in");
    [progressHUD showInView:self.view];
    
    self.navigationItem.rightBarButtonItem.enabled=NO;
    self.navigationItem.hidesBackButton=YES;
    
    
    [CLUserObject saveFirstTimeUserDetails:[CLCommon jsonStringWithPrettyPrint:NO foDict:[self getTrimmedDictionaryForWebService]]
                                 forUserId:[CLCommon sharedInstance].userName
                                  password:[CLCommon sharedInstance].passWord
                                   success:^{
                                       [progressHUD hideWithAnimation:YES];
                                       self.navigationItem.rightBarButtonItem.enabled=YES;
                                       self.navigationItem.hidesBackButton=NO;
                                       [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateSideMenuDetails];
                                       [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                       [[NSUserDefaults standardUserDefaults] removeObjectForKey:[CLCommon sharedInstance].userName];
                                       [[NSUserDefaults standardUserDefaults] synchronize];
                                       [CLCommon sharedInstance].userName=nil;
                                       [CLCommon sharedInstance].passWord=nil;
                                       [self dismissViewControllerAnimated:YES completion:nil];
                                   }
                                   failure:^(NSString *error){
                                       [progressHUD hideWithAnimation:YES];
                                       self.navigationItem.rightBarButtonItem.enabled=YES;
                                       self.navigationItem.hidesBackButton=NO;
                                       if (![error isEqualToString:@""]) {
                                           [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:@"Failed to Save. Try Again Later" cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                       }
                                   }];
}

#pragma mark - IBActions

- (IBAction)bttnActionKeyboardDone:(id)sender{
    CLSimpleTextCell *cell=[self getCellForFirstResponder];
    if (self.pickerView.tag==1) {
//        self.selectedSalutationDict=[self.salutationArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
        self.selectedSalutationDict=[self.salutationArray objectAtIndex:0];

        [cell setCellText:[[self.salutationArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kSalutationOptionTitle]];
        //self.selectedGenderDict=[self.genderArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
        //[cell setCellText:[[self.genderArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kGenderOptionTitle]];
//        self.salutationArray=[DBClient getSalutationsListforNationality:[self selectedNationalityCodeStringFromArray:self.selectedNationalitiesArray] andGender:self.selectedGenderDict];
//        self.selectedSalutationDict=nil;
    }
//    else{
//        self.selectedSalutationDict=[self.salutationArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
//        [cell setCellText:[[self.salutationArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kSalutationOptionTitle]];
//    }
    
    if ([self.selectedSalutationDict count]>0) {
        [self setTableFooter];
    }
    else{
        self.tableView.tableFooterView=nil;
    }
    [self.tableView reloadData];
}

- (IBAction)bttnActionKeyboardCancel:(id)sender{
    [self.txtFirstResponder resignFirstResponder];
}

-(IBAction)bttnActionProfileDetailsDone:(id)sender{
    if([self isFieldsValid]){
        [self saveFieldValuesToUserDefaults];
        [self sendWebServiceRequestForSavingDetails];
    }
}

#pragma mark UIPickerView Methods

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [self.salutationArray count];
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// tell the picker the title for a given component
//- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
//    if (pickerView.tag==1) {
//        return [[self.genderArray objectAtIndex:row] objectForKey:kGenderOptionTitle];
//    }
//    else if(pickerView.tag==2){
//        return [[self.salutationArray objectAtIndex:row] objectForKey:kSalutationOptionTitle];
//    }
//    return nil;
//}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = ColorCode_CareerLineGreen;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    label.text= [[self.salutationArray objectAtIndex:row] objectForKey:kSalutationOptionTitle];
//    if (pickerView.tag==1) {
//        label.text= [[self.genderArray objectAtIndex:row] objectForKey:kGenderOptionTitle];
//    }
//    else if(pickerView.tag==2){
//        label.text= [[self.salutationArray objectAtIndex:row] objectForKey:kSalutationOptionTitle];
//    }
    return label;
}

#pragma mark UItableview datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salutationCellIdentifier"];
    [cell setTextInputView:self.pickerView];
    [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
    [cell setPlaceHoldrText:NSLocalizedString(@"Salutation", @"Placeholder for Salutation field in profile")];
    if (!self.selectedSalutationDict) {
        [cell setCellText:@""];
    }
    else{
        [cell setCellText:[self.selectedSalutationDict objectForKey:kSalutationOptionTitle]];
    }
    [cell setCellIndexPath:indexPath];
    cell.delegate=self;
    return cell;
    
//    if (indexPath.section==0) {
//        CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"genederCellIdentifier"];
//        [cell setTextInputView:self.pickerView];
//        [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
//        [cell setPlaceHoldrText:NSLocalizedString(@"Gender", @"Placeholder for gender field in profile")];
//        if (!self.selectedGenderDict) {
//            [cell setCellText:@""];
//        }
//        else{
//            [cell setCellText:[self.selectedGenderDict objectForKey:kGenderOptionTitle]];
//        }
//        [cell setCellIndexPath:indexPath];
//        cell.delegate=self;
//        return cell;
//    }
//    else{
//        CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salutationCellIdentifier"];
//        [cell setTextInputView:self.pickerView];
//        [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
//        [cell setPlaceHoldrText:NSLocalizedString(@"Salutation", @"Placeholder for Salutation field in profile")];
//        if (!self.selectedSalutationDict) {
//            [cell setCellText:@""];
//        }
//        else{
//            [cell setCellText:[self.selectedSalutationDict objectForKey:kSalutationOptionTitle]];
//        }
//        [cell setCellIndexPath:indexPath];
//        cell.delegate=self;
//        return cell;
//    }
}

#pragma mark UITableView Delegates

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 0;
}

//-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    return NSLocalizedString(@"SELECT SALUTATION", @"Title for SELECT SALUTATION");
//    if (section==0) {
//        return NSLocalizedString(@"SELECT GENDER", @"Title for select gender");
//    }
//    else{
//        return NSLocalizedString(@"SELECT SALUTATION", @"Title for SELECT SALUTATION");
//    }
//}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

@end
