//
//  CLAboutMeAchievementsViewController.h
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLAchievementObject.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLAboutMeAchievementsViewController;

//Delegate Methods...
@protocol CLAchievementControllerDelegate <NSObject>

@optional
- (void)achievementController:(CLAboutMeAchievementsViewController *)controller didAddAchievement:(CLAchievementObject*)achievementObj;

@end

@interface CLAboutMeAchievementsViewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,CLProfilePhotoListingGridCellDelegate
,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLAchievementControllerDelegate> delegate;
@property(nonatomic,strong)CLAchievementObject *achievementObj;
@property(nonatomic,assign)BOOL isEditMode;

@end
