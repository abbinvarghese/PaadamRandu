//
//  CLInboxQuestionaireCell.h
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLInboxQuestionaireCell : UITableViewCell

@property(nonatomic,strong) NSString *daysLeft;
-(void)updateCellContent;

@end
