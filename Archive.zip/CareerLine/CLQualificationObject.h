//
//  CLQualificationObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CLEducationObject.h"
#import "CLTrainingObject.h"
#import "CLCertificationObject.h"
#import "CLLicenseObject.h"
#import "CLMembershipObject.h"

@interface CLQualificationObject : NSObject

@property(nonatomic,strong)NSMutableArray *educationArray;          // [(CLEducationObject),(CLEducationObject),...]
@property(nonatomic,strong)NSMutableArray *trainingArray;           // [(CLTrainingObject),(CLTrainingObject),...]
@property(nonatomic,strong)NSMutableArray *certificationArray;      // [(CLCertificationObject),(CLCertificationObject),...]
@property(nonatomic,strong)NSMutableArray *membershipArray;         // [(CLMembershipObject),(CLMembershipObject),...]
@property(nonatomic,strong)NSMutableArray *licenseArray;            // [(CLLicenseObject),(CLLicenseObject),...]



+ (void)cancelQualificationPendingRequest;
+ (void)deleteQualification:(NSString*)qualifiactionId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;
+ (void)qualificationDetailsForUser:(NSString *)userId success:(void (^)(CLQualificationObject *qualificationObj))success failure:(void (^)(NSString *error))failure;
+ (void)addDocument:(UIImage*)image forQualification:(NSString*)docId andUser:(NSString *)userId withDocType:(NSString *)docType andCaption :(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;
+ (void)deleteQDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;
@end
