//
//  CLJobsObject.h
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLCompanyObject.h"

#define ktableSectionHeadingDictKey @"sectionHeading"
#define ktableSectionValueDictKey @"sectionValue"
#define ktableRowHeadingDictKey @"heading"
#define ktableRowValueDictKey @"value"
#define kJobsDetailvalueFont 14

@interface CLJobsObject : NSObject

//Job lisitng filter..
typedef enum {
	FilterAllJobs = 0,
    FilterAccepted = 1,
    FilterDeclined = 2,
	FilterBookmarked = 3
} JobsFilterOptions;

//Job details..
@property (nonatomic, strong) NSString *jobID;
@property (nonatomic, strong) NSString *jobReceivedDate;
@property (nonatomic, strong) NSString *jobTitle;
@property (nonatomic, strong) NSString *jobLoc;
@property (nonatomic, strong) NSString *jobCountry;
@property (nonatomic, assign) int jobUnreadStatus;
@property (nonatomic, strong) CLCompanyObject *companyDetails;

@property (nonatomic, strong) NSMutableArray *jobDetailsArray;
@property (nonatomic, assign) BOOL jobBookmarkStatus;
@property (nonatomic, assign) int jobAppliedStatus;


//To cancel pending requests before a new request..
+ (void)cancelJobListingPendingRequests;
+ (void)cancelJobDetailPendingRequests;

//Method for listing jobs for a particular user..
+ (void)listJobsForUserId:(NSString*)userId selectedFilter:(JobsFilterOptions)selectedFilter pageNumber:(int)page success:(void (^)(NSMutableArray *jobs, BOOL isLastPageReached, NSInteger unreadJobsCount))success failure:(void (^)(NSString *error))failure;

//Method for getting a job detail for a particular job...
+ (void)jobsDetailsForjobId:(NSString*)jobId andUserId:(NSString *)userId success:(void (^)(CLJobsObject *jobDetail))success failure:(void (^)(NSString *error))failure;

//Method for rejecting a job suggestion...
+ (void)rejectJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status success:(void (^)(NSString *jobId))success failure:(void (^)(NSString *jobId,NSString *error))failure;

//Method for accepting a job suggestion...
+ (void)acceptJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status surveyDetails:(NSDictionary*)survey success:(void (^)(NSString *jobId))success failure:(void (^)(NSString *jobId,NSString *error))failure;

//Method for bookmarking a job...
+ (void)bookmarkJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status success:(void (^)(NSString *jobId))success failure:(void (^)(NSString *jobId,NSString *error))failure;

//Method used to send job details mail..
+ (void)shareJobDetailsViaMail:(NSString*)mailId forJobId:(NSString*)jobId withUserId:(NSString*)userId success:(void (^)(void))success failure:(void (^)(NSString *error))failure;


@end