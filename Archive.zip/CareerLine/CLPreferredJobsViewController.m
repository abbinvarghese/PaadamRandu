//
//  CLPreferredJobsViewController.m
//  CareerLine
//
//  Created by Abbin on 27/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPreferredJobsViewController.h"
#import "CLTargetJobsObject.h"

@interface CLPreferredJobsViewController ()

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityView;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorMsg;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSString *searchText;
@property (nonatomic,strong) NSMutableArray *filteredPreferredJobArray;


@end

@implementation CLPreferredJobsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Preferred Jobs", @"title for preferred jobs modal");
    [self setLeftNavigationButton];
    self.activityView.hidden = YES;
    self.lblErrorMsg.hidden = YES;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    self.tableView.tableHeaderView=self.searchBar;
    self.searchText=@"";
    [self startSearchWith:self.searchText];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.filteredPreferredJobArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.selectionStyle=UITableViewCellSelectionStyleDefault;
        cell.textLabel.font=[UIFont systemFontOfSize:14];
        cell.textLabel.numberOfLines=0;
    }
    
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredPreferredJobArray objectAtIndex:indexPath.row];
    if (![self.searchText isEqualToString:@""] && indexPath.row==0) {
        cell.textLabel.text=[NSString stringWithFormat:@"%@",[cellDict objectForKey:kCLTargetJobsPreferredJobKey]];
    }
    else{
        cell.textLabel.text=[cellDict objectForKey:kCLTargetJobsPreferredJobKey];
    }

    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        if ([_delegate respondsToSelector:@selector(loadSelectedPreferredJobs:)]){
            [_delegate loadSelectedPreferredJobs:[self.filteredPreferredJobArray objectAtIndex:indexPath.row]];
        }
}



#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}

-(void)searchAfterDelay{
    self.searchText = [self.searchText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    [self startSearchWith:self.searchText];
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)bttnActionCancelModal:(id)sender{
    [self.searchBar resignFirstResponder];
    [CLTargetJobsObject cancelGetPreferredJobsRequest];
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(void)startSearchWith:(NSString*)searchText{
    self.activityView.hidden = NO;
    [self.activityView startAnimating];
    [CLTargetJobsObject getPreferredJobsListForSearchString:searchText forUser:[CLUserObject currentUser].userID success:^(NSMutableArray *prefArray){
        if (prefArray != nil) {
            self.filteredPreferredJobArray = [self blacklistedArrayfrom:prefArray];
        }
        
        if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
            [self.filteredPreferredJobArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,kCLTargetJobsPreferredJobKey,@"0",kCLTargetJobsPreferredJobIDKey, nil] atIndex:0];
        }

        
        if([self.filteredPreferredJobArray count] ==0){
            self.lblErrorMsg.hidden = NO;
        }else{
            self.lblErrorMsg.hidden = YES;
        }
        [self.activityView stopAnimating];
        self.activityView.hidden = YES;
        [self.tableView reloadData];

    }failure:^(NSString * error){
        [self.activityView stopAnimating];
        self.activityView.hidden = YES;
        self.lblErrorMsg.hidden = YES;
        [self.tableView reloadData];
    }];
    
}

-(NSMutableArray*)blacklistedArrayfrom:(NSMutableArray*)array{
    NSMutableArray *arrayTwo = [[NSMutableArray alloc]initWithArray:array];
    for (NSDictionary *dict in array) {
        if ([self.passedOnPreferredJobsArray containsObject:dict]) {
            [arrayTwo removeObject:dict];
        }
    }
    return arrayTwo;
}

@end
