//
//  CLSideMenuViewController.m
//  CareerLine
//
//  Created by CSG on 1/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSideMenuViewController.h"
#import "CLJobsViewController.h"
#import "CLInboxViewController.h"
#import "CLComingSoonViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "CLUserObject.h"
#import "CLConstants.h"
//#import "UIImageView+WebCache.h"
#import "CLSideMenuCell.h"
#import "CLSideMenuTrafficLightCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLLoaderImageVIew.h"
#import "CLFileObject.h"
#import "CLTermsAndConditionsViewController.h"

@interface CLSideMenuViewController ()

@property (strong, nonatomic) IBOutlet UIView *tableHeaderView;
@property (weak, nonatomic) IBOutlet UILabel *buildDate;
@property (weak, nonatomic) IBOutlet UITableView *sideMenuTable;
@property (weak, nonatomic) IBOutlet UILabel *lblUserName;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *imgUserImage;
@property (weak, nonatomic) IBOutlet UIImageView *bttnTrafficLight;
@property (weak, nonatomic) IBOutlet UILabel *lblTrafficLightStatus;
@property (weak, nonatomic) IBOutlet UIImageView *imgDownArrow;
@property (weak, nonatomic) IBOutlet UIView *statusChangeTapView;
@property (weak, nonatomic) IBOutlet UILabel *termsOfUses;
@property (weak, nonatomic) IBOutlet UILabel *dataProtectioins;

@property(nonatomic,assign)BOOL isTrafficLightSelectionMode;

- (IBAction)bttnActionChangeStatus:(id)sender;
@end

@implementation CLSideMenuViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.selectedSideMenuIndex=CLKnowledgeControllerIndex;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    //self.buildDate.hidden = YES;
    NSString *dateStr = [NSString stringWithUTF8String:__DATE__];
    //NSString *timeStr = [NSString stringWithUTF8String:__TIME__];
    //self.buildDate.text = [NSString stringWithFormat:@"%@ %@",dateStr,timeStr];
    
    NSString * version = [[NSBundle mainBundle] objectForInfoDictionaryKey: @"CFBundleShortVersionString"];
    self.buildDate.text = [NSString stringWithFormat:@"Version %@-%@",version,dateStr];

    self.termsOfUses.alpha=0.4;
    self.dataProtectioins.alpha=0.4;
    self.isTrafficLightSelectionMode=NO;
    self.sideMenuTable.tableHeaderView=self.tableHeaderView;
    [self.sideMenuTable registerClass:[CLSideMenuCell class] forCellReuseIdentifier:@"sideMenuCellIdentifier"];
    [self.sideMenuTable registerClass:[CLSideMenuTrafficLightCell class] forCellReuseIdentifier:@"sideMenuTrafficLightCellIdentifier"];
    UITapGestureRecognizer *tap= [[UITapGestureRecognizer alloc] initWithTarget: self action:@selector(bttnActionChangeStatus:)];
    tap.numberOfTapsRequired = 1;
    [self.statusChangeTapView addGestureRecognizer:tap];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(profilePhotoChangeNotifReceived:) name:kCLNotifCenterProfileImageChanged object:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    self.isTrafficLightSelectionMode=NO;
    self.imgDownArrow.transform=CGAffineTransformIdentity;
    [self.sideMenuTable reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableViewController Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.isTrafficLightSelectionMode) {
        return 3;
    }
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isTrafficLightSelectionMode) {
        CLSideMenuTrafficLightCell *cell = (CLSideMenuTrafficLightCell *)[self.sideMenuTable dequeueReusableCellWithIdentifier:@"sideMenuTrafficLightCellIdentifier"];
        [cell setupCell:indexPath forLightStatus:[CLUserObject currentUser].trafficLightStatus selectedIndex:[self getSelectedIndexForTrafficLightCell]];
        return cell;
    }
    else{
        CLSideMenuCell *cell = (CLSideMenuCell *)[self.sideMenuTable dequeueReusableCellWithIdentifier:@"sideMenuCellIdentifier"];
        [cell setupCellForIndexPath:indexPath selectedIndex:self.selectedSideMenuIndex];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isTrafficLightSelectionMode) {
        CLTrafficLightStatus status;
        switch (indexPath.row) {
            case CLTrafficLightRedColor:
                status=CLTrafficLightRedColor;
                break;
            case CLTrafficLightAmberColor:
                status=CLTrafficLightAmberColor;;
                break;
            case CLTrafficLightGreenColor:
                status=CLTrafficLightGreenColor;
                break;
            default:
                status=CLTrafficLightRedColor;
                break;
        }
        
        [self changeTrafficLightAndUpdateInterfaceForStatus:status success:nil failure:nil];
    }
    else{
        [self selectTabWithIndex:(CLSideMenuViewControllerIndex)indexPath.row];
    }
}

#pragma mark Utility Methods

- (void)changeTrafficLightAndUpdateInterfaceForStatus:(CLTrafficLightStatus)status success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    CLTrafficLightStatus currentStatus=[CLUserObject currentUser].trafficLightStatus;
    [CLUserObject currentUser].trafficLightStatus=status;
    [self updateSideMenuDetails];
    [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
    [CLUserObject changeTrafficLightStatus:[CLUserObject currentUser].trafficLightStatus withEmail:[CLUserObject currentUser].email
                                   success:^{
                                       [CLUserObject currentUser].trafficLightStatus=status;
                                       [self updateSideMenuDetails];
                                       [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                       [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:YES];
                                       success();
                                   }
                                   failure:^(NSString *error){
                                       if (![error isEqualToString:@""]) {
                                           [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't update traffic light.\nPlease check your network & try again.", @"Error message when traffic light cannot be updated") cancelbuttonName:NSLocalizedString(@"OK", @"alert cance button title")];
                                           [CLUserObject currentUser].trafficLightStatus=currentStatus;
                                           [self updateSideMenuDetails];
                                           [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                           failure(error);
                                       }
                                   }];
}

-(int)getSelectedIndexForTrafficLightCell{
    switch ([CLUserObject currentUser].trafficLightStatus) {
        case CLTrafficLightGreenColor:
            return 2;
            break;
        case CLTrafficLightAmberColor:
        return 1;
            break;
        case CLTrafficLightRedColor:
            return 0;
            break;
        default:
            return 0;
            break;
    }
}

-(void)updateSideMenuProfileImage:(CLFileObject*)profileImageObj{
    [self.imgUserImage setImageWithUrlString:profileImageObj.filePreviewUrl];
}

-(void)updateSideMenuDetails{
    [self.imgUserImage setImageWithUrlString:[CLUserObject currentUser].iconURL];
    
//    [self.imgUserImage setImageWithURL:[NSURL URLWithString:[[CLUserObject currentUser].iconURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:@"user_placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//        if (!error) {
//            if (image && (cacheType == SDImageCacheTypeNone || cacheType == SDImageCacheTypeDisk))
//            {
//                self.imgUserImage.alpha = 0.0;
//                [UIView animateWithDuration:1.0
//                                 animations:^{
//                                     self.imgUserImage.alpha = 1.0;
//                                 }];
//            }
//        }
//        else{
//            NSLog(@"dp load error=%@",error.debugDescription);
//        }
//    }];
    if ([CLUserObject currentUser].preferredName.length>0) {
        [self.lblUserName setText:[CLUserObject currentUser].preferredName];
    }else{
        [self.lblUserName setText:[CLUserObject currentUser].firstName];
    }
    
    
    switch ([CLUserObject currentUser].trafficLightStatus) {
        case CLTrafficLightGreenColor:
            self.bttnTrafficLight.image=[UIImage imageNamed:@"icon_find"];
            [self.lblTrafficLightStatus setText:NSLocalizedString(@"Active",  @"Traffic light green color button text")];
            [self.lblTrafficLightStatus setTextColor:ColorCode_SideMenuTextGreen];
            break;
        case CLTrafficLightAmberColor:
            self.bttnTrafficLight.image=[UIImage imageNamed:@"icon_open"];
            [self.lblTrafficLightStatus setText:NSLocalizedString(@"Open", @"Traffic light amber color button text")];
            [self.lblTrafficLightStatus setTextColor:ColorCode_SideMenuTextAmber];
            break;
        case CLTrafficLightRedColor:
            self.bttnTrafficLight.image=[UIImage imageNamed:@"icon_happy"];
            [self.lblTrafficLightStatus setText:NSLocalizedString(@"Happy", @"Traffic light red color button text")];
            [self.lblTrafficLightStatus setTextColor:ColorCode_SideMenuTextRed];
            break;
        default:
            break;
    }
    [self.sideMenuTable reloadData];
    //[self.sideMenuTable reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationMiddle];
}

-(void)selectTabWithIndex:(CLSideMenuViewControllerIndex)index{
    switch (index){
        case CLHomeControllerIndex:{
            self.selectedSideMenuIndex=CLHomeControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.homeNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            //[self.mm_drawerController setCenterViewController:SharedAppDelegate.homeNav withCloseAnimation:YES completion:nil];
            break;
        }
        case CLProfileControllerIndex:{
            self.selectedSideMenuIndex=CLProfileControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.profileNav];
//            [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Profile"];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLMyCareerLineControllerIndex:{
            self.selectedSideMenuIndex=CLMyCareerLineControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
            [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"My CareerLine"];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLDocumentsControllerIndex:{
            self.selectedSideMenuIndex=CLDocumentsControllerIndex;
            //[self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
            //[((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Documents"];
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.documentsNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLKnowledgeControllerIndex:{
            self.selectedSideMenuIndex=CLKnowledgeControllerIndex;
            //[self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
           // [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Knowledge"];
             [self.mm_drawerController setCenterViewController:SharedAppDelegate.knowledgeNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLJobsControllerIndex:{
            self.selectedSideMenuIndex=CLJobsControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.jobsNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLCalendarControllerIndex:{
            self.selectedSideMenuIndex=CLCalendarControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
            [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Calendar"];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case ClJobPreferencesControllerIndex:{
//            self.selectedSideMenuIndex=ClJobPreferencesControllerIndex;
//            [self.mm_drawerController setCenterViewController:SharedAppDelegate.jobPreferencesNav];
//            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
//            break;
            
            self.selectedSideMenuIndex=ClJobPreferencesControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
            [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Job Preferences"];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLInboxControllerIndex:{
            self.selectedSideMenuIndex=CLInboxControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.inboxNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLSettingsControllerIndex:{
            self.selectedSideMenuIndex=CLSettingsControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.comingSoonNav];
            [((CLComingSoonViewController*)[SharedAppDelegate.comingSoonNav.viewControllers objectAtIndex:0]) setTitle:@"Settings"];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
        case CLLogoutControllerIndex:{
            HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
            progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
            progressHUD.text=NSLocalizedString(@"Logging Out...", @"Text displayed in the loading indicator while logging out");
            progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
            progressHUD.hudView.alpha=0.9;
            [progressHUD showInView:SharedAppDelegate.window];
            [CLUserObject logoutUser:[CLUserObject currentUser].userID
                             success:^{
                                 [progressHUD hideWithAnimation:NO];
                                 self.selectedSideMenuIndex=CLLogoutControllerIndex;
                                 [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:^(BOOL finished){
                                     self.selectedSideMenuIndex=CLKnowledgeControllerIndex;
                                     [SharedAppDelegate.loginNav popToRootViewControllerAnimated:NO];
                                     [CLCommon sharedInstance].currentTrafficLightColor=ColorCode_CareerLineGreen;
                                     [SharedAppDelegate updateNavBarColor];
                                     [SharedAppDelegate.drawerController presentViewController:SharedAppDelegate.loginNav animated:YES completion:^(){
                                         [self.mm_drawerController setCenterViewController:SharedAppDelegate.knowledgeNav withCloseAnimation:NO completion:nil];
                                         [CLUserObject cancelUpdateUserDetailsPendingRequest];
                                         [SharedAppDelegate popAllControllersAndClearData];
                                     }];
                                 }];
                                 
                             }
                             failure:^(NSString *error){
                                 [progressHUD hideWithAnimation:YES];
                                 if (![error isEqualToString:@""]) {
                                     [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                 }
                             }];
            break;
        }
        default:{
            self.selectedSideMenuIndex=CLTrafficLightControllerIndex;
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.statusNav];
            [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
            break;
        }
    }
    [self.sideMenuTable reloadData];
}

-(void)incrementBadgeForPushType:(CLPushNotificationKeyType)alertType{
    switch (alertType) {
        case CLPushNotifKeyTypeJobAlert:{
            [CLUserObject currentUser].unreadJobsCount++;
            [self.sideMenuTable reloadData];
            break;
        }
        case CLPushNotifKeyTypeInboxAlert:{
            [CLUserObject currentUser].unreadInboxCount++;
            [self.sideMenuTable reloadData];
            break;
        }
        default:{
            [self.sideMenuTable reloadData];
            break;
        }
    }
    [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:YES];
}

-(void)decrementBadgeForPageType:(CLSideMenuViewControllerIndex)index{
    switch (index) {
        case CLJobsControllerIndex:{
            [CLUserObject currentUser].unreadJobsCount--;
            [self.sideMenuTable reloadData];
            break;
        }
        case CLInboxControllerIndex:{
            [CLUserObject currentUser].unreadInboxCount--;
            [self.sideMenuTable reloadData];
            break;
        }
        default:{
            [self.sideMenuTable reloadData];
            break;
        }
    }
    [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:YES];
}

-(void)updateBadge:(NSInteger)badgeCount andSaveUserForPageType:(CLSideMenuViewControllerIndex)index{
    switch (index) {
        case CLJobsControllerIndex:{
            [CLUserObject currentUser].unreadJobsCount=badgeCount;
            [self.sideMenuTable reloadData];
            break;
        }
        case CLInboxControllerIndex:{
            [CLUserObject currentUser].unreadInboxCount=badgeCount;
            [self.sideMenuTable reloadData];
            break;
        }
        default:{
            [self.sideMenuTable reloadData];
            break;
        }
    }
    [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:YES];
}

-(void)pushNavigationForPushType:(CLPushNotificationKeyType)alertType pushId:(NSString*)pushId{
    switch (alertType){
        case CLPushNotifKeyTypeJobAlert:{
            self.selectedSideMenuIndex=CLJobsControllerIndex;
            [SharedAppDelegate.jobsNav popToRootViewControllerAnimated:NO];
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.jobsNav withCloseAnimation:NO completion:^(BOOL finished){
                [((CLJobsViewController*)[SharedAppDelegate.jobsNav.viewControllers objectAtIndex:0]) gotoJobsDetailViewFromPushWithJobId:pushId];
            }];
            break;
        }
        case CLPushNotifKeyTypeInboxAlert:{
            self.selectedSideMenuIndex=CLInboxControllerIndex;
            [SharedAppDelegate.inboxNav popToRootViewControllerAnimated:NO];
            [self.mm_drawerController setCenterViewController:SharedAppDelegate.inboxNav withCloseAnimation:NO completion:^(BOOL finished){
                [((CLInboxViewController*)[SharedAppDelegate.inboxNav.viewControllers objectAtIndex:0]) gotoInboxDetailViewFromPushWithInboxId:pushId];
            }];
            break;
        }
        default:{
            break;
        }
    }
}

#pragma mark IBActions

- (IBAction)bttnActionChangeStatus:(id)sender {
    //[self selectTabWithIndex:CLTrafficLightControllerIndex];
    self.isTrafficLightSelectionMode=!self.isTrafficLightSelectionMode;
    [self.sideMenuTable reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationMiddle];
    
    CGFloat degrees=180.0;
    [UIView animateWithDuration:0.3 animations:^(){
        self.imgDownArrow.transform=CGAffineTransformRotate(self.imgDownArrow.transform, degrees*M_PI/180.0);
    }];
    
}

#pragma mark NSNotification Methods

-(void)profilePhotoChangeNotifReceived:(NSNotification*) notification{
    [self updateSideMenuProfileImage:(CLFileObject*)notification.object];
}


- (IBAction)termsOfUse:(UITapGestureRecognizer *)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:^(BOOL yes){
        CLTermsAndConditionsViewController *controller = [[CLTermsAndConditionsViewController alloc]initWithNibName:@"CLTermsAndConditionsViewController" bundle:[NSBundle mainBundle]];
        [controller setTitleString:@"Terms Of Use"];
        [controller setStringURL:@"https://dev.careerlinedevelopment.com/index.php?r=site/termsofusemobile"];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }];
}

- (IBAction)dataProtection:(UITapGestureRecognizer *)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:^(BOOL yes){
        CLTermsAndConditionsViewController *controller = [[CLTermsAndConditionsViewController alloc]initWithNibName:@"CLTermsAndConditionsViewController" bundle:[NSBundle mainBundle]];
        [controller setTitleString:@"Data Protection Policy"];
        [controller setStringURL:@"https://dev.careerlinedevelopment.com/index.php?r=site/dataPrivacypolicymobile"];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }];
}


@end
