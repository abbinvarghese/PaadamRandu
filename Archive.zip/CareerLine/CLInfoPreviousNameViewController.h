//
//  CLInfoPreviousNameViewController.h
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLPreviousNameObject.h"
#import "CLSimpleTextCell.h"

@class CLInfoPreviousNameViewController;

//Delegate Methods...
@protocol CLPreviousNameControllerDelegate <NSObject>

@optional
- (void)previousNameController:(CLInfoPreviousNameViewController *)controller didAddName:(CLPreviousNameObject*)nameObj;

@end

@interface CLInfoPreviousNameViewController : UITableViewController<CLSimpleTextCellDelegate>

@property(nonatomic,weak) id <CLPreviousNameControllerDelegate> delegate;
@property(nonatomic,strong)CLPreviousNameObject *previousNameObj;
@property(nonatomic,assign)BOOL isEditMode;

@end
