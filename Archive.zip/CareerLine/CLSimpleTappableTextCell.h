//
//  CLProfileNationalityCell.h
//  CareerLine
//
//  Created by CSG on 2/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSimpleTappableTextCell;

//Delegate Methods...
@protocol CLTappableCellDelegate <NSObject>

@required
- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath;
@optional
- (void)tappableCellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextField:(UITextField*)textField;
@end


@interface CLSimpleTappableTextCell : UITableViewCell

@property (strong, nonatomic) NSIndexPath *cellIndexPath;
@property(nonatomic,weak) id <CLTappableCellDelegate> delegate;

-(void)setCellCloseBtnOption:(BOOL)status;
-(NSString*)getEnteredText;
-(void)setPlaceHoldrText:(NSString *)text;
-(void)setCellText:(NSString*)text;
-(void)setCellFont:(UIFont*)font;
-(void)updateTapStatus;
-(void)enableTapStatus;

@end

