//
//  CLBorderedTextCell.h
//  CareerLine
//
//  Created by CSG on 9/1/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"

@interface CLBorderedTextCell : UITableViewCell

@property(nonatomic,weak) id <CLSimpleTextCellDelegate> delegate;
@property (strong, nonatomic) NSIndexPath *cellIndexPath;

-(NSString*)getEnteredText;
-(void)setCellText:(NSString*)text;
-(void)setCellFont:(UIFont*)font;
-(void)setPlaceHoldrText:(NSString *)text;
-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode;
-(void)setTextInputAccesoryView:(id)view;
-(void)setKeyboardType :(UIKeyboardType)type;
-(void)isSecureType :(BOOL)isSecure;
-(void)returnKeyType:(UIReturnKeyType)type;
-(void)becomeFirstResponder;
@end
