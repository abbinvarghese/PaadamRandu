//
//  CLTargetJobsViewController.h
//  CareerLine
//
//  Created by Abbin on 31/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLJobScopeViewController.h"
#import "CLTappableTextViewCell.h"
#import "CLSelectJobLevelDetailViewController.h"
#import "CLSelectFunctionCategoryViewController.h"
#import "CLSelectJobLevelGroupViewController.h"
#import "CLIndustrySectorViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLIndustryGroupViewController.h"
#import "CLIndustryViewController.h"
#import "CLHeightAdjustTextCell.h"
#import "CLPreferredJobsEditViewController.h"
#import "CLJobScopeSelectionViewController.h"


@interface CLTargetJobsViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate,jobScopeDelegate,CLTappableCellDelegate,CLSelectJobLevelDelegate,CLEditJobFunctionDelegate,CLAddJobFunctionDelegate,CLSelectJobLevelGroupDelegate,CLEditIndustryDelegate,CLSelectOtherIndustryGroup,CLSelectIndustryDelegate,CLHeightAdjustTextCellDelegate,CLPreferredJobsEditDelegate,HTProgressHUDDelegate,JobScopeSelectionDelegate>

{
    
}
@property (nonatomic, assign)NSInteger selectedRow;

@end
