//
//  CLSelectEducationViewController.h
//  CareerLine
//
//  Created by CSG on 4/21/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectEducationViewController;

//Delegate Methods...
@protocol CLSelectEducationDelegate <NSObject>

@required
- (void)selectEducationControllerDidSelectEducation:(CLSelectEducationViewController*)controller withDict:(NSMutableDictionary *)eduDict;

@end

@interface CLSelectEducationViewController : UITableViewController

@property(nonatomic,weak) id <CLSelectEducationDelegate> delegate;
@property(nonatomic,strong) NSMutableDictionary*alreadySelectedEduLevel;
@property(nonatomic,retain)NSString*cyCode;

@end
