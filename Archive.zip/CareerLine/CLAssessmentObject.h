//
//  CLAssessmentObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLAssessmentObject : NSObject

@property(nonatomic,strong)NSString *assessmentId;
@property(nonatomic,strong)NSString *assessmentTitle;
@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *score;
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *assessDescription;
@property(nonatomic,strong)NSMutableArray *documents;       //[(CLFileObject),(CLFileObject),...]

//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for saving asessment of a particular user...
+ (void)saveAssessment:(CLAssessmentObject*)assessObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *assessId))success failure:(void (^)(NSString *error))failure;

//Method for deleting assessment for a particular user...
+ (void)deleteAssessment:(NSString*)assessmentId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading assessment document for a particular user...
+ (void)addDocument:(UIImage*)image forAssessment:(NSString*)assessId andUser:(NSString *)userId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting assessment document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
