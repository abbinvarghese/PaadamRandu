//
//  CLSalaryBenefitsViewController.m
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSalaryBenefitsViewController.h"
#import "CLAddAllowanceViewController.h"
#import "CLAddIncentivesViewController.h"
#import "CLFrequencyViewController.h"

#define kSectionFooterBgColor [UIColor whiteColor]

#define pickerValId @"id"
#define pickerValName @"longtermIncentive"
#define pickerOtherFlag @"otherText"

@interface CLSalaryBenefitsViewController ()
typedef enum {
    CLSalaryBenefitsSalaryIndex = 0,
    CLSalaryBenefitsAllowanceIndex= 1,
    CLSalaryBenefitsIncentiveIndex = 2,
    CLSalaryBenefitsLongTermIncentiveIndex = 3,
    CLSalaryBenefitsBenefitsIndex = 4
} CLSalaryBenefitsTableSectionIndex;

typedef enum {
    CLSalaryIndex = 0,
    CLSalaryBasisIndex= 1,
    CLSalaryCurrencyIndex = 2,
} CLSalaryBenefitsSectionRowIndex;

//Table Incentives Row indicator...
@property (nonatomic, assign) int longIncentiveBonusIndex;
@property (nonatomic, assign) int longIncentiveFrequencyIndex;
@property (nonatomic, assign) int longIncentiveGrossSalaryCheckBoxIndex;
@property (nonatomic, assign) int longIncentiveGrossSalaryTextIndex;
@property (nonatomic, assign) int longIncentiveActualValueCheckBoxIndex;
@property (nonatomic, assign) int longIncentiveActualValueTextIndex;
@property (nonatomic, assign) int longIncentiveCurrencyIndex;

@property (strong, nonatomic) UIPickerView *pickerView;
@property (nonatomic, retain) NSIndexPath *currentIndexPath;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;
@property (nonatomic, retain) NSMutableArray *allowanceArray;
@property (nonatomic, retain) NSMutableArray *incentiveArray;
@property (nonatomic, assign) BOOL longIncentiveGrossSalSwitch;
@property (nonatomic, assign) BOOL longIncentiveActualValSwitch;

@property (nonatomic, retain) NSString *salary;
@property (nonatomic, retain) NSString *salaryBasis;
@property (nonatomic, retain) NSString *salaryCurrency;
@property (nonatomic, retain) NSString *longTermIncentive;
@property (nonatomic, retain) NSString *frequency;
@property (nonatomic, retain) NSString *percentageGrossSal;
@property (nonatomic, retain) NSString *actualValue;
@property (nonatomic, retain) NSString *longTermCurrency;
@property (nonatomic, retain) NSString *benefitsText;
@property (nonatomic, retain) NSMutableArray *benefits;
@property (nonatomic, retain) NSMutableArray *longTermIncentiveArray;
@property (nonatomic, retain) NSMutableDictionary *selectedSalaryBasis;
@property (nonatomic, retain) NSMutableDictionary *selectedCurrency;
@property (nonatomic, retain) NSMutableDictionary *selectedLongTermFrequency;
@property (nonatomic, retain) NSMutableDictionary *selectedLongTermCurrency;
@property (nonatomic, retain) NSMutableDictionary *selectedLongTermIncentiveDict;
@property (strong, nonatomic) IBOutlet TITokenField *tokenTxtField;

@end

@implementation CLSalaryBenefitsViewController

-(void)updateLongIncentiveRowIndexes {
    
    self.longIncentiveBonusIndex =0;
    self.longIncentiveFrequencyIndex =1;
    self.longIncentiveGrossSalaryCheckBoxIndex =2;
    if (self.longIncentiveGrossSalSwitch && self.longIncentiveActualValSwitch) {
        self.longIncentiveGrossSalaryTextIndex =3;
        self.longIncentiveActualValueCheckBoxIndex =4;
        self.longIncentiveActualValueTextIndex =5;
        self.longIncentiveCurrencyIndex =6;
        
    }else if (self.longIncentiveGrossSalSwitch){
        self.longIncentiveGrossSalaryTextIndex =3;
        self.longIncentiveActualValueCheckBoxIndex =4;
        
        self.longIncentiveActualValueTextIndex =-1;
        self.longIncentiveCurrencyIndex =-1;
        
    }else if (self.longIncentiveActualValSwitch){
        self.longIncentiveActualValueCheckBoxIndex =3;
        self.longIncentiveActualValueTextIndex =4;
        self.longIncentiveCurrencyIndex =5;
        
        self.longIncentiveGrossSalaryTextIndex =-1;
        
    }else{
        self.longIncentiveActualValueCheckBoxIndex =3;
        
        self.longIncentiveGrossSalaryTextIndex =-1;
        self.longIncentiveActualValueTextIndex =-1;
        self.longIncentiveCurrencyIndex =-1;
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGRect tokenFieldFrame=self.tokenTxtField.frame;
    tokenFieldFrame.size.width=self.tableView.bounds.size.width-10;
    self.tokenTxtField.frame=tokenFieldFrame;
    if (self.salBenefitssObj) {
        self.allowanceArray = self.salBenefitssObj.allowanceObjArray;
        self.incentiveArray = self.salBenefitssObj.incentiveObjArray;
        self.salary = self.salBenefitssObj.salary;
        if ([self.salBenefitssObj.salaryBasis objectForKey:kCLCareerHistoryAllowanceFrequencykey]) {
            self.salaryBasis = [self.salBenefitssObj.salaryBasis objectForKey:kCLCareerHistoryAllowanceFrequencykey];
        }
        else{
            self.salaryBasis = [self.salBenefitssObj.salaryBasis objectForKey:@"salaryBasis"];
        }
        
        if (self.salBenefitssObj.currency.count>0) {
            if ([self.salBenefitssObj.currency objectForKey:kCLCareerHistoryLongCurrencykey]) {
                self.salaryCurrency = [self.salBenefitssObj.currency objectForKey:kCLCareerHistoryLongCurrencykey];
            }
            else{
                self.salaryCurrency = [NSString stringWithFormat:@"%@%@",[self.salBenefitssObj.currency objectForKey:@"currencyCode"],[self.salBenefitssObj.currency objectForKey:@"countryName"]];
            }
        }
        else{
            self.selectedCurrency=[[NSMutableDictionary alloc]init];
            self.selectedCurrency=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[self.selectedCountry objectForKey:@"jobLocationCountryName"]]objectAtIndex:0];
            self.salaryCurrency=[NSString stringWithFormat:@"%@/%@",[self.selectedCurrency objectForKey:kjobPreferenceCurrencyCode],[self.selectedCurrency objectForKey:kjobPreferenceCountryName]];

        }
        
        self.longTermIncentive = [self.salBenefitssObj.longTermIncentives objectForKey:kCLCareerHistoryLongIncentivekey];
        self.frequency = [self.salBenefitssObj.longTermFrequency objectForKey:kCLCareerHistoryAllowanceFrequencykey];
        self.percentageGrossSal = self.salBenefitssObj.longTermGrossSal ;
        self.actualValue = self.salBenefitssObj.longTermActualVal;
        if ([self.salBenefitssObj.longTermCurrency objectForKey:kCLCareerHistoryLongCurrencykey]) {
            self.longTermCurrency = [self.salBenefitssObj.longTermCurrency objectForKey:kCLCareerHistoryLongCurrencykey];
        }
        else{
            self.longTermCurrency = [self.salBenefitssObj.longTermCurrency objectForKey:@"longtermCurrency"];
        }
        self.benefits = self.salBenefitssObj.benefits;
        self.benefitsText = [self getBenefitsTextForTokenField:self.benefits];
        
        if (self.salBenefitssObj.currency!=nil) {
            self.selectedCurrency = [[NSMutableDictionary alloc]initWithDictionary:self.salBenefitssObj.currency];
            
        }
        if (self.salBenefitssObj.longTermCurrency!=nil) {
            self.selectedLongTermCurrency = [[NSMutableDictionary alloc]initWithDictionary:self.salBenefitssObj.longTermCurrency];
            
        }
        self.selectedLongTermIncentiveDict = self.salBenefitssObj.longTermIncentives;
        self.selectedLongTermFrequency = self.salBenefitssObj.longTermFrequency;
        self.selectedSalaryBasis = self.salBenefitssObj.salaryBasis;
    }else{
        self.salBenefitssObj = [[CLCareerSalaryBenefitsObject alloc]init];
        self.selectedCurrency=[[NSMutableDictionary alloc]init];
        self.selectedCurrency=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[self.selectedCountry objectForKey:@"jobLocationCountryName"]]objectAtIndex:0];
        self.selectedLongTermCurrency=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[self.selectedCountry objectForKey:@"jobLocationCountryName"]]objectAtIndex:0];
        self.longTermCurrency = [NSString stringWithFormat:@"%@/%@",[self.selectedLongTermCurrency objectForKey:kjobPreferenceCurrencyCode],[self.selectedLongTermCurrency objectForKey:kjobPreferenceCountryName]];
        self.salaryCurrency=[NSString stringWithFormat:@"%@/%@",[self.selectedCurrency objectForKey:kjobPreferenceCurrencyCode],[self.selectedCurrency objectForKey:kjobPreferenceCountryName]];
    }
     
    if (![self.percentageGrossSal isEqualToString:@""] && self.percentageGrossSal!=nil) {
        self.longIncentiveGrossSalSwitch = YES;
    }
    
    if (![self.actualValue isEqualToString:@""] && self.actualValue!=nil) {
        self.longIncentiveActualValSwitch = YES;
    }
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Salary and Benefits", @"Salary and Benefits page title");
    //Salary section
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"salaryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"salaryBasicsTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"salaryCurrencyTextCellIdentifier"];
    
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"benefitsTappableTextCellIdentifier"];
    
    //Long Incentive section
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"longIncentiveTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"longIncentiveActualValCurrencyCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"longIncentiveFrequencyTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"longIncentiveGrossSalaryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"longIncentiveActualValueTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"longIncentiveGrossSalaryCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"longIncentiveActualValueCellIdentifier"];
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    self.longTermIncentiveArray = [NSMutableArray arrayWithObjects:
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"1",pickerValId,
                                    NSLocalizedString(@"Stock Options", @"Stock Options text"),pickerValName,
                                    @"0",pickerOtherFlag,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"2",pickerValId,
                                    NSLocalizedString(@"Stock Grants", @"Stock Grants text"),pickerValName,
                                    @"0",pickerOtherFlag,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"3",pickerValId,
                                    NSLocalizedString(@"Mix of Options and Stock", @"Mix of Options and Stock text"),pickerValName,
                                    @"0",pickerOtherFlag,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"4",pickerValId,
                                    NSLocalizedString(@"Deferred Cash", @"Deferred Cash text"),pickerValName,
                                    @"0",pickerOtherFlag,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"5",pickerValId,
                                    NSLocalizedString(@"Other", @"Other text"),pickerValName,
                                    @"1",pickerOtherFlag,
                                    nil],
                                   nil];
    
    [self setRightNavigationButton];
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    [self updateLongIncentiveRowIndexes];
}

#pragma mark UIPickerView Methods
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    return [self.longTermIncentiveArray count];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    label.text= [[self.longTermIncentiveArray objectAtIndex:row] objectForKey:pickerValName];
    
    return label;
}

- (NSString *)getBenefitsTextForTokenField :(NSMutableArray *)array{
    
    NSMutableString *resultText = [[NSMutableString alloc] init];
    for (int i=0; i< [array count]; i++) {
        
        if ([[[array objectAtIndex:i] objectForKey:kCLCareerHistoryBenefitsOtherFlagkey] boolValue]) {
            [resultText appendString:[NSString stringWithFormat:@"%@|",[[array objectAtIndex:i] objectForKey:kCLCareerHistoryBenefitsOtherTextkey]]];
        }else{
            [resultText appendString:[NSString stringWithFormat:@"%@|",[[array objectAtIndex:i] objectForKey:kCLCareerHistoryBenefitsItemkey]]];
        }
    }
    return resultText;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods
-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"dismiss Salary benefits modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
}
- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if(cell!=nil){
        
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        
        if (cell.cellIndexPath.section == CLSalaryBenefitsLongTermIncentiveIndex && cell.cellIndexPath.row == self.longIncentiveBonusIndex) {
            if ([[[self.longTermIncentiveArray objectAtIndex:row] objectForKey:pickerOtherFlag] boolValue]) {
                
                if([CLCommon isOSversionLessThan8])
                {
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"Enter Other Long Term Incentive",@"other Long Term Incentive") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",@"cancel btn title") otherButtonTitles:NSLocalizedString(@"OK",@"ok btn title"), nil] ;
                    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
                    [alertView show];
                }
                else
                {
                    // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                                   message: NSLocalizedString(@"Enter Other Long Term Incentive",@"other Long Term Incentive")
                                                                            preferredStyle: UIAlertControllerStyleAlert];
                    
                    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                        
                    }];
                    UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"ok btn title") style:UIAlertActionStyleDefault
                                                                     handler:^(UIAlertAction * action){
                                                                         //Do Some action here
                                                                         [self.txtFirstResponder resignFirstResponder];
                                                                         UITextField *textField = alert.textFields[0];
                                                                         NSString *string = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                         if (![textField.text isEqualToString:@""] && ![CLCommon doesItHaveSpace:string]) {
                                                                             
                                                                             NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                                                                                                         @"5",pickerValId,
                                                                                                                                                         string,pickerValName,
                                                                                                                                                         @"1",pickerOtherFlag,
                                                                                                                                                         nil]];
                                                                             [cell setCellText:string];
                                                                             self.selectedLongTermIncentiveDict =dict;
                                                                             self.longTermIncentive =[dict objectForKey:pickerValName];                                                                         }
                                                                         
                                                                     }];
                    
                    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel",@"cancel btn title")
                                                                           style: UIAlertActionStyleDefault
                                                                         handler: nil];
                    
                    [alert addAction: cancelAction];
                    [alert addAction: okAction];
                    [self presentViewController:alert animated:YES completion:nil];
                }
                
            }else{
                [cell setCellText:[[self.longTermIncentiveArray objectAtIndex:row] objectForKey:pickerValName]];
                self.selectedLongTermIncentiveDict =[self.longTermIncentiveArray objectAtIndex:row];
                self.longTermIncentive =[[self.longTermIncentiveArray objectAtIndex:row] objectForKey:pickerValName];
                
            }
        }
    }
    [self.txtFirstResponder resignFirstResponder];
}

#pragma mark-alertview delegate method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    [self.txtFirstResponder resignFirstResponder];
    UITextField * alertTextField = [alertView textFieldAtIndex:0];
    NSString *string = [alertTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (buttonIndex ==1 && ![alertTextField.text isEqualToString:@""] && ![CLCommon doesItHaveSpace:string]) {
        
        CLSimpleTextCell *cell;
        cell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:self.longIncentiveBonusIndex inSection:CLSalaryBenefitsLongTermIncentiveIndex]];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                                    @"5",pickerValId,
                                                                                    string,pickerValName,
                                                                                    @"1",pickerOtherFlag,
                                                                                    nil]];
        [cell setCellText:string];
        self.selectedLongTermIncentiveDict =dict;
        self.longTermIncentive =[dict objectForKey:pickerValName];
    }
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
}
-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Course validation..

    if (![self.salary isEqualToString:@""] && ![CLCommon validateNumbersOnly:self.salary]) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Salary Amount.", @"Error Message for salary amount field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
       
            return isValid=NO;
        
    }else if ((unsigned long)self.salary.length >8 && [CLCommon validateNumbersOnly:self.salary]){
       
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Salary Amount Can Only Be Upto 8 Digits.", @"Error Message for salary amount field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
         return isValid=NO;
    }
    else if (self.actualValue.length >9){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum Length Of Actual Value Should Be 9", @"Error Message for actual value field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    else if (self.percentageGrossSal.length > 3){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum length of Gross Salary should be 3.", @"Error Message for gross salary field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    return isValid;
}

-(void)bttnActionSaveAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        CATransition *transition = [CATransition animation];
        transition.duration = 0.25;
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromBottom;
        
        self.salBenefitssObj.allowanceObjArray = self.allowanceArray;
        self.salBenefitssObj.incentiveObjArray = self.incentiveArray;
        self.salBenefitssObj.salary = self.salary;
        
        self.salBenefitssObj.longTermIncentives = self.selectedLongTermIncentiveDict;
        self.salBenefitssObj.longTermGrossSal = self.percentageGrossSal;
        self.salBenefitssObj.longTermActualVal = self.actualValue;
        
        self.salBenefitssObj.benefits = self.benefits;
//        self.salBenefitssObj.currency = self.selectedCurrency;
        
        NSMutableDictionary *dictio = [[NSMutableDictionary alloc]init];
        if ([self.selectedCurrency objectForKey:@"countryCode"]) {
            [dictio setObject:[self.selectedCurrency objectForKey:@"countryCode"] forKey:@"id"];
            [dictio setObject:[NSString stringWithFormat:@"%@/%@",[self.selectedCurrency objectForKey:@"countryName"],[self.selectedCurrency objectForKey:@"currencyCode"]] forKey:@"currency"];
        }
        else{
            if (self.selectedCurrency.count>0) {
                [dictio setObject:[self.selectedCurrency objectForKey:@"id"] forKey:@"id"];
                [dictio setObject:[self.selectedCurrency objectForKey:@"currency"] forKey:@"currency"];
            }
        }
        self.salBenefitssObj.currency = dictio;
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        if (self.selectedLongTermCurrency.count > 0) {
            if (self.selectedLongTermCurrency) {
                if ([self.selectedLongTermCurrency objectForKey:@"countryCode"]) {
                    [dict setObject:[self.selectedLongTermCurrency objectForKey:@"countryCode"] forKey:@"id"];
                    [dict setObject:[NSString stringWithFormat:@"%@/%@",[self.selectedLongTermCurrency objectForKey:@"currencyCode"],[self.selectedLongTermCurrency objectForKey:@"countryName"]] forKey:@"currency"];
                }
                else{
                    if ([self.selectedLongTermCurrency objectForKey:@"id"]) {
                        [dict setObject:[self.selectedLongTermCurrency objectForKey:@"id"] forKey:@"id"];
                    }
                    if ([self.selectedLongTermCurrency objectForKey:@"currency"]) {
                        [dict setObject:[self.selectedLongTermCurrency objectForKey:@"currency"] forKey:@"currency"];
                    }
                    else{
                        [dict setObject:[self.selectedLongTermCurrency objectForKey:@"longtermCurrency"] forKey:@"currency"];
                    }
                }
            }
        }
        
        self.salBenefitssObj.longTermCurrency =dict;
        
        self.salBenefitssObj.longTermFrequency =self.selectedLongTermFrequency;
        self.salBenefitssObj.salaryBasis =self.selectedSalaryBasis;
        
        
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(salaryBenefitsController:didAddSalaryBenefits:)]){
            [self.delegate salaryBenefitsController:self didAddSalaryBenefits:self.salBenefitssObj];
        }
        [self.navigationController popViewControllerAnimated:NO];
    }
}


#pragma mark - tableView methods

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case CLSalaryBenefitsSalaryIndex:{
            if (indexPath.row ==CLSalaryIndex) {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salaryTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Salary", @"Placeholder for Salary field")];
                [relatedToCell setCellText:self.salary];
                
                if(self.salary.length)
                    [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }else if (indexPath.row ==CLSalaryBasisIndex){
                CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salaryBasicsTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Salary Basis", @"Placeholder for Salary Basis field")];
                [relatedToCell setCellText:self.salaryBasis];
                if (![self.salaryBasis isEqualToString:@""] && self.salaryBasis!=nil) {
                    [relatedToCell setCellCloseBtnOption:NO];
                }
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
            }else if (indexPath.row ==CLSalaryCurrencyIndex){
                CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salaryCurrencyTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Currency", @"Placeholder for Currency field")];
                [relatedToCell setCellText:self.salaryCurrency];
                if (![self.salaryCurrency isEqualToString:@""] && self.salaryCurrency!=nil) {
                    [relatedToCell setCellCloseBtnOption:NO];
                }
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }
            
        }
        case CLSalaryBenefitsAllowanceIndex:{
            
            [self.tableView setAllowsSelectionDuringEditing:YES];
            if ([self.allowanceArray count]) {
                [self.tableView setEditing:YES animated:YES];
            }

            static NSString *CellIdentifier = @"alloeanceCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
                [cell.textLabel setNumberOfLines:0];
            }
            //cell.textLabel.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.text=[[[self.allowanceArray objectAtIndex:indexPath.row] objectForKey:kCLCareerHistoryAllowanceLoadingskey] objectForKey:kCLCareerHistoryAllowanceLoadingskey];
            return cell;
        }
        case CLSalaryBenefitsIncentiveIndex:{
            
            [self.tableView setAllowsSelectionDuringEditing:YES];
            if ([self.incentiveArray count]) {
                [self.tableView setEditing:YES animated:YES];
            }
            
            static NSString *CellIdentifier = @"incentiveCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
                [cell.textLabel setNumberOfLines:0];
            }
            cell.textLabel.textColor = [UIColor darkGrayColor];
            //cell.textLabel.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
            cell.textLabel.text=[[[self.incentiveArray objectAtIndex:indexPath.row] objectForKey:kCLCareerHistoryIncentiveBonuskey] objectForKey:kCLCareerHistoryIncentiveBonuskey];
            return cell;
            
        }
        case CLSalaryBenefitsLongTermIncentiveIndex:{
            if (indexPath.row ==self.longIncentiveBonusIndex) {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputView:self.pickerView];
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Long Term Incentives", @"Placeholder for Long Term Incentives field")];
                [relatedToCell setCellText:self.longTermIncentive];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
            }else if (indexPath.row ==self.longIncentiveFrequencyIndex){
                CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveFrequencyTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Frequency", @"Placeholder for Frequency field")];
                [relatedToCell setCellText:self.frequency];
                if (![self.frequency isEqualToString:@""] && self.frequency!=nil) {
                    [relatedToCell setCellCloseBtnOption:NO];
                }
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
            }else if (indexPath.row ==self.longIncentiveGrossSalaryCheckBoxIndex){
                
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveGrossSalaryCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell setKeyboardType:UIKeyboardTypeNumberPad];
                [numDaysCell setCellText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.longIncentiveGrossSalSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
                
            }else if(indexPath.row ==self.longIncentiveGrossSalaryTextIndex){
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveActualValueTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary field")];
                [relatedToCell setCellText:self.percentageGrossSal];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
                
            }else if(indexPath.row ==self.longIncentiveActualValueCheckBoxIndex){
                
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveActualValueCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell setKeyboardType:UIKeyboardTypeNumberPad];
                [numDaysCell setCellText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.longIncentiveActualValSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
                
            }else if (indexPath.row == self.longIncentiveActualValueTextIndex){
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveActualValueTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value field")];
                [relatedToCell setCellText: self.actualValue];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
                
            }else if (indexPath.row ==self.longIncentiveCurrencyIndex){
                CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"longIncentiveActualValCurrencyCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Currency", @"Placeholder for Currency field")];
                [relatedToCell setCellText:self.longTermCurrency];
                if (![self.longTermCurrency isEqualToString:@""] && self.longTermCurrency!=nil) {
                    [relatedToCell setCellCloseBtnOption:NO];
                }
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
            }
        }
        case CLSalaryBenefitsBenefitsIndex:{
            CLTappableTextViewCell *cell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"benefitsTappableTextCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell setCellPlaceHolderText:NSLocalizedString(@"Benefits", @"Placeholder for Benefits field")];
            [cell setCellText:self.benefitsText];
            [cell setCellFont:[UIFont systemFontOfSize:13]];
            [cell setCellIndexPath:indexPath];
            cell.delegate=self;
            return cell;
            
        }
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLSalaryBenefitsSalaryIndex:
            return NSLocalizedString(@"Salary", @"Placeholder for Salary field");
            break;
        case CLSalaryBenefitsAllowanceIndex:
            return NSLocalizedString(@"Allowances", @"Placeholder for Key Allowances field");
            break;
        case CLSalaryBenefitsIncentiveIndex:
            return NSLocalizedString(@"Incentive & Bonus (Target Value)", @"Placeholder for Incentive & Bonus (Target Value) field");
            break;
        case CLSalaryBenefitsLongTermIncentiveIndex:
            return NSLocalizedString(@"Long Term Incentives", @"Placeholder for Long Term Incentives field");
            break;
        case CLSalaryBenefitsBenefitsIndex:
            return NSLocalizedString(@"Benefits", @"Placeholder for Benefits field");
            break;
        default:
            return nil;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == CLSalaryBenefitsSalaryIndex) {
        return 3;
    }else if (section == CLSalaryBenefitsAllowanceIndex){
        return [self.allowanceArray count];
    }else if (section == CLSalaryBenefitsIncentiveIndex){
        return [self.incentiveArray count];;
    }else if (section == CLSalaryBenefitsLongTermIncentiveIndex){
        if (self.longIncentiveGrossSalSwitch && self.longIncentiveActualValSwitch) {
            return 7;
        }else if (self.longIncentiveGrossSalSwitch){
            return 5;
        }else if (self.longIncentiveActualValSwitch){
            return 6;
        }else{
            return 4;
        }
    }
    else{
        return 1;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLSalaryBenefitsAllowanceIndex) {
        
        CLAddAllowanceViewController *controller = [[CLAddAllowanceViewController alloc]initWithNibName:@"CLAddAllowanceViewController" bundle:[NSBundle mainBundle]];
        self.currentIndexPath =indexPath;
        controller.selectedAllowanceForEdit = [self.allowanceArray objectAtIndex:indexPath.row];
        controller.isEdit = YES;
        controller.delegate = self;
        [self.navigationController pushViewController:controller animated:YES];
        
    }else if (indexPath.section == CLSalaryBenefitsIncentiveIndex){
        
        CLAddIncentivesViewController *controller = [[CLAddIncentivesViewController alloc]initWithNibName:@"CLAddIncentivesViewController" bundle:[NSBundle mainBundle]];
        self.currentIndexPath =indexPath;
        controller.isEdit = YES;
        controller.delegate = self;
        controller.selectedIncentiveForEdit = [self.incentiveArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLSalaryBenefitsBenefitsIndex) {
        return MAX(44, [self getHeightForTokenFieldWithText:self.benefitsText]+10);
    }else{
        return 44;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    if (section == CLSalaryBenefitsAllowanceIndex) {
        return 37.0;
    }else if(section == CLSalaryBenefitsIncentiveIndex){
        return 37.0;
    }else{
        return 1.0;
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    if (section == CLSalaryBenefitsAllowanceIndex || section == CLSalaryBenefitsIncentiveIndex){
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        
        if (section == CLSalaryBenefitsAllowanceIndex){
            [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        }else if (section == CLSalaryBenefitsIncentiveIndex){
            [button addTarget:self action:@selector(bttnActionShowAddIncentiveModal:) forControlEvents:UIControlEventTouchUpInside];
        }
        
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        return sectionFooter;
        
    }else
        return nil;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == CLSalaryBenefitsAllowanceIndex) {
        return YES;
    }else if(indexPath.section == CLSalaryBenefitsIncentiveIndex){
        return YES;
    }else{
        return NO;
    }
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == CLSalaryBenefitsAllowanceIndex) {
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            [self.allowanceArray removeObjectAtIndex:indexPath.row];
            [self.tableView reloadData];
        }
    }else if (indexPath.section == CLSalaryBenefitsIncentiveIndex){
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            [self.incentiveArray removeObjectAtIndex:indexPath.row];
            [self.tableView reloadData];
        }
    }
}

-(void)bttnActionShowAddDetailModal:(UIButton *)sender{
    
    CLAddAllowanceViewController *controller = [[CLAddAllowanceViewController alloc]initWithNibName:@"CLAddAllowanceViewController" bundle:[NSBundle mainBundle]];
    controller.delegate =self;
    controller.selectedAllowanceCurrency = [[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[self.selectedCountry objectForKey:@"jobLocationCountryName"]]objectAtIndex:0];
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
    [self.navigationController presentViewController:navigation animated:YES completion:nil];
}

-(void)bttnActionShowAddIncentiveModal:(id)sender{
    
    CLAddIncentivesViewController *controller = [[CLAddIncentivesViewController alloc]initWithNibName:@"CLAddIncentivesViewController" bundle:[NSBundle mainBundle]];
    controller.delegate = self;
    controller.selectedIncentiveCurrency = [[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[self.selectedCountry objectForKey:@"jobLocationCountryName"]]objectAtIndex:0];
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
    [self.navigationController presentViewController:navigation animated:YES completion:nil];
    
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillClearContent:(CLSimpleTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (cell.cellIndexPath.section) {
        case CLSalaryBenefitsLongTermIncentiveIndex:{
            self.longTermIncentive = @"";
            self.selectedLongTermIncentiveDict =nil;
            break;
        }
        default:
            break;
    }
    [self.tableView reloadData];
}

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    [self.pickerView selectRow:0 inComponent:0 animated:YES];
    [self.pickerView reloadAllComponents];
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLSalaryBenefitsLongTermIncentiveIndex:{
            if (indexPath.row == self.longIncentiveBonusIndex) {
                self.longTermIncentive=text;
            }
            else if (indexPath.row == self.longIncentiveActualValueTextIndex){
                self.actualValue=text;
            }else if (indexPath.row == self.longIncentiveGrossSalaryTextIndex){
                self.percentageGrossSal =text;
            }
            break;
        }
        case CLSalaryIndex:{
            self.salary = text;
            break;
        }
        default:
            break;
    }
}

#pragma mark CLTappable cell delegate
- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    switch (indexPath.section) {
        case CLSalaryIndex:{
            if (indexPath.row == CLSalaryBasisIndex) {
                self.salaryBasis =@"";
                self.selectedSalaryBasis = nil;
            }else if (indexPath.row == CLSalaryCurrencyIndex){
                self.salaryCurrency = @"";
                self.selectedCurrency = nil;
            }
            break;
        }
        case CLSalaryBenefitsLongTermIncentiveIndex:{
            if (indexPath.row == self.longIncentiveFrequencyIndex) {
                self.frequency =@"";
                self.selectedLongTermFrequency = nil;
            }else if (indexPath.row == self.longIncentiveCurrencyIndex){
                self.longTermCurrency =@"";
                self.selectedLongTermCurrency =nil;
            }
             break;
        }
        default:
            break;
    }
   
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    
    if (indexPath.section == CLSalaryBenefitsBenefitsIndex) {
        CLBnefitsViewController *controller = [[CLBnefitsViewController alloc]initWithNibName:@"CLBnefitsViewController" bundle:[NSBundle mainBundle]];
        
        controller.alreadySelectedBenefits = self.benefits;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }else if (indexPath.section == CLSalaryBenefitsSalaryIndex && indexPath.row == CLSalaryBasisIndex){
        
        self.currentIndexPath =indexPath;
        CLFrequencyViewController *controller = [[CLFrequencyViewController alloc]initWithNibName:@"CLFrequencyViewController" bundle:[NSBundle mainBundle]];
        
        controller.alreadySelectedFrequency = self.selectedSalaryBasis;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }else if (indexPath.section == CLSalaryBenefitsSalaryIndex && indexPath.row == CLSalaryCurrencyIndex){
        self.currentIndexPath =indexPath;
        CLCurrencyViewController *controller = [[CLCurrencyViewController alloc]initWithNibName:@"CLCurrencyViewController" bundle:[NSBundle mainBundle]];
        
        controller.alreadySelectedCurrency = self.selectedCurrency;
        controller.delegate = self;
        
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }else if (indexPath.section == CLSalaryBenefitsLongTermIncentiveIndex && indexPath.row == self.longIncentiveCurrencyIndex){
        
        self.currentIndexPath =indexPath;
        CLCurrencyViewController *controller = [[CLCurrencyViewController alloc]initWithNibName:@"CLCurrencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedCurrency = self.selectedLongTermCurrency;
        controller.delegate = self;
        
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
        
    }
    else if (indexPath.section == CLSalaryBenefitsLongTermIncentiveIndex && indexPath.row == self.longIncentiveFrequencyIndex){
        
        self.currentIndexPath =indexPath;
        CLFrequencyViewController *controller = [[CLFrequencyViewController alloc]initWithNibName:@"CLFrequencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedFrequency = self.selectedLongTermFrequency;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }
}

#pragma mark CLTextCheckBox delegate
- (void)textCheckBoxBgChange:(CLTextCheckBoxCell *)cell withStatus:(BOOL)status{
    
    NSIndexPath *index=cell.cellIndexPath;
    [CLCommon doViewAnimation:self.view];
    if (index.section == CLSalaryBenefitsLongTermIncentiveIndex && index.row == self.longIncentiveGrossSalaryCheckBoxIndex){
        if (status) {
            self.longIncentiveGrossSalSwitch = YES;
            
            if(self.longIncentiveActualValSwitch)
            {
                self.longIncentiveActualValSwitch = NO;
                self.actualValue = @"";
                self.selectedLongTermCurrency = nil;

            }
        }else{
            self.longIncentiveGrossSalSwitch = NO;
            self.percentageGrossSal = @"";
        }
        [self updateLongIncentiveRowIndexes];
        [self.tableView reloadData];
        
    }else if (index.section == CLSalaryBenefitsLongTermIncentiveIndex && index.row == self.longIncentiveActualValueCheckBoxIndex){
        if (status) {
            self.longIncentiveActualValSwitch = YES;
            if (self.longTermCurrency==nil) {
//                self.longTermCurrency = [NSString stringWithFormat:@"%@/%@",[[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[[CLUserObject currentUser].country objectForKey:@"country"]]objectAtIndex:0] objectForKey:@"currencyCode"],[[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[[CLUserObject currentUser].country objectForKey:@"country"]]objectAtIndex:0] objectForKey:@"countryName"]];
                
                if ([self.selectedCurrency objectForKey:@"currencyCode"] && [self.selectedCurrency objectForKey:@"countryName"]) {
                    self.longTermCurrency = [NSString stringWithFormat:@"%@/%@",[self.selectedCurrency objectForKey:@"currencyCode"],[self.selectedCurrency objectForKey:@"countryName"]];
                }
                else{
                    self.longTermCurrency = [self.selectedCurrency objectForKey:@"currency"];
                }
                
                if (self.selectedLongTermCurrency == nil) {
                    self.selectedLongTermCurrency = [[NSMutableDictionary alloc]init];
                }
                if (self.longTermCurrency) {
                    [self.selectedLongTermCurrency setObject:self.longTermCurrency forKey:kCLCareerHistoryLongCurrencykey];
                }
                else{
                    [self.selectedLongTermCurrency setObject:@"" forKey:kCLCareerHistoryLongCurrencykey];
                }
//                [self.selectedLongTermCurrency setObject:[[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:[[CLUserObject currentUser].country objectForKey:@"country"]]objectAtIndex:0] objectForKey:@"countryCode"] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
                if (self.selectedCurrency) {
                    if ([self.selectedCurrency objectForKey:@"countryCode"]) {
                        [self.selectedLongTermCurrency setObject:[self.selectedCurrency objectForKey:@"countryCode"] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
                    } else{
                        [self.selectedLongTermCurrency setObject:[self.selectedCurrency objectForKey:@"id"] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
                    }
                }
            }
            if(self.longIncentiveGrossSalSwitch)
            {
                self.longIncentiveGrossSalSwitch = NO;
                self.percentageGrossSal = @"";
            }
        }else{
            self.longIncentiveActualValSwitch = NO;
            self.actualValue = @"";
            self.selectedLongTermCurrency = nil;
        }
        [self updateLongIncentiveRowIndexes];
        [self.tableView reloadData];
    }
}

#pragma mark - Allowance delegate method
-(void)allowanceController:(CLAddAllowanceViewController *)controller didAddOrChangeAllowance:(NSMutableDictionary *)editedAllowanceDict isEdit:(BOOL)isEdit{
    
    if (isEdit) {
        [self.allowanceArray removeObjectAtIndex:self.currentIndexPath.row];
        [self.allowanceArray insertObject:editedAllowanceDict atIndex:self.currentIndexPath.row];
    }else{
        if (self.allowanceArray ==nil) {
            self.allowanceArray = [[NSMutableArray alloc]init];
        }
        [self.allowanceArray addObject:editedAllowanceDict];
    }
    [self.tableView reloadData];
}

#pragma mark - Incentives delegate method
-(void)incentiveController:(CLAddIncentivesViewController *)controller didAddOrChangeIncentive:(NSMutableDictionary *)incentiveDict isEdit:(BOOL)isEdit{
    
    if (isEdit) {
        [self.incentiveArray removeObjectAtIndex:self.currentIndexPath.row];
        [self.incentiveArray insertObject:incentiveDict atIndex:self.currentIndexPath.row];
    }else{
        if (self.incentiveArray ==nil) {
            self.incentiveArray = [[NSMutableArray alloc]init];
        }
        [self.incentiveArray addObject:incentiveDict];
    }
    [self.tableView reloadData];
}

#pragma mark - benefit delegate method
-(void)benefitsController:(CLBnefitsViewController *)controller didAddBenefits:(NSMutableArray *)benefitsArray{
    
    self.benefits = benefitsArray;
    self.benefitsText = [self getBenefitsTextForTokenField:benefitsArray];
    [self.tableView reloadData];
}

#pragma mark - frequency delegate method
-(void)frequencyController:(CLFrequencyViewController *)controller didSelect:(NSMutableDictionary *)selectedDict{
    
    if (self.currentIndexPath.section == CLSalaryBenefitsSalaryIndex) {
        self.selectedSalaryBasis = selectedDict;
        self.salaryBasis = [selectedDict objectForKey:kFrequencyName];
    }else{
        self.selectedLongTermFrequency = selectedDict;
        self.frequency = [selectedDict objectForKey:kFrequencyName];
    }
    [self.tableView reloadData];
}

#pragma mark - currency delegate method
-(void)loadSelectedCurrencyDictionary:(NSMutableDictionary *)dictionary{
    
    NSString *string = [NSString stringWithFormat:@"%@/%@",[dictionary objectForKey:kjobPreferenceCurrencyCode],[dictionary objectForKey:kjobPreferenceCountryName]];
    
    if (self.currentIndexPath.section == CLSalaryBenefitsSalaryIndex) {
        if (self.selectedCurrency ==nil) {
            self.selectedCurrency = [[NSMutableDictionary alloc]init];
        }
        self.salaryCurrency = string;
        [self.selectedCurrency setObject:string forKey:kCLCareerHistoryLongCurrencykey];
        [self.selectedCurrency setObject:[dictionary objectForKey:kjobPreferenceCountryCode] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
//        self.longTermCurrency = string;
//        [self.selectedLongTermCurrency setObject:string forKey:kCLCareerHistoryLongCurrencykey];
//        [self.selectedLongTermCurrency setObject:[dictionary objectForKey:kjobPreferenceCountryCode] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
    }else{
        if (self.selectedLongTermCurrency ==nil) {
            self.selectedLongTermCurrency = [[NSMutableDictionary alloc]init];
        }
        self.longTermCurrency = string;
        [self.selectedLongTermCurrency setObject:string forKey:kCLCareerHistoryLongCurrencykey];
        [self.selectedLongTermCurrency setObject:[dictionary objectForKey:kjobPreferenceCountryCode] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
    }
    [self.tableView reloadData];
}

-(CGFloat)getHeightForTokenFieldWithText:(NSString*)text{
    
    [self.tokenTxtField setFont:[UIFont systemFontOfSize:13]];
    [self.tokenTxtField setPromptText:nil];
    [self.tokenTxtField removeAllTokens];
    [self.tokenTxtField addTokensWithTitleList:text];
    [self.tokenTxtField layoutTokensAnimated:NO];
    return self.tokenTxtField.bounds.size.height;
}
@end
