//
//  CLPreferredJobsViewController.h
//  CareerLine
//
//  Created by Abbin on 27/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CLPreferredJobsDelegate <NSObject>

-(void)loadSelectedPreferredJobs:(NSMutableDictionary*)dictionary;

@end

@interface CLPreferredJobsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong) NSMutableArray *passedOnPreferredJobsArray;
@property(nonatomic,weak) id <CLPreferredJobsDelegate> delegate;

@end
