//
//  CLFileObject.h
//  CareerLine
//
//  Created by CSG on 7/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLFileObject : NSObject

@property(nonatomic,strong)NSString *fileId;
@property(nonatomic,strong)NSString *fileTitle;
@property(nonatomic,strong)NSString *filePreviewUrl;
@property(nonatomic,strong)NSString *file;
@property(nonatomic,strong)NSString *filecaption;



//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

@end
