//
//  CLAllowanceLoadingsViewController.h
//  CareerLine
//
//  Created by RENJITH on 20/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CLAllowanceLoadingsViewController;
@protocol CLAllowanceAndLoadingDelegate <NSObject>

@optional

- (void)allowanceAndLoadingController:(CLAllowanceLoadingsViewController *)controller didSelect:(NSMutableDictionary *)selectedDict;

@end
@interface CLAllowanceLoadingsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic ,weak) id<CLAllowanceAndLoadingDelegate>delegate;
@property (nonatomic ,retain) NSMutableDictionary*alreadySelectedAllowane;
@end
