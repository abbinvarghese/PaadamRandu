//
//  CLSelectEducationViewController.m
//  CareerLine
//
//  Created by CSG on 4/21/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectEducationViewController.h"
#import "CLCoreDataHelper.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLSelectEducationViewController ()

@property(nonatomic,strong)NSMutableArray *educationArray;
@property(nonatomic,strong)NSMutableDictionary *selectedEduLevel;

@end

@implementation CLSelectEducationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Education Level", @"title for education selection page");
    [self setLeftNavigationButton];
    //[self setRightNavigationButton];
    //self.navigationItem.rightBarButtonItem.enabled=NO;
    if (self.alreadySelectedEduLevel!=nil) {
        self.selectedEduLevel = self.alreadySelectedEduLevel;
    }
    self.educationArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEducationListFromDBForCountry:self.cyCode];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark IBaction

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)bttnActionSelectionDone:(id)sender{
    dispatch_async(dispatch_get_main_queue(), ^{
    [self dismissViewControllerAnimated:YES completion:^(void){
        if([self.selectedEduLevel count]>0){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectEducationControllerDidSelectEducation:withDict:)]){
                [self.delegate selectEducationControllerDidSelectEducation:self withDict:self.selectedEduLevel];
            }
        }
    }];
    });
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.educationArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:13]];
        [cell.textLabel setNumberOfLines:0];
    }
    // if ([[self.selectedEduLevel objectForKey:keducationDictCode] isEqualToString:[[self.educationArray objectAtIndex:indexPath.row] objectForKey:keducationDictCode]])
    if ([self.selectedEduLevel objectForKey:keducationDictCode] == [[self.educationArray objectAtIndex:indexPath.row] objectForKey:keducationDictCode])
    {
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    
    NSMutableDictionary *eduLevel=[self.educationArray objectAtIndex:indexPath.row];
    cell.textLabel.text=[eduLevel objectForKey:keducationDictName];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.navigationItem.rightBarButtonItem.enabled=YES;
    self.selectedEduLevel=[self.educationArray objectAtIndex:indexPath.row];
    [self.tableView reloadData];
    [self bttnActionSelectionDone:nil];
}

//-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    return NSLocalizedString(@"Select your highest education level.", @"Title for education level");
//}
//
//- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
//    // Custom section header...
//    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
//    [header.textLabel setFont:kSectionHeaderFont];
//}

@end
