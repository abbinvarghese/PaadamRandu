//
//  CLPreviousNameObject.h
//  CareerLine
//
//  Created by CSG on 8/22/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLPreviousNameObject : NSObject

@property(nonatomic,strong)NSString *nameId;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSDate *nameDate;


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//get dictionary for object..
-(NSDictionary*)dictionaryForObject;


@end
