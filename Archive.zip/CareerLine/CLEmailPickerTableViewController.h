//
//  CLEmailPickerTableViewController.h
//  CareerLine
//
//  Created by CSG on 7/1/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLJobsObject.h"

@interface CLEmailPickerTableViewController : UITableViewController<UITextFieldDelegate>

@property(nonatomic, strong)CLJobsObject *job;

@end
