//
//  CLEmployeementTypeViewController.h
//  CareerLine
//
//  Created by RENJITH on 04/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLEmployeementTypeDetailsViewController.h"


@interface CLEmployeementTypeViewController : UITableViewController 
@property(nonatomic,weak) id <CLSelectEmpTypeDelegate> delegate;
@end
