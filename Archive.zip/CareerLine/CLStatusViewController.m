//
//  CLStatusViewController.m
//  CareerLine
//
//  Created by CSG on 1/21/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLStatusViewController.h"
#import "CLUserObject.h"
#import "CLPersonalProfileDetailsViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "CLSideMenuViewController.h"
//#import "CLGetStartedViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLEmploymentDetailsViewController.h"
#import "CLCRFEducationViewController.h"
#import "CLCRFAboutMeViewController.h"
#import "CLLocationDetailsViewController.h"

@interface CLStatusViewController ()

@property (weak, nonatomic) IBOutlet UIButton *bttnTrafficLightGreen;
@property (weak, nonatomic) IBOutlet UILabel *lblTrafficLightGreen;
@property (weak, nonatomic) IBOutlet UIButton *bttnTrafficLightAmber;
@property (weak, nonatomic) IBOutlet UILabel *lblTrafficLightAmber;
@property (weak, nonatomic) IBOutlet UIButton *bttnTrafficLightRed;
@property (weak, nonatomic) IBOutlet UILabel *lblTrafficLightRed;
@property (weak, nonatomic) IBOutlet UIImageView *trafficLightMainImage;
@property (weak, nonatomic) IBOutlet UILabel *lblHeadingText;
@property (weak, nonatomic) IBOutlet UILabel *lblSubHeadingText;
@property (weak, nonatomic) IBOutlet UILabel *lblPrivateMsg;
@property (weak, nonatomic) IBOutlet UIView *swipeView;

@property(nonatomic,assign)CLTrafficLightStatus selectedStatus;

- (IBAction)bttnActionChangeTrafficLightStatus:(id)sender;
@end

@implementation CLStatusViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToRightWithGestureRecognizer:)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToLeftWithGestureRecognizer:)];
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    
    [self.swipeView addGestureRecognizer:swipeRight];
    [self.swipeView addGestureRecognizer:swipeLeft];
    
    self.lblSubHeadingText.font=[UIFont fontWithName:@"Variable" size:15];
    self.title=NSLocalizedString(@"Status", @"Status page title");
    [self setupNavigationButtons];
    if(self.isFromWelcomeScreen){
        self.selectedStatus=CLTrafficLightGreenColor;
        [self updateInterfaceForTrafficLight:CLTrafficLightGreenColor];
    }
    self.lblPrivateMsg.text=NSLocalizedString(@"Please Select Your Career Status by Clicking on the Appropriate Icon to Receive Relevant Career Related Content, Training and Jobs.", @"Traffic light status page privacy msg");
}

- (void)slideToRightWithGestureRecognizer:(id)sender{

    UIButton *trafficLightBtn = [[UIButton alloc]init];
    if (self.selectedStatus == CLTrafficLightGreenColor) {
        trafficLightBtn.tag = CLTrafficLightGreenColor-1;
        [self bttnActionChangeTrafficLightStatus:trafficLightBtn];
    }else if (self.selectedStatus == CLTrafficLightAmberColor){
        trafficLightBtn.tag = CLTrafficLightAmberColor-1;
        [self bttnActionChangeTrafficLightStatus:trafficLightBtn];
    }
}

- (void)slideToLeftWithGestureRecognizer:(id)sender{
     UIButton *trafficLightBtn = [[UIButton alloc]init];
    if (self.selectedStatus == CLTrafficLightRedColor) {
        trafficLightBtn.tag = CLTrafficLightRedColor+1;
        [self bttnActionChangeTrafficLightStatus:trafficLightBtn];
    }else if (self.selectedStatus == CLTrafficLightAmberColor){
        trafficLightBtn.tag = CLTrafficLightAmberColor+1;
        [self bttnActionChangeTrafficLightStatus:trafficLightBtn];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    if(!self.isFromWelcomeScreen){
        [self updateInterfaceForTrafficLight:[CLUserObject currentUser].trafficLightStatus];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)bttnActionChangeTrafficLightStatus:(id)sender {
    UIButton *senderBttn=(UIButton *)sender;
    if(self.isFromWelcomeScreen){
        self.selectedStatus=(int)senderBttn.tag;
        [self updateInterfaceForTrafficLight:(CLTrafficLightStatus)senderBttn.tag];
    }
    else{
        CLTrafficLightStatus currentStatus=[CLUserObject currentUser].trafficLightStatus;
        
        [self updateInterfaceForTrafficLight:(CLTrafficLightStatus)senderBttn.tag];
        [CLUserObject currentUser].trafficLightStatus=(int)senderBttn.tag;
        
        if (!self.isFromWelcomeScreen) {
            [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateSideMenuDetails];
            [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
        }
        
        [CLUserObject changeTrafficLightStatus:(CLTrafficLightStatus)senderBttn.tag withEmail:[CLUserObject currentUser].email
                                        success:^{
                                            [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:NO];
                                        }
                                        failure:^(NSString *error){
                                            if (![error isEqualToString:@""]) {
                                                [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't update traffic light. Please try again.", @"Error message when traffic light cannot be updated") cancelbuttonName:NSLocalizedString(@"OK", @"alert cance button title")];
                                                [self updateInterfaceForTrafficLight:currentStatus];
                                                [CLUserObject currentUser].trafficLightStatus=currentStatus;
                                                [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateSideMenuDetails];
                                                if (!self.isFromWelcomeScreen) {
                                                    [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                                }
                                            }
                                        }];
    }
}

-(void)bttnActionApplyandNextPage:(id)sender{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Updating...", @"Text displayed in the loading indicator while updating traffic light");
    [progressHUD showInView:self.view];
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    [CLUserObject changeTrafficLightStatus:self.selectedStatus withEmail:[CLUserObject currentUser].email
                                    success:^{
                                        [progressHUD hideWithAnimation:YES];
                                        self.navigationItem.leftBarButtonItem.enabled = YES;
                                        self.navigationItem.rightBarButtonItem.enabled = YES;
                                        [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateSideMenuDetails];
                                        [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                        [CLCommon sharedInstance].userName=nil;
                                        [CLCommon sharedInstance].passWord=nil;
                                        [self dismissViewControllerAnimated:YES completion:nil];

                                    }
                                    failure:^(NSString *error){
                                        [progressHUD hideWithAnimation:YES];
                                        self.navigationItem.leftBarButtonItem.enabled = YES;
                                        self.navigationItem.rightBarButtonItem.enabled = YES;
                                        if (![error isEqualToString:@""]) {
                                            NSLog(@"error=%@",error);
                                            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't update traffic light. Please try again.", @"Error message when traffic light cannot be updated") cancelbuttonName:NSLocalizedString(@"OK", @"alert cance button title")];
                                        }
                                    }];
    
}

#pragma mark Utility Methods

-(void)updateInterfaceForTrafficLight:(CLTrafficLightStatus)lightStatus{
    [self.lblTrafficLightAmber setTextColor:[UIColor whiteColor]];
    [self.lblTrafficLightRed setTextColor:[UIColor whiteColor]];
    [self.lblTrafficLightGreen setTextColor:[UIColor whiteColor]];
    [self.bttnTrafficLightRed setBackgroundImage:[UIImage imageNamed:@"icon_happy_gray"] forState:UIControlStateNormal];
    [self.bttnTrafficLightAmber setBackgroundImage:[UIImage imageNamed:@"icon_open_gray"] forState:UIControlStateNormal];
    [self.bttnTrafficLightGreen setBackgroundImage:[UIImage imageNamed:@"icon_find_gray"] forState:UIControlStateNormal];
    
    [self.trafficLightMainImage setAlpha:0];
    [self.lblSubHeadingText setAlpha:0];
    
    switch (lightStatus) {
        case CLTrafficLightRedColor:{
            [self.lblTrafficLightRed setTextColor:ColorCode_SideMenuTextRed];
            [self.bttnTrafficLightRed setBackgroundImage:[UIImage imageNamed:@"icon_happy"] forState:UIControlStateNormal];
            [self.trafficLightMainImage setImage:[UIImage imageNamed:@"happyImage"]];
            [self.lblHeadingText setTextColor:ColorCode_SideMenuTextRed];
            [self.lblHeadingText setText:NSLocalizedString(@"Happy", @"Traffic light red color button text")];
            [self.lblSubHeadingText setText:NSLocalizedString(@"in your Current Job", @"status page-Traffic light red color subheading text")];
            if (!self.isFromWelcomeScreen) {
                [self.navigationController.navigationBar setBarTintColor:ColorCode_SideMenuTextRed];
            }
            break;
        }
        case CLTrafficLightAmberColor:{
            [self.lblTrafficLightAmber setTextColor:ColorCode_SideMenuTextAmber];
            [self.bttnTrafficLightAmber setBackgroundImage:[UIImage imageNamed:@"icon_open"] forState:UIControlStateNormal];
            [self.trafficLightMainImage setImage:[UIImage imageNamed:@"openImage"]];
            [self.lblHeadingText setTextColor:ColorCode_SideMenuTextAmber];
            [self.lblHeadingText setText:NSLocalizedString(@"Open", @"Traffic light amber color button text")];
            [self.lblSubHeadingText setText:NSLocalizedString(@"to Interesting Opportunities", @"status page-Traffic light amber color subheading text")];
            if (!self.isFromWelcomeScreen) {
                [self.navigationController.navigationBar setBarTintColor:ColorCode_SideMenuTextAmber];
            }
            break;
        }
        case CLTrafficLightGreenColor:{
            [self.lblTrafficLightGreen setTextColor:ColorCode_SideMenuTextGreen];
            [self.bttnTrafficLightGreen setBackgroundImage:[UIImage imageNamed:@"icon_find"] forState:UIControlStateNormal];
            [self.trafficLightMainImage setImage:[UIImage imageNamed:@"findImage"]];
            [self.lblHeadingText setTextColor:ColorCode_SideMenuTextGreen];
            [self.lblHeadingText setText:NSLocalizedString(@"Actively",  @"Traffic light green color button text")];
            [self.lblSubHeadingText setText:NSLocalizedString(@"Looking for a Change", @"status page-Traffic light green color subheading text")];
            if (!self.isFromWelcomeScreen) {
                [self.navigationController.navigationBar setBarTintColor:ColorCode_SideMenuTextGreen];
            }
            break;
        }
        default:
            break;
    }
    [UIView animateWithDuration:0.3 animations:^{
        [self.trafficLightMainImage setAlpha:1];
        [self.lblSubHeadingText setAlpha:1];
    }];
}


-(void)setupNavigationButtons{
    if(self.isFromWelcomeScreen){
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for status page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionApplyandNextPage:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
        if (self.needCustomBackButtons) {
            if (self.needCustomBackButtons) {
                UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Location", @"Text for status page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(backClicked)];
                self.navigationItem.leftBarButtonItem=leftNavBttn;
            }
        }
    }
    else{
        MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
        [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
    }
}

-(void)backClicked{
    CLLocationDetailsViewController *newVC = [[CLLocationDetailsViewController alloc]init];
    CLEmploymentDetailsViewController *newVC2 = [[CLEmploymentDetailsViewController alloc]init];
    CLCRFEducationViewController *newVC3 = [[CLCRFEducationViewController alloc]init];
    CLCRFAboutMeViewController *newVC4 = [[CLCRFAboutMeViewController alloc]init];
    NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [vcs insertObject:newVC atIndex:[vcs count]-1];
    [vcs insertObject:newVC2 atIndex:[vcs count]-2];
    [vcs insertObject:newVC3 atIndex:[vcs count]-3];
    [vcs insertObject:newVC4 atIndex:[vcs count]-4];
    [self.navigationController setViewControllers:vcs animated:NO];
    [self.navigationController popViewControllerAnimated:YES];
}


@end
