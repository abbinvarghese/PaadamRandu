//
//  CLResetPassworkController.h
//  CareerLine
//
//  Created by Abbin on 10/04/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLBorderedTextCell.h"

@interface CLResetPassworkController : UITableViewController<CLSimpleTextCellDelegate,UIAlertViewDelegate>

@property(nonatomic,retain) NSString *userID;
@property(nonatomic,retain) NSString *activeCode;

@end
