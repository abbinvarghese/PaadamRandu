//
//  CLCompanyObject.m
//  CareerLine
//
//  Created by CSG on 6/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCompanyObject.h"
#import "AFHTTPRequestOperationManager.h"
#import "NSDictionary+Additions.h"

#define kDebugMessages 0

@implementation CLCompanyObject

static NSOperationQueue *companyDetailsRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.companyId = [dictionary objectForKeyNotNull:kCLCompanyDetailIDkey];
    self.companyName = [dictionary objectForKeyNotNull:kCLCompanyDetailNamekey];
    self.companyDescription = [dictionary objectForKeyNotNull:kCLCompanyDetailDescriptionkey];
    self.companyLocation=[dictionary objectForKeyNotNull:kCLCompanyDetailLocationkey];
    self.companyWebsiteUrl = [dictionary objectForKeyNotNull:kCLCompanyDetailWebsiteUrlkey];
    self.companyLogoUrl = [dictionary objectForKeyNotNull:kCLCompanyDetailLogoUrlkey];
    
    return self;
}

+ (void)cancelCompanyDetailPendingRequests {
    [companyDetailsRequest cancelAllOperations];
    companyDetailsRequest = nil;
}

+ (void)companyDetailsForCompanyId:(NSString*)companyId success:(void (^)(CLCompanyObject *companyDetailObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLCompanyObject *companyDetailObj){};
    }
    
    NSDictionary *parameters = @{@"company": companyId};
    
    [companyDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        companyDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceCompanyDetailURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLCompanyObject *compObj=[[CLCompanyObject alloc] initWithDictionary:response];
                success(compObj);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
