//
//  CLHeightAdjustTextCell.h
//  CareerLine
//
//  Created by CSG on 7/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLReferencesObject.h"

#define kintialTextViewHeight 43

@class CLHeightAdjustTextCell;

//Delegate Methods...
@protocol CLHeightAdjustTextCellDelegate <NSObject>

@optional
- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView;
- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text;

@end

@interface CLHeightAdjustTextCell : UITableViewCell<UITextViewDelegate>

@property(nonatomic,weak) id <CLHeightAdjustTextCellDelegate> delegate;
@property(nonatomic,strong)NSString *text;
@property (strong, nonatomic) NSIndexPath *cellIndexPath;

-(NSNumber*)getTextViewHeight;
-(void)updateCellContents;
-(void)setCellFont:(UIFont*)font;
-(void)setPlaceHoldrText:(NSString *)text;
-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode;
-(void)setTextInputView:(id)picker;
-(void)setTextInputAccesoryView:(id)view;
-(void)resignCellFirstResponder;
-(BOOL)isCellFirstResponder;

@end
