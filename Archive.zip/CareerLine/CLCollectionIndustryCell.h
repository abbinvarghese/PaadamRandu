//
//  CLCollectionIndustryCell.h
//  CareerLine
//
//  Created by CSG on 2/18/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLCollectionIndustryCell : UICollectionViewCell

-(void)setCellText:(NSString*)text;
-(void)setCellImageWithName:(NSString*)imageName;

@end
