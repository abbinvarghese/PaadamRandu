//
//  CLProfileProtfolioViewController.m
//  CareerLine
//
//  Created by CSG on 7/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileProtfolioViewController.h"
#import "CLProjectObject.h"
#import "CLItemObject.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLEduProjectObject.h"

#define kCellDetailFont 14
#define kCellvalueBoldFont 16
#define kSectionHeaderFont 14

#define kSectionFooterBgColor [UIColor whiteColor]
#define kSectionHeaderBgColor [UIColor clearColor]

@interface CLProfileProtfolioViewController ()

typedef enum {
    CLProtfolioProjectsIndex = 0,
    clProtfolioEduIndex = 1,
    CLProtfolioItemsIndex= 2
} CLProfileProtfolioTableSectionIndex;

@property (weak, nonatomic) IBOutlet UITableView *protfolioTable;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property(nonatomic,assign)BOOL isDataLoaded;

@end

@implementation CLProfileProtfolioViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"Portfolio", @"Title for Portfolio page");
    self.isDataLoaded=NO;
    
//    self.isDataLoaded=YES;
    
    [self retrieveProtfolioDetails];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [self.protfolioTable reloadData];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Portfolio"];
}

-(void)viewDidDisappear:(BOOL)animated{
    [self.protfolioTable setEditing:NO animated:NO];
    [CLProtfolioObject cancelProtfolioPendingRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.isDataLoaded) {
        return 3;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==CLProtfolioProjectsIndex) {
        return [self.protfolio.projectsArray count];
    }
    else if (section == clProtfolioEduIndex){
        return [self.protfolio.educationProjects count];
    }
    else{
        return [self.protfolio.itemsArray count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"protfolioCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont boldSystemFontOfSize:kCellvalueBoldFont]];
        [cell.detailTextLabel setFont:[UIFont systemFontOfSize:kCellDetailFont]];
        [cell.textLabel setNumberOfLines:1];
        [cell.detailTextLabel setNumberOfLines:1];
        [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
        [cell.detailTextLabel setTextAlignment:NSTextAlignmentLeft];
    }
    [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
    
    [tableView setAllowsSelectionDuringEditing:YES];
    
    if (indexPath.section==CLProtfolioProjectsIndex) {
        
        if ([self.protfolio.projectsArray count])
            [tableView setEditing:YES animated:YES];
        
        CLProjectObject *projObj=[self.protfolio.projectsArray objectAtIndex:indexPath.row];
        cell.textLabel.text=projObj.projectTitle;
        cell.detailTextLabel.text=projObj.formattedDateString;
    }
    else if (indexPath.section==clProtfolioEduIndex){
        if ([self.protfolio.educationProjects count])
            [tableView setEditing:YES animated:YES];
        CLEduProjectObject *obj = [self.protfolio.educationProjects objectAtIndex:indexPath.row];
        cell.textLabel.text = obj.title;
        cell.detailTextLabel.text = obj.formateddDate;
        
        
    }
    else{
        if ([self.protfolio.itemsArray count])
            [tableView setEditing:YES animated:YES];
        
        CLItemObject *itemObj=[self.protfolio.itemsArray objectAtIndex:indexPath.row];
        cell.textLabel.text=itemObj.itemTitle;
        cell.detailTextLabel.text=nil;
    }
    
    return cell;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section==CLProtfolioProjectsIndex) {
        return NSLocalizedString(@"Projects/Functional Experiences", @"Projects/Functional Experiences");
    }
    else if(section == clProtfolioEduIndex){
        return NSLocalizedString(@"Education/Training Projects/Experiences", @"Education/Training Projects/Experiences");
    }
    else{
        return NSLocalizedString(@"Additional Portfolio Items", @"Additional Portfolio Item");
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.protfolioTable.bounds.size.width, 22);
    [sectionFooter addSubview:button];
    
    return sectionFooter;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        return 50;
    }
    else{
        return 44;
    }
}

#pragma mark UITableView Delegates
    
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLProtfolioProjectsIndex:{
            CLPortfolioProjectsViewController *projController=[[CLPortfolioProjectsViewController alloc] initWithStyle:UITableViewStylePlain];
            projController.isEditMode=YES;
            projController.projectObj=[self.protfolio.projectsArray objectAtIndex:indexPath.row];
            projController.careerListArray=self.protfolio.careerListArray;
            [self.navigationController pushViewController:projController animated:YES];
            break;
        }
        case CLProtfolioItemsIndex:{
            CLPortfolioItemViewController *itemsController=[[CLPortfolioItemViewController alloc] initWithStyle:UITableViewStylePlain];
            itemsController.isEditMode=YES;
            itemsController.itemObj=[self.protfolio.itemsArray objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:itemsController animated:YES];
            break;
        }
        case clProtfolioEduIndex:{
            CLPortfolioProjectsViewController *projController=[[CLPortfolioProjectsViewController alloc] initWithStyle:UITableViewStylePlain];
            projController.isEditMode=YES;
            projController.eduObj=[self.protfolio.educationProjects objectAtIndex:indexPath.row];
            projController.coursesArray=self.protfolio.courses;
            projController.forEdu = YES;
            [self.navigationController pushViewController:projController animated:YES];
            break;
        }
            
        default:
            break;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        switch (indexPath.section) {
            case CLProtfolioProjectsIndex:{
                [self removeProjectAtIndexPath:indexPath];
                break;
            }
            case CLProtfolioItemsIndex:{
                [self removeItemAtIndexPath:indexPath];
                break;
            }
            case clProtfolioEduIndex:{
                [self removeEduAtIndex:indexPath];
                break;
            }
            default:
                break;
        }
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:[UIFont systemFontOfSize:kSectionHeaderFont]];
}

#pragma mark Utility Methods

-(void)retrieveProtfolioDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    [CLProtfolioObject getProtfolioDetailsForUser:[CLUserObject currentUser].userID
                                          success:^(CLProtfolioObject *protfolioObj){
                                              [progressHUD hideWithAnimation:YES];
                                              self.protfolio=protfolioObj;
                                              self.isDataLoaded=YES;
                                              [self.protfolioTable reloadData];
                                              if (self.selectedRow != 0) {
                                                  NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:_selectedRow];
                                                  [self.protfolioTable scrollToRowAtIndexPath:indexPath
                                                                                 atScrollPosition:UITableViewScrollPositionTop
                                                                                         animated:NO];
                                              }
                                              _selectedRow = 0;
                                          }
                                          failure:^(NSString *error){
                                              if (![error isEqualToString:@""]) {
                                                  [progressHUD hideWithAnimation:YES];
                                                  self.isDataLoaded=NO;
                                                  [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                                  
                                              }
                                          }];
}

-(void)removeProjectAtIndexPath:(NSIndexPath *)indexPath{
    CLProjectObject *projObj=(CLProjectObject*)[self.protfolio.projectsArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLProjectObject deleteProject:projObj.projectId forUser:[CLUserObject currentUser].userID success:^(){
                                               [progressHUD hideWithAnimation:YES];
                                               self.navigationItem.hidesBackButton=NO;
                                               [self.protfolio.projectsArray removeObjectAtIndex:indexPath.row];
                                               if(indexPath.row==0 && [self.protfolio.projectsArray count]==0){
                                                   [self.protfolioTable reloadData];
                                               }
                                               else{
                                                   [self.protfolioTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                               }
                                           }
                                           failure:^(NSString *error){
                                               if (![error isEqualToString:@""]) {
                                                   [progressHUD hideWithAnimation:YES];
                                                   self.navigationItem.hidesBackButton=NO;
                                                   [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                               }
                                           }];
}

-(void)removeEduAtIndex:(NSIndexPath*)indexPath{
    CLEduProjectObject *eduObj = (CLEduProjectObject*)[self.protfolio.educationProjects objectAtIndex:indexPath.row];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLEduProjectObject deleteEdu:eduObj.idNum forUser:[CLUserObject currentUser].userID success:^(){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.hidesBackButton=NO;
        [self.protfolio.educationProjects removeObjectAtIndex:indexPath.row];
        if(indexPath.row==0 && [self.protfolio.educationProjects count]==0){
            [self.protfolioTable reloadData];
        }
        else{
            [self.protfolioTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }failure:^(NSString *error){
        if (![error isEqualToString:@""]) {
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.hidesBackButton=NO;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

-(void)removeItemAtIndexPath:(NSIndexPath *)indexPath{
    CLItemObject *itemObj=(CLItemObject*)[self.protfolio.itemsArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLItemObject deleteItem:itemObj.itemId forUser:[CLUserObject currentUser].userID success:^(){
                                     [progressHUD hideWithAnimation:YES];
                                     self.navigationItem.hidesBackButton=NO;
                                     [self.protfolio.itemsArray removeObjectAtIndex:indexPath.row];
                                     if(indexPath.row==0 && [self.protfolio.itemsArray count]==0){
                                         [self.protfolioTable reloadData];
                                     }
                                     else{
                                         [self.protfolioTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                     }
                                 }
                                 failure:^(NSString *error){
                                     if (![error isEqualToString:@""]) {
                                         [progressHUD hideWithAnimation:YES];
                                         self.navigationItem.hidesBackButton=NO;
                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                     }
                                 }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

#pragma mark IBActions

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    switch (sender.tag) {
        case CLProtfolioProjectsIndex:{
            CLPortfolioProjectsViewController *projController=[[CLPortfolioProjectsViewController alloc] initWithStyle:UITableViewStylePlain];
            projController.isEditMode=NO;
            projController.projectObj=nil;
            projController.careerListArray=self.protfolio.careerListArray;
            projController.delegate=self;
            UINavigationController *projNavigation=[[UINavigationController alloc] initWithRootViewController:projController];
            [self presentViewController:projNavigation animated:YES completion:nil];
            break;
        }
        case CLProtfolioItemsIndex:{
            CLPortfolioItemViewController *itemController=[[CLPortfolioItemViewController alloc] initWithStyle:UITableViewStylePlain];
            itemController.isEditMode=NO;
            itemController.itemObj=nil;
            itemController.delegate=self;
            UINavigationController *itemNavigation=[[UINavigationController alloc] initWithRootViewController:itemController];
            [self presentViewController:itemNavigation animated:YES completion:nil];
            break;
        }
        case clProtfolioEduIndex:{
            CLPortfolioProjectsViewController *projController=[[CLPortfolioProjectsViewController alloc] initWithStyle:UITableViewStylePlain];
            projController.isEditMode=NO;
            projController.projectObj=nil;
            projController.forEdu=YES;
            projController.coursesArray=self.protfolio.courses;
            projController.delegate=self;
            UINavigationController *projNavigation=[[UINavigationController alloc] initWithRootViewController:projController];
            [self presentViewController:projNavigation animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
}

#pragma mark CLWorkAchievementControllerDelegate Methods

- (void)projectsController:(CLPortfolioProjectsViewController *)controller didAddProject:(CLProjectObject *)projObj fromEdu:(BOOL)Education{
    if (Education) {
        [self.protfolio.educationProjects addObject:projObj];
        [self.protfolioTable reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
    }
    else{
        [self.protfolio.projectsArray addObject:projObj];
        [self.protfolioTable reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark CLAssessmentControllerDelegate Methods

- (void)itemsController:(CLPortfolioItemViewController *)controller didAddItem:(CLItemObject *)itemObj{
    [self.protfolio.itemsArray addObject:itemObj];
    [self.protfolioTable reloadSections:[NSIndexSet indexSetWithIndex:2] withRowAnimation:UITableViewRowAnimationFade];
}

@end
