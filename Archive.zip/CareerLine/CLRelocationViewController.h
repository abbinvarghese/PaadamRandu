//
//  CLRelocationViewController.h
//  CareerLine
//
//  Created by RENJITH on 10/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLTappableTextViewCell.h"
#import "CLFieldEditViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLRelocationObject.h"

@protocol RelocationDelegate <NSObject>

-(void)relocationCompletedSelectionWith:(NSMutableDictionary*)dictionary;

@end

@interface CLRelocationViewController : UITableViewController<CLTappableCellDelegate,CLFieldEditDelegate,HTProgressHUDDelegate>

@property(nonatomic) BOOL fromTwentyField;
@property (nonatomic,retain) CLRelocationObject *relocObj;
@property(nonatomic,retain) NSMutableDictionary *currentLocationDictionary;
@property(nonatomic,retain) id <RelocationDelegate> delegate;
@property (nonatomic, assign)NSInteger selectedRow;


@end
