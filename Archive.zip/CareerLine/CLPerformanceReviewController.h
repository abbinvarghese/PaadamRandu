//
//  CLPerformanceReviewController.h
//  CareerLine
//
//  Created by Pravin on 10/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLPerformanceReviewObject.h"
#import "CLHeightAdjustTextCell.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLPerformanceReviewController;

//Delegate Methods...
@protocol CLPerformanceReviewControllerDelegate <NSObject>

@optional
- (void)performanceReviewController:(CLPerformanceReviewController *)controller didAddPerformanceReview:(CLPerformanceReviewObject*)perfRevObj;

@end

@interface CLPerformanceReviewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,UIPickerViewDelegate,UIPickerViewDataSource,CLProfilePhotoListingGridCellDelegate
,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLPerformanceReviewControllerDelegate> delegate;
@property(nonatomic,strong)CLPerformanceReviewObject *perfObj;
@property(nonatomic,strong)NSMutableArray *careerListArray;
@property(nonatomic,assign)BOOL isEditMode;

@end
