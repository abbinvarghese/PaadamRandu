//
//  CLSimpleTextCell.h
//  CareerLine
//
//  Created by CSG on 2/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSimpleTextCell;

//Delegate Methods...
@protocol CLSimpleTextCellDelegate <NSObject>

@optional
- (void)cellWillBeginEditing:(UITableViewCell *)cell forTextField:(UITextField*)textField;
- (void)cellShouldReturn:(UITableViewCell *)cell forTextField:(UITextField*)textField;
- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text;
- (void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextField:(UITextField*)textField;

@end

@interface CLSimpleTextCell : UITableViewCell<UITextFieldDelegate>

@property(nonatomic,weak) id <CLSimpleTextCellDelegate> delegate;
@property (strong, nonatomic) NSIndexPath *cellIndexPath;

-(NSString*)getEnteredText;
-(void)setCellText:(NSString*)text;
-(void)setCellFont:(UIFont*)font;
-(void)setPlaceHoldrText:(NSString *)text;
-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode;
-(void)setCellClearButtonMode:(UITextFieldViewMode)mode;
-(void)setTextInputView:(id)picker;
-(void)setTextInputAccesoryView:(id)view;
-(void)resignCellFirstResponder;
-(void)enableCellField;
-(void)disableCellField;
-(BOOL)isCellFirstResponder;
-(void)setInputFieldWidth:(CGFloat)width;
-(void)disableCelltxtField;
-(void)enableCelltxtField;
-(void)setKeyboardType :(UIKeyboardType)type;
-(void)changeCelltxtFieldColor:(NSString *)hexCode;
-(void)becomeFirstResponder;
-(void)returnKeyType:(UIReturnKeyType)returnKeyType;
@end
