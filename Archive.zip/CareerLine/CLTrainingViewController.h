//
//  CLTrainingViewController.h
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLTrainingObject.h"
#import "CLSimpleTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLProfilePhotoListingGridCell.h"
#import "HTProgressHUD.h"
#import "CLSelectLocationViewController.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLSimpleTappableTextCell.h"

@class CLTrainingViewController;

@protocol CLTrainingDelegate <NSObject>

@optional
-(void)qualificationTraining:(CLTrainingViewController *)controller didAddTraining:(CLTrainingObject *)trainingObj;

@end



@interface CLTrainingViewController : UITableViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLProfilePhotoListingGridCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate,CLTextCheckBoxCellDelegate>

@property (nonatomic, weak) id <CLTrainingDelegate> delegate;
@property (nonatomic, assign) BOOL isEditMode;
@property (nonatomic, retain) CLTrainingObject *trainingObj;
@end
