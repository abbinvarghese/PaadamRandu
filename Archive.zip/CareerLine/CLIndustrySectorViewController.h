//
//  CLIndustrySectorViewController.h
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLIndustryGroupViewController.h"
@class CLIndustrySectorViewController;

//Delegate Methods...
@protocol CLEditIndustryDelegate <NSObject>

@required
- (void)selectIndustryControllerDidDeleteIndustry:(CLIndustrySectorViewController*)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray;

@end
@interface CLIndustrySectorViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,assign) BOOL singleSelection;
@property (nonatomic ,strong) NSMutableArray *alreadySelectedIndustries;
@property (nonatomic ,strong) NSMutableArray *selectedIndustryArray;
@property(nonatomic,weak) id <CLEditIndustryDelegate> delegate;
@property(nonatomic,assign)BOOL enableSelectAll;
@property (nonatomic, strong)  NSMutableArray *detailsArray;
@end
       