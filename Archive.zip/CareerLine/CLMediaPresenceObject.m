//
//  CLMediaPresence.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLMediaPresenceObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLMediaPresenceObject

static NSOperationQueue *saveMediaRequest;
static NSOperationQueue *deleteMediaRequest;


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.mediaPresenceId=[dictionary objectForKeyNotNull:kCLProfileAboutMeMediaIdkey];
    self.websiteName=[dictionary objectForKeyNotNull:kCLProfileAboutMeMediaWebsiteTitlekey];
    self.websiteUrl=[dictionary objectForKeyNotNull:kCLProfileAboutMeMediaWebsiteUrlkey];
    self.websiteDescription=[dictionary objectForKeyNotNull:kCLProfileAboutMeMediaWebsiteDescriptionkey];
    
    return self;
}

+ (void)saveMediaPresence:(NSString*)mediaId forUser:(NSString*)userId websitetitle:(NSString*)title websiteUrl:(NSString *)url remarks:(NSString*)remarks editMode:(BOOL)isEditMode success:(void (^)(NSString *achievementId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *mediaId){};
    }
    
    NSString *otherText = @"";
    
    if (![title isEqualToString:@"Website"] && ![title isEqualToString:@"Facebook"] && ![title isEqualToString:@"Twitter"] && ![title isEqualToString:@"Blog"] && ![title isEqualToString:@"Google+"]) {
        otherText = title;
        title = @"Other";
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": mediaId, @"type":title, @"url":url, @"remarks":remarks ,@"otherText":otherText};
    }
    else{
        parameters = @{@"user": userId, @"type":title, @"url":url, @"remarks":remarks ,@"otherText":otherText};
    }
    
    [saveMediaRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveMediaRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeSaveMediaURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"save media JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAboutMeSaveMediaIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)deleteWebsite:(NSString*)mediaId forUser:(NSString*)userId success:(void (^)(NSString *mediaId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *mediaId){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": mediaId};
    
    [deleteMediaRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteMediaRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeDeleteMediaURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete media JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAboutMeDeleteMediaIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
