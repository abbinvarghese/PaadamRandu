//
//  CLCertificationViewController.m
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCertificationViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLUserObject.h"
#import "CLDocumentViewController.h"
#import "CLQualificationObject.h"


#define kAddCertificationDocType @"CE"
#define kCellTextFontsize 14

@interface CLCertificationViewController ()

typedef enum {
    CLCertificationNameIndex = 0,
    CLCertificationInstitutionIndex= 1,
    CLCertificationCountryIndex = 2,
    CLCertificationLocationIndex= 3,
    CLCertificationProgressIndex = 4,
    CLCertificationStartDateIndex = 5,
    CLCertificationEndDateIndex = 6,
    CLCertificationDescIndex = 7,
    CLCertificationDocsIndex = 8
} CLCertificationTableSectionIndex;

@property(strong,nonatomic)NSString *nameText;
@property(strong,nonatomic)NSString *institutionText;
@property(strong,nonatomic)NSString *locationText;
@property(strong,nonatomic)NSDate *issuedOn;
@property(strong,nonatomic)NSDate *startDate;
@property(strong,nonatomic)NSDate *completedDate;
@property(strong,nonatomic)NSDate *endDate;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic, assign)BOOL isProgress;
@property(nonatomic, assign)BOOL isLifeTime;
@property(nonatomic,assign) BOOL forCountry;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (nonatomic,strong) NSNumber *descriptionHeight;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbarWithOutCancel;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property (nonatomic, strong) NSMutableDictionary *selectedCurrentLocation;
@property (nonatomic, strong) NSMutableDictionary *selectedCountry;
@end

@implementation CLCertificationViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Certification"];
}
- (void)viewDidLoad
{
    
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Certification", @"certification detail heading");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"nameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"institutionTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"startDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"completedDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"endDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"issuedOnDateTextCellIdentifier"];
    
    
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"expiryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentLocationCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentCountryIdentifier"];
    
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.toolbarWithOutCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        [datePickr setDate:newDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    if (self.isEditMode) {
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:self.certificationObj.location.countryName forKey:@"country"];
        [self.selectedCountry setObject:self.certificationObj.location.countryCode forKey:@"countryCode"];
        self.selectedCurrentLocation = [[NSMutableDictionary alloc]init];
        [self.selectedCurrentLocation setObject:self.certificationObj.location.locationCode forKey:@"jobLocationCode"];
        [self.selectedCurrentLocation setObject:self.certificationObj.location.countryName forKey:@"jobLocationCountryName"];
        [self.selectedCurrentLocation setObject:self.certificationObj.location.adminArea forKey:@"jobLocationAdminArea"];
        [self.selectedCurrentLocation setObject:self.certificationObj.location.countryCode  forKey:@"jobLocationCountryCode"];
        [self.selectedCurrentLocation setObject:self.certificationObj.location.locName forKey:@"jobLocationName"];

        self.nameText = self.certificationObj.title;
        self.institutionText = self.certificationObj.institution;
        self.locationText = self.certificationObj.location.locationName;
        self.issuedOn = self.certificationObj.issuedOnDate;
        self.startDate = self.certificationObj.fromDate;
        self.completedDate = self.certificationObj.completionDate;
        self.endDate = self.certificationObj.toDate;
        self.descriptionText = self.certificationObj.contents;
        self.isProgress = self.certificationObj.isProgress;
        self.isLifeTime = self.certificationObj.isLifeValid;
    }else{
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"country"]  forKey:@"country"];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:@"countryCode"];

        self.nameText = @"";
        self.institutionText = @"";
        self.locationText = @"";
        self.startDate = nil;
        self.completedDate = nil;
        self.endDate = nil;
        self.issuedOn = nil;
        self.descriptionText = @"";
    }
    
}
-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Membership modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}
-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}
-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    
    if(datePicker.tag == CLCertificationStartDateIndex){
        
        if (self.isProgress) {
            self.startDate=date;
            
            CLSimpleTextCell *startDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLCertificationStartDateIndex]];
            [startDateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
        }else{
            self.issuedOn=date;
            
            CLSimpleTextCell *issuedOnDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLCertificationStartDateIndex]];
            [issuedOnDateCell setCellText:[CLCommon getStringForDate:self.issuedOn andLocalFormat:@"MMMMdy"]];
        }
        
    }else if(datePicker.tag == CLCertificationEndDateIndex){
        if (self.isProgress) {
            
            self.completedDate=date;
            CLSimpleTextCell *endDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLCertificationEndDateIndex]];
            [endDateCell setCellText:[CLCommon getStringForDate:self.completedDate andLocalFormat:@"MMMMdy"]];
        }else{
            
            self.endDate=date;
            CLSimpleTextCell *endDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLCertificationEndDateIndex]];
            [endDateCell setCellText:[CLCommon getStringForDate:self.endDate andLocalFormat:@"MMMMdy"]];
        }
    }
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    if (cell.cellIndexPath.section == CLCertificationStartDateIndex){
        if (self.isProgress) {
            if (self.startDate==nil || !([self.startDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.startDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else{
            if (self.issuedOn==nil || !([self.issuedOn compare:self.datePicker.date] == NSOrderedSame)) {
                self.issuedOn=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        
    }else if(cell.cellIndexPath.section == CLCertificationEndDateIndex){
        if (self.isProgress) {
            if (self.completedDate==nil || !([self.completedDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.completedDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else{
            if (self.endDate==nil || !([self.endDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.endDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
    
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

- (IBAction)toolbarWithoutCancelAction:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark HTProgressHUD delegates
- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(qualificationCertification:didAddCertification:)]){
                [self.delegate qualificationCertification:self didAddCertification:self.certificationObj];
            }
            
        }];
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveCertificationForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveCertificationForEdit:NO];
    }
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    
    //Certification Name validation..
    if ([self.nameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Certification/Qualification.", @"Error Message for null Certification/Qualification field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.nameText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Certification/Qualification Length.", @"Error Message for length of Certification/Qualification field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    // institution validation..
    if ([self.institutionText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Institution.", @"Error Message for null Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.institutionText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Institution Length.", @"Error Message for length of Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Location validation
//     if ([self.selectedCurrentLocation count] ==0 && [self.locationText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    
    
    if (self.isProgress) {
        //Date validation..
        if (self.startDate==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Start Date.", @"Error Message for null start date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        //Date validation..
        if (self.completedDate ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Completed / Expected Completion Date.", @"Error Message for null Completed / Expected Completion Date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
            
        }
        if (self.startDate!=nil && self.completedDate !=nil) {
            if( [self.startDate timeIntervalSinceDate:self.completedDate] >= 0 ){
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Completion Date Should Greater Than Start Date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                
                return isValid=NO;
            }
        }
    }else{
        //Date validation..
        if (self.issuedOn ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Issued On Date.", @"Error Message for null Issued on field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        //Date validation..
        if (self.endDate==nil && !self.isLifeTime) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Date Of Expiry.", @"Error Message for null Date of Expiry field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        if (self.issuedOn!=nil && self.endDate !=nil) {
            if( [self.issuedOn timeIntervalSinceDate:self.endDate] >= 0 ){
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"End Date should be greater than Issued on date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                
                return isValid=NO;
            }
        }
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}
-(void)saveCertificationForEdit:(BOOL)isEditMode{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    CLCertificationObject *newCertObj=[[CLCertificationObject alloc] init];
    if (isEditMode) {
        
        newCertObj.certificationId = self.certificationObj.certificationId;
        
    }else{
        newCertObj.certificationId = nil;
    }
    newCertObj.title = self.nameText;
    newCertObj.institution = self.institutionText;
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]init];
//    if (self.selectedCurrentLocation == nil) {
//        if (self.certificationObj.location.locationName !=nil) {
//            [locDict setObject:self.certificationObj.location.locationName forKey:kCLProfileAboutMeLocNamekey];
//            [locDict setObject:self.certificationObj.location.locationCode forKey:kCLProfileAboutMeLocCodekey];
//            [locDict setObject:self.certificationObj.location.countryCode forKey:kCLQlfitnCertificationLocationCountrykey];
//        }
//        else if (self.selectedCountry){
//            [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnCertificationLocationCountrykey];
//        }
//        
//    }else{
    if (self.selectedCurrentLocation != nil) {
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCountryCode] forKey:kCLQlfitnCertificationLocationCountrykey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCode] forKey:kCLProfileAboutMeLocCodekey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationName] forKey:kCLProfileAboutMeLocNamekey];
    }
    else{
        [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnTrainingLocationCountrykey];
    }
    newCertObj.location = [[CLLocationObject alloc]initWithDictionary:locDict];
    newCertObj.fromDate = self.startDate;
    newCertObj.toDate = self.endDate;
    newCertObj.issuedOnDate = self.issuedOn;
    newCertObj.isProgress = self.isProgress;
    newCertObj.isLifeValid = self.isLifeTime;
    newCertObj.completionDate = self.completedDate;
    newCertObj.contents = self.descriptionText;
    
    [CLCertificationObject saveCertification:newCertObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *certificationId) {
//        if (isEditMode) {
//            self.certificationObj.title = newCertObj.title;
//            self.certificationObj.institution = newCertObj.institution;
//            self.certificationObj.issuedOnDate = newCertObj.issuedOnDate;
//            self.certificationObj.isProgress = newCertObj.isProgress;
//            self.certificationObj.isLifeValid = newCertObj.isLifeValid;
//            self.certificationObj.fromDate = newCertObj.fromDate;
//            self.certificationObj.toDate = newCertObj.toDate;
//            self.certificationObj.completionDate = newCertObj.completionDate;
//            self.certificationObj.location = newCertObj.location;
//            self.certificationObj.contents = newCertObj.contents;
//            
//        }else{
//            newCertObj.certificationId = certificationId;
//            self.certificationObj =newCertObj;
//        }
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save education. Please try again later.", @"Error message when education cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 9;
    }
    return 8;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == CLCertificationEndDateIndex && !self.isProgress) {
        return 2;
    }else{
        return 1;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLCertificationNameIndex:{
            CLSimpleTextCell *certificationCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nameTextCellIdentifier"];
            certificationCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [certificationCell setTextInputAccesoryView:self.toolbarWithOutCancel];
            [certificationCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [certificationCell setPlaceHoldrText:NSLocalizedString(@"Certification Title", @"Placeholder for Certification Title")];
            [certificationCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [certificationCell setCellText:self.nameText];
            [certificationCell setCellIndexPath:indexPath];
            certificationCell.delegate=self;
            return certificationCell;
            break;
        }
        case CLCertificationCountryIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentCountryIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Country", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCountry) {
                [currLoccell setCellText:[NSString stringWithFormat:@"%@",[self.selectedCountry objectForKey:@"country"]]];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
        }
            break;
            
        case CLCertificationInstitutionIndex:{
            CLSimpleTextCell *institutionCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"institutionTextCellIdentifier"];
            institutionCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [institutionCell setTextInputAccesoryView:self.toolbarWithOutCancel];
            [institutionCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [institutionCell setPlaceHoldrText:NSLocalizedString(@"Institution", @"Placeholder for Institution field")];
            [institutionCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [institutionCell setCellText:self.institutionText];
            [institutionCell setCellIndexPath:indexPath];
            institutionCell.delegate=self;
            return institutionCell;
            break;
        }
        case CLCertificationLocationIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentLocationCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Location (City/Town/Village, Country)", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCurrentLocation) {
                if ([[self.selectedCurrentLocation objectForKey:@"jobLocationCode"]isEqualToString:@""]) {
                    [currLoccell setCellText:@""];
                }
                else{
                    [currLoccell setCellCloseBtnOption:NO];
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]]];
                }
            }
            else{
                [currLoccell setCellText:@""];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
            break;
        }
        case CLCertificationProgressIndex:{
            
            static NSString *CellIdentifier = @"Cell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            
            UISwitch *btn = [[UISwitch alloc]init];
            btn.onTintColor = [CLCommon sharedInstance].currentTrafficLightColor;
            btn.tag = [[NSNumber numberWithBool:self.isProgress] integerValue];
            [btn setOn:self.isProgress];
            cell.selectionStyle = UITableViewCellAccessoryNone;
            [btn addTarget:self action:@selector(progressStatusSwtchAction:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.textLabel.font = [UIFont systemFontOfSize:kCellTextFontsize];
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.text = NSLocalizedString(@" Certification Is Still in Progress or Being Achieved", @"Placeholder for This Certification is still in progress or being achieved field");
            cell.accessoryView =btn;
            
            return cell;
            break;
            
        }
        case CLCertificationStartDateIndex:{
            if (self.isProgress) {
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"startDateTextCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.datePicker];
                //self.datePicker.tag = indexPath.section;
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [dateCell setPlaceHoldrText:NSLocalizedString(@"Start Date", @"Placeholder for date field")];
                [dateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
                [dateCell setCellIndexPath:indexPath];
                dateCell.delegate=self;
                return dateCell;
                break;
            }else{
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"issuedOnDateTextCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.datePicker];
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [dateCell setPlaceHoldrText:NSLocalizedString(@"Issued on", @"Placeholder for Issued on Date field")];
                [dateCell setCellText:[CLCommon getStringForDate:self.issuedOn andLocalFormat:@"MMMMdy"]];
                [dateCell setCellIndexPath:indexPath];
                dateCell.delegate=self;
                return dateCell;
                break;
            }
            
        }
        case CLCertificationEndDateIndex:{
            
            if (indexPath.row == 0) {
                if (self.isProgress) {
                    CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"completedDateTextCellIdentifier"];
                    dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [dateCell setTextInputView:self.datePicker];
                    [dateCell setTextInputAccesoryView:self.keyboardResignView];
                    [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                    [dateCell setPlaceHoldrText:NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date field")];
                    [dateCell setCellText:[CLCommon getStringForDate:self.completedDate andLocalFormat:@"MMMMdy"]];
                    [dateCell setCellIndexPath:indexPath];
                    dateCell.delegate=self;
                    return dateCell;
                    break;
                }else{
                    CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"endDateTextCellIdentifier"];
                    dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [dateCell setTextInputView:self.datePicker];
                    [dateCell setTextInputAccesoryView:self.keyboardResignView];
                    [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                    [dateCell setPlaceHoldrText:NSLocalizedString(@"Date of Expiry", @"Placeholder for date field")];
                    
                    if (self.isLifeTime) {
                        [dateCell disableCellField];
                        [dateCell setCellText:@""];
                    }else{
                        [dateCell enableCellField];
                        [dateCell setCellText:[CLCommon getStringForDate:self.endDate andLocalFormat:@"MMMMdy"]];
                    }
                    [dateCell setCellIndexPath:indexPath];
                    dateCell.delegate=self;
                    return dateCell;
                    break;
                }
            }else{
                CLTextCheckBoxCell *onGoingCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"expiryTextCellIdentifier"];
                onGoingCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [onGoingCell setTextInputAccesoryView:self.keyboardResignView];
                [onGoingCell setPlaceHoldrText:NSLocalizedString(@"", @" Placeholder")];
                [onGoingCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [onGoingCell setCellText:NSLocalizedString(@"Lifetime Validity", @"Lifetime validity Placeholder")];
                [onGoingCell setCellTextColor:[UIColor darkGrayColor]];
                [onGoingCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [onGoingCell setCellIndexPath:indexPath];
                [onGoingCell disableCelltxtField];
                [onGoingCell checkBoxClick:self.isLifeTime];
                onGoingCell.textCheckBoxdelegate=self;
                return onGoingCell;
                break;
            }
        }
        case CLCertificationDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.toolbarWithOutCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLCertificationDocsIndex:{
            CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.indexPath=indexPath;
            cell.delegate=self;
            cell.photosLimit=-1;
            cell.placeHolderImageName=@"documentPlaceHolder";
            cell.photoUrls=self.certificationObj.documentsUrl;
            [cell updateCollectionViewContents];
            return cell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLCertificationNameIndex:
            return NSLocalizedString(@"Certification Title", @"Placeholder for Certification Title");
            break;
        case CLCertificationInstitutionIndex:
            return NSLocalizedString(@"Institution", @"Placeholder for Institution");
            break;
        case CLCertificationCountryIndex:
            return NSLocalizedString(@"Country", @"Placeholder for Institution");
            break;
        case CLCertificationLocationIndex:
            return NSLocalizedString(@"Location(City/Town/Village,country)", @"Placeholder for Location(City/Town/Village,country)");
            break;
        case CLCertificationProgressIndex:
            return NSLocalizedString(@"", @"Placeholder for This Certification is still in progress or being achieved field");
            break;
        case CLCertificationStartDateIndex:
            if (self.isProgress) {
                return NSLocalizedString(@"Start Date", @"Placeholder for Start Date");
            }else{
                return NSLocalizedString(@"Issued On", @"Placeholder for Issued On Date");
            }
            break;
        case CLCertificationEndDateIndex:
            if (self.isProgress) {
                return NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date");
            }else{
                return NSLocalizedString(@"Date of Expiry", @"Placeholder for End date field");
            }
            break;
        case CLCertificationDescIndex:
            return NSLocalizedString(@"Description", @"Placeholder for Description field");
            break;
        case CLCertificationDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLCertificationDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else if(indexPath.section==CLCertificationDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.certificationObj.documentsUrl count]+1)/2));
    }else if(indexPath.section == CLCertificationProgressIndex){
        return 54;
    }else{
        return 44;
    }
}

#pragma mark CLTappableCellDelegate Methods

- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == CLCertificationLocationIndex) {
        self.selectedCurrentLocation = nil;
        self.certificationObj.location=nil;
    }
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLCertificationLocationIndex) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryBasedLocation;
        selectLocation.delegate=self;
        self.forCountry = NO;
        selectLocation.countryCodeforListing=[self.selectedCountry objectForKey:@"countryCode"];
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if (indexPath.section == CLCertificationCountryIndex){
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        self.forCountry = YES;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }

}

#pragma mark CLSelectLocationDelegate
- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        [self.selectedCountry removeAllObjects];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        self.selectedCurrentLocation =nil;
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCertificationCountryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCertificationLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{

    self.selectedCurrentLocation=locDict;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCertificationLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods
- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    self.txtFirstResponder = nil;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.datePicker.tag = indexPath.section;
    if (indexPath.section == CLCertificationEndDateIndex) {
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate *currentDate = [NSDate date];
        NSDateComponents *comps = [[NSDateComponents alloc] init];
        [comps setYear:30];
        NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
        [self.datePicker setMaximumDate:maxDate];
    }else{
        
        [self.datePicker setMaximumDate:[NSDate date]];
    }
    self.txtFirstResponder=textField;
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (indexPath.section) {
        case CLCertificationNameIndex:
            self.nameText = @"";
            break;
        case CLCertificationInstitutionIndex:
            self.institutionText = @"";
            break;
        case CLCertificationStartDateIndex:{
            if (self.isProgress) {
                self.startDate = nil;
            }
            else{
                self.issuedOn = nil;
            }
        }
            break;
        case CLCertificationEndDateIndex:{
            if (self.isProgress) {
                self.completedDate = nil;
            }
            else{
                self.endDate = nil;
            }
        }
            break;
        default:
            break;
    }
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLCertificationNameIndex:{
            self.nameText=text;
            break;
        }
        case CLCertificationInstitutionIndex:{
            self.institutionText=text;
            break;
        }
        case CLCertificationDescIndex:{
            self.descriptionText=text;
            break;
        }
        default:
            break;
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods
- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate
-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject addDocument:image forQualification:self.certificationObj.certificationId andUser:[CLUserObject currentUser].userID withDocType:kAddCertificationDocType andCaption:caption success:^(CLFileObject *fileObj) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.certificationObj.documentsUrl) {
            self.certificationObj.documentsUrl=[[NSMutableArray alloc] init];
        }
        [self.certificationObj.documentsUrl addObject:fileObj];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

#pragma mark UIActionsheet Delegates
-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLFileObject *documentObj=[self.certificationObj.documentsUrl objectAtIndex:indexPath.row];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting education doc");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject deleteQDocument:documentObj.fileId success:^{
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.certificationObj.documentsUrl removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

-(void)progressStatusSwtchAction:(UISwitch*)sender{
    
    BOOL status = [[NSNumber numberWithInteger:sender.tag] boolValue];
    if (status) {
        self.isProgress = NO;
    }else{
        self.isProgress = YES;
    }
    [self reloadTableWithAnimation:YES];
}

-(void)reloadTableWithAnimation:(BOOL)boolVal{
    if (boolVal) {
        [UIView transitionWithView:self.tableView
                          duration:0.4f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^(void) {
                            [self.tableView reloadData];
                        } completion:NULL];
    }else{
        [self.tableView reloadData];
    }
}

#pragma mark CLTextCheckBoxCellDelegate Methods
-(void)textCheckBoxCellWillBeginEditing:(CLTextCheckBoxCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    
}

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    
    [CLCommon doViewAnimation:self.view];
    if (status) {
        self.isLifeTime = YES;
        self.endDate = nil;
    }else{
        self.isLifeTime = NO;
    }
    
    [self reloadTableWithAnimation:YES];
}
@end
