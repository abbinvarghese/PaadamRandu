//
//  CLCertificationObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLLocationObject.h"
#import "CLFileObject.h"

@interface CLCertificationObject : NSObject

@property(nonatomic,strong)NSString *certificationId;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *institution;
@property(nonatomic,strong)CLLocationObject *location;
@property(nonatomic,strong)NSDate *issuedOnDate;
@property(nonatomic,strong)NSDate *fromDate;
@property(nonatomic,strong)NSDate *toDate;
@property(nonatomic,strong)NSDate *completionDate;
@property(nonatomic,assign)BOOL isProgress;
@property(nonatomic,assign)BOOL isLifeValid;
@property(nonatomic,strong)NSString *contents;
@property(nonatomic,strong)NSMutableArray *documentsUrl;//[(CLFileObject),(CLFileObject),...]

- (id)initWithDictionary:(NSDictionary*)dictionary;
+ (void)saveCertification:(CLCertificationObject*)certificationObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *certificationId))success failure:(void (^)(NSString *error))failure;
@end
