//
//  CLEmploymentDetailsViewController.m
//  CareerLine
//
//  Created by CSG on 2/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEmploymentDetailsViewController.h"
#import "CLSelectJobLevelGroupViewController.h"
#import "CLLocationDetailsViewController.h"
#import "CLTappableTextViewCell.h"
#import "TITokenField.h"
#import "CLCoreDataHelper.h"
#import "CLCRFObject.h"
#import "CLCRFThreeObject.h"
#import "CLCRFEducationViewController.h"
#import "CLCRFAboutMeViewController.h"

#define kSectionHeaderTextColor [UIColor darkGrayColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont [UIFont systemFontOfSize:14]

@interface CLEmploymentDetailsViewController ()

//Employment status indicator...
typedef enum {
    EmploymentStatusEmployed = 1,
    EmploymentStatusUnEmployed= 2,
    EmploymentStatusSelfEmployed=3
} EmploymentStatus;

//Table Section indicator...
typedef enum {
    TableSectionIndexEmploymentStatus = 0,
    TableSectionIndexEmploymentDetails= 1
} TableSectionIndex;

//Table Employment Details Row indicator...
@property(nonatomic,assign)int empTypeRowIndex;
@property(nonatomic,assign)int empWorkCountryRowIndex;
@property(nonatomic,assign)int empCompNameRowIndex;
@property(nonatomic,assign)int empCompBusinessDivRowIndex;
@property(nonatomic,assign)int empIndustryIndex;
@property(nonatomic,assign)int empCompLocRowIndex;
@property(nonatomic,assign)int empCompDescRowIndex;
@property(nonatomic,assign)int empJobTitleRowIndex;
@property(nonatomic,assign)int empJobFuncRowIndex;
@property(nonatomic,assign)int empCareerLevelRowIndex;
@property(nonatomic,assign)int empJobScopeRowIndex;

@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneToolbar;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneToolbarWithCancel;
@property (strong, nonatomic) UIPickerView *pickerView;
@property(nonatomic,strong)UITextField *txtFirstResponder;

@property (nonatomic,assign) BOOL isDataLoadedFromUserDefaults;
@property (strong, nonatomic) NSMutableArray *currentEmploymentStatusArray;
@property (strong, nonatomic) NSMutableArray *previousEmploymentStatusArray;
@property (strong, nonatomic) NSMutableArray *employmentJobScopeArray;

@property (strong, nonatomic) NSMutableDictionary *selectedCurrentEmploymentStatus;
@property (strong, nonatomic) NSMutableDictionary *selectedPreviousEmploymentStatus;
@property (strong, nonatomic) NSMutableDictionary *selectedEmploymentType;
@property (strong, nonatomic) NSString *jobTitleText;
@property (strong, nonatomic) NSMutableArray *selectedJobFunctionArray;
@property (strong, nonatomic) NSMutableDictionary *selectedJobFunction;
@property (strong, nonatomic) NSString *selectedJobFunctionText;
@property (strong, nonatomic) NSString *selectedBusinessDivText;
@property (strong, nonatomic) NSMutableDictionary *selectedJobLevel;
@property (strong, nonatomic) NSMutableArray *selectedindustry;
@property (strong, nonatomic) NSMutableDictionary *selectedJobScope;

@property (nonatomic,assign) BOOL isCompanyNotFound;
@property (strong, nonatomic) NSMutableDictionary *selectedWorkCountry;
@property (strong, nonatomic) NSMutableDictionary *selectedCompany;
@property (strong, nonatomic) NSMutableArray *selectedMultipleBusDiv;
@property (strong, nonatomic) NSMutableDictionary *selectedCompanyLocation;
@property (strong, nonatomic) NSString *companyDescText;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (strong, nonatomic)CLCRFThreeObject *threeObj;



@property (strong, nonatomic) IBOutlet TITokenField *txtTokenField;

- (IBAction)bttnActionKeyboardDone:(id)sender;
- (IBAction)bttnActionKeyboardCancel:(id)sender;
@end

@implementation CLEmploymentDetailsViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Employment", @"Profile details employment page title");
    [self setRightNavButton];
    [self registerTableCellsForReuse];
    self.tableView.tableHeaderView=self.tblHeaderView;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    self.selectedindustry=[[NSMutableArray alloc]init];
    self.previousEmploymentStatusArray=[[NSMutableArray alloc] init];
    self.employmentJobScopeArray=[[NSMutableArray alloc] init];
    self.selectedJobFunctionArray=[[NSMutableArray alloc] init];
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    [self updateEmploymentStatusArrayDetails];
    
    self.isDataLoadedFromUserDefaults=NO;
    self.isCompanyNotFound=NO;
    
    CGRect tokenFieldFrame=self.txtTokenField.frame;
    tokenFieldFrame.size.width=self.tableView.bounds.size.width-10;
    self.txtTokenField.frame=tokenFieldFrame;
    [self updateTableIndexValues];
    [self initCRFThreeDetails];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [self.txtFirstResponder resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark IBActions

-(IBAction)bttnActionGotoNextPage:(id)sender{
    if([self isFieldsValid]){
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while loading jobs");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [progressHUD showInView:self.view];
        self.navigationItem.leftBarButtonItem.enabled = NO;
        self.navigationItem.rightBarButtonItem.enabled = NO;
        
        [CLCRFObject submitCRFTHREEForUser:[CLUserObject currentUser].email withCRFDict:[self makeDictionaryForSubmit] success:^(){
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.leftBarButtonItem.enabled = YES;
            self.navigationItem.rightBarButtonItem.enabled = YES;
            CLLocationDetailsViewController *locationsView=[[CLLocationDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:locationsView animated:YES];
        }failure:^(NSString *error){
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.leftBarButtonItem.enabled = YES;
            self.navigationItem.rightBarButtonItem.enabled = YES;
            [CLCommon showAlertwithTitle:nil alertString:error cancelbuttonName:@"OK"];
        }];
    }
}

-(NSMutableDictionary*)makeDictionaryForSubmit{
    NSMutableDictionary *mainDict = [[NSMutableDictionary alloc]init];
    if ([[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:@"1"]){     // EMPLOYED
        
        NSMutableDictionary *careerlineDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[self.selectedCurrentEmploymentStatus objectForKey:@"id"],@"cl_emp_status", nil];
        
        NSMutableDictionary *clWorkHistoryDict = [[NSMutableDictionary alloc]init];
        [clWorkHistoryDict setObject:[self.selectedEmploymentType objectForKey:@"id"] forKey:@"cl_type_employment"];
        [clWorkHistoryDict setObject:[self.selectedWorkCountry objectForKey:@"cy_code"] forKey:@"ind_comp_cycode"];
        [clWorkHistoryDict setObject:[self.selectedCompany objectForKey:@"companyName"] forKey:@"ind_comp_code"];
        if (!self.isCompanyNotFound) {
            NSArray *industryArray = [[NSArray alloc]initWithObjects:[[self.selectedindustry objectAtIndex:0] objectForKey:@"indcode"], nil];
            [clWorkHistoryDict setObject:industryArray forKey:@"cl_job_indcode"];
        }
        [clWorkHistoryDict setObject:self.jobTitleText forKey:@"cl_jobtitle"];
        [clWorkHistoryDict setObject:[self.selectedJobLevel objectForKey:@"level_code"] forKey:@"cl_joblevel"];
        [clWorkHistoryDict setObject:[self.selectedJobScope objectForKey:@"id"] forKey:@"cl_jobimpact"];
        
        NSMutableDictionary *funDIct = [[NSMutableDictionary alloc]init];
        NSMutableArray *arra = [[NSMutableArray alloc]init];
        NSMutableArray *OtherArray = [[NSMutableArray alloc]init];
        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if ([[dict objectForKey:@"otherText"] isEqualToString:@""]) { //FOR NON OTHER FUNCTION
                [arra addObject:[dict objectForKey:@"fncode"]];
            }
        }

            [funDIct setObject:arra forKey:@"cl_job_fncode"];

        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if (![[dict objectForKey:@"otherText"] isEqualToString:@""]) { // FOR OTHER FUNCTION
//                [dic setObject:[dict objectForKey:@"otherText"] forKey:[dict objectForKey:@"fncode"]];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
                [dic setObject:[dict objectForKey:@"otherText"] forKey:@"value"];
                [dic setObject:[dict objectForKey:@"fncode"] forKey:@"id"];
                [OtherArray addObject:dic];
            }
        }
        if (OtherArray.count>0) {
            [funDIct setObject:OtherArray forKey:@"cl_otherfnc"];
        }

        
        [mainDict setObject:careerlineDict forKey:@"careerline"];
        [mainDict setObject:clWorkHistoryDict forKey:@"clWorkhistory"];
        [mainDict setObject:funDIct forKey:@"whFunction"];
        if (!self.isCompanyNotFound) {
            NSString *bussinessString = @"";
            int e = 1;
            for (NSDictionary *dict in self.selectedMultipleBusDiv) {
                int i = (int)[self.selectedMultipleBusDiv count];
                if (i == e) {
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@",[dict objectForKey:@"companyDivision"]]];
                }
                else{
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"companyDivision"]]];
                }
                e++;
            }
            [mainDict setObject:bussinessString forKey:@"businessdivision"];
        }
        else{
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            [dict setObject:self.companyDescText forKey:@"pi_comp_description"];
            [mainDict setObject:dict forKey:@"piClCompany"];
        }
        
    }
    else if ([[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:@"2"] && [[NSString stringWithFormat:@"%@",[self.selectedPreviousEmploymentStatus objectForKey:@"id"]] isEqualToString:@"1"]){           //Yes I have Been Employed
        NSMutableDictionary *careerDict = [[NSMutableDictionary alloc]init];
        [careerDict setObject:[self.selectedCurrentEmploymentStatus objectForKey:@"id"] forKey:@"cl_emp_status"];
        [careerDict setObject:[self.selectedPreviousEmploymentStatus objectForKey:@"id"] forKey:@"cl_emp_history"];
        
        NSMutableDictionary *clworkHistoryDict = [[NSMutableDictionary alloc]init];
        [clworkHistoryDict setObject:[self.selectedEmploymentType objectForKey:@"id"] forKey:@"cl_type_employment"];
        [clworkHistoryDict setObject:[self.selectedWorkCountry objectForKey:@"cy_code"] forKey:@"ind_comp_cycode"];
        [clworkHistoryDict setObject:[self.selectedCompany objectForKey:@"companyName"] forKey:@"ind_comp_code"];
        if (!self.isCompanyNotFound) {
            NSArray *industryArray = [[NSArray alloc]initWithObjects:[[self.selectedindustry objectAtIndex:0] objectForKey:@"indcode"], nil];
            [clworkHistoryDict setObject:industryArray forKey:@"cl_job_indcode"];
        }
        [clworkHistoryDict setObject:self.jobTitleText forKey:@"cl_jobtitle"];
        [clworkHistoryDict setObject:[self.selectedJobLevel objectForKey:@"level_code"] forKey:@"cl_joblevel"];
        [clworkHistoryDict setObject:[self.selectedJobScope objectForKey:@"id"] forKey:@"cl_jobimpact"];
        
        NSMutableDictionary *funDIct = [[NSMutableDictionary alloc]init];
        NSMutableArray *arra = [[NSMutableArray alloc]init];
        NSMutableArray *OtherArray = [[NSMutableArray alloc]init];
        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if ([[dict objectForKey:@"otherText"] isEqualToString:@""]) { //FOR NON OTHER FUNCTION
                [arra addObject:[dict objectForKey:@"fncode"]];
            }
        }
        
        [funDIct setObject:arra forKey:@"cl_job_fncode"];
        
        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if (![[dict objectForKey:@"otherText"] isEqualToString:@""]) { // FOR OTHER FUNCTION
                //                [dic setObject:[dict objectForKey:@"otherText"] forKey:[dict objectForKey:@"fncode"]];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
                [dic setObject:[dict objectForKey:@"otherText"] forKey:@"value"];
                [dic setObject:[dict objectForKey:@"fncode"] forKey:@"id"];
                [OtherArray addObject:dic];
            }
        }
        if (OtherArray.count>0) {
            [funDIct setObject:OtherArray forKey:@"cl_otherfnc"];
        }
        
        
        [mainDict setObject:careerDict forKey:@"careerline"];
        [mainDict setObject:clworkHistoryDict forKey:@"clWorkhistory"];
        [mainDict setObject:funDIct forKey:@"whFunction"];
        if (!self.isCompanyNotFound) {
            NSString *bussinessString = @"";
            int e = 1;
            for (NSDictionary *dict in self.selectedMultipleBusDiv) {
                int i = (int)[self.selectedMultipleBusDiv count];
                if (i == e) {
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@",[dict objectForKey:@"companyDivision"]]];
                }
                else{
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"companyDivision"]]];
                }
                e++;
            }
            [mainDict setObject:bussinessString forKey:@"businessdivision"];
        }
        else{
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            [dict setObject:self.companyDescText forKey:@"pi_comp_description"];
            [mainDict setObject:dict forKey:@"piClCompany"];
        }
        
    }
    
    else if ([[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:@"2"] && [[NSString stringWithFormat:@"%@",[self.selectedPreviousEmploymentStatus objectForKey:@"id"]] isEqualToString:@"2"]){             // NO I have Never Been Employed
        NSMutableDictionary *careerDict = [[NSMutableDictionary alloc]init];
        [careerDict setObject:[self.selectedCurrentEmploymentStatus objectForKey:@"id"] forKey:@"cl_emp_status"];
        [careerDict setObject:[self.selectedPreviousEmploymentStatus objectForKey:@"id"] forKey:@"cl_emp_history"];
        [mainDict setObject:careerDict forKey:@"careerline"];
    }
    else if ([[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:@"3"]){     // SELF EMPLOYED
        
        NSMutableDictionary *careerlineDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[self.selectedCurrentEmploymentStatus objectForKey:@"id"],@"cl_emp_status", nil];
        
        NSMutableDictionary *clWorkHistoryDict = [[NSMutableDictionary alloc]init];
        [clWorkHistoryDict setObject:[self.selectedEmploymentType objectForKey:@"id"] forKey:@"cl_type_employment"];
        [clWorkHistoryDict setObject:[self.selectedWorkCountry objectForKey:@"cy_code"] forKey:@"ind_comp_cycode"];
        [clWorkHistoryDict setObject:[self.selectedCompany objectForKey:@"companyName"] forKey:@"ind_comp_code"];
        if (!self.isCompanyNotFound) {
            NSArray *industryArray = [[NSArray alloc]initWithObjects:[[self.selectedindustry objectAtIndex:0] objectForKey:@"indcode"], nil];
            [clWorkHistoryDict setObject:industryArray forKey:@"cl_job_indcode"];
        }
        [clWorkHistoryDict setObject:self.jobTitleText forKey:@"cl_jobtitle"];
        [clWorkHistoryDict setObject:[self.selectedJobLevel objectForKey:@"level_code"] forKey:@"cl_joblevel"];
        [clWorkHistoryDict setObject:[self.selectedJobScope objectForKey:@"id"] forKey:@"cl_jobimpact"];
        
        NSMutableDictionary *funDIct = [[NSMutableDictionary alloc]init];
        NSMutableArray *arra = [[NSMutableArray alloc]init];
        NSMutableArray *OtherArray = [[NSMutableArray alloc]init];
        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if ([[dict objectForKey:@"otherText"] isEqualToString:@""]) {
                [arra addObject:[dict objectForKey:@"fncode"]];
            }
        }
        [funDIct setObject:arra forKey:@"cl_job_fncode"];
        
        for (NSDictionary *dict in self.selectedJobFunctionArray) {
            if (![[dict objectForKey:@"otherText"] isEqualToString:@""]) { // FOR OTHER FUNCTION
                //                [dic setObject:[dict objectForKey:@"otherText"] forKey:[dict objectForKey:@"fncode"]];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
                [dic setObject:[dict objectForKey:@"otherText"] forKey:@"value"];
                [dic setObject:[dict objectForKey:@"fncode"] forKey:@"id"];
                [OtherArray addObject:dic];
            }
        }
        if (OtherArray.count>0) {
            [funDIct setObject:OtherArray forKey:@"cl_otherfnc"];
        }
        
        
        [mainDict setObject:careerlineDict forKey:@"careerline"];
        [mainDict setObject:clWorkHistoryDict forKey:@"clWorkhistory"];
        [mainDict setObject:funDIct forKey:@"whFunction"];
        if (!self.isCompanyNotFound) {
            NSString *bussinessString = @"";
            int e = 1;
            for (NSDictionary *dict in self.selectedMultipleBusDiv) {
                int i = (int)[self.selectedMultipleBusDiv count];
                if (i == e) {
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@",[dict objectForKey:@"companyDivision"]]];
                }
                else{
                    bussinessString = [bussinessString stringByAppendingString:[NSString stringWithFormat:@"%@,",[dict objectForKey:@"companyDivision"]]];
                }
                e++;
            }
            [mainDict setObject:bussinessString forKey:@"businessdivision"];
        }
        else{
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            [dict setObject:self.companyDescText forKey:@"pi_comp_description"];
            [mainDict setObject:dict forKey:@"piClCompany"];
        }
        
    }
    [CLCommon jsonStringWithPrettyPrint:YES foDict:mainDict];
    return mainDict;
}

- (IBAction)bttnActionKeyboardDone:(id)sender {
    CLSimpleTextCell *cell=[self getCellForFirstResponder];
    if (cell!=nil) {
        NSIndexPath *indexpath=cell.cellIndexPath;
        if(indexpath.row==0 && indexpath.section==TableSectionIndexEmploymentStatus){
            if (![[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:[NSString stringWithFormat:@"%@",[[self.currentEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:@"id"]]]) {
                [self clearValuesOnFields];
                self.selectedPreviousEmploymentStatus=nil;
            }
            self.selectedCurrentEmploymentStatus=[self.currentEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            
            [cell setCellText:[[self.currentEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kemploymentStatusTitleKey]];
            [self updateTableIndexValues];
            [self.tableView reloadData];
        }
        else if (indexpath.row==1 && indexpath.section==TableSectionIndexEmploymentStatus){
            if (![[NSString stringWithFormat:@"%@",[self.selectedPreviousEmploymentStatus objectForKey:@"id"]] isEqualToString:[NSString stringWithFormat:@"%@",[[self.previousEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:@"id"]]]){
                [self clearValuesOnFields];
            }
            self.selectedPreviousEmploymentStatus=[self.previousEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            [cell setCellText:[[self.previousEmploymentStatusArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kemploymentStatusTitleKey]];
            [self updateTableIndexValues];
            [self.tableView reloadData];
        }
        else if (indexpath.row==self.empJobScopeRowIndex && indexpath.section==TableSectionIndexEmploymentDetails){
            self.selectedJobScope=[self.employmentJobScopeArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            [cell setCellText:[[self.employmentJobScopeArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kemploymentJobScopeNameKey]];
        }
    }
    
    [cell resignCellFirstResponder];
}

- (IBAction)bttnActionKeyboardCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}

#pragma mark Utility Methods

-(void)setRightNavButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for next button title to goto next page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGotoNextPage:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
    if (self.needCustomBackButtons) {
        if (self.needCustomBackButtons) {
            UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Education", @"Text for status page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(backClicked)];
            self.navigationItem.leftBarButtonItem=leftNavBttn;
        }
    }
}

-(void)backClicked{
    CLCRFEducationViewController *newVC = [[CLCRFEducationViewController alloc]init];
    CLCRFAboutMeViewController *newVC2 = [[CLCRFAboutMeViewController alloc]init];
    NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [vcs insertObject:newVC atIndex:[vcs count]-1];
    [vcs insertObject:newVC2 atIndex:[vcs count]-2];
    [self.navigationController setViewControllers:vcs animated:NO];
    [self.navigationController popViewControllerAnimated:YES];
}

-(CLSimpleTextCell*)getCellForFirstResponder{
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    return (CLSimpleTextCell*)cell;
}

-(void)updateTableIndexValues{
    self.empTypeRowIndex=0;
    self.empWorkCountryRowIndex=1;
    self.empCompNameRowIndex=2;
    
    if (([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusSelfEmployed)) {
            self.empCompLocRowIndex=-1;
            
        if (!self.isCompanyNotFound) {
            self.empIndustryIndex = 3;
            self.empCompDescRowIndex=-4;
            self.empCompBusinessDivRowIndex=4;
            self.empJobTitleRowIndex=5;
            self.empJobFuncRowIndex=6;
            self.empCareerLevelRowIndex=7;
            self.empJobScopeRowIndex=8;
        }else{
            self.empIndustryIndex = 333;
            self.empCompDescRowIndex=3;
            self.empCompBusinessDivRowIndex=-4;
            self.empJobTitleRowIndex=4;
            self.empJobFuncRowIndex=5;
            self.empCareerLevelRowIndex=6;
            self.empJobScopeRowIndex=7;
        }
        

    }
    else{
        if (self.isCompanyNotFound) {
            self.empIndustryIndex = -3;
            self.empCompBusinessDivRowIndex=-4;
            self.empCompDescRowIndex=3;
            self.empJobTitleRowIndex=4;
            self.empJobFuncRowIndex=5;
            self.empCareerLevelRowIndex=6;
            self.empJobScopeRowIndex=7;
        }
        else{
            self.empCompLocRowIndex=-1;
            self.empCompDescRowIndex=-1;
            self.empIndustryIndex = 3;
            self.empCompBusinessDivRowIndex=4;
            self.empJobTitleRowIndex=5;
            self.empJobFuncRowIndex=6;
            self.empCareerLevelRowIndex=7;
            self.empJobScopeRowIndex=8;
        }

    }
}

-(NSInteger)getNumberOfSectionsForTable{
    if(self.selectedCurrentEmploymentStatus){
        if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusEmployed) {
            return 2;
        }
        else if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusUnEmployed){
            if ([[self.selectedPreviousEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusEmployed) {
                return 2;
            }
            else{
                return 1;
            }
        }
        else if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusSelfEmployed){
            return 2;
        }
        else{
            return 1;
        }
    }
    else{
        return 1;
    }
}

-(NSInteger)getNumberOfRowsForSection:(NSInteger)section{
    if(section==TableSectionIndexEmploymentStatus){
        if(self.selectedCurrentEmploymentStatus){
            if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusEmployed) {
                return 1;
            }
            else if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusUnEmployed){
                return 2;
            }
            else if ([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusSelfEmployed){
                return 1;
            }
            else{
                return 1;
            }
        }
        else{
            return 1;
        }
    }
    else{
        if (self.isCompanyNotFound) {
            return 8;
        }
        else{
            return 9;
        }
    }
}

-(void)registerTableCellsForReuse{
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"employmentStatusFirsttextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"employmentStatusSecondtextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"empTypeTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empCountryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empCompanyNameTextCellIdentifier"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"empBusinessDivTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empIndustryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empLocationTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"empCompanyDescTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"empJobTitleTextCellIdentifier"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"functionTappableCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"jobLevelTappableCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empJobScopeTextCellIdentifier"];
    
}

-(void)updateEmploymentStatusArrayDetails{
    self.currentEmploymentStatusArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpStatusFromDB];
    
    [self.previousEmploymentStatusArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:1],kemploymentStatusIdKey,@"Yes, I Have Been Employed",kemploymentStatusTitleKey, nil]];
    [self.previousEmploymentStatusArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:2],kemploymentStatusIdKey,@"No, I Have Never Been Employed",kemploymentStatusTitleKey, nil]];
    
    self.employmentJobScopeArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpJobScopeFromDB:@"XXX"];
}

-(void)businessDivTextForArray:(NSMutableArray*)businessDivArray{
    if([businessDivArray count]>0){
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[businessDivArray count]; i++) {
            
            [string appendString:[NSString stringWithFormat:@"%@|",[[businessDivArray objectAtIndex:i] objectForKey:kCLCareerHistoryCompanyDivisionkey]]];
            
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.selectedBusinessDivText=string;
    }
    else{
        self.selectedBusinessDivText=nil;
    }
}

-(void)updateJobFuctionTextForArray:(NSMutableArray*)functionArray{
    if([functionArray count]>0){
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[functionArray count]; i++) {
            if ([[NSString stringWithFormat:@"%@",[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherFlag]] isEqualToString:@"1"] || [[NSString stringWithFormat:@"%@",[[functionArray objectAtIndex:i] objectForKey:@"other_flag"]] isEqualToString:@"1"]) {
                if ([[functionArray objectAtIndex:i] objectForKey:kjobFunctionName] && [[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherText]) {
                    [string appendString:[NSString stringWithFormat:@"%@ (%@)|",[[functionArray objectAtIndex:i] objectForKey:kjobFunctionName],[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherText]]];
                }
                else{
                    [string appendString:[NSString stringWithFormat:@"%@ (%@)|",[[functionArray objectAtIndex:i] objectForKey:@"fnname"],[[functionArray objectAtIndex:i] objectForKey:@"otherText"]]];
                }
            }
            else{
                if ([[functionArray objectAtIndex:i] objectForKey:kjobFunctionName]) {
                    [string appendString:[NSString stringWithFormat:@"%@|",[[functionArray objectAtIndex:i] objectForKey:kjobFunctionName]]];
                }
                else{
                    [string appendString:[NSString stringWithFormat:@"%@|",[[functionArray objectAtIndex:i] objectForKey:@"fnname"]]];
                }
            }
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.selectedJobFunctionText=string;
    }
    else{
        self.selectedJobFunctionText=nil;
    }
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    
    if(self.selectedCurrentEmploymentStatus!=nil){
        if([[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusEmployed || [[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==EmploymentStatusSelfEmployed){
            
            if ([self.selectedEmploymentType count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Current Employment type.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
            
            if ([self.selectedWorkCountry count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select The Country Where You Work.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
            
            if ([self.selectedCompany count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Current Company Where You Work.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
            
            if (self.isCompanyNotFound) {
                if ([self.companyDescText isEqualToString:@""] || self.companyDescText.length==0) {
                    [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Current Company Description", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                    return isValid=NO;
                }
            }
        
            if (!self.isCompanyNotFound) {
                if (self.selectedindustry.count==0) {
                    [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Company Industry.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                    return isValid=NO;
                }
            }
            
            //job title validation
            if ([self.jobTitleText isEqualToString:@""] || self.jobTitleText.length==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Current Job Title.", @"Error Message for null job title field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                return isValid=NO;
            }
            else if ([self.jobTitleText length]>200) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Current Job Title Length.", @"Error Message for length of current job title field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                return isValid=NO;
            }
            
            //job function validation
            if ([self.selectedJobFunctionArray count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Current Job Function.", @"Error Message for null job function") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                return isValid=NO;
            }
            
            //job level validation
            if ([self.selectedJobLevel count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Current Career Level.", @"Error Message for null job level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
            
            //job scope validation
            if ([self.selectedJobScope count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Current Job Scope.", @"Error Message for null job level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                return isValid=NO;
            }
        }
        else{
            if(self.selectedPreviousEmploymentStatus!=nil){
                if([[self.selectedPreviousEmploymentStatus objectForKey:kemploymentStatusIdKey] intValue]==1){
                    if ([self.selectedEmploymentType count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Previous Employment Type.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                        return isValid=NO;
                    }
                    
                    if ([self.selectedWorkCountry count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select The Country Where You Work.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                        return isValid=NO;
                    }
                    
                    if ([self.selectedCompany count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Previous Company Where You Work.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                        return isValid=NO;
                    }
                    
                    if (self.isCompanyNotFound) {
                        if ([self.selectedCompanyLocation count]==0) {

                        }
                        if ([self.companyDescText isEqualToString:@""] || self.companyDescText.length==0) {
                            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Previous Company Description", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                            return isValid=NO;
                        }
                    }
                    
                    //job title validation
                    if ([self.jobTitleText isEqualToString:@""] || self.jobTitleText.length==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Your Previous Job Title.", @"Error Message for null job title field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                        return isValid=NO;
                    }
                    else if ([self.jobTitleText length]>200) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Previous Job Title Length.", @"Error Message for length of current job title field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                        return isValid=NO;
                    }
                    
                    //job function validation
                    if ([self.selectedJobFunctionArray count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Previous Job Function.", @"Error Message for null job function") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                        return isValid=NO;
                    }
                    
                    //job level validation
                    if ([self.selectedJobLevel count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Previous Career Level.", @"Error Message for null job level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                        return isValid=NO;
                    }
                    
                    //job scope validation
                    if ([self.selectedJobScope count]==0) {
                        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Previous Job Scope.", @"Error Message for null job level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                        return isValid=NO;
                    }
                }
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Specify Whether You Have Ever Been Employed Before.", @"Error Message for null have u ever been employed field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
                return isValid=NO;
            }
        }
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Employment Status.", @"Error Message for null employment status field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
        return isValid=NO;
    }
    
    return isValid;
}



#pragma mark UIAlertView Delegate


-(void)willPresentAlertView:(UIAlertView *)alertView{
    if(alertView.tag==88){
        alertView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
        [[alertView textFieldAtIndex:0] setKeyboardType:UIKeyboardTypeAlphabet];
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}

#pragma mark CLSimpleTextCellDelegate Methods

-(void)cellShouldReturn:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    if (cell.cellIndexPath.row == self.empCompDescRowIndex) {
        CLSimpleTextCell *cell = (CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:self.empJobTitleRowIndex inSection:1]];
        [cell becomeFirstResponder];
    }
    
    
}

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath=cell.cellIndexPath;
    if(indexPath.section==TableSectionIndexEmploymentStatus && indexPath.row==0){
        self.pickerView.tag=1;
    }
    else if (indexPath.section==TableSectionIndexEmploymentStatus && indexPath.row==1){
        self.pickerView.tag=2;
    }
    else if(indexPath.section==TableSectionIndexEmploymentDetails && indexPath.row==self.empTypeRowIndex) {
        //        self.pickerView.tag=3;
        CLEmployeementTypeViewController *controller = [[CLEmployeementTypeViewController alloc]initWithNibName:@"CLEmployeementTypeViewController" bundle:[NSBundle mainBundle]];
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
        
    }
    else if(indexPath.section==TableSectionIndexEmploymentDetails && indexPath.row==self.empJobScopeRowIndex) {
        self.pickerView.tag=6;
    }
    [self.pickerView reloadAllComponents];
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
}

-(void)selectEmployeementType:(CLEmployeementTypeDetailsViewController *)controller withDictonary:(NSMutableDictionary *)selectedEmpTypeDict{
    self.selectedEmploymentType = [self editedemploymentTypeDictionary:selectedEmpTypeDict];
    [self.tableView reloadData];
}

-(NSMutableDictionary*)editedemploymentTypeDictionary:(NSMutableDictionary*)dictionary{
    NSMutableDictionary* dict = [[NSMutableDictionary alloc]init];
    [dict setValue:[dictionary objectForKey:@"empDetailId"] forKey:@"id"];
    NSString *string = [NSString stringWithFormat:@"%@ - %@",[dictionary objectForKey:@"name"],[dictionary objectForKey:@"empDetailName"]];
    [dict setValue:string forKey:@"type_employment"];
    return dict;
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    if (indexPath.section==TableSectionIndexEmploymentStatus) {
        switch (indexPath.row) {
            case 0:{
                self.selectedCurrentEmploymentStatus=nil;
                self.selectedPreviousEmploymentStatus=nil;
                break;
            }
            case 1:{
                self.selectedPreviousEmploymentStatus=nil;
                break;
            }
            default:
                break;
        }
    }
    else{
        if (indexPath.row==self.empTypeRowIndex) {
            self.selectedEmploymentType=nil;
        }
        else if (indexPath.row==self.empJobScopeRowIndex){
            self.selectedJobScope=nil;
        }
    }
    
    [self updateTableIndexValues];
    [self.tableView reloadData];
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    if(indexPath.section==TableSectionIndexEmploymentDetails){
        if (indexPath.row==self.empJobTitleRowIndex) {
            self.jobTitleText=text;
        }
        else if (indexPath.row==self.empCompDescRowIndex){
            self.companyDescText=text;
        }

    }
}

#pragma mark CLIndustry delegate

-(void)selectIndustryControllerDidSelectIndustry:(CLIndustryViewController *)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
//    self.selectedindustry = industryArray;
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:[[industryArray objectAtIndex:0] objectForKey:@"industryCode"] forKey:@"indcode"];
    [dict setObject:[[industryArray objectAtIndex:0]objectForKey:@"industry"] forKey:@"indname"];
    [dict setObject:[[industryArray objectAtIndex:0]objectForKey:@"industryGroupName"] forKey:@"mainGroupName"];
    [self.selectedindustry removeAllObjects];
    if (self.selectedindustry == nil) {
        self.selectedindustry = [[NSMutableArray alloc]init];
    }
    [self.selectedindustry addObject:dict];
    [self.tableView reloadData];
}

-(void)selectIndustryControllerDidDeleteIndustry:(CLIndustrySectorViewController *)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
    self.selectedindustry = industryArray;
    [self.tableView reloadData];
}


#pragma mark CLTappableCellDelegate Methods



- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==TableSectionIndexEmploymentDetails){
        if (indexPath.row==self.empWorkCountryRowIndex) {
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            selectLocation.locationListType=LocationListingTypeOtherCountries;
            selectLocation.delegate=self;
            selectLocation.forceSingleSelection=YES;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];
        }
        else if (indexPath.row==self.empCompNameRowIndex){
            if ([self.selectedWorkCountry count]==0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please specify the country location of this job", @"Please specify the country where you work") cancelbuttonName:NSLocalizedString(@"OK", @"Ok")];
            }
            else{
                CLSelectCompanyNameViewController *selectCompanyName=[[CLSelectCompanyNameViewController alloc] initWithNibName:@"CLSelectCompanyNameViewController" bundle:[NSBundle mainBundle]];
                selectCompanyName.countryCode = [self.selectedWorkCountry objectForKey:@"cy_code"];
                selectCompanyName.delegate=self;
                UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectCompanyName];
                [self presentViewController:nav animated:YES completion:nil];
            }
        }
        else if (indexPath.row==self.empCompLocRowIndex){
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            selectLocation.locationListType=LocationListingTypeHomeLocation;
            selectLocation.delegate=self;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];
        }
        
        else if (indexPath.row==self.empIndustryIndex){
            CLIndustrySectorViewController *controller = [[CLIndustrySectorViewController alloc]initWithNibName:@"CLIndustrySectorViewController" bundle:[NSBundle mainBundle]];
//            controller.alreadySelectedIndustries=self.selectedindustry;
//            NSMutableArray *array = [[NSMutableArray alloc]init];
//            if (self.selectedindustry.count>0) {
//                NSMutableDictionary *dicti = [[NSMutableDictionary alloc]init];
//                for (NSDictionary *dict in self.selectedindustry) {
//                    [dicti setObject:[dict objectForKey:@"indcode"] forKey:@"industryCode"];
//                    [dicti setObject:[dict objectForKey:@"indcodeA"] forKey:@"indcodea"];
//                    [dicti setObject:[dict objectForKey:@"indname"] forKey:@"industry"];
//                    [dicti setObject:[dict objectForKey:@"indsectcode"] forKey:@"indsectcode"];
//                    [dicti setObject:[dict objectForKey:@"mainGroupName"] forKey:@"industryGroupName"];
//                    [dicti setObject:[dict objectForKey:@"mainGroupCode"] forKey:@"industryGroupCode"];
//                    [dicti setObject:@"0" forKey:@"industryOther"];
//                    [array addObject:dicti];
//                }
//                controller.alreadySelectedIndustries=array;
//            }
            controller.delegate =self;
            controller.singleSelection=YES;
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
            [self presentViewController:nav animated:YES completion:nil];

        }

        else if (indexPath.row==self.empJobFuncRowIndex){
            CLSelectFunctionCategoryViewController *selectJobFuncController=[[CLSelectFunctionCategoryViewController alloc] initWithStyle:UITableViewStylePlain];
            selectJobFuncController.delegate=self;
//            selectJobFuncController.alreadySelectedFunctions=self.selectedJobFunctionArray;
            if (self.selectedJobFunctionArray.count>0) {
                NSMutableArray *array = [[NSMutableArray alloc]init];
                for (NSDictionary *dicti in self.selectedJobFunctionArray) {
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                    [dict setObject:[NSString stringWithFormat:@"%@",[dicti objectForKey:@"fncode"]] forKey:@"jobFunctionCode"];
                    [dict setObject:[dicti objectForKey:@"fnname"] forKey:@"function"];
                    if (![[dicti objectForKey:@"otherText"] isEqualToString:@""]) {
                        [dict setObject:[dicti objectForKey:@"otherText"] forKey:@"jobFunctionOtherText"];
                    }
                    
                    [dict setObject:[NSString stringWithFormat:@"%@",[dicti objectForKey:@"other_flag"]] forKey:@"jobFunctionOtherFlag"];
                    if ([dicti objectForKey:@"jobFunctionGroupCode"]) {
                        [dict setObject:[dicti objectForKey:@"jobFunctionGroupCode"] forKey:@"jobFunctionGroupCode"];
                    }
                    [array addObject:dict];
                }
                    selectJobFuncController.alreadySelectedFunctions=array;
            }
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectJobFuncController];
            [self presentViewController:nav animated:YES completion:nil];
        }
        else if (indexPath.row==self.empCareerLevelRowIndex){
            CLSelectJobLevelGroupViewController *selectJobLevelController=[[CLSelectJobLevelGroupViewController alloc] initWithStyle:UITableViewStylePlain];
            selectJobLevelController.delegate=self;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectJobLevelController];
            [self presentViewController:nav animated:YES completion:nil];
        }
        else if (indexPath.row == self.empJobScopeRowIndex){
            if (self.selectedWorkCountry.count == 0) {
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please specify the country location of this job", @"Please specify the country where you work") cancelbuttonName:NSLocalizedString(@"OK", @"Ok")];
            }
            else{
                CLJobScopeViewController *controller = [[CLJobScopeViewController alloc]initWithNibName:@"CLJobScopeViewController" bundle:[NSBundle mainBundle]];
                controller.delegateTwo=self;
                controller.delegate = self;
                controller.singleSelectionOn = YES;
                [controller setSelectedCountry:self.selectedWorkCountry];
                [controller.selectedCountry setObject:[self.selectedWorkCountry objectForKey:@"cy_code"] forKey:@"jobLocationCountryCode"];
                UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:controller];
                [self presentViewController:nav animated:YES completion:nil];
            }
            
        }
    else if (indexPath.row == self.empCompBusinessDivRowIndex){
            
            if (self.selectedCompany !=nil) {
                CLBusinessDivViewController *selectBusinessDivController=[[CLBusinessDivViewController alloc] initWithStyle:UITableViewStylePlain];
                selectBusinessDivController.delegate=self;
                selectBusinessDivController.selectedCompany = self.selectedCompany;
                selectBusinessDivController.alreadySelectedBusDivision=self.selectedMultipleBusDiv;
                UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectBusinessDivController];
                [self presentViewController:nav animated:YES completion:nil];
            }else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please specify the company name", @"Please specify the company name") cancelbuttonName:NSLocalizedString(@"Ok", @"Ok")];
            }
            
        }
    }
}

- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField
{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == TableSectionIndexEmploymentDetails)
    {
        if(indexPath.row == self.empJobScopeRowIndex)
        {
            self.selectedJobScope = nil;
        }
        else if(indexPath.row==self.empCareerLevelRowIndex)
        {
            self.selectedJobLevel = nil;
        }
    }
    [self.tableView reloadData];
}

-(void)loadSelectedJobScopeDict:(NSMutableDictionary *)jobScopeDict{
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[jobScopeDict objectForKey:kCLTargetJobsJobScopeCodeKey],kCLTargetJobsJobScopeScopeIDKey,[NSString stringWithFormat:@"%@ (%@)", [jobScopeDict objectForKey:kCLTargetJobsJobScopeGroupNameKey], [jobScopeDict objectForKey:kCLTargetJobsJobScopeKey]], kCLTargetJobsJobScopeScopeNameKey, nil];
    
    if (self.selectedJobScope == nil) {
        self.selectedJobScope = [[NSMutableDictionary alloc]init];
    }
    [self.selectedJobScope setObject:[jobScopeDict objectForKey:@"code"] forKey:@"id"];
    [self.selectedJobScope setObject:[jobScopeDict objectForKey:@"jobImpactGroup"] forKey:@"jobImpactGroup"];
    [self.selectedJobScope setObject:[jobScopeDict objectForKey:@"jobScope"] forKey:@"jobimpact"];
    [self.selectedJobScope setObject:[jobScopeDict objectForKey:@"jobScopeGroupName"] forKey:@"jobScopeGroupName"];
    [self.tableView reloadData];
}

#pragma mark CLBusinessDivDeleagte
-(void)employmentDetailsController:(CLBusinessDivViewController *)controller didAddBusinessDiv:(NSMutableArray *)businessDivArray{
    self.selectedMultipleBusDiv = businessDivArray;
    [self businessDivTextForArray:self.selectedMultipleBusDiv];
    [self.tableView reloadData];
}

#pragma mark CLSelectLocationDelegate
- (void)selectLocationControllerDidSelectLocations:(CLSelectLocationViewController*)controller forType:(LocationListingType)type withArray:(NSMutableArray *)locArray{
    if ([locArray count]>0) {
        //selected work country..
        if (type==LocationListingTypeOtherCountries) {
            self.selectedCompany=nil;
            self.selectedindustry=nil;
            self.selectedMultipleBusDiv=nil;
            self.selectedBusinessDivText=@"";
            self.selectedJobScope = nil;
            self.selectedCompanyLocation=nil;
            self.companyDescText=@"";
            self.isCompanyNotFound=NO;
            if (self.selectedWorkCountry != nil) {
                [self.selectedWorkCountry setObject:[[locArray objectAtIndex:0] objectForKey:@"jobLocationCountryCode"] forKey:@"cy_code"];
                [self.selectedWorkCountry setObject:[[locArray objectAtIndex:0] objectForKey:@"jobLocationCountryName"] forKey:@"cy_name"];
            }
            else{
                self.selectedWorkCountry = [[NSMutableDictionary alloc]init];
                [self.selectedWorkCountry setObject:[[locArray objectAtIndex:0] objectForKey:@"jobLocationCountryCode"] forKey:@"cy_code"];
                [self.selectedWorkCountry setObject:[[locArray objectAtIndex:0] objectForKey:@"jobLocationCountryName"] forKey:@"cy_name"];
            }
            [self updateTableIndexValues];
            [self.tableView reloadData];
        }
    }
}
-(void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController *)controller withDictonary:(NSMutableDictionary *)locDict{
    self.selectedCompanyLocation=locDict;
    [self updateTableIndexValues];
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.empCompLocRowIndex inSection:TableSectionIndexEmploymentDetails]] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark CLSelectCompanyDelegate

-(void)selectCompanyNameDidSelectCompanyName:(CLSelectCompanyNameViewController *)controller withDict:(NSMutableDictionary *)companyDict companyDiv:(NSMutableArray *)companyDivisions isNew:(BOOL)isNewCompany{
    [self.selectedindustry removeAllObjects];
    self.selectedMultipleBusDiv = nil;
    self.selectedBusinessDivText = nil;
    self.selectedCompanyLocation=nil;
    self.companyDescText=@"";
    if (companyDivisions.count>0) {
        if ([[companyDivisions objectAtIndex:0] objectForKey:@"industry"]) {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            
            [dict setObject:[[companyDivisions objectAtIndex:0] objectForKey:@"id"] forKey:@"indcode"];
            [dict setObject:[[companyDivisions objectAtIndex:0] objectForKey:@"industry"] forKey:@"indname"];
            [dict setObject:[[companyDivisions objectAtIndex:0] objectForKey:@"industryGroupName"] forKey:@"mainGroupName"];
            
            [self.selectedindustry removeAllObjects];
            if (self.selectedindustry == nil) {
                self.selectedindustry = [[NSMutableArray alloc]init];
            }
            [self.selectedindustry addObject:dict];
        }
    }
    
    
    self.selectedCompany=companyDict;
    
    self.isCompanyNotFound=isNewCompany;
    
    [self updateTableIndexValues];
    [self.tableView reloadData];
}

#pragma mark CLSelectJobLevelDelegate

- (void)selectJobLevelControllerDidSelectJobLevel:(CLSelectJobLevelDetailViewController*)controller withDictonary:(NSMutableDictionary *)jobLevelDict{
    
    if (self.selectedJobLevel == nil) {
        self.selectedJobLevel = [[NSMutableDictionary alloc]init];
    }
    [self.selectedJobLevel removeAllObjects];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"jobLevel"] forKey:@"level_name"];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"jobLevelGroupCode"] forKey:@"jobLevelGroupCode"];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"jobLevelGroupName"] forKey:@"jobLevelGroupName"];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"levelCode"] forKey:@"level_code"];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"lvlGroupCode"] forKey:@"lvlGroupCode"];
    [self.selectedJobLevel setObject:[jobLevelDict objectForKey:@"levelCode"] forKey:@"levelCode"];
    
    [self updateTableIndexValues];
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.empCareerLevelRowIndex inSection:TableSectionIndexEmploymentDetails]] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark CLSelectJobFunctionDelegate

- (void)selectJobFunctionControllerDidSelectJobFunction:(CLSelectFunctionViewController*)controller withArray:(NSMutableArray *)jobFunctionArray{
    if (self.selectedJobFunctionArray == nil) {
        self.selectedJobFunctionArray = [[NSMutableArray alloc]init];
    }
    if([self.selectedJobFunctionArray count]==0){
        [self.selectedJobFunctionArray removeAllObjects];
        for (NSDictionary *dict in jobFunctionArray) {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            [dic setObject:[dict objectForKey:@"function"] forKey:@"fnname"];
            [dic setObject:[dict objectForKey:@"jobFunctionCode"] forKey:@"fncode"];
            [dic setObject:[dict objectForKey:@"jobFunctionGroupCode"] forKey:@"jobFunctionGroupCode"];
            [dic setObject:[dict objectForKey:@"jobFunctionOtherFlag"] forKey:@"other_flag"];
            if ([dict objectForKey:@"jobFunctionOtherText"]) {
                [dic setObject:[dict objectForKey:@"jobFunctionOtherText"] forKey:@"otherText"];
            }
            else{
                [dic setObject:@"" forKey:@"otherText"];
            }
            [self.selectedJobFunctionArray addObject:dic];
        }
    }
    else{
        for (NSDictionary *dict in jobFunctionArray) {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            [dic setObject:[dict objectForKey:@"function"] forKey:@"fnname"];
            [dic setObject:[dict objectForKey:@"jobFunctionCode"] forKey:@"fncode"];
            [dic setObject:[dict objectForKey:@"jobFunctionGroupCode"] forKey:@"jobFunctionGroupCode"];
            [dic setObject:[dict objectForKey:@"jobFunctionOtherFlag"] forKey:@"other_flag"];
            if ([dict objectForKey:@"jobFunctionOtherText"]) {
                [dic setObject:[dict objectForKey:@"jobFunctionOtherText"] forKey:@"otherText"];
            }
            else{
                [dic setObject:@"" forKey:@"otherText"];
            }
            [self.selectedJobFunctionArray addObject:dic];
        }

    }
    [self updateJobFuctionTextForArray:self.selectedJobFunctionArray];
    [self updateTableIndexValues];
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.empJobFuncRowIndex inSection:TableSectionIndexEmploymentDetails]] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)selectJobFunctionControllerDidDeleteJobFunction:(CLSelectFunctionCategoryViewController*)controller withArray:(NSMutableArray *)jobFunctionArray{

    if (self.selectedJobFunctionArray == nil) {
        self.selectedJobFunctionArray = [[NSMutableArray alloc]init];
    }
    [self.selectedJobFunctionArray removeAllObjects];
    for (NSDictionary *dict in jobFunctionArray) {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
        [dic setObject:[dict objectForKey:@"function"] forKey:@"fnname"];
        [dic setObject:[dict objectForKey:@"jobFunctionCode"] forKey:@"fncode"];
        if ([dict objectForKey:@"jobFunctionGroupCode"]) {
            [dic setObject:[dict objectForKey:@"jobFunctionGroupCode"] forKey:@"jobFunctionGroupCode"];
        }
        else{
            [dic setObject:@"" forKey:@"jobFunctionGroupCode"];
        }
        [dic setObject:[dict objectForKey:@"jobFunctionOtherFlag"] forKey:@"other_flag"];
        if ([dict objectForKey:@"jobFunctionOtherText"]) {
            [dic setObject:[dict objectForKey:@"jobFunctionOtherText"] forKey:@"otherText"];
        }
        else{
            [dic setObject:@"" forKey:@"otherText"];
        }
        [self.selectedJobFunctionArray addObject:dic];
    }

    [self updateJobFuctionTextForArray:self.selectedJobFunctionArray];
    [self updateTableIndexValues];
    [self.tableView reloadData];
    
}

#pragma mark UIPickerView Methods

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView.tag==1) {
        return [self.currentEmploymentStatusArray count];
    }
    else if(pickerView.tag==2){
        return [self.previousEmploymentStatusArray count];
    }
    else{
        return [self.employmentJobScopeArray count];
    }
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = ColorCode_CareerLineGreen;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag==1) {
        label.text= [[self.currentEmploymentStatusArray objectAtIndex:row] objectForKey:kemploymentStatusTitleKey];
    }
    else if(pickerView.tag==2){
        label.text= [[self.previousEmploymentStatusArray objectAtIndex:row] objectForKey:kemploymentStatusTitleKey];
    }
    else{
        label.text= [[self.employmentJobScopeArray objectAtIndex:row] objectForKey:kemploymentJobScopeNameKey];
    }
    return label;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self getNumberOfSectionsForTable];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self getNumberOfRowsForSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==TableSectionIndexEmploymentStatus){
        if(indexPath.row==0){
            CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"employmentStatusFirsttextCellIdentifier"];
            [cell setTextInputView:self.pickerView];
            [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
            [cell setPlaceHoldrText:NSLocalizedString(@"Employment Status", @"Placeholder for employment status field in profile")];
            [cell setCellClearButtonMode:UITextFieldViewModeAlways];
            if (!self.selectedCurrentEmploymentStatus) {
                [cell setCellText:@""];
            }
            else{
                if ([self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusTitleKey]) {
                    [cell setCellText:[self.selectedCurrentEmploymentStatus objectForKey:kemploymentStatusTitleKey]];
                }
                else{
                    [cell setCellText:[self.selectedCurrentEmploymentStatus objectForKey:@"status"]];
                }
            }
            [cell setCellIndexPath:indexPath];
            cell.delegate=self;
            return cell;
        }
        else{
            CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"employmentStatusSecondtextCellIdentifier"];
            [cell setTextInputView:self.pickerView];
            [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
            if (!self.selectedPreviousEmploymentStatus) {
                [cell setCellText:@""];
            }
            else{
                if ([self.selectedPreviousEmploymentStatus objectForKey:kemploymentStatusTitleKey]) {
                    [cell setCellText:[self.selectedPreviousEmploymentStatus objectForKey:kemploymentStatusTitleKey]];
                }
                else{
                    [cell setCellText:[self.selectedPreviousEmploymentStatus objectForKey:@"SubStatus"]];
                }
            }
            [cell setPlaceHoldrText:NSLocalizedString(@"Have You Ever Been Employed?", @"Placeholder for 'Have you ever been employed' field in profile")];
            [cell setCellClearButtonMode:UITextFieldViewModeAlways];
            [cell setCellIndexPath:indexPath];
            cell.delegate=self;
            return cell;
        }
    }
    else{
        if (indexPath.row==self.empTypeRowIndex) {
            CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empTypeTextCellIdentifier"];
            
            if(self.selectedPreviousEmploymentStatus!=nil){
                [cell setPlaceHoldrText:NSLocalizedString(@"Past Employment Type", @"Placeholder text")];
            }
            else{
                [cell setPlaceHoldrText:NSLocalizedString(@"Current Employment Type", @"Placeholder text")];
            }
            
            [cell setCellClearButtonMode:UITextFieldViewModeAlways];
            if (!self.selectedEmploymentType) {
                [cell setCellText:@""];
            }
            else{
                if ([self.selectedEmploymentType objectForKey:kemploymentTypeNameKey]) {
                    [cell setCellText:[self.selectedEmploymentType objectForKey:kemploymentTypeNameKey]];
                }
                else{
                    [cell setCellText:[self.selectedEmploymentType objectForKey:@"type_employment"]];
                }
            }
            [cell setCellIndexPath:indexPath];
            cell.delegate=self;
            return cell;
        }
        else if (indexPath.row==self.empWorkCountryRowIndex){
            CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empCountryTextCellIdentifier"];
            [cell setPlaceHoldrText:NSLocalizedString(@"Country Location of This Job", @"Placeholder text")];
            cell.delegate=self;
            [cell setCellFont:[UIFont systemFontOfSize:14]];
            if (!self.selectedWorkCountry) {
                [cell setCellText:@""];
            }
            else{
                if ([self.selectedWorkCountry objectForKey:kLocationCountryName]) {
                    [cell setCellText:[self.selectedWorkCountry objectForKey:kLocationCountryName]];
                }
                else{
                    [cell setCellText:[self.selectedWorkCountry objectForKey:@"cy_name"]];
                }
            }
            [cell setCellIndexPath:indexPath];
            return cell;
        }
        else if (indexPath.row==self.empCompNameRowIndex){
            CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empCompanyNameTextCellIdentifier"];
            [cell setPlaceHoldrText:NSLocalizedString(@"Company Name", @"Placeholder text")];
            cell.delegate=self;
            [cell setCellFont:[UIFont systemFontOfSize:14]];
            if (!self.selectedCompany) {
                [cell setCellText:@""];
            }
            else{
                    [cell setCellText:[self.selectedCompany objectForKey:kCLCareerHistoryCompanyNamekey]];

            }
            [cell setCellIndexPath:indexPath];
            return cell;
        }
        
        else if (indexPath.row == self.empIndustryIndex){
            CLSimpleTappableTextCell *unctionCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empIndustryTextCellIdentifier"];
            [unctionCell setPlaceHoldrText:NSLocalizedString(@"Industry", @"Placeholder text")];
            unctionCell.delegate=self;
            [unctionCell setCellFont:[UIFont systemFontOfSize:13]];
            if (self.selectedindustry.count  != 0) {
                if ([[self.selectedindustry objectAtIndex:0]objectForKey:@"industry"] && [[self.selectedindustry objectAtIndex:0]objectForKey:@"industryGroupName"]) {
                    [unctionCell setCellText:[NSString stringWithFormat:@"%@ %@",[[self.selectedindustry objectAtIndex:0]objectForKey:@"industry"],[[self.selectedindustry objectAtIndex:0]objectForKey:@"industryGroupName"]]];
                }
                else{
                    [unctionCell setCellText:[NSString stringWithFormat:@"%@ %@",[[self.selectedindustry objectAtIndex:0]objectForKey:@"indname"],[[self.selectedindustry objectAtIndex:0]objectForKey:@"mainGroupName"]]];
                }
            }
            else{
                [unctionCell setCellText:@""];
            }
            [unctionCell setCellIndexPath:indexPath];
            return unctionCell;

        }
        else if (indexPath.row==self.empCompBusinessDivRowIndex){
                CLTappableTextViewCell *functionCell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empBusinessDivTextCellIdentifier"];
                [functionCell setCellPlaceHolderText:NSLocalizedString(@"Business Division", @"Placeholder text")];
                functionCell.delegate=self;
                [functionCell setCellFont:[UIFont systemFontOfSize:13]];
                [functionCell setCellText:self.selectedBusinessDivText];
                [functionCell setCellIndexPath:indexPath];
                return functionCell;
            }
        
        else if (indexPath.row==self.empCompLocRowIndex){
            CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empLocationTextCellIdentifier"];
            [cell setPlaceHoldrText:NSLocalizedString(@"Location Where Company Is Based", @"Placeholder text")];
            cell.delegate=self;
            [cell setCellFont:[UIFont systemFontOfSize:14]];
            if (!self.selectedCompanyLocation) {
                [cell setCellText:@""];
            }
            else{
                [cell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCompanyLocation objectForKey:kLocationName],[self.selectedCompanyLocation objectForKey:kLocationAdminArea],[self.selectedCompanyLocation objectForKey:kLocationCountryName]]];
            }
            [cell setCellIndexPath:indexPath];
            return cell;
        }
        else if (indexPath.row==self.empCompDescRowIndex){
            CLSimpleTextCell *descCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empCompanyDescTextCellIdentifier"];
            [descCell setTextInputAccesoryView:self.keyboardDoneToolbar];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Company Description", @"Placeholder text")];
            [descCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellText:self.companyDescText];
            [descCell returnKeyType:UIReturnKeyNext];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
        }
        else if (indexPath.row==self.empJobTitleRowIndex){
            CLSimpleTextCell *jobTitleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empJobTitleTextCellIdentifier"];
            [jobTitleCell setTextInputAccesoryView:self.keyboardDoneToolbar];
            if(self.selectedPreviousEmploymentStatus!=nil){
                [jobTitleCell setPlaceHoldrText:NSLocalizedString(@"Past Job Title", @"Placeholder for Past Job Title field in profile")];
            }
            else{
                [jobTitleCell setPlaceHoldrText:NSLocalizedString(@"Current Job Title", @"Placeholder for Job Title field in profile")];
            }
            [jobTitleCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [jobTitleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [jobTitleCell setCellText:self.jobTitleText];
            [jobTitleCell setCellIndexPath:indexPath];
            jobTitleCell.delegate=self;
            return jobTitleCell;
        }
        else if (indexPath.row==self.empJobFuncRowIndex){
            CLTappableTextViewCell *functionCell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"functionTappableCellIdentifier"];
            [functionCell setCellPlaceHolderText:NSLocalizedString(@"Function", @"Placeholder for Function field in profile")];
            functionCell.delegate=self;
            [functionCell setCellFont:[UIFont systemFontOfSize:13]];
            [functionCell setCellText:self.selectedJobFunctionText];
            [functionCell setCellIndexPath:indexPath];
            return functionCell;
        }
        else if (indexPath.row==self.empCareerLevelRowIndex){
            CLSimpleTappableTextCell *jobLevelcell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobLevelTappableCellIdentifier"];
            [jobLevelcell setPlaceHoldrText:NSLocalizedString(@"Career Level", @"Placeholder for Job Level field in profile")];
            jobLevelcell.delegate=self;
            [jobLevelcell setCellFont:[UIFont systemFontOfSize:14]];
            
            if(!self.selectedJobLevel)
                [jobLevelcell setCellCloseBtnOption:YES];
            else
                [jobLevelcell setCellCloseBtnOption:NO];
            
            if ([self.selectedJobLevel objectForKey:jobLevelDetailDictName]) {
                [jobLevelcell setCellText:[self.selectedJobLevel objectForKey:jobLevelDetailDictName]];
            }
            else{
                [jobLevelcell setCellText:[self.selectedJobLevel objectForKey:@"level_name"]];
            }
            [jobLevelcell setCellIndexPath:indexPath];
            return jobLevelcell;
        }
        else if (indexPath.row==self.empJobScopeRowIndex){
            CLSimpleTappableTextCell *jobScopeCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empJobScopeTextCellIdentifier"];
            [jobScopeCell setPlaceHoldrText:NSLocalizedString(@"Job Scope", @"Placeholder for Job Scope field in profile")];
            jobScopeCell.delegate=self;
            [jobScopeCell setCellFont:[UIFont systemFontOfSize:14]];
            
            if (!self.selectedJobScope) {
                [jobScopeCell setCellText:@""];
                [jobScopeCell setCellCloseBtnOption:YES];
            }
            else{
                [jobScopeCell setCellCloseBtnOption:NO];
                if ([self.selectedJobScope objectForKey:kemploymentJobScopeNameKey]) {
                    [jobScopeCell setCellText:[self.selectedJobScope objectForKey:kemploymentJobScopeNameKey]];
                }
                else{
                    [jobScopeCell setCellText:[self.selectedJobScope objectForKey:@"jobimpact"]];
                }
            }
            [jobScopeCell setCellIndexPath:indexPath];
            return jobScopeCell;

        }
    }
    return nil;
}


#pragma mark - Table view delegate

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section==TableSectionIndexEmploymentStatus){
        return NSLocalizedString(@"EMPLOYMENT STATUS", @"Title for employment status");
    }
    else if (section==TableSectionIndexEmploymentDetails){
        if(self.selectedCurrentEmploymentStatus && self.selectedPreviousEmploymentStatus){
            return NSLocalizedString(@"PAST EMPLOYMENT", @"Title for past employment details");
        }
        else{
            return NSLocalizedString(@"CURRENT EMPLOYMENT", @"Title for current employment details");
        }
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==TableSectionIndexEmploymentDetails){
        if (indexPath.row==self.empJobFuncRowIndex){
            return MAX(44, [self getHeightForTokenFieldWithText:self.selectedJobFunctionText]+10);
        }
        else{
            return 44;
        }
    }
    else{
        return 44;
    }
}

-(CGFloat)getHeightForTokenFieldWithText:(NSString*)text{
    [self.txtTokenField setFont:[UIFont systemFontOfSize:13]];
    [self.txtTokenField setPromptText:nil];
    [self.txtTokenField removeAllTokens];
    [self.txtTokenField addTokensWithTitleList:text];
    [self.txtTokenField layoutTokensAnimated:NO];
    return self.txtTokenField.bounds.size.height;
}



-(void)initCRFThreeDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    [CLCRFObject getCRFThreeDetailsForUser:[CLUserObject currentUser].email success:^(CLCRFThreeObject *threeObj){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.leftBarButtonItem.enabled = YES;
        self.navigationItem.rightBarButtonItem.enabled = YES;
        self.threeObj = threeObj;
        self.selectedWorkCountry = [self.threeObj.country mutableCopy];
        if (![[self.threeObj.employmentStatus objectForKey:@"id"]isEqualToString:@""]) {
            self.selectedCurrentEmploymentStatus = self.threeObj.employmentStatus;
            if (self.threeObj.employmentSubStatus) {
                self.selectedPreviousEmploymentStatus = self.threeObj.employmentSubStatus;
            }
            else{
                self.selectedPreviousEmploymentStatus = self.threeObj.employmentHistory;
            }
            
            if (![[NSString stringWithFormat:@"%@",[self.selectedPreviousEmploymentStatus objectForKey:@"id"]] isEqualToString:@"2"] || ![[NSString stringWithFormat:@"%@",[self.selectedCurrentEmploymentStatus objectForKey:@"id"]] isEqualToString:@"2"])  // UNEMPLOYED AND NO I HAVE NEVER BEEN EMPLOYED SELECTED
            {
                self.selectedEmploymentType = [self.threeObj.employmentType mutableCopy];
                
                self.selectedindustry = [NSMutableArray arrayWithObjects:self.threeObj.industry, nil];
                self.selectedMultipleBusDiv = [self.threeObj.businessDivision mutableCopy];
                self.isCompanyNotFound = [self.threeObj.isOtherCompany boolValue];
                if (![[self.threeObj.companyName objectForKey:@"companyName"] isEqualToString:@""]) {
                    self.selectedCompany = [self.threeObj.companyName mutableCopy];
                }
                else{
                    self.selectedCompany = [self.threeObj.otherCompany mutableCopy];
                }
                [self businessDivTextForArray:self.selectedMultipleBusDiv];
                self.companyDescText = [self.threeObj.otherCompany objectForKey:@"companyDescription"];
                self.jobTitleText = self.threeObj.jobTitle;
                self.selectedJobFunctionArray = [self.threeObj.function mutableCopy];
                [self updateJobFuctionTextForArray:self.selectedJobFunctionArray];
                self.selectedJobLevel = [self.threeObj.jobLevel mutableCopy];
                self.selectedJobScope = [self.threeObj.jobImpact mutableCopy];
            }

        }
        
        [self updateTableIndexValues];
        [self.tableView reloadData];
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.leftBarButtonItem.enabled = YES;
        self.navigationItem.rightBarButtonItem.enabled = YES;
        [CLCommon showAlertwithTitle:nil alertString:error cancelbuttonName:@"OK"];
    }];
    
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[UIColor blackColor];
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)clearValuesOnFields{
    [self.selectedEmploymentType removeAllObjects];
//    [self.selectedWorkCountry removeAllObjects];
    [self.selectedindustry removeAllObjects];
    [self.selectedMultipleBusDiv removeAllObjects];
    self.isCompanyNotFound = NO;

    [self.selectedCompany removeAllObjects];
    self.selectedBusinessDivText = @"";
    self.companyDescText = @"";
    self.jobTitleText = @"";
    [self.selectedJobFunctionArray removeAllObjects];
    self.selectedJobFunctionText = @"";
    [self.selectedJobLevel removeAllObjects];
    [self.selectedJobScope removeAllObjects];
}
@end
