//
//  CLProfileReferenceCell.m
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileReferenceCell.h"

@interface CLProfileReferenceCell()

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@end

@implementation CLProfileReferenceCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLProfileReferenceCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

-(void)updateCellContents{
    [self.lblTitle setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
    self.lblTitle.text=[NSString stringWithFormat:@"%@, %@, %@",self.revObj.refferedBy,self.revObj.jobTitle,self.revObj.Company];
    self.lblDescription.text=self.revObj.testimonials;
    self.lblDate.text=self.revObj.formattedDateString;
}

@end
