//
//  CLCareerHistoryCell.m
//  CareerLine
//
//  Created by RENJITH on 23/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerHistoryCell.h"
#import "NSDictionary+Additions.h"
#import "CLConstants.h"

@interface CLCareerHistoryCell()

@property (weak, nonatomic) IBOutlet UILabel *jobTitleLbl;
@property (weak, nonatomic) IBOutlet UILabel *jobDurationLbl;
@property (weak, nonatomic) IBOutlet UILabel *companyNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *companyLocationLbl;

@end

@implementation CLCareerHistoryCell

- (void)awakeFromNib
{
 
    // Initialization code
   

}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLCareerHistoryCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        self = [arrayOfViews objectAtIndex:0];
    }
   
    return self;
}
//-(NSInteger)getYearFromDateString:(NSString *)dateStr{
//
//    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
//    [dateFormatter setLocale:[NSLocale currentLocale]];
//    dateFormatter.dateFormat=@"dd-MM-yyyy";
//    NSDate *date = [dateFormatter dateFromString:dateStr];
//
//    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:date];
//
//    return [components year];
//}
-(NSInteger)getYearFromDate:(NSDate *)date{
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:date];
    
    return [components year];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    self.jobTitleLbl.text = self.careerHistoryObj.jobTitle;
    self.jobTitleLbl.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    NSString *duration;
    if (self.careerHistoryObj.durationFrom!=nil) {
        
        
        if (!self.careerHistoryObj.durationCurrent) {
            
            duration = [NSString stringWithFormat:@"%ld-%ld",(long)[self getYearFromDate:self.careerHistoryObj.durationFrom],(long)[self getYearFromDate:self.careerHistoryObj.durationTo]];
        }else{
            
            duration = [NSString stringWithFormat:@"%ld-%@",(long)[self getYearFromDate:self.careerHistoryObj.durationFrom],@"Current"];
        }
        self.jobDurationLbl.text = duration;
    }else{
        self.jobDurationLbl.text = @"";
    }
    if (![[self.careerHistoryObj.companyName objectForKeyNotNull:kCLCareerHistoryCompanyNamekey] isEqualToString:@""]) {
        self.companyNameLbl.text = [self.careerHistoryObj.companyName objectForKeyNotNull:kCLCareerHistoryCompanyNamekey];
    }else{
        self.companyNameLbl.text = [self.careerHistoryObj.otherCompanyName objectForKeyNotNull:kCLCareerHistoryCompanyNamekey];
    }
    
    self.companyLocationLbl.text = self.careerHistoryObj.careerLocation.locationName;
 
}

@end
