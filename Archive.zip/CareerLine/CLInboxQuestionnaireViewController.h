//
//  CLInboxQuestionnaireViewController.h
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTProgressHUD.h"
 
@interface CLInboxQuestionnaireViewController : UITableViewController<UIAlertViewDelegate,HTProgressHUDDelegate>

@property(strong,nonatomic) NSString *inboxId;
@property(strong,nonatomic) NSMutableArray *questionnaire;
@property(assign,nonatomic) BOOL isSubmitted;
@end
