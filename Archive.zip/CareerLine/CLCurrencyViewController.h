//
//  CLCurrencyViewController.h
//  CareerLine
//
//  Created by Abbin on 12/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CLCurrencyDelegate <NSObject>

-(void)loadSelectedCurrencyDictionary:(NSMutableDictionary*)dictionary;

@end

@interface CLCurrencyViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@property(nonatomic,weak) id <CLCurrencyDelegate>delegate;
@property(nonatomic, retain) NSMutableDictionary *alreadySelectedCurrency;

@end
