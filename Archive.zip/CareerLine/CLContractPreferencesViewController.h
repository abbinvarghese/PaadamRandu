//
//  CLContractPreferencesViewController.h
//  CareerLine
//
//  Created by Abbin on 07/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//
#import "CLContractPreferencesObject.h"
#import <UIKit/UIKit.h>
#import "CLTappableTextViewCell.h"
#import "CLSimpleTextCell.h"
#import "CLEmployeementTypeViewController.h"
#import "CLCurrencyViewController.h"
#import "CLTextCheckBoxCell.h"

@protocol contractPreferenceDelegate <NSObject>

-(void)loadPreferenceObject:(CLContractPreferencesObject*)object isEditOn:(BOOL)edit;

@end

@interface CLContractPreferencesViewController : UITableViewController<CLTappableCellDelegate,CLSimpleTextCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate,CLSelectEmpTypeDelegate,CLCurrencyDelegate,CLTextCheckBoxCellDelegate>

@property(nonatomic) BOOL isEditOn;
@property (nonatomic,retain) CLContractPreferencesObject *preferenceObject;

@property(nonatomic,retain)id<contractPreferenceDelegate> delegate;

@end
