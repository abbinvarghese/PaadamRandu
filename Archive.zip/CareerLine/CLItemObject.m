//
//  CLItemObject.m
//  CareerLine
//
//  Created by Pravin on 10/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLItemObject.h"
#import "CLFileObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLItemObject

static NSOperationQueue *saveItemRequest;
static NSOperationQueue *deleteItemRequest;
static NSOperationQueue *uploadItemDocumentRequest;
static NSOperationQueue *deleteItemDocumentRequest;



//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary{
    self.itemId=[dictionary objectForKeyNotNull:kCLProfileProtfolioItemIdkey];
    self.itemTitle=[dictionary objectForKeyNotNull:kCLProfileProtfolioItemTitlekey];
    self.itemRemarks=[dictionary objectForKeyNotNull:kCLProfileProtfolioItemRemarksKey];
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLProfileProtfolioItemFilesArraykey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    return self;
}

+(NSString*)jsonStringForObject:(CLItemObject*)itemObj{
    NSMutableDictionary *itemDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    [insideDict setObject:itemObj.itemTitle forKey:kCLProfileProtfolioItemTitlekey];
    [insideDict setObject:itemObj.itemRemarks forKey:kCLProfileProtfolioItemRemarksKey];
    
    [itemDict setObject:insideDict forKey:kCLProfileProtfolioItemArraykey];
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:itemDict];
}

//Method for saving item of a particular user...
+ (void)saveItem:(CLItemObject*)itemObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *itemId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *itemId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": itemObj.itemId, @"fields":[CLItemObject jsonStringForObject:itemObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLItemObject jsonStringForObject:itemObj]};
    }
    if (kDebugMessages) {
        NSLog(@"saveItem parameters: %@", parameters);
    }
    
    [saveItemRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveItemRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileItemSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveItem JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileItemSaveIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting item for a particular user...
+ (void)deleteItem:(NSString*)itemId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": itemId};
    if (kDebugMessages) {
        NSLog(@"delete item parameters: %@", parameters);
    }
    
    [deleteItemRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteItemRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioDeleteItemURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete item JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading item document for a particular user...
+ (void)addDocument:(UIImage*)image forItem:(NSString*)itemId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": itemId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadItemDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadItemDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileItemUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"Project" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"item document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting item document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteItemDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteItemDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileItemDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete item document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
