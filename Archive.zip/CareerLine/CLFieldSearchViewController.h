//
//  CLRegionModalViewController.h
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol CLFieldSearchDelegate <NSObject>

-(void)addSelectedFields:(NSMutableDictionary*)dictionary;

@end

#import "CLFieldEditViewController.h"

@interface CLFieldSearchViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,weak)id<CLFieldSearchDelegate>delegate;
@property(nonatomic,retain) NSMutableArray *selectedDictArray;
@property(nonatomic,retain) NSIndexPath *selectedIndex;
@property(nonatomic,retain) NSString *titleString;
@property(nonatomic) BOOL fromTwentyField;
@property(nonatomic,retain) NSMutableDictionary*currentLocationDictionary;
@end
