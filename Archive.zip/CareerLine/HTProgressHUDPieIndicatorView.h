//
//  HTProgressHUDPieIndicatorView.h
//  HTProgressHUD
//
//  Created by 최건우 on 13. 6. 30..
//  Copyright (c) 2013년 Hardtack. All rights reserved.
//

#import "HTProgressHUDIndicatorView.h"

@interface HTProgressHUDPieIndicatorView : HTProgressHUDIndicatorView

@property (nonatomic, strong) UIColor *tintColor; // Default is white

@end
