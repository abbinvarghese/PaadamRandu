//
//  CLLoginViewController.m
//  CareerLine
//
//  Created by CSG on 1/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLoginViewController.h"
#import "CLForgotPassViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "UIViewController+MMDrawerController.h"
#import "CLSideMenuViewController.h"
#import "UIImageView+WebCache.m"
#import "CLWelcomeScreenViewController.h"
#import "CLGetStartedViewController.h"
#import "CLPersonalProfileDetailsViewController.h"
#import "CLCRFAboutMeViewController.h"
#import "CLCRFEducationViewController.h"
#import "CLEmploymentDetailsViewController.h"
#import "CLLocationDetailsViewController.h"
#import "CLStatusViewController.h"
//#import "CLInboxQuestionnaireViewController.h"
//#import "CLQuestionnaireObject.h"


#define klogInUserEmail @"rememberedUserEmail"

@interface CLLoginViewController ()

//Login Success redirect type...
typedef enum {
	CLLoginSuccessTypeWelcomeScreen = 1,
	CLLoginSuccessTypeHomeScreen= 2
} CLLoginSuccessType;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *loginFieldsTopSpaceConstraint;
@property (weak, nonatomic) IBOutlet UITextField *txtEmailField;
@property (weak, nonatomic) IBOutlet UITextField *txtPasswordField;
@property (weak, nonatomic) IBOutlet UIButton *bttnLogin;
@property (nonatomic,strong) NSString * userID;
@property (nonatomic,strong) NSString * password;
@property (nonatomic,strong) NSString * welcomeStat;

- (IBAction)bttnActionLogin:(id)sender;
- (IBAction)bttnActionForgotPassword:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *versionLbl;
@end

@implementation CLLoginViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (self.fromRest) {
        [self setleftNavigationButton];
    }
    // Do any additional setup after loading the view from its nib.
    self.bttnLogin.layer.cornerRadius=4;
    self.txtEmailField.text = self.userEmail;
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *majorVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    self.versionLbl.text = [NSString stringWithFormat:@"Version %@",majorVersion];
    self.title=NSLocalizedString(@"Log In", @"Login page title");
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self registerForNotifications];
    
    self.txtEmailField.text = [[NSUserDefaults standardUserDefaults]
                            stringForKey:klogInUserEmail];
    
    [[UINavigationBar appearance] setBarTintColor:ColorCode_CareerLineGreen];
    self.navigationItem.leftBarButtonItem.title = @"Back";
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Login"];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [self resignAllFirstResponders];
    [self deRegisterFromNotifications];
}

-(void)viewDidDisappear:(BOOL)animated{
    
   
    
    [super viewDidDisappear:YES];
    [CLUserObject cancelPendingRequests];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITextfield Delegates

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if([self.txtEmailField isFirstResponder]){
        [self.txtPasswordField becomeFirstResponder];
    }
    else if ([self.txtPasswordField isFirstResponder]){
        [self.txtPasswordField resignFirstResponder];
        [self bttnActionLogin:nil];
    }
    return YES;
}

#pragma mark NSNotifications Methods

- (void)keyboardWasShown:(NSNotification*)aNotification
{
    self.loginFieldsTopSpaceConstraint.constant=90;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:[aNotification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue]];
    [UIView setAnimationCurve:[aNotification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue]];
    [UIView setAnimationBeginsFromCurrentState:YES];
    
    [self.view layoutIfNeeded];
    
    [UIView commitAnimations];
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    self.loginFieldsTopSpaceConstraint.constant=220;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:[aNotification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue]];
    [UIView setAnimationCurve:[aNotification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue]];
    [UIView setAnimationBeginsFromCurrentState:YES];
    
    [self.view layoutIfNeeded];
    
    [UIView commitAnimations];
}

#pragma mark IBActions

- (IBAction)bttnActionLogin:(id)sender {
    if([self isFieldsValid]){
        [self resignAllFirstResponders];
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Logging In...", @"Text displayed in the loading indicator while logging in");
        [progressHUD showInView:self.view];
    
        NSString *valueToSave = self.txtEmailField.text;
        [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:klogInUserEmail];
        [[NSUserDefaults standardUserDefaults] synchronize];
    
//        CLWelcomeScreenViewController *welcomeScreen=[[CLWelcomeScreenViewController alloc] initWithNibName:@"CLWelcomeScreenViewController" bundle:[NSBundle mainBundle]];
//        [CLCommon sharedInstance].userName=@"praveen@padmamtechnologies.com";
//        welcomeScreen.fromPageFlag=CLNavigationFromWelcomePage;
//        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain target:nil action:nil];
//        [self.navigationController pushViewController:welcomeScreen animated:YES];
        
//        CLGetStartedViewController *welcomeScreen=[[CLGetStartedViewController alloc] initWithNibName:@"CLGetStartedViewController" bundle:[NSBundle mainBundle]];
//        [CLCommon sharedInstance].userName=@"yoyopravin@gmail.com";
//        welcomeScreen.isFirstTime=NO;
//        [self.navigationController pushViewController:welcomeScreen animated:YES];
        
//        CLInboxQuestionnaireViewController *inboxQuestionnaireController=[[CLInboxQuestionnaireViewController alloc] initWithNibName:@"CLInboxQuestionnaireViewController" bundle:[NSBundle mainBundle]];
//        //inboxQuestionnaireController.inboxId=self.inbox.inboxId;
//        inboxQuestionnaireController.questionnaire=[[NSMutableArray alloc] initWithObjects:[[CLQuestionnaireObject alloc] initInboxWithDummyData],[[CLQuestionnaireObject alloc] initInboxWithDummyData],[[CLQuestionnaireObject alloc] initInboxWithDummyData], nil];
//        inboxQuestionnaireController.isSubmitted=NO;
//        [self.navigationController pushViewController:inboxQuestionnaireController animated:YES];
        
        self.navigationItem.hidesBackButton=YES;
        [CLUserObject loginUser:self.txtEmailField.text password:self.txtPasswordField.text typeAutoLogin:@"0"
//        [CLUserObject loginUser:@"testerios@padmamtechnologies.com" password:@"test12345" typeAutoLogin:@"0"
                        success:^(int successFlag, NSString *userName, NSString *password,int autosave, NSString *welcomeStat){
//                            [self.mm_drawerController setCenterViewController:SharedAppDelegate.profileNav withCloseAnimation:NO completion:nil];
                            [CLCommon sentEventNameToGoogleAnalytics:@"Login Action" screenName:@"IOS - Login"];
                            self.navigationItem.hidesBackButton=NO;
                            [progressHUD hideWithAnimation:YES];
                            if(successFlag==CLLoginSuccessTypeHomeScreen){
                                [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateSideMenuDetails];
                                [SharedAppDelegate updateCurrentTrafficLightColorAndUpdateNav];
                                [self dismissViewControllerAnimated:YES completion:nil];
                            }
                            else if (successFlag==CLLoginSuccessTypeWelcomeScreen){
                                if (autosave == 0) {
                                    [self pushViewControllerTotheCorrectPageWithUsername:userName andPassword:password WithWelcomeStat:welcomeStat];
                                }
                                else{
                                    if([CLCommon isOSversionLessThan8]){
                                        UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"CareerLine Has Detected An Abnormal Termination Of Session. Please Go Back To The Website To Recover The Data Or Click Discard To Continue", @"title") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"Cancel") otherButtonTitles:NSLocalizedString(@"Discard", @"Done"), nil];
                                        self.userID = userName;
                                        self.password = password;
                                        self.welcomeStat = welcomeStat;
                                        enterFuncAlert.tag=88;
                                        [enterFuncAlert show];
                                    }
                                    else{
                                        UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                                                       message: NSLocalizedString(@"CareerLine Has Detected An Abnormal Termination Of Session Please Go Back To The Website To Recover The Data Or Click Discard To Continue", @"title")
                                                                                                preferredStyle: UIAlertControllerStyleAlert];
                                        UIAlertAction *recoverAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", @"title") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                                            
                                            [CLUserObject logoutUser:[CLUserObject currentUser].userID
                                                             success:^{

                                                             }
                                                             failure:^(NSString *error){

                                                             }];
                                        }];
                                        
                                        UIAlertAction *discardAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Discard", @"title") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action){
                                            [self pushViewControllerTotheCorrectPageWithUsername:userName andPassword:password WithWelcomeStat:welcomeStat];
                                        }];
                                        [alert addAction:recoverAction];
                                        [alert addAction:discardAction];
                                        [self presentViewController:alert animated:YES completion:nil];
                                    }
                                }
                                
                            }
                        }
                        failure:^(NSString *error){
                            self.navigationItem.hidesBackButton=NO;
                            [progressHUD hideWithAnimation:YES];
                            if (![error isEqualToString:@""]) {
                                [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                            }
                        }];
    }
}

-(void)pushViewControllerTotheCorrectPageWithUsername:(NSString*)userName andPassword:(NSString*)password WithWelcomeStat:(NSString*)welcomeStat{
    switch ([welcomeStat integerValue]) {
        case 0:{
            CLWelcomeScreenViewController *welcomeScreen=[[CLWelcomeScreenViewController alloc] initWithNibName:@"CLWelcomeScreenViewController" bundle:[NSBundle mainBundle]];
            [CLCommon sharedInstance].userName=userName;
            [CLCommon sharedInstance].passWord=password;
            welcomeScreen.isFirstTime = YES;
            welcomeScreen.fromPageFlag=CLNavigationFromWelcomePage;
            self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain target:nil action:nil];
            [self.navigationController pushViewController:welcomeScreen animated:YES];
        }
            break;
        case 1:{
            CLCRFEducationViewController *controller = [[CLCRFEducationViewController alloc]initWithNibName:@"CLCRFEducationViewController" bundle:[NSBundle mainBundle]];
            controller.needCustomBackButtons = YES;
            [self.navigationController pushViewController:controller animated:YES];
        }
            break;
        case 2:{
            CLEmploymentDetailsViewController *employmentsView=[[CLEmploymentDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
            employmentsView.needCustomBackButtons = YES;
            [self.navigationController pushViewController:employmentsView animated:YES];
        }
            break;
        case 3:{
            CLLocationDetailsViewController *locationsView=[[CLLocationDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
            locationsView.needCustomBackButtons = YES;
            [self.navigationController pushViewController:locationsView animated:YES];
        }
            break;
        case 4:{
            CLStatusViewController *statusScreen=[[CLStatusViewController alloc] initWithNibName:@"CLStatusViewController" bundle:[NSBundle mainBundle]];
            statusScreen.isFromWelcomeScreen=YES;
            statusScreen.needCustomBackButtons = YES;
            [self.navigationController pushViewController:statusScreen animated:YES];
        }
            
        default:
            break;
    }
}

- (IBAction)bttnActionForgotPassword:(id)sender {
    CLForgotPassViewController *forgotPassController=[[CLForgotPassViewController alloc] initWithNibName:@"CLForgotPassViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:forgotPassController animated:YES];
}

#pragma mark Utility Functions

-(void)resignAllFirstResponders{
    [self.txtEmailField resignFirstResponder];
    [self.txtPasswordField resignFirstResponder];
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    if ([self.txtEmailField.text isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Email Address.", @"Error Message for null email address login field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        isValid=NO;
	}
    else if (![CLCommon validateEmailWithString:self.txtEmailField.text]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Email address.", @"Error Message for invalid email address for login") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        isValid=NO;
    }
    else if ([self.txtPasswordField.text isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Password.", @"Error Message for null password login field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        isValid=NO;
	}
//    else if ([self.txtPasswordField.text length]<8) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Password must contain minimum 8 characters", @"Error Message for password login field less than 6") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        isValid=NO;
//    }
    return isValid;
}

-(void)registerForNotifications{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
}

-(void)deRegisterFromNotifications{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

-(void)setleftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Back", @"contract prefference modal cancel button title") style:UIBarButtonItemStyleBordered target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0){
        [CLUserObject logoutUser:[CLUserObject currentUser].userID
                         success:^{
                             
                         }
                         failure:^(NSString *error){
                             
                         }];

    }
    else{
        [self pushViewControllerTotheCorrectPageWithUsername:self.userID andPassword:self.password WithWelcomeStat:self.welcomeStat];
    }
}


@end
