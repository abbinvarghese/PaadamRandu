//
//  CLLocationObject.m
//  CareerLine
//
//  Created by CSG on 7/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLocationObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager+Timeout.h"

#define kDebugMessages 0

@implementation CLLocationObject

static NSOperationQueue *getLocationsForSearchStringrequest;


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.adminArea = [dictionary objectForKey:@"adminArea"];
    if (self.adminArea==nil) {
        self.adminArea = [dictionary objectForKey:@"jobLocationAdminArea"];
    }
    self.countryName = [dictionary objectForKey:@"cyname"];
    if (self.countryName ==nil) {
        self.countryName = [dictionary objectForKey:@"jobLocationCountryName"];
    }
    self.locName = [dictionary objectForKey:@"location"];
    if (self.locName == nil) {
        self.locName = [dictionary objectForKey:@"jobLocationName"];
    }
    self.locationId=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocIdkey];
//    self.locationApartment=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocApartmentkey];
//    self.locationfloor=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocFloorkey];
//    self.locationHouseNumber=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocHouseNumberkey];
    [[dictionary objectForKeyNotNull:kCLProfileAboutMeLocIsCommAddresskey] isEqualToString:@"1"] ? (self.isCommunicationAddress=YES) : (self.isCommunicationAddress=NO);
    self.locationAddress=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocAddresskey];
    self.locationCode=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocCodekey];
    self.locationName=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocNamekey];
    self.countryCode =[dictionary objectForKeyNotNull:kCLQlfitnEducationLocationCountrykey];
    self.locationPincode=[dictionary objectForKeyNotNull:kCLProfileAboutMeLocPincodekey];
    self.formattedAddress=[self formattedAddressForDisplay];
    
    return self;
}

-(NSDictionary*)dictionaryForObject{
    NSMutableDictionary *tempDict=[[NSMutableDictionary alloc] init];
    
    if (self.locationId) {
        [tempDict setObject:self.locationId forKey:kCLProfileAboutMeLocIdkey];
    }
    
    if (self.isCommunicationAddress) {
        [tempDict setObject:@"1" forKey:kCLProfileAboutMeLocIsCommAddresskey];
    }
    else{
        [tempDict setObject:@"0" forKey:kCLProfileAboutMeLocIsCommAddresskey];
    }
    
    if (self.locationAddress) {
        [tempDict setObject:self.locationAddress forKey:kCLProfileAboutMeLocAddresskey];
    }
    
    if (self.locationCode) {
        [tempDict setObject:self.locationCode forKey:kCLProfileAboutMeLocCodekey];
    }
    
    if (self.locationPincode) {
        [tempDict setObject:self.locationPincode forKey:kCLProfileAboutMeLocPincodekey];
    }
    
    return tempDict;
}

-(void)updateFormattedAddress{
    self.formattedAddress=[self formattedAddressForDisplay];
}

-(NSString*)formattedAddressForDisplay{
    NSMutableString *formattedString=[[NSMutableString alloc] init];
    
//    if (self.locationApartment.length!=0) {
//        [formattedString appendFormat:@"%@, ",self.locationApartment];
//    }
//    if (self.locationfloor.length!=0) {
//        [formattedString appendFormat:@"%@, ",self.locationfloor];
//    }
//    if (self.locationHouseNumber.length!=0) {
//        [formattedString appendFormat:@"%@, ",self.locationHouseNumber];
//    }
    if (self.locationAddress.length!=0) {
        [formattedString appendFormat:@"%@, ",self.locationAddress];
    }
    if (self.locationName.length!=0) {
        [formattedString appendFormat:@"%@, ",self.locationName];
    }
    if (self.locationPincode.length!=0) {
        [formattedString appendFormat:@"%@, ",self.locationPincode];
    }
    if (formattedString.length>1) {
        [formattedString deleteCharactersInRange:NSMakeRange([formattedString length]-2, 2)];
    }
    
    return formattedString;
}

- (id)copyWithZone:(NSZone *)zone
{
    id copy = [[[self class] allocWithZone:zone] init];
    
    if (copy) {
        // Copy NSObject subclasses
        [copy setLocationId:[self.locationId copyWithZone:zone]];
//        [copy setLocationApartment:[self.locationApartment copyWithZone:zone]];
//        [copy setLocationfloor:[self.locationfloor copyWithZone:zone]];
//        [copy setLocationHouseNumber:[self.locationHouseNumber copyWithZone:zone]];
        [copy setLocationAddress:[self.locationAddress copyWithZone:zone]];
        [copy setLocationCode:[self.locationCode copyWithZone:zone]];
        [copy setLocationName:[self.locationName copyWithZone:zone]];
        [copy setLocationPincode:[self.locationPincode copyWithZone:zone]];
        [copy setCountryCode:[self.countryCode copyWithZone:zone]];
        [copy setFormattedAddress:[self.formattedAddress copyWithZone:zone]];
        
        // Set primitives
        [copy setIsCommunicationAddress:self.isCommunicationAddress];
    }
    
    return copy;
}

+ (void)cancelGetLocationRequest {
    [getLocationsForSearchStringrequest cancelAllOperations];
    getLocationsForSearchStringrequest = nil;
}

//Method for getting locations for home location listing...
+ (void)getLocationsForSearchString:(NSString*)keyword forPage:(int)pageNumber success:(void (^)(NSMutableArray *locationList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *locationList,BOOL isLastPageReached){};
    }
    
    NSDictionary *parameters = @{@"loc_str": keyword, @"page":[NSNumber numberWithInt:pageNumber]};
    
    [getLocationsForSearchStringrequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getLocationsForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceGetLocHomeSearchString] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"location JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *locations=[[NSMutableArray alloc] init];
                NSArray *results=[response objectForKey:@"results"];
                BOOL lastPageReached = NO;
                if ([[NSString stringWithFormat:@"%@",[response objectForKey:@"cur_page"]] isEqualToString:[NSString stringWithFormat:@"%@",[response objectForKey:@"pages"]]]) {
                    lastPageReached = YES;
                }
                for (int i=0; i<[results count]; i++) {
                    NSDictionary *locDetail=[results objectAtIndex:i];
                    NSString *loccode = [locDetail objectForKey:kCLGetLocHomeLocCodekey];
                    NSString *locname = [locDetail objectForKey:kCLGetLocHomeLocNamekey];
                    NSString *cycode = [locDetail objectForKey:kCLGetLocHomeCyCodekey];
                    NSString *cyname = [locDetail objectForKey:kCLGetLocHomeCyNamekey];
                    NSString *locAdminArea = [locDetail objectForKey:kCLGetLocHomeRegNamekey];
                    
                    [locations addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName,locAdminArea,kLocationAdminArea, nil]];
                }
                
                success(locations,lastPageReached);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            NSLog(@"%@",[CLCommon getMessageForErrorCode:error.code]);
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for getting locations for same country listing...
+ (void)getLocationsForSearchString:(NSString*)keyword withCountryCode:(NSString*)code notIn:(NSString*)blackListString forPage:(int)pageNumber success:(void (^)(NSMutableArray *locationList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *locationList,BOOL isLastPageReached){};
    }
    
    NSDictionary *parameters = @{@"loc_str": keyword, @"country": code, @"locations": blackListString, @"page":[NSNumber numberWithInt:pageNumber]};
    
    [getLocationsForSearchStringrequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getLocationsForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceGetLocSameCountrySearchString] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"location JSON: %@", response);
            }
            if ([[response objectForKey:@"message"] isEqualToString:@"No Results Found."]) {
                failure([response objectForKey:@"message"]);
            }
            else if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *locations=[[NSMutableArray alloc] init];
                NSArray *results=[response objectForKey:@"results"];
                BOOL lastPageReached = NO;
                if ([[NSString stringWithFormat:@"%@",[response objectForKey:@"cur_page"]] isEqualToString:[NSString stringWithFormat:@"%@",[response objectForKey:@"pages"]]]) {
                    lastPageReached = YES;
                }
                for (int i=0; i<[results count]; i++) {
                    NSDictionary *locDetail=[results objectAtIndex:i];
                    NSString *loccode = [locDetail objectForKey:kCLGetLocHomeLocCodekey];
                    NSString *locname = [locDetail objectForKey:kCLGetLocHomeLocNamekey];
                    NSString *cycode = [locDetail objectForKey:kCLGetLocHomeCyCodekey];
                    NSString *cyname = [locDetail objectForKey:kCLGetLocHomeCyNamekey];
                    NSString *locAdminArea = [locDetail objectForKey:kCLGetLocHomeRegNamekey];
                    
                    [locations addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName, locAdminArea,kLocationAdminArea,nil]];
                }
                
                success(locations,lastPageReached);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
