//
//  CLAssessmentObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAssessmentObject.h"
#import "CLFileObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLAssessmentObject

static NSOperationQueue *saveAssessmentRequest;
static NSOperationQueue *deleteAssessmentRequest;
static NSOperationQueue *uploadAssessmentDocumentRequest;
static NSOperationQueue *deleteAssessmentDocumentRequest;


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary{
    self.assessmentId=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentIdkey];
    self.assessmentTitle=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentTitlekey];
    //self.date=[CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentDatekey] andFormat:@"dd-MM-yyyy"];
    self.date=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMy"];
    }
    self.score=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentScorekey];
    self.url=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentURLkey];
    self.assessDescription=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentDescriptionkey];
    
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentFilesArraykey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    return self;
}

-(void)updateDate:(NSDate*)date{
    self.date=date;
    self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
}

+(NSString*)jsonStringForObject:(CLAssessmentObject*)assObj{
    NSMutableDictionary *assessmentDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    [insideDict setObject:assObj.assessmentTitle forKey:kCLProfileProtfolioAssessmentTitlekey];
    [insideDict setObject:[CLCommon getStringForDate:assObj.date andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileProtfolioAssessmentDatekey];
    if (assObj.score) {
        [insideDict setObject:assObj.score forKey:kCLProfileProtfolioAssessmentScorekey];
    }
    if (assObj.url) {
        [insideDict setObject:assObj.url forKey:kCLProfileProtfolioAssessmentURLkey];
    }
    if (assObj.assessDescription) {
        [insideDict setObject:assObj.assessDescription forKey:kCLProfileProtfolioAssessmentDescriptionkey];
    }
    
    [assessmentDict setObject:insideDict forKey:kCLProfileProtfolioAssessmentArraykey];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:assessmentDict];
}

//Method for saving asessment of a particular user...
+ (void)saveAssessment:(CLAssessmentObject*)assessObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *assessId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *workAchId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": assessObj.assessmentId, @"fields":[CLAssessmentObject jsonStringForObject:assessObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLAssessmentObject jsonStringForObject:assessObj]};
    }
    
    [saveAssessmentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveAssessmentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileAssessmentSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveAssessment JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAssessmentSaveIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting assessment for a particular user...
+ (void)deleteAssessment:(NSString*)assessmentId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": assessmentId};
    
    [deleteAssessmentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteAssessmentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioDeleteAssessmentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete assessment JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading assessment document for a particular user...
+ (void)addDocument:(UIImage*)image forAssessment:(NSString*)assessId andUser:(NSString *)userId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": assessId};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadAssessmentDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadAssessmentDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileAssessmentUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"Assessments" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"assessment document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting assessment document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteAssessmentDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteAssessmentDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
    
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileAssessmentDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete assessment document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
