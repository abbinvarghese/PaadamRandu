//
//  CLPerformanceReviewObject.h
//  CareerLine
//
//  Created by Pravin on 10/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLPerformanceReviewObject : NSObject

@property(nonatomic,strong)NSString *performanceId;
@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *performanceDescription;
@property(nonatomic,strong)NSMutableDictionary *careerSelected;
@property(nonatomic,strong)NSMutableArray *documents;       //[(CLFileObject),(CLFileObject),...]


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for saving PerformanceReview of a particular user...
+ (void)savePerformanceReview:(CLPerformanceReviewObject*)perfObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *perfId))success failure:(void (^)(NSString *error))failure;

//Method for deleting PerformanceReview for a particular user...
+ (void)deletePerformanceReview:(NSString*)perfId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading PerformanceReview document for a particular user...
+ (void)addDocument:(UIImage*)image forPerformanceReview:(NSString*)perfId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting PerformanceReview document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
