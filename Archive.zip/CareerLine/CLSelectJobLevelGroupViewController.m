//
//  CLSelectJobLevelGroupViewController.m
//  CareerLine
//
//  Created by CSG on 2/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectJobLevelGroupViewController.h"
#import "CLCoreDataHelper.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLSelectJobLevelGroupViewController ()

@property(nonatomic,strong)NSMutableArray *jobLevelGroupArray;
@property(nonatomic,strong)NSMutableArray* selectedCareerlevelDictArray;

typedef enum {
    CLCareerLevelSectionEditIndex = 0,
    CLCareerLevelSectionMainSelectionsIndex= 1,
    CLCareerLevelSectionMainSelectionWithoutEdit = 0
} CLCareerLevelSectionIndex;

@end

@implementation CLSelectJobLevelGroupViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
//    if (self.selectedCareerlevelDictArray.count > 0) {
//        [self.tableView setEditing:YES animated:YES];
//        [self.tableView setAllowsSelectionDuringEditing:YES];
//    }
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    if (self.selectedCareerlevelDictArray.count > 0) {
        [self.tableView setEditing:YES animated:YES];
        [self.tableView setAllowsSelectionDuringEditing:YES];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.selectedCareerlevelDictArray = [[NSMutableArray alloc]initWithArray:self.selectedCareerlevelDictArrayTwo];
    self.title=NSLocalizedString(@"Career Level", @"Select Career Level page title");
    if (!self.multipleSelectionON) {
        [self setLeftNavigationButton];
    }
    else{
        [self setRightNavigationButtun];
    }
    self.jobLevelGroupArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobLevelGroupFromDB];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)setRightNavigationButtun{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)bttnActionDone:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^(){
        if ([_delegateForJobfunction respondsToSelector:@selector(loadSelectedCareerLevelDictArray:withArray:)]) {
            [_delegateForJobfunction loadSelectedCareerLevelDictArray:self withArray:self.selectedCareerlevelDictArray];
        }
    }];
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([self.selectedCareerlevelDictArray count] > 0) {
        return 2;
    }
    else {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.selectedCareerlevelDictArray count] > 0) {
        switch (section) {
            case CLCareerLevelSectionEditIndex:
                return  self.selectedCareerlevelDictArray.count;
                break;
            case CLCareerLevelSectionMainSelectionsIndex:
                return self.jobLevelGroupArray.count;
                break;
                
            default:
                break;
        }
    }
    else {
        return [self.jobLevelGroupArray count];
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ((self.selectedCareerlevelDictArray.count >0) && self.multipleSelectionON) {
        switch (indexPath.section) {
            case CLCareerLevelSectionEditIndex:{
                UITableViewCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"cellidentify"];
                if (cellOne == nil) {
                    cellOne = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellidentify"];
                }
                [cellOne.textLabel setFont:[UIFont systemFontOfSize:12]];
                [cellOne.textLabel setNumberOfLines:0];
                cellOne.textLabel.textColor = ColorCode_CareerLineGreen;
                cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
                NSMutableDictionary *jobLevelGroup=[self.selectedCareerlevelDictArray objectAtIndex:indexPath.row];
                cellOne.textLabel.text=[jobLevelGroup objectForKey:jobLevelDetailDictName];
                
                return cellOne;
                
            }
                break;
                
            case CLCareerLevelSectionMainSelectionsIndex:{
                static NSString *CellIdentifier = @"Cell";
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
                    [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
                    [cell.textLabel setNumberOfLines:0];
                }
                
                NSMutableDictionary *jobLevelGroup=[self.jobLevelGroupArray objectAtIndex:indexPath.row];
                cell.textLabel.text=[jobLevelGroup objectForKey:kjobLevelGroupDictName];
//                [cell.detailTextLabel setText:[self getNumberForCellDetailTextLabel:indexPath]];
                
                return cell;
            }
                break;
                
            default:
                return nil;
                break;
        }
    }
    else{
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
            [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
            [cell.textLabel setNumberOfLines:0];
        }
        
        NSMutableDictionary *jobLevelGroup=[self.jobLevelGroupArray objectAtIndex:indexPath.row];
        cell.textLabel.text=[jobLevelGroup objectForKey:kjobLevelGroupDictName];
//        if (self.multipleSelectionON) {
//            [cell.detailTextLabel setText:[self getNumberForCellDetailTextLabel:indexPath]];
//        }
        return cell;
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if ((self.multipleSelectionON) && (indexPath.section == CLCareerLevelSectionEditIndex) && (self.selectedCareerlevelDictArray.count > 0)) {
        return YES;
    }
    else{
        return NO;
    }
    
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.selectedCareerlevelDictArray removeObjectAtIndex:indexPath.row];
        if(indexPath.row==0 && [self.selectedCareerlevelDictArray count]==0){
            [self.tableView setEditing:NO animated:NO];
            [self.tableView reloadData];
        }
        else{
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
}

//-(NSString*)getNumberForCellDetailTextLabel:(NSIndexPath*)indexPath {
//    NSString *sstring = [[NSString alloc]init];
//    int executive = 0;
//    int manegement = 0;
//    int teamMember = 0;
//    int student = 0;
//    for (NSMutableDictionary *dict in self.selectedCareerlevelDictArray) {
//        NSString *string = [dict objectForKey:kjobLevelGroupDictCode];
//        if ([string isEqualToString:@"10"]) {
//            executive++;
//        }
//        else if ([string isEqualToString:@"15"]){
//            manegement++;
//        }
//        else if ([string isEqualToString:@"20"]){
//            teamMember++;
//        }
//        else if ([string isEqualToString:@"25"]){
//            student++;
//        }
//    }
//    switch (indexPath.row) {
//        case 0:
//            sstring = [NSString stringWithFormat:@"%d",executive];
//            break;
//        case 1:
//            sstring = [NSString stringWithFormat:@"%d",manegement];
//            break;
//        case 2:
//            sstring = [NSString stringWithFormat:@"%d",teamMember];
//            break;
//        case 3:
//            sstring = [NSString stringWithFormat:@"%d",student];
//            break;
//            
//        default:
//            break;
//    }
//    return sstring;
//}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.selectedCareerlevelDictArray.count > 0) {
        if (indexPath.section == CLCareerLevelSectionMainSelectionsIndex) {
            CLSelectJobLevelDetailViewController *detailViewController = [[CLSelectJobLevelDetailViewController alloc] initWithNibName:@"CLSelectJobLevelDetailViewController" bundle:[NSBundle mainBundle]];
            if (self.multipleSelectionON) {
                [detailViewController setMultipleSelectionOn:YES];
            }
            detailViewController.delegate=self.delegate;
            detailViewController.selectedJobLevelGroupDict=[self.jobLevelGroupArray objectAtIndex:indexPath.row];
//            if (self.multipleSelectionON) {
                [detailViewController setSecondselectedCareerLevelGroupArray:self.selectedCareerlevelDictArray];
//            }
            [self.navigationController pushViewController:detailViewController animated:YES];
        }
    }
    else {
        CLSelectJobLevelDetailViewController *detailViewController = [[CLSelectJobLevelDetailViewController alloc] initWithNibName:@"CLSelectJobLevelDetailViewController" bundle:[NSBundle mainBundle]];
        if (self.multipleSelectionON) {
            [detailViewController setMultipleSelectionOn:YES];
        }
        detailViewController.delegate=self.delegate;
        detailViewController.selectedJobLevelGroupDict=[self.jobLevelGroupArray objectAtIndex:indexPath.row];
        if (self.selectedCareerlevelDict) {
            detailViewController.selectedCareerlevelDict = self.selectedCareerlevelDict;
        }
        if (self.multipleSelectionON) {
            [detailViewController setSecondselectedCareerLevelGroupArray:self.selectedCareerlevelDictArray];
        }
        
        [self.navigationController pushViewController:detailViewController animated:YES];
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (self.selectedCareerlevelDictArray.count > 0 && section == CLCareerLevelSectionEditIndex) {
        return NSLocalizedString(@"Edit Career Level", @"Title for edit job level");
    }
    else if (self.selectedCareerlevelDictArray.count > 0 && section == CLCareerLevelSectionMainSelectionsIndex){
        return NSLocalizedString(@"Which one best describes your job?", @"Title for job level");
    }
    else{
        return NSLocalizedString(@"Which one best describes your job?", @"Title for job level");
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

@end
