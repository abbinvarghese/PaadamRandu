//
//  CLTrainingObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLLocationObject.h"
#import "CLFileObject.h"

@interface CLTrainingObject : NSObject

@property(nonatomic,strong)NSString *trainingId;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *institution;
@property(nonatomic,strong)CLLocationObject *location;
@property(nonatomic,strong)NSDate *fromDate;
@property(nonatomic,strong)NSString *numberOfDays;
@property(nonatomic,strong)NSString *contents;
@property(nonatomic,strong)NSString *trainer;
@property(nonatomic,strong)NSString *vendor;
//@property(nonatomic,strong)NSString *relatedTo;
@property(nonatomic,strong)NSMutableArray *documentsUrl;//[(CLFileObject),(CLFileObject),...]

- (id)initWithDictionary:(NSDictionary*)dictionary;

+ (void)saveTraining:(CLTrainingObject*)trainingObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *traningId))success failure:(void (^)(NSString *error))failure;
@end
