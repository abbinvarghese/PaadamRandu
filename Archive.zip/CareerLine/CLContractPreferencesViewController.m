//
//  CLContractPreferencesViewController.m
//  CareerLine
//
//  Created by Abbin on 07/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLContractPreferencesViewController.h"


//#define kCLSalaryBasisNameKey @"salaryBasis"

@interface CLContractPreferencesViewController ()

@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (strong, nonatomic) IBOutlet UIToolbar *keybpadrToolBarWithoutCancel;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardToolBarWithCancel;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerView;

@property (nonatomic,retain) NSArray *salaryBasisArray;
@property (nonatomic,retain) NSArray *sectionHeader;

@property (strong ,nonatomic) UITextField *txtFirstResponder;

@property (nonatomic,retain) NSMutableArray *empContractType;
@property (nonatomic,retain) NSMutableDictionary *selectedEmpContractType;
@property (nonatomic,retain) NSMutableDictionary *selectedEmployMentType;
@property (nonatomic,retain) NSMutableDictionary *selectedSalarybasis;
@property (nonatomic,retain) NSMutableDictionary *selectedCurrencyDict;

@property(nonatomic,retain) NSString *minimumSalary;
@property(nonatomic,retain) NSString *salaryIncrease;
@property(nonatomic,retain) NSString *negotiable;
@property(nonatomic,retain) NSString *other;

typedef enum {
    CLContractPreferencesEmploymentTypeIndex = 0,
    CLContractPreferenceEmploymentContractTypeIndex= 1,
    CLContractPreferenceCurrencyIndex = 2,
    CLContractPreferenceMinimumSavaryIndex = 3,
    CLContractPreferenceSalaryBasisIndex = 4,
    CLContractPreferenceIncreaseOverCurrentSalaryIndex = 5,
    CLContractPreferenceNegotiableIndex = 6,
    CLContractPreferenceOtherIndex = 7
    
} CLContractConsiderationTableSectionIndex;

typedef enum {
    CLContractTypePickerTag = 1,
    CLSalaryBasisPickerTag= 2
} CLContractPreferencePickerViewPickerTag;

@end

@implementation CLContractPreferencesViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.selectedEmployMentType = [[NSMutableDictionary alloc]init];
    self.selectedEmpContractType = [[NSMutableDictionary alloc]init];
    self.selectedSalarybasis = [[NSMutableDictionary alloc]init];
    
    if (self.isEditOn) {
        [self setpreferenceObjectToFields];
    }
    
    self.title = NSLocalizedString(@"Preferences", @"Preferences title");
    
    [self SaveArrayOfSectionHeaders];
    [self saveArrayOfEmpContractType];
    if (self.selectedEmpContractType.count == 0) {
        self.selectedEmpContractType = [self.empContractType objectAtIndex:0];
    }
    [self saveArrayOfSalaryBasis];
    if (!self.isEditOn) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    [self.listTableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"currencyCell"];
    [self.listTableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"customeEmploymentTypeCell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"salaryBasisCell"];
    [self.listTableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"negotiableCell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"increseSalaryCell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"minimumSalarycell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"otherCell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"preferenceContractTypeCell"];
    [self.listTableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"preferenceCurrencyCell"];
    
    self.keybpadrToolBarWithoutCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardToolBarWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIPickerView *businessDivPickerView=[[UIPickerView alloc] init];
    businessDivPickerView.backgroundColor=[UIColor whiteColor];
    businessDivPickerView.tag =1;
    businessDivPickerView.delegate=self;
    businessDivPickerView.dataSource=self;
    businessDivPickerView.showsSelectionIndicator = YES;
    self.pickerView =businessDivPickerView;
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark UITableView delegate methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 8;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionHeader objectAtIndex:section];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLContractPreferencesEmploymentTypeIndex:{
            CLTappableTextViewCell *employmentTypeCell = (CLTappableTextViewCell*) [self.listTableView dequeueReusableCellWithIdentifier:@"customeEmploymentTypeCell"];
            employmentTypeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [employmentTypeCell setCellPlaceHolderText:NSLocalizedString(@"Employment Type", @"placeholder for Employment Type cell")];
            if (_selectedEmployMentType.count != 0) {
                [employmentTypeCell setCellText:[self getStringFromDictForEmploymentType]];
            }
            [employmentTypeCell setCellFont:[UIFont systemFontOfSize:13]];
            [employmentTypeCell setCellIndexPath:indexPath];
            employmentTypeCell.delegate = self;
            employmentTypeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            
            return employmentTypeCell;
        }
            break;
        case CLContractPreferenceEmploymentContractTypeIndex:{
            CLSimpleTextCell *contractTypeCell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"preferenceContractTypeCell"];
            contractTypeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [contractTypeCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [contractTypeCell setTextInputView:self.pickerView];
            [contractTypeCell setPlaceHoldrText:NSLocalizedString(@"Employment Contract Type", @"Placeholder for Employment Contract Type")];
            [contractTypeCell setCellText:[self.selectedEmpContractType objectForKey:kCLContractPreferenceemploymentContractkey]];
            [contractTypeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [contractTypeCell setCellIndexPath:indexPath];
            contractTypeCell.delegate=self;
            contractTypeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            return contractTypeCell;

        }
            break;
        case CLContractPreferenceCurrencyIndex:{
            CLTappableTextViewCell *currencyCell = (CLTappableTextViewCell*) [self.listTableView dequeueReusableCellWithIdentifier:@"currencyCell"];
            currencyCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [currencyCell setCellPlaceHolderText:NSLocalizedString(@"Currency", @"placeholder for currency cell")];
            if (_selectedCurrencyDict.count != 0) {
                [currencyCell setCellText:[self getStringFromDictForCurrency]];
            }
            [currencyCell setCellFont:[UIFont systemFontOfSize:13]];
            [currencyCell setCellIndexPath:indexPath];
            currencyCell.delegate = self;
            currencyCell.selectionStyle=UITableViewCellSelectionStyleNone;
            return currencyCell;

        }
            break;
        case CLContractPreferenceMinimumSavaryIndex:{
            CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"minimumSalarycell"];
            [cell setTextInputAccesoryView:self.keybpadrToolBarWithoutCancel];
            [cell setCellFont:[UIFont systemFontOfSize:13]];
            [cell setPlaceHoldrText:NSLocalizedString(@"Minimum Salary", @"placeholder text for Minimum Salary cell.")];
            [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [cell setCellClearButtonMode:UITextFieldViewModeAlways];
            [cell setKeyboardType:UIKeyboardTypeNumberPad];
            
            if (![self.minimumSalary isEqual:[NSNull null]]) {
                [cell setCellText:self.minimumSalary];
            }
            [cell setCellIndexPath:indexPath];
            cell.delegate=self;
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;

        }
            break;
        case CLContractPreferenceSalaryBasisIndex:{
            CLSimpleTextCell *salaryBasiscell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"salaryBasisCell"];
            [salaryBasiscell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [salaryBasiscell setTextInputView:self.pickerView];
            [salaryBasiscell setCellFont:[UIFont systemFontOfSize:13]];
            [salaryBasiscell setPlaceHoldrText:NSLocalizedString(@"Salary Basis", @"placeholder text for Salary basis.")];
            [salaryBasiscell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [salaryBasiscell setCellClearButtonMode:UITextFieldViewModeAlways];
            [salaryBasiscell setCellText:[self.selectedSalarybasis objectForKey:kCLContractPreferenceSalaryBasiskey]];
            [salaryBasiscell setCellIndexPath:indexPath];
            salaryBasiscell.delegate=self;
            salaryBasiscell.selectionStyle=UITableViewCellSelectionStyleNone;
            return salaryBasiscell;
        }
            break;
        case CLContractPreferenceIncreaseOverCurrentSalaryIndex:{
            CLSimpleTextCell *increseSalaryCell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"increseSalaryCell"];
            [increseSalaryCell setTextInputAccesoryView:self.keybpadrToolBarWithoutCancel];
            [increseSalaryCell setCellFont:[UIFont systemFontOfSize:13]];
            [increseSalaryCell setPlaceHoldrText:NSLocalizedString(@"% Increase over Current Salary", @"placeholder text for increase salary cell.")];
            [increseSalaryCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [increseSalaryCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [increseSalaryCell setKeyboardType:UIKeyboardTypeNumberPad];
            if (![self.salaryIncrease isEqual:[NSNull null]]) {
                [increseSalaryCell setCellText:self.salaryIncrease];
            }
            [increseSalaryCell setCellIndexPath:indexPath];
            increseSalaryCell.delegate=self;
            increseSalaryCell.selectionStyle=UITableViewCellSelectionStyleNone;
            return increseSalaryCell;

        }
            break;
        case CLContractPreferenceNegotiableIndex:{
//            CLSimpleTextCell *NegotiableCell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"negotiableCell"];
//            [NegotiableCell setTextInputAccesoryView:self.keybpadrToolBarWithoutCancel];
//            [NegotiableCell setCellFont:[UIFont systemFontOfSize:13]];
//            [NegotiableCell setPlaceHoldrText:NSLocalizedString(@"Negotiable", @"placeholder text for Negotiable cell.")];
//            [NegotiableCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//            [NegotiableCell setCellClearButtonMode:UITextFieldViewModeAlways];
//            if (![self.negotiable isEqual:[NSNull null]]) {
//                [NegotiableCell setCellText:self.negotiable];
//            }
//            [NegotiableCell setCellIndexPath:indexPath];
//            NegotiableCell.delegate=self;
//            NegotiableCell.selectionStyle=UITableViewCellSelectionStyleNone;
//            return NegotiableCell;
            
            CLTextCheckBoxCell *negotiableCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"negotiableCell"];
            negotiableCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [negotiableCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [negotiableCell setCellText:NSLocalizedString(@"Negotiable", @"placeholder text for Negotiable cell.")];
            [negotiableCell setCellFont:[UIFont systemFontOfSize:13]];
            [negotiableCell setCellTextColor:[UIColor darkGrayColor]];
            [negotiableCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
            [negotiableCell setCellIndexPath:indexPath];
            [negotiableCell disableCelltxtField];
            BOOL negotiable = NO;
            if ([[NSString stringWithFormat:@"%@",self.negotiable] isEqualToString:@"0"] || self.negotiable == nil) {
                negotiable = NO;
            }
            else{
                negotiable = YES;
            }
            [negotiableCell checkBoxClick:negotiable];
            negotiableCell.textCheckBoxdelegate=self;
            negotiableCell.selectionStyle = UITableViewCellSelectionStyleNone;
            return negotiableCell;
            

        }
            break;
        case CLContractPreferenceOtherIndex:{
            CLSimpleTextCell *otherCell = (CLSimpleTextCell *)[self.listTableView dequeueReusableCellWithIdentifier:@"otherCell"];
            [otherCell setTextInputAccesoryView:self.keybpadrToolBarWithoutCancel];
            [otherCell setCellFont:[UIFont systemFontOfSize:13]];
            [otherCell setPlaceHoldrText:NSLocalizedString(@"Other - Please Tell Us", @"placeholder text for other cell.")];
            [otherCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [otherCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [otherCell setKeyboardType:UIKeyboardTypeDefault];
            if (![self.other isEqual:[NSNull null]]) {
                [otherCell setCellText:self.other];
            }
            [otherCell setCellIndexPath:indexPath];
            otherCell.delegate=self;
            otherCell.selectionStyle=UITableViewCellSelectionStyleNone;
            return otherCell;
        }
            break;
        default:
            break;
    }
    return nil;
}




#pragma mark UIPickerView delegate methods

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    
    if (pickerView.tag == CLContractTypePickerTag) {
        label.text = [[self.empContractType objectAtIndex:row] objectForKey:kCLContractPreferenceemploymentContractkey];
        
    }
    else if (pickerView.tag == CLSalaryBasisPickerTag){
        label.text = [[self.salaryBasisArray objectAtIndex:row] objectForKey:kCLContractPreferenceSalaryBasiskey];
    }
    return label;
    
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (pickerView.tag == CLContractTypePickerTag) {
        return [self.empContractType count];
    }
    else if (pickerView.tag == CLSalaryBasisPickerTag){
        return [self.salaryBasisArray count];
    }
    return 1;
}



#pragma mark CustomCell delegate methods

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (indexPath.section) {
        case CLContractPreferenceMinimumSavaryIndex:
            self.minimumSalary = @"";
            break;
        case CLContractPreferenceSalaryBasisIndex:
            self.selectedSalarybasis = nil;
            break;
        case CLContractPreferenceIncreaseOverCurrentSalaryIndex:
            self.salaryIncrease = @"";
            break;
        case CLContractPreferenceNegotiableIndex:
            self.negotiable = @"";
            break;
        case CLContractPreferenceOtherIndex:
            self.other = @"";
            break;
            
        default:
            break;
    }
}

-(void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case CLContractPreferencesEmploymentTypeIndex:{
            CLEmployeementTypeViewController *controller = [[CLEmployeementTypeViewController alloc]initWithNibName:@"CLEmployeementTypeViewController" bundle:[NSBundle mainBundle]];
            controller.delegate =self;
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
            [self presentViewController:nav animated:YES completion:nil];
        }
            break;
        case CLContractPreferenceCurrencyIndex:{
            CLCurrencyViewController *currencyController = [[CLCurrencyViewController alloc]initWithNibName:@"CLCurrencyViewController" bundle:[NSBundle mainBundle]];
            currencyController.delegate = self;
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:currencyController];
            [self presentViewController:nav animated:YES completion:nil];
        }
            break;
            
        default:
            break;
    }
}

-(void)selectEmployeementType:(CLEmployeementTypeDetailsViewController *)controller withDictonary:(NSMutableDictionary *)selectedEmpTypeDict{
    self.selectedEmployMentType = [self editedEmploymentTypeDictionaryFrom:selectedEmpTypeDict];
    [self.listTableView reloadData];
}

-(NSMutableDictionary*)editedEmploymentTypeDictionaryFrom:(NSMutableDictionary*)dictionary{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setValue:[dictionary objectForKey:kCLContractConsiderationEmpDetailIdKey] forKey:kCLContractPreferenceEmploymentIdkey];
    [dict setValue:[NSString stringWithFormat:@"%@ - %@", [dictionary objectForKey:kCLContractConsiderationNameKey],[dictionary objectForKey:kCLContractConsiderationEmpDetailNameKey]] forKey:kCLContractPreferenceemploymentTypekey];
    return dict;
}

-(void)loadSelectedCurrencyDictionary:(NSMutableDictionary *)dictionary{
    self.selectedCurrencyDict = [self editedCurrencyDictFrom:dictionary];
    [self.listTableView reloadData];
}

-(NSMutableDictionary*)editedCurrencyDictFrom:(NSMutableDictionary*)dictionary{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setValue:[dictionary objectForKey:kCLContractConsiderationCountryCode] forKey:kCLContractPreferenceCountryIdkey];
    [dict setValue:[NSString stringWithFormat:@"%@/%@",[dictionary objectForKey:kCLContractConsiderationCurrencyCode],[dictionary objectForKey:kCLContractConsiderationCountryNameKey]] forKey:kCLContractPreferenceCurrencykey];
    return dict;
}


-(void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLContractPreferenceMinimumSavaryIndex:
            self.minimumSalary = text;
            break;
        case CLContractPreferenceIncreaseOverCurrentSalaryIndex:
            self.salaryIncrease = text;
            break;
        case CLContractPreferenceNegotiableIndex:
            self.negotiable = text;
            break;
        case CLContractPreferenceOtherIndex:
            self.other = text;
            break;
        default:
            break;
    }
}

-(void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath = cell.cellIndexPath;
    
    if (indexPath.section == CLContractPreferenceEmploymentContractTypeIndex) {
        self.pickerView.tag = CLContractTypePickerTag;
    }
    else if(indexPath.section == CLContractPreferenceSalaryBasisIndex){
        self.pickerView.tag = CLSalaryBasisPickerTag;
    }
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    [self.pickerView reloadAllComponents];
}




#pragma mark IBActions

-(IBAction)bttnActionDismissModal:(id)sender{
    [self.txtFirstResponder resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(BOOL)isTheFieldsValid{
    BOOL firldsAreValid = YES;
    
    if (self.selectedEmployMentType.count < 1) {
        firldsAreValid = NO;
        [CLCommon showAlertwithTitle:@"Alert" alertString:NSLocalizedString(@"Employment Type is Required Field", @"Error message when fileds are selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }
//    else{
//        if (self.selectedEmpContractType.count < 1) {
//            firldsAreValid = NO;
//            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Employment Contract Type is Required Field", @"Error message when fileds are selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
//        }
//    }
    else if (self.selectedEmpContractType.count < 1){
        firldsAreValid = NO;
        [CLCommon showAlertwithTitle:@"Alert" alertString:NSLocalizedString(@"Employment Contract Type is Required Field", @"Error message when fileds are selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }
    else if (self.minimumSalary.length > 9){
        firldsAreValid = NO;
        [CLCommon showAlertwithTitle:@"Alert" alertString:NSLocalizedString(@"Minumum Salary should be less than 9 digits", @"Error message when fileds are selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }
    else if (self.salaryIncrease.length > 9){
        firldsAreValid = NO;
        [CLCommon showAlertwithTitle:@"Alert" alertString:NSLocalizedString(@"Salary Increase should be less than 9 digits", @"Error message when minimum salary exeed") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }
    
    
    return firldsAreValid;
}

-(IBAction)bttnActionSavePrefferenceAndDismissModal:(id)sender{
    if ([self isTheFieldsValid]) {
        [self savePreferenceObject];
        [self.txtFirstResponder resignFirstResponder];
        if (self.isEditOn) {
            if([_delegate respondsToSelector:@selector(loadPreferenceObject:isEditOn:)])
            {
                [_delegate loadPreferenceObject:self.preferenceObject isEditOn:_isEditOn];
            }
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }
        else{
            [self dismissViewControllerAnimated:YES completion:^(){
                if([_delegate respondsToSelector:@selector(loadPreferenceObject:isEditOn:)])
                {
                    [_delegate loadPreferenceObject:self.preferenceObject isEditOn:_isEditOn];
                }
            }];
        }
    }
    
}

- (IBAction)keyboardWithNocancelClickedDone:(UIBarButtonItem *)sender {
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)keyboardDoneClicked:(id)sender{
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.listTableView indexPathForCell:cell];
    
    if (index.section == CLContractPreferenceEmploymentContractTypeIndex) {
        NSInteger row = [self.pickerView selectedRowInComponent:0];
                CLSimpleTextCell *empContractTypeCell;
                empContractTypeCell=(CLSimpleTextCell*)[self.listTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLContractPreferenceEmploymentContractTypeIndex]];
                [empContractTypeCell setCellText:[[self.empContractType objectAtIndex:row] objectForKey:kCLContractPreferenceemploymentContractkey]];
                self.selectedEmpContractType = [self.empContractType objectAtIndex:row];
    }
    else if (index.section == CLContractPreferenceSalaryBasisIndex) {
        NSInteger row = [self.pickerView selectedRowInComponent:0];
                CLSimpleTextCell*salaryBasisCell;
                salaryBasisCell=(CLSimpleTextCell*)[self.listTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLContractPreferenceSalaryBasisIndex]];
                [salaryBasisCell setCellText:[[self.salaryBasisArray objectAtIndex:row] objectForKey:kCLContractPreferenceSalaryBasiskey]];
                self.selectedSalarybasis = [self.salaryBasisArray objectAtIndex:row];
    }

    
    [self.txtFirstResponder resignFirstResponder];
    
}

- (IBAction)bttnActionKeyboardCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}




#pragma mark Utility

-(NSString*)getStringFromDictForEmploymentType{
    NSString *string = [NSString stringWithFormat:@"%@|",[_selectedEmployMentType objectForKey:kCLContractPreferenceemploymentTypekey]];
    return string;
}

-(NSString*)getStringFromDictForCurrency{
    NSString *string = [NSString stringWithFormat:@"%@",[self.selectedCurrencyDict objectForKey:kCLContractPreferenceCurrencykey]];
    return string;
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"contract prefference modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"ontract prefference modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSavePrefferenceAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)savePreferenceObject{
    if (!self.isEditOn) {
        self.preferenceObject = [[CLContractPreferencesObject alloc]init];
    }
    self.preferenceObject.employMentTypeDict = [self EditedSelectedEmploymentTypefrom:self.selectedEmployMentType];
    self.preferenceObject.contractTypeDict = self.selectedEmpContractType;
    self.preferenceObject.currencyDict = self.selectedCurrencyDict;
    self.preferenceObject.minimumSalary = self.minimumSalary;
    self.preferenceObject.salaryBasisDict = self.selectedSalarybasis;
    self.preferenceObject.increaseInSalary = self.salaryIncrease;
    self.preferenceObject.negotiable = self.negotiable;
    self.preferenceObject.Other = self.other;
    
}

-(void)setpreferenceObjectToFields{
    
    self.selectedEmployMentType = self.preferenceObject.employMentTypeDict;
    self.selectedEmpContractType = self.preferenceObject.contractTypeDict;
    self.selectedCurrencyDict = self.preferenceObject.currencyDict;
    self.minimumSalary = self.preferenceObject.minimumSalary;
    self.selectedSalarybasis = self.preferenceObject.salaryBasisDict;
    self.salaryIncrease = self.preferenceObject.increaseInSalary;
    self.negotiable = self.preferenceObject.negotiable;
    self.other = self.preferenceObject.Other;
}



-(NSMutableDictionary*)EditedSelectedEmploymentTypefrom:(NSMutableDictionary*)dictionary{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setValue:[dictionary objectForKey:kCLContractPreferenceEmploymentIdkey] forKey:kCLContractPreferenceEmploymentIdkey];
    [dict setValue:[NSString stringWithFormat:@"%@",[dictionary objectForKey:kCLContractPreferenceemploymentTypekey]] forKey:kCLContractPreferenceemploymentTypekey];
    return dict;
}

-(void)saveArrayOfEmpContractType{
    self.empContractType = [NSMutableArray arrayWithObjects:
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"1",kempContractId,
                             NSLocalizedString(@"Local", @"Local text"),kCLContractPreferenceemploymentContractkey,
                             nil],
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"2",kempContractId,
                             NSLocalizedString(@"Local Plus", @"Local Plus text"),kCLContractPreferenceemploymentContractkey,
                             nil],
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"3",kempContractId,
                             NSLocalizedString(@"Expat", @"Expat text"),kCLContractPreferenceemploymentContractkey,
                             nil],
                            nil];
    
}

-(void)SaveArrayOfSectionHeaders{
    self.sectionHeader = [[NSArray alloc]initWithObjects:
                          NSLocalizedString(@"Employment Type",@"Employment Type heading text"),
                          NSLocalizedString(@"Employment Contract Type", @"Employment Contract Type heading"),
                          NSLocalizedString(@"Currency", @"Currency heading"),
                          NSLocalizedString(@"Minimum Salary Value",@"Minimum Salary heading"),
                          NSLocalizedString(@"Salary Basis", @"Salary basis heading"),
                          NSLocalizedString(@"Or % Increase Over Current Salary", @"salary increase heading"),
                          NSLocalizedString(@"Or Negotiable", @"Negotiable heading"),
                          NSLocalizedString(@"Or Other-Please Tell Us", @"Other heading"), nil];
}

-(void)saveArrayOfSalaryBasis{
    self.salaryBasisArray = [[NSArray alloc]initWithObjects:
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"1",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Hourly", @"hourly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"2",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Daily", @"daily selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"3",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Weekly", @"weekly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"4",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Bi-Weekly", @"bi-weekly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"5",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Monthly", @"monthly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"6",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Bi-Monthly", @"bi-monthly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"7",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Quarterly", @"quarterly selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"8",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Annually", @"annually selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"9",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"On Completion (100% on Completion)", @"On Completion selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"10",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Phased Payments (e.g 30% on start, 70% on Completion)", @"phased payments selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             [NSDictionary dictionaryWithObjectsAndKeys:
                              @"11",kCLContractPreferenceSalaryBasisID,
                              NSLocalizedString(@"Other", @"other selection"),kCLContractPreferenceSalaryBasiskey,
                              nil],
                             nil];
}


#pragma mark -
#pragma mark CLTextCheckBox delegate

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    self.negotiable = [NSString stringWithFormat:@"%d",status];
}


@end
