//
//  CLContractConsiderationsViewController.m
//  CareerLine
//
//  Created by Abbin on 07/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLContractConsiderationsViewController.h"
#import "CLConstants.h"
#import "CLContractConsiderationObject.h"


#define kSectionFooterBgColor [UIColor whiteColor]

@interface CLContractConsiderationsViewController ()

typedef enum {
    CLContractConsiderationPreferencesIndex = 0,
    CLContractConsiderationWhenCanYouStartIndex= 1,
    CLContractConsiderationAnyThingElseIndex = 2
} CLContractConsiderationTableSectionIndex;

@property (strong,nonatomic) IBOutlet UIToolbar *keyboardToolBarWithCancel;
@property (strong,nonatomic) IBOutlet UIPickerView *pickerView;
@property (weak,nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;

@property (nonatomic,retain) NSMutableArray *preferenceObjectArray;
@property (nonatomic,retain) NSMutableDictionary *selectedWhenCanYouStartDict;
@property (nonatomic,retain) NSArray* sectionHeadings;
@property (nonatomic,retain) NSArray *startArray;
@property (nonatomic,retain) NSString *anythingElseString;
@property (nonatomic,retain) NSIndexPath *selectedIndexPath;
@property(nonatomic,strong)NSNumber *descriptionHeight;


@property (nonatomic,retain) CLContractConsiderationObject *contractConsiderationObj;
@property (nonatomic,retain) CLContractPreferencesObject *preferenceObject;
@property (strong, nonatomic) HTProgressHUD *activityIndicator;

@end

@implementation CLContractConsiderationsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.preferenceObjectArray = [[NSMutableArray alloc]init];
    self.preferenceObject = [[CLContractPreferencesObject alloc]init];
    
    [self getContractConsiderationsSummaryDetails];
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"startCell"];
//    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"anythingCell"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"anythingElseCellIdentifier"];
    
    
    
    [self setRightNavigationButton];
    [self saveStartArray];
    
    self.title = NSLocalizedString(@"Contract Considerations", @"Contract Considerations title");
    self.keyboardToolBarWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignView.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
    
    self.sectionHeadings = [[NSArray alloc]initWithObjects: NSLocalizedString(@"Preferences",@"Preferences heading text"),NSLocalizedString(@"When can you start?",@"When can you start heading text"),NSLocalizedString(@"Anything else to say about this?:",@"any thing else heading text"), nil];
    
    UIPickerView *businessDivPickerView=[[UIPickerView alloc] init];
    businessDivPickerView.backgroundColor=[UIColor whiteColor];
    businessDivPickerView.tag =1;
    businessDivPickerView.delegate=self;
    businessDivPickerView.dataSource=self;
    businessDivPickerView.showsSelectionIndicator = YES;
    self.pickerView =businessDivPickerView;
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Contract Considerations"];
}

-(void)viewWillDisappear:(BOOL)animated{
    [self.tableView setEditing:NO animated:NO];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [CLContractConsiderationObject cancelContractConsiderationSummeryRequest];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}





#pragma mark TableView delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(self.contractConsiderationObj){
        return [self.sectionHeadings count];
    }
    else{
        return 0;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == CLContractConsiderationPreferencesIndex) {
        return [self.preferenceObjectArray count];
    }
    else {
        return 1;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLContractConsiderationPreferencesIndex:{
            
            [self.tableView setAllowsSelectionDuringEditing:YES];

            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contractConsiderationCell"];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"contractConsiderationCell"];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.textLabel.font = [UIFont systemFontOfSize:13];
            }
            
            NSString *text = [self getTextLabelFromObject:indexPath];
            
            if (text.length)
                [self.tableView setEditing:YES animated:YES];
                
            cell.textLabel.text = [self getTextLabelFromObject:indexPath];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
        case CLContractConsiderationWhenCanYouStartIndex: {
            CLSimpleTextCell *startCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"startCell"];
            [startCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [startCell setTextInputView:self.pickerView];
            [startCell setCellFont:[UIFont systemFontOfSize:13]];
            [startCell setPlaceHoldrText:NSLocalizedString(@"When Can You Start?", @"placeholder text for When can you start.")];
            [startCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [startCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [startCell setCellText:[self.selectedWhenCanYouStartDict objectForKey:kCLContractConsiderationavailabilityNamekey]];
            [startCell setCellIndexPath:indexPath];
            startCell.selectionStyle=UITableViewCellSelectionStyleNone;
            startCell.delegate=self;
            
            return startCell;
        }
            break;
        case CLContractConsiderationAnyThingElseIndex:{
//            CLSimpleTextCell *anythingElseCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"anythingCell"];
//            [anythingElseCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
//            [anythingElseCell setCellFont:[UIFont systemFontOfSize:13]];
//            [anythingElseCell setPlaceHoldrText:NSLocalizedString(@"Anything else to say about this?", @"placeholder text for Anything")];
//            [anythingElseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//            [anythingElseCell setCellClearButtonMode:UITextFieldViewModeAlways];
//            [anythingElseCell setCellText:self.anythingElseString];
//            [anythingElseCell setCellIndexPath:indexPath];
//            anythingElseCell.delegate=self;
            
            CLHeightAdjustTextCell *anythingElseCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"anythingElseCellIdentifier"];
            anythingElseCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [anythingElseCell setTextInputAccesoryView:self.keyboardResignView];
            [anythingElseCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for Anything else you want to say about this")];
            [anythingElseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [anythingElseCell setCellFont:[UIFont systemFontOfSize:13]];
            anythingElseCell.text=self.anythingElseString;
            [anythingElseCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [anythingElseCell setCellIndexPath:indexPath];
            anythingElseCell.delegate=self;
            anythingElseCell.selectionStyle=UITableViewCellSelectionStyleNone;
            return anythingElseCell;
        }
            break;
            
        default:
            break;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.preferenceObjectArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLContractConsiderationPreferencesIndex) {
        return YES;
    }
    else{
        return NO;
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionHeadings objectAtIndex:section];
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
    [sectionFooter addSubview:button];
    if (section == CLContractConsiderationPreferencesIndex) {
        return sectionFooter;
    }
    else return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == CLContractConsiderationPreferencesIndex) {
        return 37.0;
    }
    else return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLContractConsiderationAnyThingElseIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.anythingElseString];
        }
        return MAX(44, ansHeight+1);
    }
    else{
        return 44;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        self.selectedIndexPath = indexPath;
        CLContractPreferencesViewController *prefferenceController = [[CLContractPreferencesViewController alloc]initWithNibName:@"CLContractPreferencesViewController" bundle:[NSBundle mainBundle]];
        prefferenceController.delegate=self;
        [prefferenceController setIsEditOn:YES];
        [prefferenceController setPreferenceObject:[self.preferenceObjectArray objectAtIndex:indexPath.row]];
        [self.navigationController pushViewController:prefferenceController animated:YES];
        
    }
}

- (IBAction)doneButtonAction:(UIBarButtonItem *)sender {
    [self.txtViewFirstResponder resignFirstResponder];
}


#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.anythingElseString=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}


#pragma mark CustomCell delegate methods

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    if (indexPath.section == CLContractConsiderationWhenCanYouStartIndex) {
        self.selectedWhenCanYouStartDict = nil;
    }
    else if (indexPath.section == CLContractConsiderationAnyThingElseIndex){
        self.anythingElseString = @"";
    }
}

-(void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath = cell.cellIndexPath;
    if (indexPath.section == CLContractConsiderationWhenCanYouStartIndex) {
        self.pickerView.tag = 1;
    }
    else if (indexPath.section == CLContractConsiderationAnyThingElseIndex){
        self.pickerView.tag = 2;
    }
    [self.pickerView reloadAllComponents];
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
}

-(void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath withText:(NSString *)text{
    if (indexPath.section == CLContractConsiderationAnyThingElseIndex) {
        self.anythingElseString = text;
    }
}

-(void)loadPreferenceObject:(CLContractPreferencesObject *)object{
    if (object.objectId.length == 0) {
        [self.preferenceObjectArray addObject:object];
    }
    else{
        [self.preferenceObjectArray replaceObjectAtIndex:self.selectedIndexPath.row withObject:object];
    }
    
        [self.tableView reloadData];
}

-(void)loadPreferenceObject:(CLContractPreferencesObject *)object isEditOn:(BOOL)edit{
    if (!edit) {
        [self.preferenceObjectArray addObject:object];
    }
    else{
        [self.preferenceObjectArray replaceObjectAtIndex:self.selectedIndexPath.row withObject:object];
    }
    
    [self.tableView reloadData];
}


#pragma mark PickeView delegate

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [self.startArray count];
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    
    if (pickerView.tag == 1) {
        label.text = [[self.startArray objectAtIndex:row] objectForKey:kCLContractConsiderationavailabilityNamekey];
    }
    return label;
}



#pragma mark IBActions

-(IBAction)bttnActionSaveAndDismissModal:(id)sender{
    
    [self.view endEditing:YES];
//    if (self.preferenceObjectArray.count != 0) {
    self.anythingElseString = [self.anythingElseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    if ([self doesItHaveSapce:cutString]) {
//        self.anythingElseString = @"";
//    }
        [self saveContractConsiderations];
//    }
//    else{
//        [CLCommon showAlertwithTitle:@"Alert" alertString:NSLocalizedString(@"Need atleast one Preferences to save", @"Error message when no preferrence is seved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
//    }
    
}

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    CLContractPreferencesViewController *prefferenceController = [[CLContractPreferencesViewController alloc]initWithNibName:@"CLContractPreferencesViewController" bundle:[NSBundle mainBundle]];
    prefferenceController.delegate=self;
    UINavigationController *prefferenceNav = [[UINavigationController alloc]initWithRootViewController:prefferenceController];
    [self presentViewController:prefferenceNav animated:YES completion:nil];
}

- (IBAction)cancelButton:(UIBarButtonItem *)sender {
    [self.txtFirstResponder resignFirstResponder];
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    UITextField * alertTextField = [alertView textFieldAtIndex:0];
    NSString *cutString = [alertTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    if (buttonIndex ==1 && ![cutString isEqualToString:@""] && ![CLCommon doesItHaveSpace:cutString]){
        CLSimpleTextCell *whenCanYouStartCell;
        whenCanYouStartCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
        [whenCanYouStartCell setCellText:cutString];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:@"1" forKey:kCLContractConsiderationOtherkey];
        //[dict setObject:@"0" forKey:@"id"];
        //[dict setObject:[self.selectedWhenCanYouStartDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
        [dict setObject:cutString forKey:kCLContractConsiderationavailabilityNamekey];
        self.selectedWhenCanYouStartDict = dict;

    }
}


- (IBAction)doneButton:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    
    if (index.section == CLContractConsiderationWhenCanYouStartIndex) {
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        if ([[[self.startArray objectAtIndex:row] objectForKey:kCLContractConsiderationOtherkey] isEqualToString:@"1"]) {
            if([CLCommon isOSversionLessThan8])
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"Enter When You Can Start",@"other message") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",@"cancel btn title") otherButtonTitles:NSLocalizedString(@"OK",@"ok btn title"), nil] ;
                alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
                [alertView show];
            }
            else{
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                               message: NSLocalizedString(@"Enter When You Can Start",@"other message")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    
                }];
                
                UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"ok btn title") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                    UITextField *textField = alert.textFields[0];
                    NSString *cutString = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

                    if (![cutString isEqualToString:@""] && ![CLCommon doesItHaveSpace:cutString]){
                        [self.txtFirstResponder resignFirstResponder];
                        CLSimpleTextCell *companyDivCell;
                        companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
                        [companyDivCell setCellText:cutString];
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                        [dict setObject:@"1" forKey:kCLContractConsiderationOtherkey];
                        //[dict setObject:@"0" forKey:@"id"];
                        //[dict setObject:[self.selectedWhenCanYouStartDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
                        [dict setObject:cutString forKey:kCLContractConsiderationavailabilityNamekey];
                        self.selectedWhenCanYouStartDict = dict;
                    }
                }];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel",@"cancel btn title")
                                                                       style: UIAlertActionStyleDefault
                                                                     handler: nil];
                [alert addAction: cancelAction];
                [alert addAction: okAction];
                [self presentViewController:alert animated:YES completion:nil];

            }

        }
        else{
            CLSimpleTextCell*salaryBasisCell;
            salaryBasisCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];
            [salaryBasisCell setCellText:[[self.startArray objectAtIndex:row] objectForKey:kCLContractConsiderationavailabilityNamekey]];
            self.selectedWhenCanYouStartDict = [self.startArray objectAtIndex:row];
        }
        
    }
    [self.txtFirstResponder resignFirstResponder];
}



#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"ContractConsideration save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(NSString*)getTextLabelFromObject:(NSIndexPath*)indexPath{
    if ([self.preferenceObjectArray count] !=0) {
        CLContractPreferencesObject *obj = [[CLContractPreferencesObject alloc]init];
        obj = [self.preferenceObjectArray objectAtIndex:indexPath.row];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        dict = obj.employMentTypeDict;
        NSString *string = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLContractPreferenceemploymentTypekey]];
        return string;
    }
    else {
       return @"";
    }
}

-(void)saveStartArray{
    self.startArray = [[NSArray alloc]initWithObjects:
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"1",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"Immediate", @"immediate selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"2",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"1 Week", @"1 week selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"3",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"2 Weeks", @"2 weeks selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"4",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"4 Weeks", @"4 weeks selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"5",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"8 Weeks", @"8 weeks selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"0", kCLContractConsiderationOtherkey,
                        @"6",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"12 Weeks", @"12 weeks selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       [NSDictionary dictionaryWithObjectsAndKeys:
                        @"1", kCLContractConsiderationOtherkey,
                        @"7",kCLContractConsiderationIdkey,
                        NSLocalizedString(@"Other", @"Other selection"),kCLContractConsiderationavailabilityNamekey,
                        nil],
                       nil];
}

-(void)getContractConsiderationsSummaryDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.navigationController.view animated:YES];
//    self.tableView.hidden = YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLContractConsiderationObject contractConsiderationSummaryForUser:[CLUserObject currentUser].userID lang:@"en" success:^(CLContractConsiderationObject *conObj){
        self.contractConsiderationObj = conObj;
        [self setObjectValueToFields];
        [self.tableView reloadData];
 //       self.tableView.hidden = NO;;
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.rightBarButtonItem.enabled=YES;
        
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't Load Contract Consideration. Please try again later.", @"Error message when contract Consideration cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }];

}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)setObjectValueToFields{
    self.selectedWhenCanYouStartDict = self.contractConsiderationObj.whenCanYouStartDictionary;
    self.preferenceObjectArray = self.contractConsiderationObj.preferenceObjArray;
    self.anythingElseString = self.contractConsiderationObj.anythingsElseString;
}

-(void)saveContractConsiderations{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    self.navigationItem.hidesBackButton=YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    CLContractConsiderationObject *newConObj = [[CLContractConsiderationObject alloc]init];
    newConObj.preferenceObjArray = self.preferenceObjectArray;
    newConObj.whenCanYouStartDictionary = self.selectedWhenCanYouStartDict;
    newConObj.anythingsElseString = self.anythingElseString;
    
    [CLContractConsiderationObject saveContractConsideration:newConObj forUser:[CLUserObject currentUser].userID forlang:@"en" success:^(NSString *contaractId){
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error){
        self.navigationItem.hidesBackButton=NO;
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Work Condition Consideration. Please try again later.", @"Error message when Work Condition Consideration cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];

    }];
    
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
        [self.navigationController popViewControllerAnimated:YES];
}
        



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end
