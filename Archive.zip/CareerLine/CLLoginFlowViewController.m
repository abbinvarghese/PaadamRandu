//
//  CLLoginViewController.m
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLoginFlowViewController.h"
//#import "CLRegisterViewController.h"
#import "CLRegisterTableController.h"
#import "CLLoginViewController.h"
#import "CLImageScrollCell.h"

#define kmotionEffectLimit 14
#define knumOfScrollingPages 5
#define kscrollImageNames4inch @"loginBackground1-4inch.jpg",@"loginBackground2-4inch.jpg",@"loginBackground3-4inch.jpg",@"loginBackground4-4inch.jpg",@"loginBackground5-4inch.jpg"
#define kscrollImageNames3inch @"loginBackground1-3inch.jpg",@"loginBackground2-3inch.jpg",@"loginBackground3-3inch.jpg",@"loginBackground4-3inch.jpg",@"loginBackground5-3inch.jpg"

@interface CLLoginFlowViewController ()

@property (weak, nonatomic) IBOutlet UIPageControl *pageIndicator;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSArray *imageNameArray;
@property (weak, nonatomic) IBOutlet UIButton *bttnRegister;
@property (weak, nonatomic) IBOutlet UIButton *bttnLogin;
@property (weak, nonatomic) IBOutlet UIImageView *iconImgView;
@property (weak, nonatomic) IBOutlet UIView *bttnHolderView;
@property (weak, nonatomic) IBOutlet UIView *textView;
@property (weak, nonatomic) IBOutlet UILabel *lblText;

- (IBAction)bttnActionGotoRegisterPage:(id)sender;
- (IBAction)bttnActionGotoLoginPage:(id)sender;
@end

@implementation CLLoginFlowViewController
@synthesize pageIndicator,imageNameArray,collectionView;

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.bttnRegister.layer.cornerRadius=4;
    self.bttnLogin.layer.cornerRadius=4;
    //self.textView.layer.cornerRadius=4;
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    self.automaticallyAdjustsScrollViewInsets=NO;
    [self setupCollectionView];
    if ([UIScreen mainScreen].bounds.size.height>481) {
        imageNameArray=[[NSArray alloc] initWithObjects:kscrollImageNames4inch, nil];
    }
    else{
       imageNameArray=[[NSArray alloc] initWithObjects:kscrollImageNames3inch, nil];
    }
    
    [self addMotionEffectsToViews];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Home"];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark Utility Methods

-(void)addMotionEffectsToViews{
    UIInterpolatingMotionEffect *verticalMotionEffect = [[UIInterpolatingMotionEffect alloc] initWithKeyPath:@"center.y" type:UIInterpolatingMotionEffectTypeTiltAlongVerticalAxis];
    verticalMotionEffect.minimumRelativeValue = @(-kmotionEffectLimit);
    verticalMotionEffect.maximumRelativeValue = @(kmotionEffectLimit);
    
    UIInterpolatingMotionEffect *horizontalMotionEffect = [[UIInterpolatingMotionEffect alloc] initWithKeyPath:@"center.x" type:UIInterpolatingMotionEffectTypeTiltAlongHorizontalAxis];
    horizontalMotionEffect.minimumRelativeValue = @(-kmotionEffectLimit);
    horizontalMotionEffect.maximumRelativeValue = @(kmotionEffectLimit);
    
    UIMotionEffectGroup *motionGroup = [UIMotionEffectGroup new];
    motionGroup.motionEffects = @[horizontalMotionEffect, verticalMotionEffect];
    
    [self.iconImgView addMotionEffect:motionGroup];
    [self.bttnHolderView addMotionEffect:motionGroup];
    //[self.textView addMotionEffect:motionGroup];
    [self.pageIndicator addMotionEffect:motionGroup];
}

#pragma mark UICollectionView methods

-(void)setupCollectionView {
    [self.collectionView registerClass:[CLImageScrollCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    [flowLayout setMinimumInteritemSpacing:0.0f];
    [flowLayout setMinimumLineSpacing:0.0f];
    [self.collectionView setCollectionViewLayout:flowLayout];
}


-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return knumOfScrollingPages;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CLImageScrollCell *cell = (CLImageScrollCell *)[self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    
    NSString *imageName = [self.imageNameArray objectAtIndex:indexPath.row];
    [cell setImageName:imageName];
    [cell updateCell];
    
    return cell;
    
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return self.collectionView.frame.size;
}

#pragma mark UIScrollView Delegates

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    CGPoint currentOffset = [self.collectionView contentOffset];
    int currentIndex = currentOffset.x / self.collectionView.frame.size.width;
    self.pageIndicator.currentPage=currentIndex;
}

#pragma mark IBActions

- (IBAction)bttnActionGotoRegisterPage:(id)sender {
    CLRegisterTableController *controller=[[CLRegisterTableController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:controller animated:YES];
    
//    CLRegisterViewController *registerController=[[CLRegisterViewController alloc] initWithNibName:@"CLRegisterViewController" bundle:[NSBundle mainBundle]];
//    [self.navigationController pushViewController:registerController animated:YES];
}

- (IBAction)bttnActionGotoLoginPage:(id)sender {
    CLLoginViewController *loginController=[[CLLoginViewController alloc] initWithNibName:@"CLLoginViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:loginController animated:YES];
}
@end
