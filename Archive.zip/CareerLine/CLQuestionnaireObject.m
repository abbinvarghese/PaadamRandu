//
//  CLQuestionnaireObject.m
//  CareerLine
//
//  Created by CSG on 3/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLQuestionnaireObject.h"
#import "AFHTTPRequestOperationManager.h"
#import "NSDictionary+Additions.h"

#define kDebugMessages 1

@implementation CLQuestionnaireObject

static NSOperationQueue *postQuestionnaireRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.questionionnaireId=[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnaireIdkey];
    self.question=[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnaireQuestkey];
    self.answer=[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnaireAnskey];
    self.rating=[[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnaireRating] intValue];
    return self;
}


//To submit or save questionnaire according to the status(draftStatus: 0=submitQuestionnaire, 1=saveQuestionnaire)..
+ (void)submitQuestionnaireforInboxId:(NSString*)inboxId withQuestionnaire:(NSString*)questJson submitStatus:(NSString*)draftStatus success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(void){};
    }
    NSDictionary *parameters = @{@"user":[CLUserObject currentUser].userID, @"thread": inboxId, @"questionnaire": questJson , @"draft": draftStatus};
    
    [postQuestionnaireRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        postQuestionnaireRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceQuestionnairePostReplyURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"submit quest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
