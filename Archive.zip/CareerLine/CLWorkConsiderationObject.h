//
//  CLWorkConsiderationObject.h
//  CareerLine
//
//  Created by Abbin on 20/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLWorkConsiderationObject : NSObject

@property (nonatomic,retain) NSMutableDictionary * businessTravelDict;
//@property (nonatomic,retain) NSMutableDictionary *workRadius;
@property (nonatomic) BOOL flexibleWorkSchedule;
@property (nonatomic) BOOL flexTime;
@property (nonatomic) BOOL compressedWorkWeek;
@property (nonatomic) BOOL jobsharing;
@property (nonatomic,retain) NSMutableDictionary *workFromHome;
@property (nonatomic,retain) NSString *other;
@property (nonatomic) BOOL disabilityWorkSpace;
@property (nonatomic,retain) NSString *anythingElse;

+(void)cancelWorkConsiderationRequest;

+ (void)workConsiderationSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLWorkConsiderationObject *workObj))success failure:(void (^)(NSString *error))failure;

+ (void)saveWorkConsideration:(CLWorkConsiderationObject*)workObj forUser:(NSString*)userId forLang:(NSString*)lang success:(void (^)(NSString *WorkId))success failure:(void (^)(NSString *error))failure;

@end
