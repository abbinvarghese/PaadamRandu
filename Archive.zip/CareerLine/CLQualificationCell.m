//
//  CLQualificationCell.m
//  CareerLine
//
//  Created by RENJITH on 29/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLQualificationCell.h"
#import "CLCommon.h"
typedef enum {
    CLEducationIndex = 0,
    CLTrainingIndex= 1,
    CLCertificationsIndex= 2,
    CLLicensesIndex= 3,
    CLMembershipIndex= 4
    
} CLQualificationSectionIndex;
@interface CLQualificationCell()

@property (weak, nonatomic) IBOutlet UILabel *durationLbl;
@property (weak, nonatomic) IBOutlet UILabel *locationLbl;
@property (weak, nonatomic) IBOutlet UILabel *subLbl;

@end
@implementation CLQualificationCell

- (void)awakeFromNib
{
    // Initialization code
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLQualificationCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        self = [arrayOfViews objectAtIndex:0];
    }
    
    return self;
}

//-(NSInteger)getYearFromDateString:(NSString *)dateStr{
//    
//    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
//    [dateFormatter setLocale:[NSLocale currentLocale]];
//    dateFormatter.dateFormat=@"dd-MM-yyyy";
//    NSDate *date = [dateFormatter dateFromString:dateStr];
//    
//    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:date];
//    
//    return [components year];
//}

-(NSInteger)getYearFromDate:(NSDate *)date{
 
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:date];
    
    return [components year];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    if (self.section == CLEducationIndex) {
        
        self.headingLbl.text = self.educationObj.course;
        self.subLbl.text = self.educationObj.institution;
        if (self.educationObj.location.locationName.length >0)  {
            self.locationLbl.text = self.educationObj.location.locationName;
        }
        else{
            self.locationLbl.text = self.educationObj.location.countryName;
        }
        if (self.educationObj.fromDate != nil) {
            NSInteger fromYear = [self getYearFromDate:self.educationObj.fromDate];
            
            if(self.educationObj.isOngoing){
                self.durationLbl.text = [NSString stringWithFormat:@"%ld - %@",(long)fromYear,NSLocalizedString(@"Ongoing", @"on going label text")];
            }else{
                NSInteger toYear = [self getYearFromDate:self.educationObj.completionDate];
                self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
            }
        }
        else{
            self.durationLbl.text = @"";
        }
      
 
    }else if (self.section == CLTrainingIndex){
        
        self.headingLbl.text = self.trainingObj.name;
        self.subLbl.text = self.trainingObj.institution;
        self.locationLbl.text = self.trainingObj.location.locationName;
        //NSDate *date = [CLCommon getDateForString:self.trainingObj.fromDate andFormat:@"dd-MM-yyyy"];
        NSString *fromDate = [CLCommon getStringForDate:self.trainingObj.fromDate andLocalFormat:@"MMMdy"];
        self.durationLbl.text = [NSString stringWithFormat:@"%@",fromDate];
    
    }else if (self.section == CLCertificationsIndex){
        
        self.headingLbl.text = self.certificationObj.title;
        self.subLbl.text = self.certificationObj.institution;
        self.locationLbl.text = self.certificationObj.location.locationName;
        
        if (self.certificationObj.isProgress) {
                NSInteger fromYear = [self getYearFromDate:self.certificationObj.fromDate];
                NSInteger toYear = [self getYearFromDate:self.certificationObj.completionDate];
                self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
        }else{
            if (self.certificationObj.issuedOnDate!=nil) {
                NSInteger fromYear = [self getYearFromDate:self.certificationObj.issuedOnDate];
                NSInteger toYear = 0;
                if(self.certificationObj.toDate !=nil){
                    toYear = [self getYearFromDate:self.certificationObj.toDate];
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
                }else{
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %@",(long)fromYear,NSLocalizedString(@"Life Time", @"life time label")];
                }
 
            }else{
                self.durationLbl.text = @"";
            }
        }

    }else if (self.section == CLLicensesIndex){
        
        self.headingLbl.text = self.licenseObj.title;
        self.subLbl.text = self.licenseObj.number;
        self.locationLbl.text = self.licenseObj.clas;
        
        
        if (self.licenseObj.isProgress) {
            NSInteger fromYear = [self getYearFromDate:self.licenseObj.fromDate];
            NSInteger toYear = [self getYearFromDate:self.licenseObj.completionDate];
            self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
        }else{
            if (self.licenseObj.issuedOnDate!=nil) {
                NSInteger fromYear = [self getYearFromDate:self.licenseObj.issuedOnDate];
                NSInteger toYear = 0;
                if(self.licenseObj.toDate !=nil){
                    toYear = [self getYearFromDate:self.licenseObj.toDate];
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
                }else{
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %@",(long)fromYear,NSLocalizedString(@"Life Time", @"life time label")];
                }
                
            }else{
                self.durationLbl.text = @"";
            }
        }

        
        
//        NSInteger fromYear = [self getYearFromDate:self.licenseObj.fromDate];
//        NSInteger toYear = [self getYearFromDate:self.licenseObj.toDate];
//        
//        self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];

    }else if (self.section == CLMembershipIndex){
        
        self.headingLbl.text = self.membershipObj.title;
        self.subLbl.text = self.membershipObj.number;
        self.locationLbl.text = self.membershipObj.clas;
        
        if (self.membershipObj.isProgress) {
            NSInteger fromYear = [self getYearFromDate:self.membershipObj.fromDate];
            NSInteger toYear = [self getYearFromDate:self.membershipObj.completionDate];
            self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
        }else{
            if (self.membershipObj.issuedOnDate!=nil) {
                NSInteger fromYear = [self getYearFromDate:self.membershipObj.issuedOnDate];
                NSInteger toYear = 0;
                if(self.membershipObj.toDate !=nil){
                    toYear = [self getYearFromDate:self.membershipObj.toDate];
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
                }else{
                    self.durationLbl.text = [NSString stringWithFormat:@"%ld - %@",(long)fromYear,NSLocalizedString(@"Life Time", @"life time label")];
                }
                
            }else{
                self.durationLbl.text = @"";
            }
        }
        
//        NSInteger fromYear = 0;
//        NSInteger toYear = 0;
//        if (self.membershipObj.fromDate) {
//             fromYear = [self getYearFromDate:self.membershipObj.fromDate];
//        }
//        if (self.membershipObj.toDate) {
//             toYear = [self getYearFromDate:self.membershipObj.toDate];
//        }
//          self.durationLbl.text = [NSString stringWithFormat:@"%ld - %ld",(long)fromYear,(long)toYear];
    }

}

@end
