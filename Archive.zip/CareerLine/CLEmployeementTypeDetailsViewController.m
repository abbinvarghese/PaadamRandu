//
//  CLEmployeementDetailsViewController.m
//  CareerLine
//
//  Created by RENJITH on 05/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEmployeementTypeDetailsViewController.h"
#define kSectionHeaderFont [UIFont systemFontOfSize:14]

@interface CLEmployeementTypeDetailsViewController ()

@property(nonatomic,strong)NSMutableArray *empTypeDetailArray;
@property(nonatomic,strong)NSMutableDictionary *selectedEmpTypeDict;

@end

@implementation CLEmployeementTypeDetailsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=[self.selectedEmpTypeGroupDict objectForKey:kempTypeName];
     self.empTypeDetailArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpTypeDetailForGroup:self.selectedEmpTypeGroupDict];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark IBaction

-(void)bttnActionSelectionDone:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:^(void){
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectEmployeementType:withDictonary:)]){
            
            [self.selectedEmpTypeDict setObject:[self.selectedEmpTypeGroupDict objectForKey:kempTypeId] forKey:kempTypeId];
            [self.selectedEmpTypeDict setObject:[self.selectedEmpTypeGroupDict objectForKey:kempTypeName] forKey:kempTypeName];
            [self.delegate selectEmployeementType:self withDictonary:self.selectedEmpTypeDict];
        }
    }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.empTypeDetailArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    
    if ([self.selectedEmpTypeGroupDict isEqualToDictionary:[self.empTypeDetailArray objectAtIndex:indexPath.row]]) {
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSMutableDictionary *empType=[self.empTypeDetailArray objectAtIndex:indexPath.row];
    cell.textLabel.text=[empType objectForKey:kempTypeDetailName];
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.navigationItem.rightBarButtonItem.enabled=YES;
    self.selectedEmpTypeDict=[self.empTypeDetailArray objectAtIndex:indexPath.row];
    [self.tableView reloadData];
    [self bttnActionSelectionDone:nil];
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.selectedEmpTypeGroupDict objectForKey:kempTypeName];
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

@end
