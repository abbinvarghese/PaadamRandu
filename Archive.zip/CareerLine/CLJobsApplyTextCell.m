//
//  CLJobsApplyTextCell.m
//  CareerLine
//
//  Created by CSG on 1/28/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsApplyTextCell.h"

#define kintialTextViewHeight 40

@interface CLJobsApplyTextCell()

@property(nonatomic, assign) float txtHeight;
@property (weak, nonatomic) IBOutlet UITextView *txtCommentView;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaceHolder;
@property (weak, nonatomic) IBOutlet UIToolbar *accesoryToolbar;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButtonDone;

- (IBAction)bttnActionDone:(id)sender;
@end

@implementation CLJobsApplyTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLJobsApplyTextCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        self.txtHeight=kintialTextViewHeight;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setUpCell{
    self.barButtonDone.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.txtCommentView.inputAccessoryView=self.accesoryToolbar;
    self.txtCommentView.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
}

-(NSNumber*)getEstimatedTextViewHeight{
    return [NSNumber numberWithFloat:self.txtHeight];
}

-(NSString*)getCommentText{
    return self.txtCommentView.text;
}

- (CGRect)getCursorRectForTextView:(UITableView *)table{
    CGRect cursorRect = [self.txtCommentView caretRectForPosition:self.txtCommentView.selectedTextRange.start];
    cursorRect = [table convertRect:cursorRect fromView:self.txtCommentView];
    return cursorRect;
}

-(CGSize)getTextViewSize{
    CGSize maximumLabelSize = CGSizeMake(self.frame.size.width-20, FLT_MAX);
    return [self.txtCommentView sizeThatFits:maximumLabelSize];
}

- (IBAction)bttnActionDone:(id)sender {
    [self.txtCommentView resignFirstResponder];
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.lblPlaceHolder.hidden = YES;
}

-(void)textViewDidChange:(UITextView*)textView{
     self.lblPlaceHolder.hidden = ([textView.text length] > 0);
    self.txtHeight=[self getTextViewSize].height;
    if (self.txtHeight>=kintialTextViewHeight) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterJobsApplyCellHeightChange object:self];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.lblPlaceHolder.hidden = ([textView.text length] > 0);
}

@end
