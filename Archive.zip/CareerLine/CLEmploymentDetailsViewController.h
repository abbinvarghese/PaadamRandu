//
//  CLEmploymentDetailsViewController.h
//  CareerLine
//
//  Created by CSG on 2/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectJobLevelDetailViewController.h"
#import "CLSelectFunctionViewController.h"
#import "CLSelectFunctionCategoryViewController.h"
#import "CLSelectLocationViewController.h"
#import "CLSelectCompanyNameViewController.h"
#import "CLEmployeementTypeViewController.h"
#import "CLJobScopeViewController.h"
#import "CLBusinessDivViewController.h"
#import "CLIndustrySectorViewController.h"

@interface CLEmploymentDetailsViewController : UITableViewController<UIPickerViewDataSource,UIPickerViewDelegate,CLSimpleTextCellDelegate,CLTappableCellDelegate,CLSelectJobLevelDelegate,CLAddJobFunctionDelegate,CLEditJobFunctionDelegate,CLSelectLocationDelegate,CLSelectCompanyNameDelegate,CLSelectEmpTypeDelegate,jobScopeDelegate,JobScopeSelectionDelegate,CLBusinessDivDelegate,CLSelectIndustryDelegate,CLEditIndustryDelegate>

@property(nonatomic,assign)BOOL needCustomBackButtons;

@end
