//
//  CLResetPassworkController.m
//  CareerLine
//
//  Created by Abbin on 10/04/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLResetPassworkController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLLoginViewController.h"

@interface CLResetPassworkController ()
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIView *tableViewHeader;
@property (strong, nonatomic) IBOutlet UIView *tableViewFooter;
@property(nonatomic,retain) NSString *confirmPassword;
@property(nonatomic,retain) NSString *newpass;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@end

@implementation CLResetPassworkController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setRightNavigationButton];
    self.emailLabel.text = self.userID;
       [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"firstNameCellIdentifier"];
    self.tableView.tableHeaderView = self.tableViewHeader;
    self.tableView.tableFooterView = self.tableViewFooter;
    self.title = NSLocalizedString(@"Reset Your Password", @"title");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0) {
        CLBorderedTextCell *password = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"firstNameCellIdentifier"];
        password.selectionStyle=UITableViewCellSelectionStyleNone;
        [password setTextInputAccesoryView:self.keyboardResignView];
        [password setPlaceHoldrText:NSLocalizedString(@"New Password", @"Placeholder text")];
        [password returnKeyType:UIReturnKeyNext];
        [password setCellIndexPath:indexPath];
        password.delegate=self;
        [password isSecureType:YES];
        [password setKeyboardType:UIKeyboardTypeAlphabet];
        return password;
    }
    else{
        CLBorderedTextCell *password = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"firstNameCellIdentifier"];
        password.selectionStyle=UITableViewCellSelectionStyleNone;
        [password setTextInputAccesoryView:self.keyboardResignView];
        [password setPlaceHoldrText:NSLocalizedString(@"Confirm Password", @"Placeholder text")];
        [password returnKeyType:UIReturnKeyGo];
        [password setCellIndexPath:indexPath];
        password.delegate=self;
        [password isSecureType:YES];
        [password setKeyboardType:UIKeyboardTypeAlphabet];
        return password;
    }
}

- (IBAction)toolBarDoneClicked:(UIBarButtonItem *)sender {
    [self.view endEditing:YES];
}

#pragma mark CLSimpleTextCellDelegate

-(void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath withText:(NSString *)text{
    if (indexPath.row == 0) {
        self.newpass = text;
    }
    else if(indexPath.row == 1){
        self.confirmPassword = text;
    }
}

-(void)cellShouldReturn:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    if (cell.cellIndexPath.row == 0) {
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
        [cell becomeFirstResponder];
    }
    else if (cell.cellIndexPath.row == 1){
        [self restButtonClicked:self];
    }
}

- (IBAction)restButtonClicked:(id)sender {
    [self.view endEditing:YES];
    if ([self isFieldsValid]) {
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Resetting Password...", @"Text displayed in the loading indicator");
        [progressHUD showInView:self.navigationController.view];
        
        [CLUserObject resetPasswordForUserName:self.userID withPassword:self.confirmPassword andActiveCode:self.activeCode success:^{
            [progressHUD hideWithAnimation:YES];
            CLLoginViewController *loginController=[[CLLoginViewController alloc] initWithNibName:@"CLLoginViewController" bundle:[NSBundle mainBundle]];
            loginController.fromRest = YES;
            if([CLCommon isOSversionLessThan8])
            {
                UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Your Password Has Been Reset", @"Enter Your Other Option") message:@"Please Login To Continue" delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"OK") otherButtonTitles:nil];
                [enterFuncAlert show];
                
            } else{
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @"Your Password Has Been Reset"
                                                                               message: NSLocalizedString(@"Please Login To Continue", @"message")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                UIAlertAction * okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction*action){
                    [self.navigationController pushViewController:loginController animated:YES];
                }];
                [alert addAction:okAction];
                [self presentViewController:alert animated:YES completion:nil];
            }
        }failure:^(NSString *error){
            [progressHUD hideWithAnimation:YES];
            [CLCommon showAlertwithTitle:nil alertString:error cancelbuttonName:@"OK"];
        }];
    }
    
    
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    CLLoginViewController *loginController=[[CLLoginViewController alloc] initWithNibName:@"CLLoginViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:loginController animated:YES];
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"contract prefference modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=rightNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(BOOL)isFieldsValid{
    BOOL isValid = YES;
    if ([self.newpass isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Password.", @"Error Message for null password registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    if (![CLCommon isPasswordStrong:self.newpass]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Your Password Should Be at Least 8 Characters with a Combination of Letters and Numbers Without Any Spaces.", @"Error Message for password") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
        
    }
    if ([self.confirmPassword isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Confirm Password.", @"Error Message for null password registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    if (![self.newpass isEqualToString:self.confirmPassword]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Passwords do not match.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

@end
