//
//  CLAboutMeAchievementsViewController.m
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAboutMeAchievementsViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLDocumentViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>

@interface CLAboutMeAchievementsViewController ()

typedef enum {
    CLAchievementTitleIndex = 0,
    CLAchievementDateIndex= 1,
    CLAchievementDescIndex = 2,
    CLAchievementDocsIndex = 3
} CLAchievementTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;

@property(strong,nonatomic)NSString *titleText;
@property(strong,nonatomic)NSDate *date;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;

@end

@implementation CLAboutMeAchievementsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Personal Achievement", @"Personal Achievement edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"titleTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"dateTextCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        [datePickr setDate:[CLUserObject currentUser].birthDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.isEditMode) {
        self.titleText=self.achievementObj.achievementTitle;
        self.date=self.achievementObj.achievementDate;
        [self.datePicker setDate:self.date];
        self.descriptionText=self.achievementObj.achievementDescription;
    }
    else{
        self.titleText=@"";
        self.descriptionText=@"";
        self.date=nil;
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    if([self.txtFirstResponder isFirstResponder])
        [self.txtFirstResponder resignFirstResponder];
    else if([self.txtViewFirstResponder isFirstResponder])
        [self.txtViewFirstResponder resignFirstResponder];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 4;
    }
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLAchievementTitleIndex:{
            CLSimpleTextCell *titleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            titleCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [titleCell setTextInputAccesoryView:self.keyboardResignView];
            [titleCell setPlaceHoldrText:NSLocalizedString(@"Awards/Titles/Achievements/Notable Events", @"Placeholder for achievement title")];
            [titleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [titleCell setCellText:self.titleText];
            [titleCell setCellIndexPath:indexPath];
            titleCell.delegate=self;
            return titleCell;
            break;
        }
        case CLAchievementDateIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"dateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.datePicker];
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Date", @"Placeholder for date field")];
            [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
            break;
        }
        case CLAchievementDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLAchievementDocsIndex:{
            CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.indexPath=indexPath;
            cell.delegate=self;
            cell.photosLimit=-1;
            cell.placeHolderImageName=@"documentPlaceHolder";
            cell.photoUrls=self.achievementObj.achievementDocs;
            [cell updateCollectionViewContents];
            return cell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLAchievementTitleIndex:
            return NSLocalizedString(@"Title", @"Placeholder for achievement title");
            break;
        case CLAchievementDateIndex:
            return NSLocalizedString(@"Date", @"Placeholder for date field");
            break;
        case CLAchievementDescIndex:
            return NSLocalizedString(@"Description", @"Placeholder for description field");
            break;
        case CLAchievementDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
            
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLAchievementDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else if(indexPath.section==CLAchievementDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.achievementObj.achievementDocs count]+1)/2));
    }
    else{
        return 44;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                               {
                                                   [self addDocumentActionSheetDismissedWithIndex:0];
                                               }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self editDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
    
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLAchievementTitleIndex:{
            self.titleText=text;
            break;
        }
        case CLAchievementDescIndex:
            self.descriptionText=text;
            break;
        default:
            break;
    }
}

#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
     if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
     }
     else{
          [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
     }
    
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAchievementAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddAchievementAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Achievements modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Full Name validation..
    if ([self.titleText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter The Title.", @"Error Message for null title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.titleText length]>200) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Title Length.", @"Error Message for length of title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Date validation..
    if (self.date==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Achievement Date.", @"Error Message for null date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(void)savePersonalAchievementForEdit:(BOOL)isEditMode{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLAchievementObject savePersonalAchievement:self.achievementObj.achievementId forUser:[CLUserObject currentUser].userID title:self.titleText date:[CLCommon getStringForDate:self.date andExactFormat:@"dd-MM-yyyy"] remarks:self.descriptionText editMode:isEditMode
                                            success:^(NSString *achievementId){
                                                if (isEditMode) {
                                                    self.achievementObj.achievementTitle=self.titleText;
                                                    self.achievementObj.achievementDescription=self.descriptionText;
                                                    [self.achievementObj updateDate:self.date];
                                                }
                                                else{
                                                    self.achievementObj=[[CLAchievementObject alloc] init];
                                                    self.achievementObj.achievementId=achievementId;
                                                    self.achievementObj.achievementTitle=self.titleText;
                                                    self.achievementObj.achievementDescription=self.descriptionText;
                                                    [self.achievementObj updateDate:self.date];
                                                }
                                                
                                                [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                                            }
                                            failure:^(NSString *error){
                                                if (![error isEqualToString:@""]) {
                                                    self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                                    self.navigationItem.rightBarButtonItem.enabled=YES;
                                                    [progressHUD hideWithAnimation:YES];
                                                    [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save achievement. Please try again later.", @"Error message when achievement cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                                }
                                            }];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLAchievementObject addDocument:image forAchievement:self.achievementObj.achievementId andUser:[CLUserObject currentUser].userID andCaption:caption
                                 success:^(CLFileObject *documentObj){
                                     [progressHUD hideWithAnimation:YES];
                                     self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                     self.navigationItem.rightBarButtonItem.enabled=YES;
                                     if (!self.achievementObj.achievementDocs) {
                                         self.achievementObj.achievementDocs=[[NSMutableArray alloc] init];
                                     }
                                     [self.achievementObj.achievementDocs addObject:documentObj];
                                     [self.tableView reloadData];
                                 }
                                 failure:^(NSString *error) {
                                     if (![error isEqualToString:@""]) {
                                         [progressHUD hideWithAnimation:YES];
                                         self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                         self.navigationItem.rightBarButtonItem.enabled=YES;
                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                     }
                                 }];
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *documentObj=[self.achievementObj.achievementDocs objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLAchievementObject deleteDocument:documentObj.fileId forUser:[CLUserObject currentUser].userID
                                    success:^(){
                                        [progressHUD hideWithAnimation:YES];
                                        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                        self.navigationItem.rightBarButtonItem.enabled=YES;
                                        [self.achievementObj.achievementDocs removeObjectAtIndex:indexPath.row];
                                        [self.tableView reloadData];
                                    }
                                    failure:^(NSString *error){
                                        if (![error isEqualToString:@""]) {
                                            [progressHUD hideWithAnimation:YES];
                                            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                            self.navigationItem.rightBarButtonItem.enabled=YES;
                                            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                        }
                                    }];
}

#pragma mark IBActions

-(IBAction)bttnActionSaveAchievementAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self savePersonalAchievementForEdit:YES];
    }
}

-(IBAction)bttnActionAddAchievementAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self savePersonalAchievementForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if (cell!=nil) {
        if (cell.cellIndexPath.section==CLAchievementDateIndex) {
            if (self.date==nil || !([self.date compare:self.datePicker.date] == NSOrderedSame)) {
                self.date=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
    

    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.date=date;
    
    CLSimpleTextCell *dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLAchievementDateIndex]];
    [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
}

#pragma mark UIActionsheet Delegates

-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(achievementController:didAddAchievement:)]){
                [self.delegate achievementController:self didAddAchievement:self.achievementObj];
            }
        }];
    }
}

@end
