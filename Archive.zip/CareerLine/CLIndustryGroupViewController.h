//
//  CLIndustryGroupViewController.h
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLIndustryViewController.h"
@class CLIndustryGroupViewController;

@protocol CLSelectOtherIndustryGroup <NSObject>

@optional
-(void)industryGroupViewController:(CLIndustryGroupViewController *)controller didAddOtherIndustryGroup:(NSMutableDictionary *)selectedOtherGroup andListArray:(NSMutableArray *)listArray;

@end
@interface CLIndustryGroupViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,assign) BOOL singleSelection;
@property(nonatomic ,weak) id<CLSelectOtherIndustryGroup>delegate;
@property(nonatomic ,strong) NSMutableArray *alrdySelectedindustries;
@property(nonatomic ,strong) NSMutableDictionary *selectedIndustrySectorDict;
@property(nonatomic,assign)BOOL enableSelectAll;
@end
      