//
//  CLCollectionCell.h
//  testProj
//
//  Created by CSG on 1/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLCollectionHomeViewCell : UICollectionViewCell

-(void)updateContentsForIndexPath:(NSIndexPath*)indexPath;

@end
