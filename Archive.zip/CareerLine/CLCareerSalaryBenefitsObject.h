//
//  CLCareerSalaryBenefitsObject.h
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCareerSalaryBenefitsObject : NSObject

@property (nonatomic, strong) NSString *salary;
@property (nonatomic, retain) NSString *longTermGrossSal;
@property (nonatomic, retain) NSString *longTermActualVal;

@property (nonatomic, retain) NSMutableDictionary *salaryBasis;
@property (nonatomic, retain) NSMutableDictionary *currency;
@property (nonatomic, retain) NSMutableArray *allowanceObjArray;
@property (nonatomic, retain) NSMutableArray *incentiveObjArray;
@property (nonatomic, retain) NSMutableDictionary *longTermIncentives;
@property (nonatomic, retain) NSMutableDictionary *longTermFrequency;

@property (nonatomic, retain) NSMutableDictionary *longTermCurrency;
@property (nonatomic, retain) NSMutableArray *benefits;

@end
