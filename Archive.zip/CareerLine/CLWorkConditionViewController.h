//
//  CLWorkConditionViewController.h
//  CareerLine
//
//  Created by Abbin on 11/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLHeightAdjustTextCell.h"

@interface CLWorkConditionViewController : UITableViewController<CLSimpleTextCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate,CLTextCheckBoxCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate>

@end
