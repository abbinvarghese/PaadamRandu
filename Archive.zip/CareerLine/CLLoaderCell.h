//
//  CLLoaderCell.h
//  CareerLine
//
//  Created by Abbin on 13/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLLoaderCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property(nonatomic) BOOL lastPageReached;

-(void)updateLoaderForPage:(BOOL)lastPages;

@end
