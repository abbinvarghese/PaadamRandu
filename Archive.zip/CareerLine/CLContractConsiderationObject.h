//
//  CLContractConsiderationObject.h
//  CareerLine
//
//  Created by Abbin on 19/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLContractConsiderationObject : NSObject

@property(nonatomic,strong) NSMutableArray *preferenceObjArray;
@property(nonatomic,strong) NSMutableDictionary *whenCanYouStartDictionary;
@property(nonatomic,strong) NSString *anythingsElseString;

+ (void)contractConsiderationSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLContractConsiderationObject *conObj))success failure:(void (^)(NSString *error))failure;
+ (void)saveContractConsideration:(CLContractConsiderationObject*)conObj forUser:(NSString*)userId forlang:(NSString*)lang success:(void (^)(NSString *eduId))success failure:(void (^)(NSString *error))failure;
+(void)cancelContractConsiderationSummeryRequest;

@end
