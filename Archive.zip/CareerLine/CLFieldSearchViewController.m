//
//  CLRegionModalViewController.m
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLFieldSearchViewController.h"
#import "CLRelocationObject.h"
#import "CLLocationLoaderCell.h"

@interface CLFieldSearchViewController ()
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *noResultLabel;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic,strong) NSString *searchText;
@property (nonatomic,strong) NSMutableArray *filteredArray;
@property (nonatomic, retain) NSString *locType;

@property(nonatomic,assign)BOOL shouldPaginate;
@property(nonatomic,assign)BOOL isLastPageReached;
@property(nonatomic,assign)int nextPageToLoad;
@property(nonatomic,assign)BOOL needToclearArray;
@property(nonatomic,retain) NSTimer *timer;
@property(nonatomic) BOOL timerStarted;


@end

@implementation CLFieldSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.needToclearArray=YES;
    [self.tableView registerClass:[CLLocationLoaderCell class] forCellReuseIdentifier:@"CLLocationLoaderCell"];
    self.filteredArray = [[NSMutableArray alloc]init];
    self.nextPageToLoad=1;
    self.title = NSLocalizedString(@"Select Region", @"region Title");
    [self setRightNavigationButton];
    [self setLeftNavigationButton];
    self.tableView.tableHeaderView=self.searchBar;
    self.searchText=@"";
    self.activityIndicator.hidden = YES;
    self.noResultLabel.hidden = YES;
    [self startSearchWith:self.searchText];
    
    [self.searchBar becomeFirstResponder];
    
    if (self.selectedIndex.section == 0) {
//        switch (self.selectedIndex.row) {
//            case 3:
        NSString *titleString = [NSString stringWithFormat:@"Select %@",self.titleString];
                self.title = NSLocalizedString(titleString, @"title");
//                break;
//            case 4:
//                self.title = NSLocalizedString(@"Select State", @"title");
//                break;
//            case 5:
//                self.title = NSLocalizedString(@"Select Metro", @"title");
//                break;
//            case 6:
//                self.title = NSLocalizedString(@"Select Metro Cluster", @"title");
//                break;
//            case 7:
//                self.title = NSLocalizedString(@"Select Tier2 Cities", @"title");
//                break;
//            case 8:
//                self.title = NSLocalizedString(@"Select Town/Villages", @"title");
//                break;
//            default:
//                break;
//        }
    }
    else if (self.selectedIndex.section == 1){
        switch (self.selectedIndex.row) {
            case 2:
                self.title = NSLocalizedString(@"Select Region", @"title");
                break;
            case 3:
                self.title = NSLocalizedString(@"Select Sub Region", @"title");
                break;
            case 4:
                self.title = NSLocalizedString(@"Select Country", @"title");
                break;
            case 5:
                self.title = NSLocalizedString(@"Select Location", @"title");
                break;
            default:
                break;
        }
    }
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.searchBar resignFirstResponder];
    [self.timer invalidate];
}

-(NSString*)loctypeString:(NSIndexPath*) indePath{
    NSString *loctype;
    NSLog(@"%@",self.currentLocationDictionary);
    if ([[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode]isEqualToString:@"AUS"]) {
        switch (indePath.row) {
            case 4:
                loctype = @"ST";
                break;
            case 5:
                loctype = @"RG";
                break;
            case 6:
                loctype = @"CT";
                break;
            case 7:
                loctype = @"CL";
                break;
            case 8:
                loctype = @"SB";
                break;
                
            default:
                break;
        }
    }  else if([[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode]isEqualToString:@"IND"]){
        switch (indePath.row) {
            case 3:
                loctype = @"RG";
                break;
            case 4:
                loctype = @"ST";
                break;
            case 5:
                loctype = @"MT";
                break;
            case 6:
                loctype = @"MC";
                break;
            case 7:
                loctype = @"T2";
                break;
            case 8:
                loctype = @"TV";
                break;
                
            default:
                break;
        }
    } else{
        switch (indePath.row) {
            case 3:
                loctype = @"RG";
                break;
            case 4:
                loctype = @"ST";
                break;
            case 5:
                loctype = @"MT";
                break;
            case 6:
                loctype = @"MC";
                break;
            case 7:
                loctype = @"T2";
                break;
            case 8:
                loctype = @"LOC";
                break;
                
            default:
                break;
        }

    }
    return loctype;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (self.filteredArray.count > 0) {
        if (self.isLastPageReached) {
            return [self.filteredArray count];
        }else{
            if (self.filteredArray.count>0) {
                return [self.filteredArray count]+1;
            }
            else{
                return [self.filteredArray count];
            }
        }
    }
    else{
        return 0;
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == [self.filteredArray count]) {
        CLLocationLoaderCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"CLLocationLoaderCell"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell startActivityIndicator];
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
            cell.selectionStyle=UITableViewCellSelectionStyleDefault;
            cell.textLabel.font=[UIFont systemFontOfSize:14];
            cell.textLabel.numberOfLines=0;
        }
        
        NSDictionary *cellDict=nil;
        if (self.filteredArray.count>0) {
            cellDict=[self.filteredArray objectAtIndex:indexPath.row];
            NSString *countryString = [cellDict objectForKey:kCLRelocationLocationKey];
            
            NSData *data = [countryString dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
            cell.textLabel.text = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        }
        
        //    if (![self.searchText isEqualToString:@""] && indexPath.row==0) {
        //        cell.textLabel.text=[NSString stringWithFormat:@"\"%@\"",[cellDict objectForKey:@"location"]];
        //    }
        //    else{
        
        
        //    }
        return cell;
    }
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.searchBar resignFirstResponder];
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        if ([_delegate respondsToSelector:@selector(addSelectedFields:)] && self.filteredArray.count>indexPath.row) {
            [_delegate addSelectedFields:[self.filteredArray objectAtIndex:indexPath.row]];
        }
    }];
}


#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.needToclearArray=YES;
    self.nextPageToLoad=1;
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}


-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"region modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    UIBarButtonItem *RightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"region modal done button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnDoneActionDismissModal:)];
    self.navigationItem.rightBarButtonItem=RightNavBttn;
}

-(IBAction)bttnDoneActionDismissModal:(id)sender{
    [self.searchBar resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(void)searchAfterDelay{
    [self startSearchWith:self.searchText];
}


-(void)startSearchWith:(NSString*)searchText{
    if (self.needToclearArray) {
        [self.filteredArray removeAllObjects];
    }
    
    if (self.needToclearArray) {
        [self.activityIndicator startAnimating];
        self.activityIndicator.hidden = NO;
    }
    if (self.selectedIndex.section == 0) {
        self.locType = [self loctypeString:self.selectedIndex];
    if (self.selectedIndex.row == 3) {
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad  success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            self.noResultLabel.hidden = NO;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }

            
        }];
    }
    else if (self.selectedIndex.row == 4){
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }

            [self.tableView reloadData];
            
        }];

    }
    else if (self.selectedIndex.row == 5){
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }

            [self.tableView reloadData];
            
        }];

    }
    else if (self.selectedIndex.row == 6){
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }

            [self.tableView reloadData];
            
        }];

    }
    else if (self.selectedIndex.row == 7){
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }

            [self.tableView reloadData];
            
        }];

    }
    else if (self.selectedIndex.row == 8){
        [CLRelocationObject getRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forLocType:self.locType countryCode:[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode] fromTwentyField:self.fromTwentyField forPage:self.nextPageToLoad success:^(NSMutableArray *regionArray,BOOL isLastPageReached){
            [self.timer invalidate];
            self.nextPageToLoad++;
            self.timerStarted = NO;
            if (regionArray != nil) {
                [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:regionArray]];
            }
            if (!isLastPageReached) {
                self.shouldPaginate=YES;
            }
            self.isLastPageReached = isLastPageReached;
            if([self.filteredArray count] ==0){
                self.noResultLabel.hidden = NO;
            }else{
                self.noResultLabel.hidden = YES;
            }
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            [self.tableView reloadData];
            
            
        }failure:^(NSString *error){
            [self.activityIndicator stopAnimating];
            self.activityIndicator.hidden = YES;
            if (!self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.needToclearArray) {
                self.noResultLabel.hidden = NO;
            }
            [self.tableView reloadData];
            
        }];

    }
    }
    else if (self.selectedIndex.section == 1){
        switch (self.selectedIndex.row) {
            case 2:{
                [CLRelocationObject getSecondSectionRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forType:@"region" fromTwentyField:self.fromTwentyField currentLocationDictionary:self.currentLocationDictionary forPage:self.nextPageToLoad success:^(NSMutableArray*listArray,BOOL isLastPageReached){
                    [self.timer invalidate];
                    self.nextPageToLoad++;
                    self.timerStarted = NO;
                    if (listArray != nil) {
                        [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:listArray]];
                    }
                    if (!isLastPageReached) {
                        self.shouldPaginate=YES;
                    }
                    self.isLastPageReached = isLastPageReached;
                    if([self.filteredArray count] ==0){
                        self.noResultLabel.hidden = NO;
                    }else{
                        self.noResultLabel.hidden = YES;
                    }
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    [self.tableView reloadData];

                }failure:^(NSString *error){
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    if (!self.timerStarted) {
                        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                        self.timerStarted = YES;
                    }
                    if (self.needToclearArray) {
                        self.noResultLabel.hidden = NO;
                    }

                    [self.tableView reloadData];

                }];

            }
                break;
            case 3:{
                [CLRelocationObject getSecondSectionRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forType:@"sub_region" fromTwentyField:self.fromTwentyField currentLocationDictionary:self.currentLocationDictionary forPage:self.nextPageToLoad  success:^(NSMutableArray*listArray,BOOL isLastPageReached){
                    [self.timer invalidate];
                    self.nextPageToLoad++;
                    self.timerStarted = NO;
                    if (listArray != nil) {
                        [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:listArray]];
                    }
                    if (!isLastPageReached) {
                        self.shouldPaginate=YES;
                    }
                    self.isLastPageReached = isLastPageReached;
                    if([self.filteredArray count] ==0){
                        self.noResultLabel.hidden = NO;
                    }else{
                        self.noResultLabel.hidden = YES;
                    }
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    [self.tableView reloadData];
                    
                }failure:^(NSString *error){
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    if (!self.timerStarted) {
                        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                        self.timerStarted = YES;
                    }
                    if (self.needToclearArray) {
                        self.noResultLabel.hidden = NO;
                    }

                    [self.tableView reloadData];
                    
                }];

            }
                break;
            case 4:{
                [CLRelocationObject getSecondSectionRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forType:@"country" fromTwentyField:self.fromTwentyField currentLocationDictionary:self.currentLocationDictionary forPage:self.nextPageToLoad  success:^(NSMutableArray*listArray,BOOL isLastPageReached){
                    [self.timer invalidate];
                    self.nextPageToLoad++;
                    self.timerStarted = NO;
                    if (listArray != nil) {
                        [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:listArray]];
                    }
                    if (!isLastPageReached) {
                        self.shouldPaginate=YES;
                    }
                    self.isLastPageReached = isLastPageReached;
                    if([self.filteredArray count] ==0){
                        self.noResultLabel.hidden = NO;
                    }else{
                        self.noResultLabel.hidden = YES;
                    }
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    [self.tableView reloadData];
                    
                }failure:^(NSString *error){
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    if (!self.timerStarted) {
                        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                        self.timerStarted = YES;
                    }
                    if (self.needToclearArray) {
                        self.noResultLabel.hidden = NO;
                    }

                    [self.tableView reloadData];
                    
                }];
            }
                break;
            case 5:{
                [CLRelocationObject getSecondSectionRegionListForSearchString:self.searchText forUserId:[CLUserObject currentUser].userID forType:@"location" fromTwentyField:self.fromTwentyField currentLocationDictionary:self.currentLocationDictionary forPage:self.nextPageToLoad  success:^(NSMutableArray*listArray,BOOL isLastPageReached){
                    [self.timer invalidate];
                    self.nextPageToLoad++;
                    self.timerStarted = NO;
                    if (listArray != nil) {
                        [self.filteredArray addObjectsFromArray:[self blacklistedArrayFrom:listArray]];
                    }
                    if (!isLastPageReached) {
                        self.shouldPaginate=YES;
                    }
                    self.isLastPageReached = isLastPageReached;
                    if([self.filteredArray count] ==0){
                        self.noResultLabel.hidden = NO;
                    }else{
                        self.noResultLabel.hidden = YES;
                    }
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    [self.tableView reloadData];
                    
                }failure:^(NSString *error){
                    [self.activityIndicator stopAnimating];
                    self.activityIndicator.hidden = YES;
                    if (!self.timerStarted) {
                        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                        self.timerStarted = YES;
                    }
                    if (self.needToclearArray) {
                        self.noResultLabel.hidden = NO;
                    }

                    [self.tableView reloadData];
                    
                }];
            }
                break;
                
            default:
                break;
        }
    }
    
    
}

-(NSMutableArray*)blacklistedArrayFrom:(NSMutableArray*)array{
    NSMutableArray *dictArray = [[NSMutableArray alloc]initWithArray:array];
    for (NSMutableDictionary *dict in self.selectedDictArray) {
//        if ([array containsObject:dict]) {
//            [dictArray removeObject:dict];
//        }
        NSString *string = [dict objectForKey:@"id"];
        for (NSMutableDictionary *dictTwo in array) {
            NSString *stringTwo = [dictTwo objectForKey:@"id"];
            if ([string isEqualToString:stringTwo]) {
                [dictArray removeObject:dictTwo];
            }
        }
    }
    return dictArray;
}

#pragma mark - Pagination Methods

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (self.filteredArray.count>0) {
        
        float scrollViewHeight = scrollView.frame.size.height;
        float scrollContentSizeHeight = scrollView.contentSize.height;
        float scrollOffset = scrollView.contentOffset.y;
        if (self.shouldPaginate && !self.isLastPageReached) {
            if ((scrollOffset + scrollViewHeight >= scrollContentSizeHeight) && (scrollContentSizeHeight>0)){
                self.needToclearArray = NO;
                self.shouldPaginate = NO;
                [self startSearchWith:self.searchText];
                
            }
        }
        
    }
}

-(void)startTimer{
    [self startSearchWith:self.searchText];
}


@end
