//
//  CLJobsApplyRatingCell.h
//  CareerLine
//
//  Created by CSG on 1/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RateView.h"

@interface CLJobsApplyRatingCell : UITableViewCell<RateViewDelegate>

//Smiley Rating for job suggestion..
typedef enum {
    CLJobSmileyRatingNone = 0,
    CLJobSmileyRatingOne=  1,
    CLJobSmileyRatingTwo = 2,
    CLJobSmileyRatingThree = 3,
    CLJobSmileyRatingFour = 4,
    CLJobSmileyRatingFive = 5,
} CLJobSmileyRating;

-(CLJobSmileyRating)getSelectedRating;

@end
