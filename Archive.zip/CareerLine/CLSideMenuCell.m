//
//  CLSideMenuCell.m
//  CareerLine
//
//  Created by CSG on 1/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSideMenuCell.h"
#import "CLUserObject.h"

#define kCellBgColor [UIColor colorFromHexCode:@"#292929"]
#define kCellSelectedBgColor [UIColor colorFromHexCode:@"#1C1C1C"]

@interface CLSideMenuCell()

@property (weak, nonatomic) IBOutlet UILabel *lblSideMenuTitle;
@property (weak, nonatomic) IBOutlet UIImageView *imgSideMenuIcon;
@property (weak, nonatomic) IBOutlet UIView *sideMenubadgeView;
@property (weak, nonatomic) IBOutlet UIImageView *imgSideMenuNotif;
@property (weak, nonatomic) IBOutlet UILabel *lblSideMenuBadge;
@end

@implementation CLSideMenuCell

#pragma mark Cell Methods

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLSideMenuCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setupCellForIndexPath:(NSIndexPath*)indexPath selectedIndex:(CLSideMenuViewControllerIndex)selectedSideMenuIndex{
    if(indexPath.row==selectedSideMenuIndex){
//        switch ([CLUserObject currentUser].trafficLightStatus) {
//            case CLTrafficLightGreenColor:
//                self.lblSideMenuTitle.textColor=ColorCode_SideMenuTextGreen;
//                break;
//            case CLTrafficLightAmberColor:
//                self.lblSideMenuTitle.textColor=ColorCode_SideMenuTextAmber;
//                break;
//            case CLTrafficLightRedColor:
//                self.lblSideMenuTitle.textColor=ColorCode_SideMenuTextRed;
//                break;
//            default:
//                break;
//        }
        
        self.lblSideMenuTitle.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
        self.backgroundColor=kCellSelectedBgColor;
        //self.imgSideMenuIcon.image=[self getIconForSelectedSideMenuController:indexPath.row];
    }
    else{
        self.lblSideMenuTitle.textColor=[UIColor grayColor];
        self.backgroundColor=kCellBgColor;
        //self.imgSideMenuIcon.image=[self getIconForNotSelectedSideMenuController:indexPath.row];
    }
    
    switch (indexPath.row){
        case CLHomeControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Home", @"Side Menu home option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLProfileControllerIndex:{
            self.lblSideMenuTitle.text= NSLocalizedString(@"Profile", @"Side Menu Profile option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLMyCareerLineControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"My CareerLine", @"Side Menu My CareerLine option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLDocumentsControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Documents", @"Side Menu Documents option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLKnowledgeControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"WAKE", @"Side Menu Knowledge option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLJobsControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Jobs", @"Side Menu Jobs option title");
            if ([CLUserObject currentUser].unreadJobsCount!=0) {
                self.sideMenubadgeView.hidden=NO;
                self.lblSideMenuBadge.text=[NSString stringWithFormat:@"%ld",(long)[CLUserObject currentUser].unreadJobsCount];
                self.imgSideMenuNotif.image=[self getImageForSideMenuNotifBadge];
            }
            else{
                self.sideMenubadgeView.hidden=YES;
                self.imgSideMenuNotif.image=nil;
            }
            break;
        }
        case CLCalendarControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Calendar", @"Side Menu Calendar option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLInboxControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Inbox", @"Side Menu Inbox option title");
            if ([CLUserObject currentUser].unreadInboxCount!=0) {
                self.sideMenubadgeView.hidden=NO;
                self.lblSideMenuBadge.text=[NSString stringWithFormat:@"%ld",(long)[CLUserObject currentUser].unreadInboxCount];
                self.imgSideMenuNotif.image=[self getImageForSideMenuNotifBadge];
            }
            else{
                self.sideMenubadgeView.hidden=YES;
                self.imgSideMenuNotif.image=nil;
            }
            break;
        }
        case CLSettingsControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Settings", @"Side Menu Settings option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case ClJobPreferencesControllerIndex: {
            self.lblSideMenuTitle.text=NSLocalizedString(@"Job Preferences", @"Side Menu Log Out option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        case CLLogoutControllerIndex:{
            self.lblSideMenuTitle.text=NSLocalizedString(@"Log Out", @"Side Menu Log Out option title");
            self.sideMenubadgeView.hidden=YES;
            break;
        }
        default:
            break;
    }
}

#pragma mark Utility Methods

-(UIImage *)getImageForSideMenuNotifBadge{
    if ([CLUserObject currentUser].trafficLightStatus==CLTrafficLightRedColor) {
        return [UIImage imageNamed:@"sidemenu_badge_red@2x"];
    }
    else if ([CLUserObject currentUser].trafficLightStatus==CLTrafficLightAmberColor){
        return [UIImage imageNamed:@"sidemenu_badge_orange@2x"];
    }
    else{
        return [UIImage imageNamed:@"sidemenu_badge_green@2x"];
    }
}


//-(UIImage*)getIconForNotSelectedSideMenuController:(CLSideMenuViewControllerIndex)controllerIndex{
//    switch (controllerIndex) {
//        case CLHomeControllerIndex:{
//            return [UIImage imageNamed:@"homeIcon"];
//            break;
//        }
//        case CLProfileControllerIndex:{
//            return [UIImage imageNamed:@"profileIcon"];
//            break;
//        }
//        case CLMyCareerLineControllerIndex:{
//            return [UIImage imageNamed:@"myCLIcon"];
//            break;
//        }
//        case CLDocumentsControllerIndex:{
//            return [UIImage imageNamed:@"documentsIcon"];
//            break;
//        }
//        case CLKnowledgeControllerIndex:{
//            return [UIImage imageNamed:@"knowledgeIcon"];
//            break;
//        }
//        case CLJobsControllerIndex:{
//            return [UIImage imageNamed:@"jobsIcon"];
//            break;
//        }
//        case CLCalendarControllerIndex:{
//            return [UIImage imageNamed:@"calendarIcon"];
//            break;
//        }
//        case CLInboxControllerIndex:{
//            return [UIImage imageNamed:@"inboxIcon"];
//            break;
//        }
//        case CLSettingsControllerIndex:{
//            return [UIImage imageNamed:@"settingsIcon"];
//            break;
//        }
//        case CLLogoutControllerIndex:{
//            return [UIImage imageNamed:@"logoutIcon"];
//            break;
//        }
//        default:
//            return nil;
//            break;
//    }
//}

//-(UIImage*)getIconForSelectedSideMenuController:(CLSideMenuViewControllerIndex)controllerIndex{
//    if ([CLUserObject currentUser].trafficLightStatus==CLTrafficLightGreenColor) {
//        switch (controllerIndex) {
//            case CLHomeControllerIndex:{
//                return [UIImage imageNamed:@"homeIconGreen"];
//                break;
//            }
//            case CLProfileControllerIndex:{
//                return [UIImage imageNamed:@"profileIconGreen"];
//                break;
//            }
//            case CLMyCareerLineControllerIndex:{
//                return [UIImage imageNamed:@"myCLIconGreen"];
//                break;
//            }
//            case CLDocumentsControllerIndex:{
//                return [UIImage imageNamed:@"documentsIconGreen"];
//                break;
//            }
//            case CLKnowledgeControllerIndex:{
//                return [UIImage imageNamed:@"knowledgeIconGreen"];
//                break;
//            }
//            case CLJobsControllerIndex:{
//                return [UIImage imageNamed:@"jobsIconGreen"];
//                break;
//            }
//            case CLCalendarControllerIndex:{
//                return [UIImage imageNamed:@"calendarIconGreen"];
//                break;
//            }
//            case CLInboxControllerIndex:{
//                return [UIImage imageNamed:@"inboxIconGreen"];
//                break;
//            }
//            case CLSettingsControllerIndex:{
//                return [UIImage imageNamed:@"settingsIconGreen"];
//                break;
//            }
//            case CLLogoutControllerIndex:{
//                return [UIImage imageNamed:@"logoutIconGreen"];
//                break;
//            }
//            default:
//                return nil;
//                break;
//        }
//    }
//    else if ([CLUserObject currentUser].trafficLightStatus==CLTrafficLightAmberColor) {
//        switch (controllerIndex) {
//            case CLHomeControllerIndex:{
//                return [UIImage imageNamed:@"homeIconAmber"];
//                break;
//            }
//            case CLProfileControllerIndex:{
//                return [UIImage imageNamed:@"profileIconAmber"];
//                break;
//            }
//            case CLMyCareerLineControllerIndex:{
//                return [UIImage imageNamed:@"myCLIconAmber"];
//                break;
//            }
//            case CLDocumentsControllerIndex:{
//                return [UIImage imageNamed:@"documentsIconAmber"];
//                break;
//            }
//            case CLKnowledgeControllerIndex:{
//                return [UIImage imageNamed:@"knowledgeIconAmber"];
//                break;
//            }
//            case CLJobsControllerIndex:{
//                return [UIImage imageNamed:@"jobsIconAmber"];
//                break;
//            }
//            case CLCalendarControllerIndex:{
//                return [UIImage imageNamed:@"calendarIconAmber"];
//                break;
//            }
//            case CLInboxControllerIndex:{
//                return [UIImage imageNamed:@"inboxIconAmber"];
//                break;
//            }
//            case CLSettingsControllerIndex:{
//                return [UIImage imageNamed:@"settingsIconAmber"];
//                break;
//            }
//            case CLLogoutControllerIndex:{
//                return [UIImage imageNamed:@"logoutIconAmber"];
//                break;
//            }
//            default:
//                return nil;
//                break;
//        }
//    }
//    else if ([CLUserObject currentUser].trafficLightStatus==CLTrafficLightRedColor) {
//        switch (controllerIndex) {
//            case CLHomeControllerIndex:{
//                return [UIImage imageNamed:@"homeIconRed"];
//                break;
//            }
//            case CLProfileControllerIndex:{
//                return [UIImage imageNamed:@"profileIconRed"];
//                break;
//            }
//            case CLMyCareerLineControllerIndex:{
//                return [UIImage imageNamed:@"myCLIconRed"];
//                break;
//            }
//            case CLDocumentsControllerIndex:{
//                return [UIImage imageNamed:@"documentsIconRed"];
//                break;
//            }
//            case CLKnowledgeControllerIndex:{
//                return [UIImage imageNamed:@"knowledgeIconRed"];
//                break;
//            }
//            case CLJobsControllerIndex:{
//                return [UIImage imageNamed:@"jobsIconRed"];
//                break;
//            }
//            case CLCalendarControllerIndex:{
//                return [UIImage imageNamed:@"calendarIconRed"];
//                break;
//            }
//            case CLInboxControllerIndex:{
//                return [UIImage imageNamed:@"inboxIconRed"];
//                break;
//            }
//            case CLSettingsControllerIndex:{
//                return [UIImage imageNamed:@"settingsIconRed"];
//                break;
//            }
//            case CLLogoutControllerIndex:{
//                return [UIImage imageNamed:@"logoutIconRed"];
//                break;
//            }
//            default:
//                return nil;
//                break;
//        }
//    }
//    else{
//        return nil;
//    }
//}

@end
