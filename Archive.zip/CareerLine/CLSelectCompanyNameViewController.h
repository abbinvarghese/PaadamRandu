//
//  CLSelectCompanyNameViewController.h
//  CareerLine
//
//  Created by RENJITH on 10/09/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectCompanyNameViewController;

@protocol CLSelectCompanyNameDelegate <NSObject>

@required
- (void)selectCompanyNameDidSelectCompanyName:(CLSelectCompanyNameViewController*)controller withDict:(NSMutableDictionary *)companyDict companyDiv:(NSMutableArray *)companyDivisions isNew:(BOOL)isNewCompany;

@end

@interface CLSelectCompanyNameViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,weak) id <CLSelectCompanyNameDelegate> delegate;
@property(nonatomic, retain) NSString *countryCode;
@end
 