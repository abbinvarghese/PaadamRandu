//
//  CLSelectLocationViewController.m
//  CareerLine
//
//  Created by CSG on 2/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectLocationViewController.h"
#import "CLLocationObject.h"
#import "CLLocationLoaderCell.h"

#define kCellTextFontSize 14

@interface CLSelectLocationViewController ()

@property (weak, nonatomic) IBOutlet UITableView *locTableView;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityView;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorMsg;

@property(nonatomic,strong)NSMutableArray *filteredLocationsArray;
@property(nonatomic,strong)NSMutableDictionary *selectedLocationsDict;
@property(nonatomic,strong)NSMutableArray *selectedLocationsArray;
@property(nonatomic,strong)NSString *searchText;

@property(nonatomic,assign)BOOL shouldPaginate;
@property(nonatomic,assign)BOOL isLastPageReached;
@property(nonatomic,assign)int nextPageToLoad;
@property(nonatomic,assign)BOOL needToclearArray;

@end

@implementation CLSelectLocationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.needToclearArray=YES;
    [self.locTableView registerClass:[CLLocationLoaderCell class] forCellReuseIdentifier:@"CLLocationLoaderCell"];
    self.nextPageToLoad=1;
    self.shouldPaginate = YES;
    self.isLastPageReached = NO;
    if(self.locationListType == LocationListingTypeOtherCountries || self.locationListType == LocationListingCountryForCRF)
        self.title=NSLocalizedString(@"Search Country", @"Select Country page title");
    else
        self.title=NSLocalizedString(@"Search Location", @"Select Location page title");
    
    
    [self setLeftNavigationButton];
    if (self.locationListType!=LocationListingTypeHomeLocation) {
        [self setRightNavigationButton];
    }
    
    self.locTableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    self.locTableView.tableHeaderView=self.searchBar;
    self.filteredLocationsArray=[[NSMutableArray alloc] init];
    self.selectedLocationsArray=[[NSMutableArray alloc] init];
    self.navigationItem.rightBarButtonItem.enabled=NO;
    self.lblErrorMsg.hidden=YES;
    self.lblErrorMsg.text=@"";
    self.searchText=@"";
    
    
    if (self.locationListType==LocationListingTypeHomeLocation) {
       // [self filterContentForSearchText:self.searchText];
    }
    else if (self.locationListType==LocationListingTypeOtherCountries){
//        [self.activityView startAnimating];
//        self.filteredLocationsArray=[DBClient getAllCountriesListFromDBnotIn:[self createBlacklistStringForSelectedLocation]];
//        [self.activityView stopAnimating];
    }
    else{
       // [self filterContentForSearchText:self.searchText];
    }
    
    [self.locTableView reloadData];
}

-(void)viewDidAppear:(BOOL)animated{
    [self.searchBar becomeFirstResponder];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self.searchBar resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(NSString*)createBlacklistStringForSelectedLocation{
    NSMutableString *string=[[NSMutableString alloc] init];
    if (self.locationListType==LocationListingTypeOtherCountries){
        if ([self.selectedLocations count]>0) {
            for (int i=0; i<[self.selectedLocations count]; i++) {
                [string appendString:[NSString stringWithFormat:@"%@,",[[self.selectedLocations objectAtIndex:i] objectForKey:kLocationCountryCode]]];
            }
            [string appendFormat:@"%@",self.countryCodeforListing];
        }
    }
    else{
        if ([self.selectedLocations count]>0) {
            for (int i=0; i<[self.selectedLocations count]; i++) {
                [string appendString:[NSString stringWithFormat:@"%@,",[[self.selectedLocations objectAtIndex:i] objectForKey:kLocationCode]]];
            }
            [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        }
    }
    return string;
}


-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

- (void)filterContentForSearchText:(NSString*)searchText
{
	// Update the filtered array based on the search text.
    if (self.needToclearArray) {
        [self.filteredLocationsArray removeAllObjects];
        [self.locTableView reloadData];
        self.lblErrorMsg.hidden=YES;
        self.lblErrorMsg.text=@"";
    }
    
    if (self.locationListType==LocationListingTypeHomeLocation) {
        if (self.needToclearArray) {
            [self.activityView startAnimating];
        }
        
        [CLLocationObject getLocationsForSearchString:searchText forPage:self.nextPageToLoad
                                          success:^(NSMutableArray *locationList,BOOL lastPageReached){
                                              [self.activityView stopAnimating];
                                              self.nextPageToLoad++;
                                              if (!lastPageReached) {
                                                  self.shouldPaginate=YES;
                                              }
                                              self.isLastPageReached = lastPageReached;
                                              
                                              [self.filteredLocationsArray addObjectsFromArray:locationList];
                                              [self.locTableView reloadData];
                                              if (self.filteredLocationsArray.count == 0) {
                                                  self.lblErrorMsg.hidden=NO;
                                                  self.lblErrorMsg.text=@"No Results Found. Please Enter a Valid Region";
                                              }
                                          }
                                          failure:^(NSString *error){
                                              if (![error isEqualToString:@""]) {
                                                  [self.activityView stopAnimating];
                                                  [self.locTableView reloadData];
                                                  self.lblErrorMsg.hidden=NO;
                                                  self.lblErrorMsg.text=@"No Results Found. Please Enter Your Region";
                                              }
                                          }];
    }
    else if (self.locationListType==LocationListingTypeOtherCountries){
        self.filteredLocationsArray = [NSMutableArray arrayWithArray:[[CLCoreDataHelper sharedCLCoreDataHelper] getCountriesListForSearchString:searchText notIn:[self createBlacklistStringForSelectedLocation]]];
        [self.locTableView reloadData];
        if ([self.filteredLocationsArray count]==0) {
            self.lblErrorMsg.hidden=NO;
            self.lblErrorMsg.text=NSLocalizedString(@"No Results Found. Please Enter Your Country Name", @"No results found for search");
        }
        else{
            self.lblErrorMsg.hidden=YES;
            self.lblErrorMsg.text=@"";
        }
    }
    
    else if (self.locationListType == LocationListingCountryForCRF){
        self.filteredLocationsArray = [NSMutableArray arrayWithArray:[[CLCoreDataHelper sharedCLCoreDataHelper] getCountriesListForSearchString:searchText notIn:@""]];
        [self.locTableView reloadData];
        if ([self.filteredLocationsArray count]==0) {
            self.lblErrorMsg.hidden=NO;
            self.lblErrorMsg.text=NSLocalizedString(@"No Results Found. Please Enter Your Country Name", @"No results found for search");
        }
        else{
            self.lblErrorMsg.hidden=YES;
            self.lblErrorMsg.text=@"";
        }
    }
    
    else if (self.locationListType == LocationListingCountryBasedLocation){
        if (self.needToclearArray) {
            [self.activityView startAnimating];
        }
        
        NSString *code=nil;
        if (self.countryCodeforListing) {
            code = self.countryCodeforListing;
        }
        else{
            NSDictionary *savedDataDict=[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName];
           code=[[savedDataDict objectForKey:kCLUserDefaultsProfileCountryKey]objectForKey:@"jobLocationCountryCode"];
        }
        
        [CLLocationObject getLocationsForSearchString:searchText withCountryCode:code notIn:@"" forPage:self.nextPageToLoad
                                              success:^(NSMutableArray *locationList,BOOL lastPageReached){
                                                  [self.activityView stopAnimating];
                                                  self.nextPageToLoad++;
                                                  if (!lastPageReached) {
                                                      self.shouldPaginate=YES;
                                                  }
                                                  self.isLastPageReached = lastPageReached;
                                                  
                                                  [self.filteredLocationsArray addObjectsFromArray:locationList];
                                                  [self.locTableView reloadData];
                                                  self.lblErrorMsg.hidden=YES;
                                                  self.lblErrorMsg.text=@"";
                                              }
                                              failure:^(NSString *error){
                                                  if (![error isEqualToString:@""]) {
                                                      [self.activityView stopAnimating];
                                                      [self.locTableView reloadData];
                                                      self.lblErrorMsg.hidden=NO;
                                                      self.lblErrorMsg.text=@"No Results Found. Please Enter Your Region";
                                                  }
                                              }];
    }
    
    else{
        if (self.needToclearArray) {
            [self.activityView startAnimating];
        }
        [CLLocationObject getLocationsForSearchString:searchText withCountryCode:self.countryCodeforListing notIn:[self createBlacklistStringForSelectedLocation] forPage:self.nextPageToLoad
                                          success:^(NSMutableArray *locationList,BOOL lastPageReached){
                                              [self.activityView stopAnimating];
                                              self.nextPageToLoad++;
                                              if (!lastPageReached) {
                                                  self.shouldPaginate=YES;
                                              }
                                              self.isLastPageReached = lastPageReached;
                                              
                                              [self.filteredLocationsArray addObjectsFromArray:locationList];
                                              [self.locTableView reloadData];
                                              self.lblErrorMsg.hidden=YES;
                                              self.lblErrorMsg.text=@"";

                                          }
                                          failure:^(NSString *error){
                                              if (![error isEqualToString:@""]) {
                                                  [self.activityView stopAnimating];
                                                  [self.locTableView reloadData];
                                                  self.lblErrorMsg.hidden=NO;
                                                  self.lblErrorMsg.text=@"No Results Found. Please Enter Your Region";
                                              }
                                          }];
    }
}

-(BOOL)selectedLocationsContainsDict:(NSDictionary*)cellDict{
    BOOL isContains=NO;
    NSDictionary *selectedDict=nil;
    for (int i=0; i<[self.selectedLocationsArray count]; i++) {
        selectedDict=[self.selectedLocationsArray objectAtIndex:i];
        if (self.locationListType==LocationListingTypeOtherCountries){
            if([[cellDict objectForKey:kLocationCountryCode] isEqualToString:[selectedDict objectForKey:kLocationCountryCode]]){
                isContains=YES;
                break;
            }
        }
        else{
            if([[cellDict objectForKey:kLocationCode] isEqualToString:[selectedDict objectForKey:kLocationCode]]){
                isContains=YES;
                break;
            }
        }
    }
    return isContains;
}

#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [CLLocationObject cancelGetLocationRequest];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)bttnActionSelectionDone:(id)sender{
    [CLLocationObject cancelGetLocationRequest];
    dispatch_async(dispatch_get_main_queue(), ^{
    [self dismissViewControllerAnimated:YES completion:^(void){
        if (self.locationListType==LocationListingTypeHomeLocation) {
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectLocationControllerDidSelectHomeLocation:withDictonary:)]){
                [self.delegate selectLocationControllerDidSelectHomeLocation:self withDictonary:self.selectedLocationsDict];
            }
        }
        else if (self.locationListType==LocationListingCountryForCRF){
            if (self.delegate!=nil && [self.delegate respondsToSelector:@selector(selectLocationControllerDidSelectHomeLocation:withDictonary:)]) {
                [self.delegate selectLocationControllerDidSelectHomeLocation:self withDictonary:self.selectedLocationsDict];
            }
        }
        else if (self.locationListType==LocationListingCountryBasedLocation){
            if (self.delegate!=nil && [self.delegate respondsToSelector:@selector(selectLocationControllerDidSelectHomeLocation:withDictonary:)]) {
                [self.delegate selectLocationControllerDidSelectHomeLocation:self withDictonary:self.selectedLocationsDict];
            }
        }
        else{
            if([self.selectedLocationsArray count]>0){
                if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectLocationControllerDidSelectLocations:forType:withArray:)]){
                    [self.delegate selectLocationControllerDidSelectLocations:self forType:self.locationListType withArray:self.selectedLocationsArray];
                }
            }
        }
    }];
    });
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.filteredLocationsArray.count > 0) {
        if (self.isLastPageReached) {
            return [self.filteredLocationsArray count];
        }else{
            return [self.filteredLocationsArray count]+1;
        }
    }
    else{
        return 0;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == [self.filteredLocationsArray count]) {
        CLLocationLoaderCell *cell = [self.locTableView dequeueReusableCellWithIdentifier:@"CLLocationLoaderCell"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell startActivityIndicator];
        return cell;
    }
    else{
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.textLabel.font=[UIFont systemFontOfSize:kCellTextFontSize];
            cell.textLabel.numberOfLines=0;
        }
        
        NSDictionary *cellDict=nil;
        cellDict=[self.filteredLocationsArray objectAtIndex:indexPath.row];
        
        if (self.locationListType==LocationListingTypeHomeLocation) {
            //single selection..
            if([self.selectedLocationsDict isEqualToDictionary:[self.filteredLocationsArray objectAtIndex:indexPath.row]]){
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }
            else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
        }
        else if (self.locationListType==LocationListingTypeSameCountry || self.locationListType==LocationListingTypeOtherCountries){
            if([self selectedLocationsContainsDict:cellDict]){
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }
            else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
        }
        
        
        
        if (self.locationListType==LocationListingTypeOtherCountries){
            cell.textLabel.text=[cellDict objectForKey:kLocationCountryName];
        }
        else if (self.locationListType==LocationListingTypeSameCountry){
            cell.textLabel.text=[cellDict objectForKey:kLocationName];
        }
        else if (self.locationListType == LocationListingCountryForCRF){
            cell.textLabel.text=[cellDict objectForKey:kLocationCountryName];
        }
        else if (self.locationListType == LocationListingCountryBasedLocation){
            if ([[cellDict objectForKey:@"jobLocationAdminArea"] isEqualToString:@""]) {
                cell.textLabel.text=[NSString stringWithFormat:@"%@, %@",[cellDict objectForKey:kLocationName],[cellDict objectForKey:kLocationCountryName]];
            }
            else{
                cell.textLabel.text=[NSString stringWithFormat:@"%@, %@, %@",[cellDict objectForKey:kLocationName],[cellDict objectForKey:kLocationAdminArea],[cellDict objectForKey:kLocationCountryName]];
            }
            
        }
        else{
            cell.textLabel.text=[NSString stringWithFormat:@"%@, %@, %@",[cellDict objectForKey:kLocationName],[cellDict objectForKey:kLocationAdminArea],[cellDict objectForKey:kLocationCountryName]];
        }
        
        return cell;

    }
}

#pragma mark - Table view delegate


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (self.filteredLocationsArray.count>0) {
        
        float scrollViewHeight = scrollView.frame.size.height;
        float scrollContentSizeHeight = scrollView.contentSize.height;
        float scrollOffset = scrollView.contentOffset.y;
        if (self.shouldPaginate && !self.isLastPageReached) {
            if ((scrollOffset + scrollViewHeight >= scrollContentSizeHeight) && (scrollContentSizeHeight>0)){
                self.needToclearArray = NO;
                self.shouldPaginate = NO;
                [self filterContentForSearchText:self.searchText];
                
            }
        }

    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==self.filteredLocationsArray.count) {
        return 44;
    }
    else{
        NSString *expectedText=nil;
        NSDictionary *cellDict=nil;
        cellDict=[self.filteredLocationsArray objectAtIndex:indexPath.row];
        
        if (self.locationListType==LocationListingTypeOtherCountries){
            expectedText=[cellDict objectForKey:kLocationCountryName];
        }
        else if (self.locationListType==LocationListingTypeSameCountry){
            expectedText=[cellDict objectForKey:kLocationName];
        }
        else{
            expectedText=[NSString stringWithFormat:@"%@, %@, %@",[cellDict objectForKey:kLocationName],[cellDict objectForKey:kLocationAdminArea],[cellDict objectForKey:kLocationCountryName]];
        }
        
        
        CGRect expectedQuestextFrame = [expectedText boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                                               attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                           [UIFont systemFontOfSize:kCellTextFontSize], NSFontAttributeName,
                                                                           nil]
                                                                  context:nil];
        
        return MAX(44, ceil(expectedQuestextFrame.size.height)+27);
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.navigationItem.rightBarButtonItem.enabled=YES;
    if (self.locationListType==LocationListingTypeHomeLocation) {
        if (indexPath.row == self.filteredLocationsArray.count) {
            
        }
        else{
            self.selectedLocationsDict=[self.filteredLocationsArray objectAtIndex:indexPath.row];
            [self.locTableView reloadData];
            [self bttnActionSelectionDone:nil];
        }
    }
    else if (self.locationListType == LocationListingCountryForCRF){
        if (indexPath.row == self.filteredLocationsArray.count) {
            
        } else{
            self.selectedLocationsDict=[self.filteredLocationsArray objectAtIndex:indexPath.row];
            [self bttnActionSelectionDone:nil];
        }
    }
    else if (self.locationListType==LocationListingCountryBasedLocation){
        if (indexPath.row == self.filteredLocationsArray.count) {
            
        }else{
        self.selectedLocationsDict=[self.filteredLocationsArray objectAtIndex:indexPath.row];
        [self bttnActionSelectionDone:nil];
        }
    }
    else{
        if (indexPath.row == self.filteredLocationsArray.count) {
            
        }
        else{
            if (!self.forceSingleSelection) {
                if([self selectedLocationsContainsDict:[self.filteredLocationsArray objectAtIndex:indexPath.row]]){
                    [self.selectedLocationsArray removeObject:[self.filteredLocationsArray objectAtIndex:indexPath.row]];
                    [self.locTableView reloadData];
                }
                else{
                    [self.selectedLocationsArray addObject:[self.filteredLocationsArray objectAtIndex:indexPath.row]];
                    [self.locTableView reloadData];
                }
            }
            else{
                [self.selectedLocationsArray addObject:[self.filteredLocationsArray objectAtIndex:indexPath.row]];
                [self.locTableView reloadData];
                [self bttnActionSelectionDone:nil];
            }
 
        }
        
    }
    
}

#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    //[self filterContentForSearchText:searchBar.text];
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.needToclearArray=YES;
    self.nextPageToLoad=1;
    self.searchText=searchBar.text;
    if (self.locationListType==LocationListingTypeOtherCountries) {
        [self filterContentForSearchText:searchBar.text];
    }
    else{
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
        [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
    }
}

-(void)searchAfterDelay{
    [self filterContentForSearchText:self.searchText];
}


//-(void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller{
//    [self.tableView reloadData];
//    
//    if (self.locationListType==LocationListingTypeHomeLocation) {
//        //To scroll to the selected value..
//        if([self.selectedLocationsDict count]>0){
//            NSIndexPath *indexpath=nil;
//            for (int i=0; i<[self.locationsArray count]; i++) {
//                if([self.selectedLocationsDict isEqualToDictionary:[self.locationsArray objectAtIndex:i]]){
//                    indexpath=[NSIndexPath indexPathForRow:i inSection:0];
//                    break;
//                }
//            }
//            [self.tableView scrollToRowAtIndexPath:indexpath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
//        }
//    }
//}
//
//- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
//{
//    // Tells the table data source to reload when text changes
//    [self filterContentForSearchText:searchString];
//    
//    // Return YES to cause the search result table view to be reloaded.
//    return YES;
//}
//
//-(void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller {
//    [controller.searchBar setShowsCancelButton:YES animated:YES];
//    UIButton *cancelButton;
//    UIView *topView = controller.searchBar.subviews[0];
//    for (UIView *subView in topView.subviews) {
//        if ([subView isKindOfClass:NSClassFromString(@"UINavigationButton")]) {
//            cancelButton = (UIButton*)subView;
//        }
//    }
//    if (cancelButton) {
//        [cancelButton setTitle:@"Done" forState:UIControlStateNormal];
//    }
//}


@end
