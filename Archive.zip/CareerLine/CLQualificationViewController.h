//
//  CLQualificationViewController.h
//  CareerLine
//
//  Created by RENJITH on 29/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLEducationViewController.h"
#import "CLMembershipViewController.h"
#import "CLTrainingViewController.h"
#import "CLCertificationViewController.h"
#import "CLLicenseViewController.h"

@interface CLQualificationViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CLQualificationControllerDelegate,CLQualificationMembershipDelegate,CLCertificationDelegate,ClQualificationLicenseDeleagte,CLTrainingDelegate>

@property (nonatomic, assign)NSInteger selectedRow;

@end
