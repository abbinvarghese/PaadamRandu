//
//  CLCoreDataHelper.m
//  CareerLine
//
//  Created by Padmam on 12/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLCoreDataHelper.h"
#import "CoreDataHelper.h"

@implementation CLCoreDataHelper

static CLCoreDataHelper *coreDataHelper = nil;

#pragma mark -
#pragma mark initilization
#pragma mark -

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        managedObjectContext	= [[CoreDataHelper sharedCoreDataHelper] createManagedObjectContext];
    }
    return self;
}
/*----------------------------------------------------------------------------------------------*/
/*shared instance*/
/*----------------------------------------------------------------------------------------------*/
+ (CLCoreDataHelper *)sharedCLCoreDataHelper
{
    @synchronized(self)
    {
        if(coreDataHelper == nil)
        {
            coreDataHelper =[[self alloc] init];
        }
    }
    return coreDataHelper;
}


+ (id)allocWithZone:(NSZone *)zone
{
    @synchronized(self)
    {
        if (coreDataHelper == nil)
        {
            coreDataHelper = [super allocWithZone:zone];
            return coreDataHelper;  // assignment and return on first allocation
        }
    }
    return nil; //on subsequent allocation attempts return nil
}


- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (NSManagedObjectContext *)getManagedObjectContext;
{
    return managedObjectContext;
}


#pragma mark -
#pragma mark Core data helper funcitons
#pragma mark -

/*----------------------------------------------------------------------------------------------
 @Method Name  : deleteAllObjects
 @Param        : NSString*
 @Return       : void
 @Description  :
 ----------------------------------------------------------------------------------------------*/
- (void)deleteAllObjects:(NSString *)entityDescription
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityDescription inManagedObjectContext:managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSArray *items = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    //[fetchRequest release];
    
    for (NSManagedObject *managedObject in items)
    {
        [managedObjectContext deleteObject:managedObject];
    }
    if (![managedObjectContext save:&error])
    {
        
    }
}


- (id)NULL_TO_NIL:(id)obj
{
    __typeof__ (obj) __obj = (obj);
    if (__obj == [NSNull null])
    {
        __obj = nil;
    }
    else
    {
        return __obj;
    }
    return __obj;
}


- (NSString*)getISDOfCurrentCountry:(NSString*)cyCode
{
    NSString *ISD;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"cyCode = %@", cyCode];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        NSArray *userDetailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        ClCountries *details = [userDetailsArray objectAtIndex:0];
        ISD = details.isdcode;
        
    }
    END_BLOCK
    return ISD;
    
}


-(NSString*)getCountryCodeForCountry :(NSString*)country{
    NSString *CountryCode;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"cyName = %@",country];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        NSArray *userDetailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        ClCountries *details = [userDetailsArray objectAtIndex:0];
        CountryCode = details.cyCode;
    }
    END_BLOCK
    return CountryCode;
}

-(NSMutableDictionary*)getNationalityFromCountryCode :(NSString*)cyCode{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"cyCode = %@", cyCode];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        NSArray *userDetialsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        ClCountries *details = [userDetialsArray objectAtIndex:0];
        if (details != nil) {
            [dict setValue:details.cyNationality forKey:@"nationalityName"];
            [dict setValue:details.cyCode forKey:@"nationalityCode"];
        }
    }
    END_BLOCK
    return dict;
    
}

- (NSMutableArray*)getAllCareerMoveListFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbRfm" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"rfmId"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"rfmId"]stringValue] forKey: kreasonForMoveDictId];
            [dict removeObjectForKey: @"rfmId"];
            
            NSString *rfmName = [dict objectForKey: @"rfm"];
            
            [dict setObject: [dict objectForKey: @"rfm"] forKey: kreasonForMoveDictName];
            [dict removeObjectForKey: @"rfm"];
            
            if ([rfmName isEqualToString:@"Other"])
            {
                [dict setObject:@"1" forKey: kreasonOtherFlag];
            }
            else
            {
                [dict setObject:@"0" forKey: kreasonOtherFlag];
            }
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    
    return newDetailsArray;
}

//To get all the ISD Code..
- (NSArray*)getAllISDCodeFromDB
{
    NSArray *detailsArray = nil;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"isdcode"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];

        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isdcode!=nil AND isdcode!=''"];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];

    }
    END_BLOCK
    return detailsArray;
}

-(NSMutableArray*)getAllBenefitsListFromDB
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbBenefits" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]initWithKey:@"tid" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kBenefitsId];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject:@"0" forKey:kBenefitsOtherFlag];
            
            [dict setObject:[dict objectForKey: @"benefits"] forKey:kBenefitsName];
            [dict removeObjectForKey:@"benefits"];
            
            [array addObject:dict];
        }
    }
    END_BLOCK
    return array;
}



-(NSMutableArray*)getAllowanceAndLoadingListFromDB
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbAllowancesLoadings" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]initWithKey:@"tid" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *allowence = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [allowence count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[allowence objectAtIndex:index]];
            [dict setObject: [dict objectForKey: @"allowancesLoadings"] forKey: kAllowanceAndLoadingName];
            [dict removeObjectForKey: @"allowancesLoadings"];
            
            [dict setObject:@"0" forKey:kAllowanceAndLoadingOtherFlag];
            
            [dict setObject:[[dict objectForKey: @"tid"]stringValue] forKey:kAllowanceAndLoadingId];
            [dict removeObjectForKey:@"tid"];
            
            [array addObject:dict];
        }

        
    }
    END_BLOCK
    return [array mutableCopy];
}

-(NSMutableArray*)getIncentiveBonusListFromDB{
    NSMutableArray *incentiveList=[[NSMutableArray alloc] init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIncentiveBonus" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]initWithKey:@"tid" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *allowence = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [allowence count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[allowence objectAtIndex:index]];
//            [dict setObject: [dict objectForKey: @"incentiveBonus"] forKey: kIncentiveBonusName];
//            [dict removeObjectForKey: @"incentiveBonus"];
            
            [dict setObject:@"0" forKey:kIncentiveBonusOtherFlag];
            
            [dict setObject:[[dict objectForKey: @"tid"]stringValue] forKey:kIncentiveBonusId];
            [dict removeObjectForKey:@"tid"];
            
            [incentiveList addObject:dict];
        }

        
    }
    END_BLOCK
    return incentiveList;
}

- (NSMutableArray*)getAllCountryDetailsForCurrency:(NSString*)string
{

    NSMutableArray *array = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]initWithKey:@"cyName" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cyCurrencycode!=nil AND isdcode!='' AND %K LIKE[cd] %@", @"cyName",[NSString stringWithFormat:@"%@*",string]];
        
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *jobFuncCatList=[managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [jobFuncCatList count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[jobFuncCatList objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"cyCurrencycode"] forKey: kjobPreferenceCurrencyCode];
            [dict removeObjectForKey: @"cyCurrencycode"];
            
            [dict setObject: [dict objectForKey: @"cyNationality"] forKey: kjobPreferenceCountryName];
            [dict removeObjectForKey: @"cyNationality"];
            
            [dict setObject: [dict objectForKey: @"cyCode"] forKey: kjobPreferenceCountryCode];
            [dict removeObjectForKey: @"cyCode"];
            
            [array addObject:dict];
    }
    }
    END_BLOCK
    return array;
}

//To get all the Gender list..
- (NSArray*)getAllGenderListFromDB
{
    NSArray *detailsArray = nil;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbGender" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"clGenderName"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];

        NSError *error;
        detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
    }
    END_BLOCK
    return detailsArray;

}

//To get all the Employment status..
- (NSMutableArray*)getAllEmpStatusFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];

    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbEmpStatus" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"clEsCode"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"clEsCode"]stringValue] forKey: kemploymentStatusIdKey];
            [dict removeObjectForKey: @"clEsCode"];
            
            [dict setObject: [dict objectForKey: @"clEsName"] forKey: kemploymentStatusTitleKey];
            [dict removeObjectForKey: @"clEsName"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

//To get all the Employment type..
- (NSMutableArray*)getAllEmpTypeFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbTypeEmployment" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"typeEmployment"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"jobMode"] forKey: kemploymentTypeIdKey];
            [dict removeObjectForKey: @"jobMode"];
            
            [dict setObject: [dict objectForKey: @"typeEmployment"] forKey: kemploymentTypeNameKey];
            [dict removeObjectForKey: @"typeEmployment"];
            
            [newDetailsArray addObject:dict];
        }

    }
    END_BLOCK
    return newDetailsArray;
    
}

//To get all the education list ..
- (NSMutableArray*)getAllEducationListFromDBForCountry:(NSString*)cyCode
{
    if (![cyCode isEqualToString:@"IND"]) {
        cyCode = @"xxx";
    }
    
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];

    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbCyEduEquilent" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"cyid"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cycode = %@", cyCode];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"cyid"]stringValue] forKey: keducationDictCode];
            [dict removeObjectForKey: @"cyid"];
            
            [dict setObject: [dict objectForKey: @"cyEqName"] forKey: keducationDictName];
            [dict removeObjectForKey: @"cyEqName"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

//To get all employeement group
- (NSMutableArray*)getAllEmpTypeGroupFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbTypeEmploymentGroup" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"tid"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kempTypeId];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject: [dict objectForKey: @"typeEmploymentGroup"] forKey: kempTypeName];
            [dict removeObjectForKey: @"typeEmploymentGroup"];
            
            [newDetailsArray addObject:dict];
        }

    }
    END_BLOCK
    return newDetailsArray;
    
}


//To get all employeement group details
- (NSMutableArray*)getAllEmpTypeDetailForGroup:(NSDictionary *)empTypeGroup
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbTypeEmploymentSub" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"tid"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *theId = [empTypeGroup objectForKey:kempTypeId];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"typeEmployment = %@", theId];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kempTypeDetailId];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject: [[dict objectForKey: @"typeEmployment"]stringValue] forKey: kempTypeGroupId];
            [dict removeObjectForKey: @"typeEmployment"];
            
            [dict setObject: [dict objectForKey: @"typeEmploymentSub"] forKey: kempTypeDetailName];
            [dict removeObjectForKey: @"typeEmploymentSub"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

//to get sectionName
- (NSString*)getIndustrySectionNameFrom:(NSString*)sectionCode
{
    NSString *sectionName;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIndsector" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"indsectcode = %@", sectionCode];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        NSArray *userDetailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        TbIndsector *details = [userDetailsArray objectAtIndex:0];
        sectionName = details.indsectname;
        
    }
    END_BLOCK
    return sectionName;
    
}

- (NSMutableArray*)getAllIndustrySectorsFromDB:(id)sender notIn:(NSString *)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIndsector" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"indsectcode"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate;
        
        if(blackListString.length!=0)
        {
            predicate = [NSPredicate predicateWithFormat:@"NOT (indsectcode CONTAINS[cd] %@)", blackListString];
        }

        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"indsectcode"] forKey: kIndSectDictCode];
            [dict removeObjectForKey: @"indsectcode"];
            
            [dict setObject: [dict objectForKey: @"indsectname"] forKey: kIndSectDictName];
            [dict removeObjectForKey: @"indsectname"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

- (NSMutableArray*)getIndustriesGroupedForSector:(NSMutableDictionary*)sectorDict
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIndgroup" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"indgroupname"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *theId = [sectorDict objectForKey:@"industrySectCode"];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"indsectcode = %@", theId];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"indsectcode"] forKey: kIndSectDictCode];
            [dict removeObjectForKey: @"indsectcode"];
            
            [dict setObject: [dict objectForKey: @"indgroupcode"] forKey: kIndustryGrpDictCode];
            [dict removeObjectForKey: @"indgroupcode"];
            
            [dict setObject: [dict objectForKey: @"indgroupname"] forKey: kIndustryGrpDictName];
            [dict removeObjectForKey: @"indgroupname"];
            
            [dict setObject:@"0" forKey: kIndGrpOtherFlag];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}


- (NSMutableArray*)getMainIndustriesListForGroup:(NSMutableDictionary*)groupDict notIn:(NSString*)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    NSString *indGroupedcode= [groupDict objectForKey:kIndustryGrpDictCode];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIndustry" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"indname"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate;
        if(blackListString.length==0)
        {
            NSString *theId = [groupDict objectForKey:@"industryGroupCode"];
            predicate = [NSPredicate predicateWithFormat:@"indgroupcode = %@", theId];
        }
        else
        {
            NSArray *textArr = [blackListString componentsSeparatedByString:@","];
            
            predicate = [NSPredicate predicateWithFormat:@"(indgroupcode = %@)", indGroupedcode];
            predicate = [self predicateWithItems:textArr andKeyName:@"indcode" andPredicate:predicate];
            
            //predicate = [NSPredicate predicateWithFormat:@"(indgroupcode = %@) AND NOT (indcode CONTAINS[cd] %@)", indGroupedcode,blackListString];
        }
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"indgroupcode"] forKey: kIndustryGrpDictCode];
            [dict removeObjectForKey: @"indgroupcode"];
            
            [dict setObject: [dict objectForKey: @"indname"] forKey: kIndustryDictName];
            [dict removeObjectForKey: @"indname"];
            
            [dict setObject: [[dict objectForKey: @"indcode"]stringValue] forKey: kIndustryDictCode];
            [dict removeObjectForKey: @"indcode"];
            
            [dict setObject:@"0" forKey: kIndOtherFlag];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

- (NSString*)getIndustryGroupNamefrom:(NSString*)groupCode
{
    NSString *groupName;
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbIndgroup" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"indgroupcode = %@", groupCode];
        [fetchRequest setPredicate:predicate];
        
        NSError *error;
        NSArray *userDetailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        TbIndgroup *details = [userDetailsArray objectAtIndex:0];
        groupName = details.indgroupname;
        
    }
    END_BLOCK
    return groupName;
}

- (NSMutableArray*)getAllJobFunctionsCategory
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbFunctionCat" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"fnCategory"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kjobFunctionCategoryCode];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject: [dict objectForKey: @"fnCategory"] forKey: kjobFunctionCategoryName];
            [dict removeObjectForKey: @"fnCategory"];
            
            [newDetailsArray addObject:dict];
        }
        
    }
    END_BLOCK
    return newDetailsArray;
}

- (NSMutableArray*)getAllJobFunctionsForCategory:(NSString*)catId notIn:(NSString*)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbFunction" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"otherFlag"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate;
        if(blackListString.length==0)
        {
            predicate = [NSPredicate predicateWithFormat:@" %K LIKE[cd] %@", @"fnCatCode", catId];
        }
        else
        {
            NSArray *textArr = [blackListString componentsSeparatedByString:@","];
            
            predicate = [NSPredicate predicateWithFormat:@" %K LIKE[cd] %@", @"fnCatCode", catId];
            predicate = [self predicateWithItems:textArr andKeyName:@"fncode" andPredicate:predicate];
        }
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"fncode"]stringValue] forKey: kjobFunctionCode];
            [dict removeObjectForKey: @"fncode"];
            
            [dict setObject: [dict objectForKey: @"fnname"] forKey: kjobFunctionName];
            [dict removeObjectForKey: @"fnname"];
            
            [dict setObject: [[dict objectForKey: @"fnCatCode"]stringValue] forKey: kjobFunctionCategoryCode];
            [dict removeObjectForKey: @"fnCatCode"];
            
            [dict setObject: [[dict objectForKey: @"otherFlag"]stringValue] forKey: kjobFunctionOtherFlag];
            [dict removeObjectForKey: @"otherFlag"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

- (NSMutableArray*)getAllJobLevelGroupFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbLevelGroup" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"groupcode"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"groupcode"]stringValue] forKey: kjobLevelGroupDictCode];
            [dict removeObjectForKey: @"groupcode"];
            
            [dict setObject: [dict objectForKey: @"groupname"] forKey: kjobLevelGroupDictName];
            [dict removeObjectForKey: @"groupname"];
            
            [newDetailsArray addObject:dict];
        }
        
    }
    END_BLOCK
    return newDetailsArray;
}


- (NSMutableArray*)getAllJobLevelDetailForJobGroup:(NSDictionary *)jobGroup
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbLevel" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"levelCode"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSString *theId = [jobGroup objectForKey:@"jobLevelGroupCode"];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"lvlGroupCode = %@", theId];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"levelCode"]stringValue] forKey: jobLevelDetailDictCode];
            //[dict removeObjectForKey: @"levelCode"];
            
            [dict setObject: [dict objectForKey: @"levelName"] forKey: jobLevelDetailDictName];
            [dict removeObjectForKey: @"levelName"];
            
            [dict setObject: [dict objectForKey: @"lvlDescription"] forKey: jobLevelDetailDictDesc];
            [dict removeObjectForKey: @"lvlDescription"];
            
            
            [newDetailsArray addObject:dict];
            
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}
- (NSMutableArray*)getAllEmpJobScopeFromDB:(NSString*)countryCode
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbJobimpactGroup" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"tid"
                                                                       ascending:NO selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cyCode = %@", countryCode];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kemploymentJobScopeIdKey];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject: [dict objectForKey: @"jobImpactGroup"] forKey: kemploymentJobScopeNameKey];
            [dict removeObjectForKey: @"jobImpactGroup"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
}

- (NSMutableArray*)getJobScopeGroupedForSector:(NSMutableDictionary*)sectorDict
{
    NSString *jobScopeCode = [sectorDict objectForKey:kCLTargetJobsJobScopeCodeKey];
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbJobimpact" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"tid"
                                                                       ascending:NO selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"jobimpactGroup = %@", jobScopeCode];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kCLTargetJobsJobScopeCodeKey];
            [dict removeObjectForKey: @"tid"];
            
            [dict setObject: [[dict objectForKey: @"jobimpactGroup"]stringValue] forKey: kCLTargetJobsJobImpactGroupKey];
            [dict removeObjectForKey: @"jobimpactGroup"];
            
            [dict setObject: [dict objectForKey: @"jobimpact"] forKey: kCLTargetJobsJobScopeKey];
            [dict removeObjectForKey: @"jobimpact"];
            
            [newDetailsArray addObject:dict];
            
        }
    }
    END_BLOCK
    return newDetailsArray;
}


- (NSMutableArray*)getAllNationalityListFromDBnotIn:(NSString*)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];

        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"cyNationality"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = nil;
        if(blackListString.length>0)
        {
            //predicate = [NSPredicate predicateWithFormat:@"NOT (cyCode CONTAINS[cd] %@) AND cyNationality!=nil AND cyNationality!=''", blackListString];
            
            NSArray *textArr = [blackListString componentsSeparatedByString:@","];
            
            predicate = [NSPredicate predicateWithFormat:@"cyNationality!=nil AND cyNationality!=''"];
            predicate = [self predicateWithItems:textArr andKeyName:@"cyCode" andPredicate:predicate];
        }
        else
        {
            predicate = [NSPredicate predicateWithFormat:@"cyNationality!=nil AND cyNationality!=''"];
        }
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"cyCode"] forKey: knationalityDictCode];
            [dict removeObjectForKey: @"cyCode"];
            
            [dict setObject: [dict objectForKey: @"cyNationality"] forKey: knationalityDictName];
            [dict removeObjectForKey: @"cyNationality"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
}

- (NSMutableArray*)getNationalityListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"cyNationality"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate = nil;
        if(blackListString.length==0)
        {
            predicate = [NSPredicate predicateWithFormat:@"cyNationality!=nil AND cyNationality!='' AND %K LIKE[cd] %@", @"cyNationality",[NSString stringWithFormat:@"%@*",keyword]];
        }
        else
        {
            NSArray *textArr = [blackListString componentsSeparatedByString:@","];
            
            predicate = [NSPredicate predicateWithFormat:@"cyNationality!=nil AND cyNationality!='' AND %K LIKE[cd] %@", @"cyNationality", [NSString stringWithFormat:@"%@*",keyword]];
            
            predicate = [self predicateWithItems:textArr andKeyName:@"cyCode" andPredicate:predicate];
        }
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"cyCode"] forKey: knationalityDictCode];
            [dict removeObjectForKey: @"cyCode"];
            
            [dict setObject: [dict objectForKey: @"cyNationality"] forKey: knationalityDictName];
            [dict removeObjectForKey: @"cyNationality"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
}

- (NSPredicate *)predicateWithItems:(NSArray *)searchItems andKeyName:(NSString *)keyValue andPredicate:(NSPredicate*)availablePredicate
{
    NSMutableArray *subpredicates = [[NSMutableArray alloc] init];
    
    if(availablePredicate != nil)
        [subpredicates addObject:availablePredicate];
    
    for (NSString *searchTerm in searchItems) {
        NSPredicate *subpredicate = [NSPredicate predicateWithFormat:@" NOT (%K CONTAINS[cd] %@)", keyValue, searchTerm];
        [subpredicates addObject:subpredicate];
    }
    
    NSPredicate *result = [NSCompoundPredicate andPredicateWithSubpredicates:subpredicates];
    
    return result;
}

- (NSMutableArray*)getAllFrequencyListFromDB
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbFrequency" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"tid"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"tid"]stringValue] forKey: kFrequencyId];
            [dict removeObjectForKey: @"tid"];
            
//            [dict setObject: [dict objectForKey: @"frequency"] forKey: kFrequencyName];
//            [dict removeObjectForKey: @"frequency"];
            
            [dict setObject:@"0" forKey: kFrequencyOtherFlag];
            
            [newDetailsArray addObject:dict];
        }
        
    }
    END_BLOCK
    return newDetailsArray;
}

//To get the Countries based on the searchString from DB except those contained in blackListString..
- (NSMutableArray*)getCountriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString
{
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ClCountries" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"cyName"
                                                                       ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        
        NSPredicate *predicate;
        if(blackListString.length==0)
        {
            predicate = [NSPredicate predicateWithFormat:@"%K LIKE[cd] %@ AND grType='C'", @"cyName",[NSString stringWithFormat:@"%@*",keyword]];
        }
        else
        {
            NSArray *textArr = [blackListString componentsSeparatedByString:@","];
            
            predicate = [NSPredicate predicateWithFormat:@"%K LIKE[cd] %@ AND grType='C'", @"cyName", [NSString stringWithFormat:@"%@*",keyword]];
            
            predicate = [self predicateWithItems:textArr andKeyName:@"cyCode" andPredicate:predicate];
        }
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [dict objectForKey: @"cyCode"] forKey: kLocationCountryCode];
            [dict removeObjectForKey: @"cyCode"];
            
            [dict setObject: [dict objectForKey: @"cyName"] forKey: kLocationCountryName];
            [dict removeObjectForKey: @"cyName"];
            
            [newDetailsArray addObject:dict];
        }
    }
    END_BLOCK
    return newDetailsArray;
    
}

//TODO: remove gender dependency
- (NSMutableArray*)getSalutationsListforNationality:(NSMutableString*)nationalityString
{
    [nationalityString appendString:@",INT"];
    
    NSMutableArray *newDetailsArray = [[NSMutableArray alloc]init];
    
    BEGIN_BLOCK
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"TbSalutation" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSArray *textArr = [nationalityString componentsSeparatedByString:@","];
        NSPredicate *predicate = [NSPredicate predicateWithFormat: @"clCycode IN %@", textArr];
        [fetchRequest setPredicate:predicate];
        
        [fetchRequest setResultType:NSDictionaryResultType];
        [fetchRequest setReturnsDistinctResults:YES];
        
        NSError *error;
        NSArray *detailsArray = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        for(NSInteger index = 0; index < [detailsArray count]; index++)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:[detailsArray objectAtIndex:index]];
            
            [dict setObject: [[dict objectForKey: @"clSalutationid"]stringValue] forKey: kSalutationOptionId];
            [dict removeObjectForKey: @"clSalutationid"];
            
            NSString *salutationTitle = [dict objectForKey: @"clSalutation"];
            [dict setObject: [dict objectForKey: @"clSalutation"] forKey: kSalutationOptionTitle];
            [dict removeObjectForKey: @"clSalutation"];

            //Process the salutaion array to remove duplicates(if duplicates present then take the first one)..
            //checking whether the retreived title present in already added salutation array..
            BOOL isSameSalutationTitlePresent=NO;
            
            for (int i=0; i<[newDetailsArray count]; i++)
            {
                NSString *tempTitle=[[newDetailsArray objectAtIndex:i] objectForKey:kSalutationOptionTitle];
                if ([salutationTitle isEqualToString:tempTitle])
                {
                    isSameSalutationTitlePresent=YES;
                }
            }
            //if same title not present then add to salutation array..
            if (!isSameSalutationTitlePresent)
            {
                [newDetailsArray addObject:dict];
            }
        }
    }
    END_BLOCK
    return newDetailsArray;
}


@end
