//
//  CLPerformanceReviewObject.m
//  CareerLine
//
//  Created by Pravin on 10/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPerformanceReviewObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLPerformanceReviewObject

static NSOperationQueue *saveProjectRequest;
static NSOperationQueue *deleteProjectRequest;
static NSOperationQueue *uploadProjectDocumentRequest;
static NSOperationQueue *deleteProjectDocumentRequest;


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary{
    self.performanceId=[dictionary objectForKeyNotNull:kCLProfilePerfReviewIdkey];
    self.date=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMy"];
    }
    self.performanceDescription=[dictionary objectForKeyNotNull:kCLProfilePerfReviewDescriptionkey];
    self.careerSelected=[dictionary objectForKeyNotNull:kCLProfilePerfReviewCareerSelectedDictkey];
    
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLProfilePerfReviewFilesArraykey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    
    return self;
}

-(void)updateDate:(NSDate*)date{
    self.date=date;
    self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
}

+(NSString*)jsonStringForObject:(CLPerformanceReviewObject*)projObj{
    NSMutableDictionary *projectDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    [insideDict setObject:[CLCommon getStringForDate:projObj.date andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfilePerfReviewDatekey];
    if ([projObj.careerSelected objectForKey:kCLProfilePerfReviewCareerIdkey]) {
        [insideDict setObject:projObj.careerSelected forKey:kCLProfilePerfReviewCareerSelectedDictkey];
    }
    if (projObj.performanceDescription) {
        [insideDict setObject:projObj.performanceDescription forKey:kCLProfilePerfReviewDescriptionkey];
    }
    
    [projectDict setObject:insideDict forKey:kCLProfilePerfReviewArraykey];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:projectDict];
}

//Method for saving PerformanceReview of a particular user...
+ (void)savePerformanceReview:(CLPerformanceReviewObject*)perfObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *perfId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *perfId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": perfObj.performanceId, @"fields":[CLPerformanceReviewObject jsonStringForObject:perfObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLPerformanceReviewObject jsonStringForObject:perfObj]};
    }
    
    if (kDebugMessages) {
        NSLog(@"parameters passed: %@", parameters);
    }
    
    NSLog(@"%@",parameters);
    
    [saveProjectRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveProjectRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfilePerfReviewSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"savePerfRevRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfilePerfReviewSaveIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting PerformanceReview for a particular user...
+ (void)deletePerformanceReview:(NSString*)perfId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": perfId};
    if (kDebugMessages) {
        NSLog(@"delete project parameters: %@", parameters);
    }
    
    [deleteProjectRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteProjectRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileDeletePerfReviewURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete perfrev JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading PerformanceReview document for a particular user...
+ (void)addDocument:(UIImage*)image forPerformanceReview:(NSString*)perfId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": perfId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadProjectDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadProjectDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfilePerfReviewUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"Review" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"perfrev document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting PerformanceReview document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteProjectDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteProjectDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfilePerfReviewDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete perfrev document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
