//
//  CLProfileAboutMeViewController.h
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLAboutMeObject.h"
#import "CLProfilePhotoListingGridCell.h"
#import "CLAboutMeAchievementsViewController.h"
#import "CLAboutMeMediaViewController.h"
#import "CLAboutMeInterestViewController.h"
#import "CLAboutMeInfoViewController.h"

@interface CLProfileAboutMeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLProfilePhotoListingGridCellDelegate,CLAchievementControllerDelegate,CLMediaControllerDelegate,CLInterestControllerDelegate,CLInfoControllerDelegate>

@property(nonatomic,strong)CLAboutMeObject *aboutMe;

@end
