//
//  CLWorkConsiderationObject.m
//  CareerLine
//
//  Created by Abbin on 20/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLWorkConsiderationObject.h"
#import "AFHTTPRequestOperationManager+Timeout.h"
#define kDebugMessages 0

@implementation CLWorkConsiderationObject

static NSOperationQueue *workConsiderationsSummeryRequest;
static NSOperationQueue *saveWorkConsderationRequest;



+(void)cancelWorkConsiderationRequest{
    [workConsiderationsSummeryRequest cancelAllOperations];
    workConsiderationsSummeryRequest = nil;
}

-(id)initWithDictionary:(NSDictionary*)dictionary{
    self = [super init];
    if (self == nil) return nil;
    NSMutableArray *array = [[NSMutableArray alloc]init];
    array = [dictionary objectForKey:kCLWorkconsiderationkey];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    dict = [array objectAtIndex:0];
    self.businessTravelDict = [dict objectForKey:kCLWorkconsiderationbusinessTravelkey];
//    self.workRadius = [dict objectForKey:@"workPreference"];
    self.flexibleWorkSchedule = [[dict objectForKey:kCLWorkConsiderationWorkSchedulekey]boolValue];
    self.flexTime = [[dict objectForKey:kCLWorkConsiderationFlextimekey]boolValue];
    self.compressedWorkWeek = [[dict objectForKey:kCLWorkConsiderationWorkWeekkey]boolValue];
    self.jobsharing = [[dict objectForKey:kCLWorkConsiderationJobSharingkey]boolValue];
    self.workFromHome = [dict objectForKey:kCLWorkconsiderationworkHomekey];
    self.other = [dict objectForKey:kCLWorkConsiderationWorkHomeOtherkey];
    self.disabilityWorkSpace = [[dict objectForKey:kCLWorkConsiderationFriendlyWOrkPlacekey]boolValue];
    self.anythingElse = [dict objectForKey:kCLWorkConsiderationFriendlyWorkRemarkkey];
    return self;
}

+ (void)workConsiderationSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLWorkConsiderationObject *workObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLWorkConsiderationObject *workObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"lang": lang};
    
    [workConsiderationsSummeryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        workConsiderationsSummeryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceWorkConsiderationsSummaryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSMutableDictionary *response=(NSMutableDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLWorkConsiderationObject *workObj=[[CLWorkConsiderationObject alloc] initWithDictionary:response];
                success(workObj);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)saveWorkConsideration:(CLWorkConsiderationObject*)workObj forUser:(NSString*)userId forLang:(NSString*)lang success:(void (^)(NSString *workId))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *workId){};
    }
    
    NSDictionary *parameters =@{@"user": userId, @"fields":[CLWorkConsiderationObject jsonStringForObject:workObj], @"lang": lang};
    
    [saveWorkConsderationRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveWorkConsderationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServicePostWorkConsiderationsURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveWorkConsiderationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLJobPreferenceIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+(NSString*)jsonStringForObject:(CLWorkConsiderationObject*)workObj{
    NSMutableDictionary *mainDictionary = [[NSMutableDictionary alloc]init];
    NSMutableDictionary *insideDictionary = [[NSMutableDictionary alloc]init];
    if (workObj.businessTravelDict != nil) {
        [insideDictionary setObject:workObj.businessTravelDict forKey:kCLWorkconsiderationbusinessTravelkey];
    }
    else{
        [insideDictionary setObject:@"" forKey:kCLWorkconsiderationbusinessTravelkey];
    }
//    if (workObj.workRadius != nil) {
//        [insideDictionary setObject:workObj.workRadius forKey:@"workPreference"];
//    }
    NSString *flwxibleWorkSchedule = [NSString stringWithFormat:@"%@", workObj.flexibleWorkSchedule ? @"Yes" : @"No"];
    [insideDictionary setObject:flwxibleWorkSchedule forKey:kCLWorkConsiderationWorkSchedulekey];
    NSString *flextime = [NSString stringWithFormat:@"%@", workObj.flexTime ? @"Yes" : @"No"];
    [insideDictionary setObject:flextime forKey:kCLWorkConsiderationFlextimekey];
    NSString *workWeek = [NSString stringWithFormat:@"%@", workObj.compressedWorkWeek ? @"Yes" : @"No"];
    [insideDictionary setObject:workWeek forKey:kCLWorkConsiderationWorkWeekkey];
    NSString *jobSharing = [NSString stringWithFormat:@"%@", workObj.jobsharing ? @"Yes" : @"No"];
    [insideDictionary setObject:jobSharing forKey:kCLWorkConsiderationJobSharingkey];
    if (workObj.workFromHome != nil) {
        [insideDictionary setObject:workObj.workFromHome forKey:kCLWorkconsiderationworkHomekey];
    }
    else{
        [insideDictionary setObject:@"" forKey:kCLWorkconsiderationworkHomekey];
    }
    if (workObj.other != nil) {
        [insideDictionary setObject:workObj.other forKey:kCLWorkConsiderationWorkHomeOtherkey];
    }
    else{
        [insideDictionary setObject:@"" forKey:kCLWorkConsiderationWorkHomeOtherkey];
    }
    NSString *friendlyWorkplace = [NSString stringWithFormat:@"%@", workObj.disabilityWorkSpace ? @"Yes" : @"No"];
    [insideDictionary setObject:friendlyWorkplace forKey:kCLWorkConsiderationFriendlyWOrkPlacekey];
    if (workObj.anythingElse != nil) {
        [insideDictionary setObject:workObj.anythingElse forKey:kCLWorkConsiderationFriendlyWorkRemarkkey];
    }
    else{
        [insideDictionary setObject:@"" forKey:kCLWorkConsiderationFriendlyWorkRemarkkey];
    }
    
    [mainDictionary setObject:insideDictionary forKey:kCLWorkconsiderationkey];
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:mainDictionary];
}


@end
