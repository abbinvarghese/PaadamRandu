//
//  CLPreferredJobsEditViewController.h
//  CareerLine
//
//  Created by Abbin on 27/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLPreferredJobsViewController.h"

@protocol CLPreferredJobsEditDelegate <NSObject>

-(void)loadFinalSelectedJobsPreferenceArray:(NSMutableArray*)array;

@end

@interface CLPreferredJobsEditViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,CLPreferredJobsDelegate>

@property(nonatomic,strong) NSMutableArray *passedOnPreferredJobsArray;

@property(nonatomic,weak) id<CLPreferredJobsEditDelegate>delegate;

@end
