//
//  CLAboutMeInterestViewController.m
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAboutMeInterestViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUDFadeZoomAnimation.h"

#define kSectionFooterBgColor [UIColor whiteColor]

@interface CLAboutMeInterestViewController ()

typedef enum {
    CLInterestTitleIndex = 0,
    CLInterestDescriptionIndex = 1
} CLInterestTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;

@property(strong,nonatomic)NSMutableArray *selectedInterestArray;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@end

@implementation CLAboutMeInterestViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Hobby/Interest", @"Hobby/Interest page title");
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    if (self.isEditMode) {
        self.selectedInterestArray=[self.interestObj.interestArray mutableCopy];
        self.descriptionText=self.interestObj.interestDescription;
    }
    else{
        self.selectedInterestArray=[[NSMutableArray alloc] init];
        self.descriptionText=@"";
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.selectedInterestArray count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==CLInterestTitleIndex) {
        return [self.selectedInterestArray count];
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLInterestTitleIndex:{
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            if (cell==nil) {
                cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"titleTextCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
            }
            cell.textLabel.text=[[self.selectedInterestArray objectAtIndex:indexPath.row] objectForKey:kCLProfileAboutMeInterestTitlekey];
            return cell;
            break;
        }
        case CLInterestDescriptionIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for interest description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLInterestTitleIndex:
            return NSLocalizedString(@"My Hobbies/Interests", @"Placeholder for Hobby title");
            break;
        case CLInterestDescriptionIndex:
            return NSLocalizedString(@"Description", @"Placeholder for Description field");
            break;
            
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLInterestDescriptionIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else{
        return 44;
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==CLInterestTitleIndex) {
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        
        return sectionFooter;
    }
    else{
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section==CLInterestTitleIndex) {
        return 44;
    }
    else{
        return 0;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section==CLInterestTitleIndex){
        return YES;
    }
    else{
        return NO;
    }
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if(indexPath.section==CLInterestTitleIndex){
            [self.selectedInterestArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.selectedInterestArray count]==0){
                [self.tableView reloadData];
            }
            else{
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLInterestTitleIndex:{
            break;
        }
        case CLInterestDescriptionIndex:
            self.descriptionText=text;
            break;
        default:
            break;
    }
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Interests modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveInterestAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Interests modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddInterestAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Interests modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Hobby Name validation..
    if ([self.selectedInterestArray count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Hobby/Interest.", @"Error Message for null title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(void)saveInterestForEdit:(BOOL)isEditMode{
    CLInterestObject *newIntObj=[[CLInterestObject alloc] init];
    if (isEditMode) {
        newIntObj.interestId=self.interestObj.interestId;
    }
    else{
        newIntObj.interestId=nil;
    }
    newIntObj.interestArray=self.selectedInterestArray;
    newIntObj.interestDescription=self.descriptionText;
    [newIntObj updateFormattedHobbyTitle];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
     self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLInterestObject saveInterest:newIntObj ForUser:[CLUserObject currentUser].userID editMode:isEditMode
                                  success:^(NSString *interestId){
                                      if (isEditMode) {
                                          self.interestObj.interestArray=self.selectedInterestArray;
                                          self.interestObj.interestDescription=self.descriptionText;
                                          [self.interestObj updateFormattedHobbyTitle];
                                      }
                                      else{
                                          newIntObj.interestId=interestId;
                                          self.interestObj=newIntObj;
                                      }
                                      
                                      [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                                  }
                                  failure:^(NSString *error){
                                      if (![error isEqualToString:@""]) {
                                           self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                          self.navigationItem.rightBarButtonItem.enabled=YES;
                                          [progressHUD hideWithAnimation:YES];
                                          [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Hobby details. Please try again later.", @"Error message when website cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                      }
                                  }];
}


#pragma mark IBActions

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    CLSelectHobbyViewController *selectLocation=[[CLSelectHobbyViewController alloc] initWithStyle:UITableViewStyleGrouped];
    selectLocation.alreadySelectedHobbies=self.selectedInterestArray;
    selectLocation.delegate=self;
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
    [self presentViewController:nav animated:YES completion:nil];
}

-(IBAction)bttnActionSaveInterestAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveInterestForEdit:YES];
    }
}

-(IBAction)bttnActionAddInterestAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveInterestForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark CLSelectHobbyDelegate

- (void)hobbyController:(CLSelectHobbyViewController *)controller didSelectHobby:(NSMutableDictionary *)hobbyDict{
    [self.selectedInterestArray addObject:hobbyDict];
    if ([self.selectedInterestArray count]==1) {
        [self.tableView reloadData];
    }
    else{
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLInterestTitleIndex] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(interestController:didAddInterest:)]){
                [self.delegate interestController:self didAddInterest:self.interestObj];
            }
        }];
    }
}

@end
