//
//  CLCollectionProfilePhotoCell.m
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCollectionProfilePhotoCell.h"
#import "UIImageView+WebCache.h"

@interface CLCollectionProfilePhotoCell()

@property (weak, nonatomic) IBOutlet UIImageView *photoImgView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rightBorderConstant;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topBorderConstant;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomBorderConstant;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftBorderConstant;

@end

@implementation CLCollectionProfilePhotoCell

-(void)awakeFromNib
{
    self.contentView.frame = self.bounds;
    self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLCollectionProfilePhotoCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        self.placeHolderImageName=@"company_placeholder";
        [self.activityIndicator setColor:[CLCommon sharedInstance].currentTrafficLightColor];
    }
    return self;
}

-(void)updateActivityIndicatorColor{
    [self.activityIndicator setColor:[CLCommon sharedInstance].currentTrafficLightColor];
}

-(void)setWhiteBorderWidth:(int)borderWidth{
    self.rightBorderConstant.constant=borderWidth;
    self.leftBorderConstant.constant=borderWidth;
    self.topBorderConstant.constant=borderWidth;
    self.bottomBorderConstant.constant=borderWidth;
    [self updateConstraints];
}

-(void)setCellImageWithUrl:(NSString*)imageUrl{
//    self.photoImgView.image=[UIImage imageNamed:self.placeHolderImageName];
//    [self.activityIndicator setColor:[CLCommon sharedInstance].currentTrafficLightColor];
//    [self.activityIndicator startAnimating];
//    [[SDWebImageManager sharedManager] downloadWithURL:[NSURL URLWithString:[imageUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] options:SDWebImageRetryFailed progress:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished) {
//        [self.activityIndicator stopAnimating];
//        if (!error) {
//            if (image) {
//                self.photoImgView.image=image;
//                if (cacheType == SDImageCacheTypeNone) {
//                    self.alpha=0.0;
//                    [UIView animateWithDuration:1.0
//                                     animations:^{
//                                         self.alpha = 1.0;
//                                     }];
//                }
//                
//            }
//        }
//        else{
//            self.photoImgView.image=[UIImage imageNamed:self.placeHolderImageName];
//            NSLog(@"dp load error=%@\nurl=%@",error.localizedDescription,[imageUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]);
//        }
//    }];
    
    
    
    
    [self.activityIndicator startAnimating];
//    [self.photoImgView setImageWithURL:[NSURL URLWithString:[imageUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:self.placeHolderImageName] options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType) {
//        [self.activityIndicator stopAnimating];
//        if (image && cacheType == SDImageCacheTypeNone)
//        {
//            self.photoImgView.alpha = 0.0;
//            [UIView animateWithDuration:1.0
//                             animations:^{
//                                 self.photoImgView.alpha = 1.0;
//                             }];
//        }
//    }];
    
    [self.photoImgView sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[UIImage imageNamed:self.placeHolderImageName] options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [self.activityIndicator stopAnimating];
        if (image && cacheType == SDImageCacheTypeNone)
        {
            self.photoImgView.alpha = 0.0;
            [UIView animateWithDuration:1.0
                             animations:^{
                                 self.photoImgView.alpha = 1.0;
                             }];
        }    }];
    //old one with percentage encoding
//    [self.photoImgView sd_setImageWithURL:[NSURL URLWithString:[imageUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:self.placeHolderImageName] options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
//        [self.activityIndicator stopAnimating];
//        if (image && cacheType == SDImageCacheTypeNone)
//        {
//            self.photoImgView.alpha = 0.0;
//            [UIView animateWithDuration:1.0
//                             animations:^{
//                                 self.photoImgView.alpha = 1.0;
//                             }];
//        }    }];
    
//    [self.photoImgView setImageWithURL:[NSURL URLWithString:[imageUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]]
//                      placeholderImage:[UIImage imageNamed:self.placeHolderImageName]
//                             completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//                                 [self.activityIndicator stopAnimating];
//                                 if (image && cacheType == SDImageCacheTypeNone)
//                                 {
//                                     self.photoImgView.alpha = 0.0;
//                                     [UIView animateWithDuration:1.0
//                                                      animations:^{
//                                                          self.photoImgView.alpha = 1.0;
//                                                      }];
//                                 }
//                             }];
}

@end
