//
//  CLKnowledgeDetailsPage.m
//  CareerLine
//
//  Created by Abbin on 20/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLKnowledgeDetailsPage.h"
#import "CLKnowledgeDetailObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "UIImageView+WebCache.h"
#import "CLLoaderImageVIew.h"
#import "CLKnowledgeObject.h"

@interface CLKnowledgeDetailsPage ()

@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (nonatomic,retain) CLKnowledgeDetailObject *detailObj;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *bookmarks;
@property (weak, nonatomic) IBOutlet UIButton *likes;
@property (weak, nonatomic) IBOutlet UILabel *numberOfLikes;
@property (weak, nonatomic) IBOutlet UILabel *summary;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *mainImage;
@property (weak, nonatomic) IBOutlet UILabel *type;
@property (weak, nonatomic) IBOutlet UILabel *subType;
@property (weak, nonatomic) IBOutlet UITextView *discription;
@property (weak, nonatomic) IBOutlet UILabel *fileURL;
@property (weak, nonatomic) IBOutlet UILabel *author;
@property (weak, nonatomic) IBOutlet UILabel *URL;
@property (weak, nonatomic) IBOutlet UILabel *published;
@property (weak, nonatomic) IBOutlet UILabel *edition;
@property (weak, nonatomic) IBOutlet UILabel *volume;
@property (weak, nonatomic) IBOutlet UILabel *isbnTen;
@property (weak, nonatomic) IBOutlet UILabel *isbnThirteen;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *file;
@property (weak, nonatomic) IBOutlet UILabel *authorTopHeading;



@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightOfContentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titileTextHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *summeryHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *typeHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *discriptionHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *urlHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *authorHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *authorUrlHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *publishedHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *editionHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *volumeHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *isbnTenHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *isbnThirteenHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *subtypeHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mainImageHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mainImageWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondImageWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondImageHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topAuthorHeight;


@end

@implementation CLKnowledgeDetailsPage

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Article", @"heading for knowload detail page");
    [self getknowledgeDetail];
    self.contentView.hidden = YES;
    self.file.hidden = YES;
    
    self.discription.clipsToBounds = YES;
    self.discription.layer.cornerRadius = 10.0f;
    
    self.titleLabel.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    self.heightOfContentView.constant = 1153;
    // Do any additional setup after loading the view from its nib.
     [self.navigationController setToolbarHidden:YES];
    
    self.discription.layer.borderWidth = 1.0f;
    self.discription.layer.borderColor = [[UIColor grayColor] CGColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Wake Details"];
}

-(void)getknowledgeDetail{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading WAKE...", @"Text displayed in the loading indicator while loading documents");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [self.activityIndicator showInView:self.view];
    
    [CLKnowledgeDetailObject getknowledgeDetailForUser:[CLUserObject currentUser].userID andKnowledgeID:self.knowledgeRecId type:self.ktype success:^(CLKnowledgeDetailObject *detailObj){
        self.detailObj = detailObj;
        [self setHeightToTheFields];
        [self setValuesToOutLets];
        self.contentView.hidden = NO;
        [self.activityIndicator hideWithAnimation:YES];
        
        
    }failure:^(NSString *error){
        [self.activityIndicator hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Failed to load Article", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        
    }];
}

-(void)setValuesToOutLets{
    self.titleLabel.text = self.detailObj.title;
    if (self.detailObj.bookmarks) {
        [self.bookmarks setBackgroundImage:[UIImage imageNamed:@"bookmarked.png"] forState:UIControlStateNormal];
    }
    else{
        [self.bookmarks setBackgroundImage:[UIImage imageNamed:@"bookmark.png"] forState:UIControlStateNormal];
    }
    [self.likes setBackgroundImage:[UIImage imageNamed:@"like.png"] forState:UIControlStateNormal];
    if (self.detailObj.isLiked) {
        self.likes.userInteractionEnabled = NO;
        [self.likes setAlpha:0.4];
    }
    else{
        self.likes.userInteractionEnabled = YES;
        [self.likes setAlpha:1];
    }
    self.numberOfLikes.text = self.detailObj.likes;
    self.summary.text = self.detailObj.summary;
    
    [self.mainImage setImageWithUrlString:[NSString stringWithFormat:@"%@",self.detailObj.imageURL] andPlaceHolderName:@"documentPlaceHolder.png"];
    
    self.mainImage.clipsToBounds = YES;
    self.mainImage.contentMode = UIViewContentModeScaleAspectFit;
    
    self.type.text = self.detailObj.type;
//    self.subType.text = self.detailObj.subType;
    
    NSAttributedString *attributedString = [[NSAttributedString alloc] initWithData:[self.detailObj.discription dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    self.discription.attributedText = attributedString;
    
    
//    self.discription.attributedText =  [[NSAttributedString alloc]
//                                        initWithData: [self.detailObj.discription dataUsingEncoding:NSUTF8StringEncoding]
//                                        options: @{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType }
//                                        documentAttributes: nil
//                                        error:nil];
    
    self.fileURL.text = @"Click To Read More";
    if (self.detailObj.author && self.detailObj.author.count>0){
        self.authorTopHeading.text = [[self.detailObj.author objectAtIndex:0]objectForKey:@"author"] ;
        self.author.text = @"Author/Owner";//[[self.detailObj.author objectAtIndex:0]objectForKey:@"url"] ;
        self.URL.text = self.detailObj.PublicationDate;
    }
    else{
        self.author.text = @"" ;
        self.URL.text = @"";
    }
    
    self.published.text = self.detailObj.published;
    self.edition.text = self.detailObj.edition;
    self.volume.text = self.detailObj.volume;
    self.isbnTen.text = self.detailObj.isbnTen;
    self.isbnThirteen.text = self.detailObj.isbnThirteen;
    if (![self.detailObj.fileUrl isEqualToString:@""]) {
        self.file.hidden = NO;
        [self.file setImageWithUrlString:self.detailObj.fileUrl andPlaceHolderName:@"documentPlaceHolder.png"];
    }
    
}

-(float)getHeightForLabelForText:(NSString*)text :(UILabel*)label :(BOOL)forDiscription{
    NSAttributedString *attributedText = nil;
    if (forDiscription) {
       attributedText = [[NSAttributedString alloc] initWithString:text];
    }
    else{
       attributedText = [[NSAttributedString alloc] initWithString:text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    }

    CGRect rect = [attributedText boundingRectWithSize:(CGSize){label.frame.size.width, CGFLOAT_MAX}
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    return rect.size.height;
}

-(float)getHeightForTextViewForText:(NSString*)text :(UITextView*)textView :(BOOL)forDiscription{
    
    NSAttributedString *attr = [[NSAttributedString alloc] initWithData:[text dataUsingEncoding:NSUTF8StringEncoding]
                                                                options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                          NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                                     documentAttributes:nil
                                                                  error:nil];
    
    CGRect rect = [attr boundingRectWithSize:(CGSize){textView.frame.size.width, CGFLOAT_MAX}
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    return MIN(rect.size.height + 15, 400);;
}

-(void)setHeightToTheFields{
    self.titileTextHeight.constant = [self getHeightForLabelForText:self.detailObj.title :self.titleLabel :NO];
    self.summeryHeight.constant = [self getHeightForLabelForText:self.detailObj.summary :self.summary :NO];
    self.typeHeight.constant = 0;//[self getHeightForLabelForText:self.detailObj.type :self.type :NO];
    self.subtypeHeight.constant = 0;//[self getHeightForLabelForText:self.detailObj.subType :self.subType :NO];
    self.discriptionHeight.constant = [self getHeightForTextViewForText:[NSString stringWithFormat:@"%@", self.detailObj.discription] :self.discription :YES];
    self.urlHeight.constant = [self getHeightForLabelForText:@"Click To Read More" :self.fileURL :NO];
    if (self.detailObj.author && self.detailObj.author.count>0) {
        self.topAuthorHeight.constant = [self getHeightForLabelForText:[[self.detailObj.author objectAtIndex:0] objectForKey:@"author"] :self.author :NO];
        self.authorHeight.constant = [self getHeightForLabelForText:[[self.detailObj.author objectAtIndex:0] objectForKey:@"url"]  :self.URL :NO];//[self getHeightForLabelForText:[[self.detailObj.author objectAtIndex:0] objectForKey:@"author"] :self.author :NO];
        self.authorUrlHeight.constant = [self getHeightForLabelForText:self.detailObj.PublicationDate  :self.URL :NO];//[self getHeightForLabelForText:[[self.detailObj.author objectAtIndex:0] objectForKey:@"url"]  :self.URL :NO];
    }
    else{
        self.authorHeight.constant = 0;
        self.authorUrlHeight.constant = 0;
    }
    
    
    if (self.detailObj.published) {
        self.publishedHeight.constant = [self getHeightForLabelForText:self.detailObj.published :self.published :NO];
    }
    else{
        self.publishedHeight.constant = 0;
    }
    if (self.detailObj.edition) {
        self.editionHeight.constant = [self getHeightForLabelForText:self.detailObj.edition :self.edition :NO];
    }
    else{
        self.editionHeight.constant = 0;
    }
    if (self.detailObj.volume) {
        self.volumeHeight.constant = [self getHeightForLabelForText:self.detailObj.volume :self.volume :NO];
    }
    else{
        self.volumeHeight.constant =0;
    }
    if (self.detailObj.isbnTen) {
        self.isbnTenHeight.constant = [self getHeightForLabelForText:self.detailObj.isbnTen :self.isbnTen :NO];
    }
    else{
        self.isbnTenHeight.constant =0;
    }
    if (self.detailObj.isbnThirteen) {
        self.isbnThirteenHeight.constant = [self getHeightForLabelForText:self.detailObj.isbnThirteen :self.isbnThirteen :NO];
    }
    else{
        self.isbnThirteenHeight.constant = 0;
    }
    
    //[self setHeightOfImageView];
    
    [self setcontentViewInScrollView];
    
}

-(void)setHeightOfImageView{
    self.mainImageHeight.constant = [self.detailObj.mainImageHeight floatValue]/[self.detailObj.mainImageWidth floatValue]*240;
    if (self.detailObj.secondImageHeight && self.detailObj.secondImageWidth) {
        self.secondImageHeight.constant = [self.detailObj.secondImageHeight floatValue]/[self.detailObj.secondImageWidth floatValue]*128;
    }
    
}

-(void)setcontentViewInScrollView{
    
    self.heightOfContentView.constant = self.titileTextHeight.constant + self.summeryHeight.constant + self.typeHeight.constant + self.subtypeHeight.constant + self.discriptionHeight.constant + self.urlHeight.constant + self.authorHeight.constant + self.authorUrlHeight.constant + self.publishedHeight.constant + self.editionHeight.constant + self.volumeHeight.constant + self.isbnTenHeight.constant + self.isbnThirteenHeight.constant + self.mainImageHeight.constant + self.secondImageHeight.constant;
    
    self.scrollview.contentSize = self.contentView.bounds.size;
    
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}


- (IBAction)bookMarkButtonClicked:(UIButton *)sender {
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Bookmark...", @"Text displayed in the loading indicator while bookmarking");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:SharedAppDelegate.window];
    
    [CLKnowledgeObject bookMarkKnowledgeforUser:self.knowledgeRecId type:self.ktype success:^{
        if (self.detailObj.bookmarks) {
            self.detailObj.bookmarks = NO;
            [self.bookmarks setBackgroundImage:[UIImage imageNamed:@"bookmark.png"] forState:UIControlStateNormal];
            
            
        }
        else{
            self.detailObj.bookmarks = YES;
            [self.bookmarks setBackgroundImage:[UIImage imageNamed:@"bookmarked.png"] forState:UIControlStateNormal];
        }
        
        [progressHUD hideWithAnimation:YES];
        
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
    }];
}
- (IBAction)likeButtonClicked:(UIButton *)sender {
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Bookmark...", @"Text displayed in the loading indicator while bookmarking");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:SharedAppDelegate.window];
    
    [CLKnowledgeObject likeKnowledge:self.detailObj.knowledgeID forUser:[CLUserObject currentUser].userID type:self.ktype success:^{
        if (!self.detailObj.isLiked) {
            self.detailObj.isLiked = YES;
            self.likes.userInteractionEnabled = NO;
            [self.likes setAlpha:0.4];
            long likes = [self.detailObj.likes integerValue];
            self.numberOfLikes.text = [NSString stringWithFormat:@"%ld",++likes];
        }
        [progressHUD hideWithAnimation:YES];
        
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
    }];
}
- (IBAction)urlLabelTapped:(UITapGestureRecognizer *)sender {
    
    if (self.detailObj.orgUrl) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.detailObj.orgUrl]];
    }
    
}
- (IBAction)authorurlClicked:(UITapGestureRecognizer *)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[[self.detailObj.author objectAtIndex:0]objectForKey:@"url"]]];
}

@end
