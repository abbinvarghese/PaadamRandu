//
//  CLKnowledgeViewCell.m
//  CareerLine
//
//  Created by RENJITH on 19/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLKnowledgeViewCell.h"
#import "UIImageView+WebCache.h"
#import "CLLoaderImageVIew.h"
#import "CLKnowledgeObject.h"
#import "CLMsgDisplayView.h"

@interface CLKnowledgeViewCell()

@property (weak, nonatomic) IBOutlet UILabel *fileTilename;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *tileImageView;
@property (weak, nonatomic) IBOutlet UILabel *typeName;
@property (weak, nonatomic) IBOutlet UILabel *subTypeName;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelOneHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelTwoHeight;
@property (strong, nonatomic) CLMsgDisplayView *msgDisplay;

- (IBAction)likeBtnAction:(id)sender;
- (IBAction)bookmarkBtnAction:(id)sender;

@end
@implementation CLKnowledgeViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLKnowledgeViewCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        self = [arrayOfViews objectAtIndex:0];
        
    }
    
    return self;
    
}


-(void)updateContentsForIndexPath:(NSIndexPath*)indexPath
{
    float result;
    NSString *newsCompanyName, *lableTwo;
    
    if (indexPath.row == 11)
    {
        
    }
    
    NSLog(@"%f %f",[self.knowledgeObj.imgWidth floatValue],[self.knowledgeObj.imgHeight floatValue]);
    if (self.knowledgeObj.imgHeight == 0 || self.knowledgeObj.imgWidth == 0) {
        result=0;
    }
    else
    {
        float height=[self.knowledgeObj.imgHeight floatValue];
        float width = [self.knowledgeObj.imgWidth floatValue];
        
        result=height/width*158;
//        result=95;
        
    }
    
    self.imageHeight.constant=result;
    NSLog(@"Title - %@", self.fileTilename.text);
    
    self.fileTilename.text = self.knowledgeObj.title;
    self.likeLbl.text = [NSString stringWithFormat:@"%@",self.knowledgeObj.likeCount];
    self.fileTilename.textColor =[CLCommon sharedInstance].currentTrafficLightColor;
    if (self.knowledgeObj.isBookMarked) {
        [self.bookmarkBtn setBackgroundImage:[UIImage imageNamed:@"bookmarked.png"] forState:UIControlStateNormal];
    }else{
        [self.bookmarkBtn setBackgroundImage:[UIImage imageNamed:@"bookmark.png"] forState:UIControlStateNormal];
    }
    if (self.knowledgeObj.isLiked)
    {
        UIImage *buttonImg = [UIImage imageNamed:@"like.png"];
        UIImage *btnImage = [CLCommon filledImageFrom:buttonImg withColor:[UIColor lightGrayColor]];
        [self.likeBtn setImage:btnImage forState:UIControlStateNormal];
    }
    else
    {
        UIImage *buttonImg = [UIImage imageNamed:@"like.png"];
        [self.likeBtn setImage:buttonImg forState:UIControlStateNormal];

        self.likeBtn.enabled = YES;
    }

    if ([self.knowledgeObj.type isEqualToString:@"W"]) {
        newsCompanyName = self.knowledgeObj.author;
        lableTwo = self.knowledgeObj.publishedCreated;
    }
    else if ([self.knowledgeObj.type isEqualToString:@"E"]){
        newsCompanyName =self.knowledgeObj.location;
        lableTwo=self.knowledgeObj.eventDate;
    }
    else if ([self.knowledgeObj.type isEqualToString:@"O"]){
        newsCompanyName=self.knowledgeObj.companyName;
        lableTwo=self.knowledgeObj.author;
    }
    else if ([self.knowledgeObj.type isEqualToString:@"V"]){
        newsCompanyName = self.knowledgeObj.companyName;
        lableTwo=[NSString stringWithFormat:@"%@, %@",self.knowledgeObj.location, self.knowledgeObj.eventDate];
    }
    else if ([self.knowledgeObj.type isEqualToString:@"K"]){
        newsCompanyName = [NSString stringWithFormat:@"%@, %@",self.knowledgeObj.author,self.knowledgeObj.companyName];
        lableTwo=self.knowledgeObj.dateCreated;
    }
    else if ([self.knowledgeObj.type isEqualToString:@"R"]){
        newsCompanyName = self.knowledgeObj.author;
        lableTwo = self.knowledgeObj.publishedCreated;
    }
    
    NSString *textString = @"";
    if([CLCommon trimWhiteSpaces:self.fileTilename.text].length && [CLCommon trimWhiteSpaces:newsCompanyName].length && [CLCommon trimWhiteSpaces:lableTwo].length)
    {
        textString = [NSString stringWithFormat:@"%@\n\n%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:self.fileTilename.text],[CLCommon trimWhiteSpaces:newsCompanyName], [CLCommon trimWhiteSpaces:lableTwo]];
    }
    else if([CLCommon trimWhiteSpaces:self.fileTilename.text].length != 0 && [CLCommon trimWhiteSpaces:newsCompanyName].length == 0 && [CLCommon trimWhiteSpaces:lableTwo].length != 0)
    {
        textString = [NSString stringWithFormat:@"%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:self.fileTilename.text], [CLCommon trimWhiteSpaces:lableTwo]];
    }
    else if([CLCommon trimWhiteSpaces:self.fileTilename.text].length != 0 && [CLCommon trimWhiteSpaces:newsCompanyName].length != 0 && [CLCommon trimWhiteSpaces:lableTwo].length == 0)
    {
        textString = [NSString stringWithFormat:@"%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:self.fileTilename.text],[CLCommon trimWhiteSpaces:newsCompanyName]];
    }
    
    if([CLCommon trimWhiteSpaces:textString].length)
    {
        NSMutableAttributedString *attrString = nil;
        UIFont *font = HELVETICA_NEUE_BOLD_FONT_WITH_SIZE(12.0);
        
        attrString = [[NSMutableAttributedString alloc] initWithString:textString ];
        
        if([CLCommon trimWhiteSpaces:self.fileTilename.text].length)
        {
            NSRange titleRange	= [textString  rangeOfString:[CLCommon trimWhiteSpaces:self.fileTilename.text] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:titleRange];
            [attrString addAttribute:NSForegroundColorAttributeName value:[CLCommon sharedInstance].currentTrafficLightColor range:titleRange];
        }
        
        font = HELVETICA_NEUE_REGULAR_FONT_WITH_SIZE(11.0);
        
        if([CLCommon trimWhiteSpaces:newsCompanyName].length)
        {
            NSRange newComRange	= [textString rangeOfString:[CLCommon trimWhiteSpaces:newsCompanyName] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:newComRange];
            [attrString addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:newComRange];
        }
        
        if([CLCommon trimWhiteSpaces:lableTwo].length)
        {
            NSRange lbl2Range	= [textString rangeOfString:[CLCommon trimWhiteSpaces:lableTwo] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:lbl2Range];
            [attrString addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:lbl2Range];
        }
        
        self.fileTilename.attributedText = attrString;
    }
    else
        self.fileTilename.text = @"";
    
    [self.tileImageView setImageWithUrlString:self.knowledgeObj.imgUrl andPlaceHolderName:@"company_placeholder@2x.png"];
}

- (IBAction)likeBtnAction:(id)sender {
    
    if (self.knowledgeObj.isLiked)
    {
        if(self.msgDisplay == nil)
        {
            self.msgDisplay = [[CLMsgDisplayView alloc] initWithFrame:CGRectMake(100, 300, 100, 60)];
            self.msgDisplay.displayMsg = NSLocalizedString(@"Item already liked", @"Text displayed");
            [self.msgDisplay showInView:SharedAppDelegate.window];
            [self performSelector:@selector(hideMsgDisplay) withObject:nil afterDelay:2.0f];
        }
    }
    else
    {
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellLikeKnowledge:)]){
            [self.delegate cellLikeKnowledge:self];
        }
    }
}

- (IBAction)bookmarkBtnAction:(id)sender {
    
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellBookmarkKnowledge:)]){
        [self.delegate cellBookmarkKnowledge:self];
    }
}

- (void)hideMsgDisplay
{
    [self.msgDisplay hide];
    self.msgDisplay = nil;
}

@end
