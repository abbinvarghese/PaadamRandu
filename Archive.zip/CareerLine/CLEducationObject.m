//
//  CLEducation.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEducationObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 1

@implementation CLEducationObject

static NSOperationQueue *saveEducationRequest;




- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.educationId = [dictionary objectForKeyNotNull:kCLQlfitnEducationIdkey];
    self.course = [dictionary objectForKeyNotNull:kCLQlfitnEducationCoursekey];
    self.specialization = [dictionary objectForKeyNotNull:kCLQlfitnEducationSpecializationkey];
    self.institution = [dictionary objectForKeyNotNull:kCLQlfitnEducationInstitutionkey];
    self.location = [[CLLocationObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLQlfitnEducationLocationkey]];
//    [self.location setValue:[[dictionary objectForKeyNotNull:@"Country"] objectForKey:@"countryCode"] forKey:@"countryCode"];
//    [self.location setValue:[[dictionary objectForKeyNotNull:@"Country"] objectForKey:@"country"] forKey:@"countryName"];
    self.isOngoing = [[dictionary objectForKeyNotNull:kCLQlfitnEducationIsOngoingkey] boolValue];
    
    NSString *toDateStr = [dictionary objectForKeyNotNull:kCLQlfitnEducationToDatekey];
    NSString *fromDateStr = [dictionary objectForKeyNotNull:kCLQlfitnEducationFromDatekey];
    
    NSMutableString *startDateStr = [[NSMutableString alloc]init];
    NSArray *startDateArray = [fromDateStr componentsSeparatedByString:@"-"];
    if (![fromDateStr isEqualToString:@""]) {
        if ([startDateArray count]>0) {
            if ([[startDateArray objectAtIndex:0] isEqualToString:@""] ) {
                [startDateStr appendString:@"01"];
                [startDateStr appendString:@"-"];
                [startDateStr appendString:[NSString stringWithFormat:@"%@",[startDateArray objectAtIndex:1]]];
                [startDateStr appendString:@"-"];
                [startDateStr appendString:[NSString stringWithFormat:@"%@",[startDateArray objectAtIndex:2]]];
                self.fromDate = [CLCommon getDateForString:startDateStr andFormat:@"dd-MM-yyyy"];
            }else{
                self.fromDate = [CLCommon getDateForString:fromDateStr andFormat:@"dd-MM-yyyy"];
            }
        }
    }

   // if (!self.isOngoing) {
  
         if (![toDateStr isEqualToString:@""]) {
    NSMutableString *completionDateStr = [[NSMutableString alloc]init];
    NSArray *endDateArray = [toDateStr componentsSeparatedByString:@"-"];
    if ([[endDateArray objectAtIndex:0] isEqualToString:@""]) {
        [completionDateStr appendString:@"01"];
        [completionDateStr appendString:@"-"];
        [completionDateStr appendString:[endDateArray objectAtIndex:1]];
        [completionDateStr appendString:@"-"];
        [completionDateStr appendString:[endDateArray objectAtIndex:2]];
        
        self.completionDate = [CLCommon getDateForString:completionDateStr andFormat:@"dd-MM-yyyy"];
    }else{
        self.completionDate = [CLCommon getDateForString:toDateStr andFormat:@"dd-MM-yyyy"];
    }
         }
   // }
   
    self.educationLevel = [[dictionary objectForKeyNotNull:kCLQlfitnEducationLevelkey] objectForKeyNotNull:kCLQlfitnEducationLevelDesckey];
    self.educationLevelId = [[dictionary objectForKeyNotNull:kCLQlfitnEducationLevelkey] objectForKeyNotNull:kCLQlfitnEducationLevelIdkey];
    self.ratingType = [dictionary objectForKeyNotNull:kCLQlfitnEducationRatingTypekey];
    //self.ratingTypeCode = [[dictionary objectForKeyNotNull:kCLQlfitnEducationRatingTypekey] objectForKeyNotNull:kCLQlfitnEducationRatingTypeCodekey];
    //self.rating = [dictionary objectForKeyNotNull:kCLQlfitnEducationRatingkey];
    self.descption = [dictionary objectForKeyNotNull:kCLQlfitnEducationDescptionkey];
   
    self.documentsUrl=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLQlfitnEducationDocumentsUrlkey];
    for (int i=0; i<[files count]; i++) {
        [self.documentsUrl addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    return self;
}

//Method for saving education of a particular user...
+ (void)saveEducation:(CLEducationObject*)educationObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *eduId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *eduId){};
    }
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": educationObj.educationId, @"fields":[CLEducationObject jsonStringForObject:educationObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLEducationObject jsonStringForObject:educationObj]};
    }
    
    
    [saveEducationRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveEducationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceEducationSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveEducationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLQlfitnEducationIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(NSString*)jsonStringForObject:(CLEducationObject*)eduObj{
    NSMutableDictionary *educationDict=[[NSMutableDictionary alloc] init];

    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    
     [insideDict setObject:eduObj.institution forKey:kCLQlfitnEducationInstitutionkey];
     [insideDict setObject:eduObj.course forKey:kCLQlfitnEducationCoursekey];
     [insideDict setObject:eduObj.specialization forKey:kCLQlfitnEducationSpecializationkey];    
    
    if (eduObj.location) {
        if (eduObj.location.locationCode !=nil) {
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:eduObj.location.locationCode forKey:kCLQlfitnEducationLocationCodekey];
            [locationDict setObject:eduObj.location.countryCode forKey:kCLQlfitnEducationLocationCountrykey];
            [insideDict setObject:locationDict forKey:kCLQlfitnEducationLocationkey];
        }
        else if(eduObj.location.countryCode != nil){
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:eduObj.location.countryCode forKey:kCLQlfitnEducationLocationCountrykey];
            [insideDict setObject:locationDict forKey:kCLQlfitnEducationLocationkey];
        }
   
    }
    if (eduObj.educationLevel) {
        NSMutableDictionary *educationLevelDict=[[NSMutableDictionary alloc] init];
        [educationLevelDict setObject:eduObj.educationLevelId forKey:kCLQlfitnEducationLevelIdkey];
        [educationLevelDict setObject:eduObj.educationLevel forKey:kCLQlfitnEducationLevelDesckey];
        [insideDict setObject:educationLevelDict forKey:kCLQlfitnEducationLevelkey];
    }
    //if (eduObj.ratingType) {
       // NSMutableDictionary *ratingDict=[[NSMutableDictionary alloc] init];
       // [ratingDict setObject:eduObj.ratingType forKey:kCLQlfitnEducationRatingTypeDesckey];
        //[ratingDict setObject:eduObj.ratingTypeCode forKey:kCLQlfitnEducationRatingTypeCodekey];
        [insideDict setObject:eduObj.ratingType forKey:kCLQlfitnEducationRatingTypekey];
  //  }
    if (eduObj.isOngoing) {
        [insideDict setObject:@"1" forKey:kCLQlfitnEducationIsOngoingkey];
    }else{
        [insideDict setObject:@"0" forKey:kCLQlfitnEducationIsOngoingkey];
    }
//    if (eduObj.rating) {
//         [insideDict setObject:eduObj.rating forKey:kCLQlfitnEducationRatingkey];
//    }
    if (eduObj.descption) {
        [insideDict setObject:eduObj.descption forKey:kCLQlfitnEducationDescptionkey];
    }
    if (eduObj.fromDate) {
        [insideDict setObject:[CLCommon getStringForDate:eduObj.fromDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnEducationFromDatekey];
    }
   
    if (eduObj.completionDate) {
         [insideDict setObject:[CLCommon getStringForDate:eduObj.completionDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnEducationToDatekey];
    }
    [educationDict setObject:insideDict forKey:kCLQlfitnEducationkey];
    NSLog(@"%@",[CLCommon jsonStringWithPrettyPrint:NO foDict:educationDict]);
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:educationDict];
}
@end
