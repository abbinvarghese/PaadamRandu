//
//  CLInboxObject.m
//  CareerLine
//
//  Created by CSG on 3/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxObject.h"
#import "AFHTTPRequestOperationManager.h"
#import "NSDictionary+Additions.h"
#import "CLQuestionnaireObject.h"

#define kDebugMessages 1

@implementation CLInboxObject

static NSOperationQueue *inboxListingRequest;
static NSOperationQueue *inboxDetailsRequest;
static NSOperationQueue *postReplyRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.inboxJob=[[CLJobsObject alloc] init];
    self.inboxJob.companyDetails=[[CLCompanyObject alloc] init];
    self.inboxId=[dictionary objectForKeyNotNull:kCLInboxListId];
    self.inboxEntryDate=[dictionary objectForKeyNotNull:kCLInboxListMsgTimekey];
    self.inboxThreadReadStatus=[[dictionary objectForKeyNotNull:kCLInboxListMailUnreadStatuskey] intValue];
    self.inboxJob.jobID = [dictionary objectForKeyNotNull:kCLInboxListjobIDkey];
    self.inboxJob.jobTitle = [dictionary objectForKeyNotNull:kCLInboxListjobTitlekey];
    self.inboxJob.companyDetails.companyName = [dictionary objectForKeyNotNull:kCLInboxListjobCompanykey];
    self.inboxJob.companyDetails.companyLogoUrl = [dictionary objectForKeyNotNull:kCLInboxListjobIconUrlkey];
    
    NSString *lastMsgHtml=[dictionary objectForKeyNotNull:kCLInboxListLastMsgkey];
    if (lastMsgHtml) {
        NSMutableString *htmlString=[[[NSAttributedString alloc] initWithData:[lastMsgHtml dataUsingEncoding:NSUTF8StringEncoding]
                                                                      options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                NSCharacterEncodingDocumentAttribute: [NSNumber numberWithInt:NSUTF8StringEncoding]}
                                                           documentAttributes:nil error:nil].string mutableCopy];
        [htmlString replaceOccurrencesOfString:@"\n" withString:@" " options:NSCaseInsensitiveSearch range:NSMakeRange(0, htmlString.length)];
        self.inboxLastMsg=htmlString;
    }
    else{
        self.inboxLastMsg=lastMsgHtml;
    }
    
    return self;
}


- (id)initInboxDetailsWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.inboxJob=[[CLJobsObject alloc] init];
    self.inboxJob.companyDetails=[[CLCompanyObject alloc] init];
    self.inboxId=[dictionary objectForKeyNotNull:kCLInboxDetailIdkey];
    self.inboxThreadReadStatus=[[dictionary objectForKeyNotNull:kCLInboxListMailUnreadStatuskey] intValue];
    self.inboxJob.jobID = [dictionary objectForKeyNotNull:kCLInboxDetailjobIDkey];
    self.inboxJob.jobTitle = [dictionary objectForKeyNotNull:kCLInboxDetailjobTitlekey];
    self.inboxJob.companyDetails.companyName = [dictionary objectForKeyNotNull:kCLInboxDetailjobCompanykey];
    self.inboxJob.companyDetails.companyLogoUrl = [dictionary objectForKeyNotNull:kCLInboxDetailjobIconUrlkey];
    self.questionnaireDueDate=[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnnaireDueDatekey];
    if ([dictionary objectForKeyNotNull:kCLInboxDetailQuestionnnairePresentkey]) {
        self.isQuestionnairePresent=[[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnnairePresentkey] intValue];
    }
    if ([dictionary objectForKeyNotNull:kCLInboxDetailQuestionnnaireSubmittedkey]) {
        self.isQuestionnaireSubmitted=[[dictionary objectForKeyNotNull:kCLInboxDetailQuestionnnaireSubmittedkey] intValue];
    }
    
    //Msgs array converting html to attributed text..
    NSMutableArray *arr=[[dictionary objectForKeyNotNull:@"mails"] mutableCopy];
    NSMutableDictionary *dict=nil;
    NSAttributedString *attStr=nil;
    for (int i=0; i<[arr count]; i++) {
        dict=[[arr objectAtIndex:i] mutableCopy];
        attStr=[[NSAttributedString alloc] initWithData:[[dict objectForKey:kCLInboxDetailMsgTextkey] dataUsingEncoding:NSUTF8StringEncoding]
                                         options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                   NSCharacterEncodingDocumentAttribute: [NSNumber numberWithInt:NSUTF8StringEncoding]}
                              documentAttributes:nil error:nil];
        [dict setObject:attStr forKey:kCLInboxDetailMsgTextkey];
        [arr replaceObjectAtIndex:i withObject:dict];
    }
    self.msgsArray=arr;
    //self.msgsArray=[dictionary objectForKeyNotNull:@"mails"];
    
    self.questionnaireArray=[[NSMutableArray alloc] init];
    NSArray *questArr=[dictionary objectForKeyNotNull:@"Quest"];
    if (questArr) {
        for (int j=0; j<[questArr count]; j++) {
            [self.questionnaireArray addObject:[[CLQuestionnaireObject alloc] initWithDictionary:[questArr objectAtIndex:j]]];
        }
    }
    
    return self;
}

+ (void)cancelInboxListingPendingRequests {
    [inboxListingRequest cancelAllOperations];
    inboxListingRequest = nil;
}

+ (void)cancelInboxDetailPendingRequests {
    [inboxDetailsRequest cancelAllOperations];
    inboxDetailsRequest = nil;
}

+ (void)listInboxForUserId:(NSString*)userId success:(void (^)(NSMutableArray *jobs, NSInteger unreadInboxCount))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *jobs, NSInteger unreadInboxCount){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [inboxListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        inboxListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceInboxListURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"list inbox JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *inboxList=[[NSMutableArray alloc] init];
                
                NSArray *inboxArr=[response objectForKey:@"mails"];
                for (int i=0; i<[inboxArr count]; i++) {
                    CLInboxObject *inboxObj=[[CLInboxObject alloc] initWithDictionary:[inboxArr objectAtIndex:i]];
                    [inboxList addObject:inboxObj];
                }
                NSInteger unreadInboxCount=[[response objectForKeyNotNull:kCLInboxListTotalUnreadInboxKey] intValue];
                
                success(inboxList,unreadInboxCount);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for getting inbox detail...
+ (void)inboxDetailsForinboxId:(NSString*)inboxId success:(void (^)(CLInboxObject *inboxDetail))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLInboxObject *jobDetail){};
    }
    
    NSDictionary *parameters = @{@"mail": inboxId, @"user": [CLUserObject currentUser].userID};
    
    [inboxDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        inboxDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceInboxDetailURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"inbox detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLInboxObject *inboxObj=[[CLInboxObject alloc] initInboxDetailsWithDictionary:response];
                success(inboxObj);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for posting reply...
+ (void)postReplyforInboxId:(NSString*)inboxId withMessage:(NSString*)msg success:(void (^)(CLInboxObject *inboxDetail))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLInboxObject *inboxDetail){};
    }
    
     NSDictionary *parameters = @{@"thread": inboxId, @"message": msg};
    
    [postReplyRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        postReplyRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceInboxPostReplyURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"post reply JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLInboxObject *inboxObj=[[CLInboxObject alloc] initInboxDetailsWithDictionary:response];
                success(inboxObj);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
