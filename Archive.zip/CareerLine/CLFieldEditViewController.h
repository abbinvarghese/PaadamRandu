//
//  CLFieldEditViewController.h
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLFieldSearchViewController.h"

@protocol CLFieldEditDelegate <NSObject>

-(void)addSelectedFieldsDictArray:(NSMutableArray*)array to:(NSIndexPath*)index;

@end

@interface CLFieldEditViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CLFieldSearchDelegate>

@property(nonatomic,weak)id<CLFieldEditDelegate>delegate;
@property(nonatomic,retain) NSMutableArray *selectedFieldsValuePassedOn;
@property(nonatomic,retain) NSIndexPath *selectedIndex;
@property(nonatomic,retain) NSString *titleString;
@property(nonatomic) BOOL fromTwentyField;
@property(nonatomic,retain) NSMutableDictionary*currentLocationDictionary;

@end
