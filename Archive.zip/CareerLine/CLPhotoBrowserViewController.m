//
//  CLPhotoBrowserViewController.m
//  CareerLine
//
//  Created by CSG on 7/23/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPhotoBrowserViewController.h"
#import "CLPhotoViewController.h"

@interface CLPhotoBrowserViewController ()

@property (nonatomic, strong) UIPageViewController *pageViewController;

@end

@implementation CLPhotoBrowserViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"Photos", @"Photo browser title");
    [self setRightNavigationButton];
    
    self.pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll
                                                          navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal
                                                                        options:[NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:5.0f] forKey:UIPageViewControllerOptionInterPageSpacingKey]];
    
    self.pageViewController.dataSource = self;
    CLPhotoViewController *startingPage = [CLPhotoViewController photoViewControllerForPageIndex:self.startingIndex andPhotos:self.photos];
    if (startingPage != nil)
    {
        [self.pageViewController setViewControllers:@[startingPage]
                                          direction:UIPageViewControllerNavigationDirectionForward
                                           animated:NO
                                         completion:nil];
        
        [self addChildViewController:self.pageViewController];
        [self.view addSubview:self.pageViewController.view];
        
        [self.pageViewController didMoveToParentViewController:self];
        
        self.pageViewController.view.frame = self.view.bounds;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Dismiss modal button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark IBActions

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIPageViewControllerDelegate

- (UIViewController *)pageViewController:(UIPageViewController *)pvc viewControllerBeforeViewController:(CLPhotoViewController *)photoController
{
    NSUInteger index = photoController.pageIndex;
    return [CLPhotoViewController photoViewControllerForPageIndex:(index - 1) andPhotos:self.photos];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pvc viewControllerAfterViewController:(CLPhotoViewController *)photoController
{
    NSUInteger index = photoController.pageIndex;
    return [CLPhotoViewController photoViewControllerForPageIndex:(index + 1) andPhotos:self.photos];
}

@end
