//
//  CLUserObject.h
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLUserObject : NSObject

//user details..
@property (nonatomic, strong) NSString *userID;
@property (strong, nonatomic) NSMutableDictionary *country;
@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *preferredName;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSDate *birthDate;
@property (nonatomic, strong) NSString *iconURL;
@property (nonatomic, assign) NSInteger formStatus;
@property (nonatomic, assign) NSInteger unreadJobsCount;
@property (nonatomic, assign) NSInteger unreadInboxCount;
@property (nonatomic, assign) CLTrafficLightStatus trafficLightStatus;
@property (nonatomic, assign) NSString* clWelcomeStatus;


//Method used to register a user with username and password...
+ (void)registerUser:(NSString*)userName withFirstName:(NSString *)firstName lastName:(NSString*)lastName password:(NSString*)password success:(void (^)(NSString *userName, NSString *password))success failure:(void (^)(NSString *error))failure;

//Method used to resend verification mail for registration...
+ (void)resendRegisterVerificationMailforUser:(NSString*)userName success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//Method used to reset password when a user forgets his password...
+ (void)forgotPassword:(NSString*)userName success:(void (^)(NSString *userName))success failure:(void (^)(NSString *error))failure;

//Method used to resend verification mail for forgot pass...
+ (void)resendForgotPassVerificationMailforUser:(NSString*)userName success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//Method used to login a user with username and password...
+ (void)loginUser:(NSString*)userName password:(NSString*)password typeAutoLogin:(NSString *)autologin success:(void (^)(int successFlag, NSString *userName, NSString *password,int autosave, NSString *welcomeStat))success failure:(void (^)(NSString *error))failure;

//Method used to update user details with user id...
+ (void)updateUserDetailsWithUserId:(NSString*)userId success:(void (^)(void))success failure:(void (^)(void))failure;

//Method for saving user details from 20 fields submission...
+ (void)saveFirstTimeUserDetails:(NSString*)detailsJsonString forUserId:(NSString*)userId password:(NSString*)password success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//Method used to logout user with user id...
+ (void)logoutUser:(NSString*)userId success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//To change the traffic light status..
+ (void)changeTrafficLightStatus:(int)status withEmail:(NSString*)email success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//To get Company Divisions
+(void)getCompanyDivListForSearchString:(NSString*)searchText companyId:(NSString *)companyID andBlackListString:(NSString*)blackListString success:(void (^)(NSMutableArray *companyDivList))success failure:(void (^)(NSString *error))failure;

//To Get Document List by user id
+ (void)listDocumentsForUserId:(NSString*)userId pageNumber:(int)page success:(void (^)(NSMutableArray *documentList,BOOL isLastPageReached, NSInteger documentCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure;

//update document caption

+(void)updateCaption:(NSString*)captionString forDocId:(NSString*)docId success:(void (^)(void)) success ailure:(void (^)(NSString *error))failure;

//To restPassword
+(void)resetPasswordForUserName:(NSString*) userName withPassword :(NSString*)password andActiveCode :(NSString*) activeCode success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//To get the current user object..
+ (CLUserObject *)currentUser;

//To clear all details of the current user..
+ (void)logout;

//To check whether session is valid..
+ (BOOL)isSessionValid;

//To cancel web service requests...
+ (void)cancelPendingRequests;

//To cancel UpdateUserDetails web service requests...
+ (void)cancelUpdateUserDetailsPendingRequest;

//To cancel first time login web service requests...
+ (void)cancelFirstTimeLoginPendingRequest;

//set current user from cache..
+(void)setCurrentUserFromUserDefaults;

//To save user details to useDefaults..
+ (void)saveLoginCredentialsWithUsername:(NSString*)username password:(NSString*)password isUpdating:(BOOL)isUpdating;

//to set the current user..
//- (void)setCurrentUser;

@end
