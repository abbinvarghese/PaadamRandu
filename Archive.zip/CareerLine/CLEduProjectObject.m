//
//  CLEduProjectObject.m
//  CareerLine
//
//  Created by Abbin on 12/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLEduProjectObject.h"
#import "NSDictionary+Additions.h"
#import "CLFileObject.h"
#import "NSDate+Utilities.h"

#define kDebugMessages 0

@implementation CLEduProjectObject

static NSOperationQueue *saveEduRequest;
static NSOperationQueue *deleteEduRequest;
static NSOperationQueue *uploadEduDocumentRequest;
static NSOperationQueue *deleteEduDocumentRequest;


-(id)initWithDictionary:(NSDictionary *)dictionary{
    self.day = [dictionary objectForKeyNotNull:@"Day"];
    self.months = [dictionary objectForKeyNotNull:@"Month"];
    self.year = [dictionary objectForKeyNotNull:@"Year"];
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:@"attachDocuments"];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    self.course = [dictionary objectForKeyNotNull:@"course"];
    
    self.date = [NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
                 
    self.idNum = [dictionary objectForKeyNotNull:@"id"];
    self.remark = [dictionary objectForKeyNotNull:@"remarks"];
    self.title = [dictionary objectForKeyNotNull:@"title"];
    self.type = [dictionary objectForKeyNotNull:@"type"];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formateddDate=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formateddDate=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMy"];
    }
    return self;
}

-(void)updateDate:(NSDate*)date{
    self.date=date;
    self.formateddDate=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
}

+ (void)saveEdu:(CLEduProjectObject*)eduObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *eduId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *projId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters =@{@"user":userId, @"id":eduObj.idNum, @"fields":[CLEduProjectObject jsonStringForObject:eduObj]};
    }
    else{
        parameters = @{@"user":userId, @"fields":[CLEduProjectObject jsonStringForObject:eduObj]};
    }
    
    [saveEduRequest cancelAllOperations];
    
    if ([CLCommon isNetworkConnected]) {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveEduRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProjectSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveProjectRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileWorkAchievementSaveIdkey]);
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    }
    
    
}

+ (void)deleteEdu:(NSString*)eduId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": eduId};
    
    [deleteEduRequest cancelAllOperations];
    
    if ([CLCommon isNetworkConnected]) {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteEduRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioDeleteEduURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete project JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+ (void)addDocument:(UIImage*)image forEdu:(NSString*)eduId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": eduId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadEduDocumentRequest cancelAllOperations];
    if([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadEduDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileEduUploadDocumentURL] parameters:parameters
constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
    [formData appendPartWithFileData:imageData name:@"Education" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
}
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"work achievement document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];

    }
}

+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteEduDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteEduDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileEDuDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete project document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
}


+(NSString*)jsonStringForObject:(CLEduProjectObject*)projObj{
    NSMutableDictionary *projectDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    [insideDict setObject:projObj.title forKey:@"title"];
    [insideDict setObject:[CLCommon getStringForDate:projObj.date andExactFormat:@"dd-MM-yyyy"] forKey:@"date"];
    if ([projObj.course objectForKey:kCLProfileProtfolioProjectCareerIdkey]) {
        [insideDict setObject:projObj.course forKey:@"course"];
    }
    if (projObj.remark) {
        [insideDict setObject:projObj.remark forKey:kCLProfileProtfolioProjectDescriptionkey];
    }
    
    [projectDict setObject:insideDict forKey:@"EducationProject"];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:projectDict];
}


@end
