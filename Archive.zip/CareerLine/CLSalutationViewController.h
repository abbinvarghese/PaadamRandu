//
//  CLSalutationViewController.h
//  CareerLine
//
//  Created by CSG on 2/24/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"

@interface CLSalutationViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,CLSimpleTextCellDelegate>

@end
