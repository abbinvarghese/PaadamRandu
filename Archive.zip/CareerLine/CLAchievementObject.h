//
//  CLAchievements.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLAchievementObject : NSObject

@property(nonatomic,strong)NSString *achievementId;
@property(nonatomic,strong)NSString *achievementTitle;
@property(nonatomic,strong)NSDate *achievementDate;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *achievementDescription;
@property(nonatomic,strong)NSMutableArray *achievementDocs;     //[(CLFileObject),(CLFileObject),...]


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for saving achievement of a particular user...
+ (void)savePersonalAchievement:(NSString*)achievementId forUser:(NSString*)userId title:(NSString*)title date:(NSString *)date remarks:(NSString*)remarks editMode:(BOOL)isEditMode success:(void (^)(NSString *mediaId))success failure:(void (^)(NSString *error))failure;

//Method for deleting achievement for a particular user...
+ (void)deletePersonalAchievement:(NSString*)achievementId forUser:(NSString*)userId success:(void (^)(NSString *achievementId))success failure:(void (^)(NSString *error))failure;

//Method for uploading achievement document for a particular user...
+ (void)addDocument:(UIImage*)image forAchievement:(NSString*)achId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting achievement document for a particular user...
+ (void)deleteDocument:(NSString*)documentId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
