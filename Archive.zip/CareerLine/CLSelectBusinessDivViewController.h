//
//  CLSelectBusinessDivViewController.h
//  CareerLine
//
//  Created by RENJITH on 05/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectBusinessDivViewController;

@protocol CLAddBusDivDelegate <NSObject>
- (void)businessDivController:(CLSelectBusinessDivViewController*)controller didSelectBusDiv:(NSMutableDictionary *)selectedBusDivDict;
@optional


@end
@interface CLSelectBusinessDivViewController : UITableViewController


//@property(nonatomic,strong) NSMutableArray *completeBusinessDiv;
@property(nonatomic,strong) NSMutableDictionary *selectedCompany;
@property (nonatomic,weak) id<CLAddBusDivDelegate>delegate;
@property (nonatomic,strong) NSMutableArray *alreadySelectedBusDiv;
@end
