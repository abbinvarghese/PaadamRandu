//
//  CLEmployeementTypeViewController.m
//  CareerLine
//
//  Created by RENJITH on 04/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEmployeementTypeViewController.h"
#import "CLEmployeementTypeDetailsViewController.h"
#import "CLCoreDataHelper.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:14]

@interface CLEmployeementTypeViewController ()
@property(nonatomic,strong)NSMutableArray *empTypeGroupArray;
@end

@implementation CLEmployeementTypeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Employment Type", @"Select Employeement Type page title");
    
    [self setLeftNavigationButton];
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    self.empTypeGroupArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpTypeGroupFromDB];
    
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

#pragma mark - IBActions
-(void)bttnActionCancelModal:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.empTypeGroupArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *CellIdentifier = @"employeementTypeCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    // Configure the cell...
    NSMutableDictionary *empTypeGroup=[self.empTypeGroupArray objectAtIndex:indexPath.row];
    cell.textLabel.text=[empTypeGroup objectForKey:kempTypeName];
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CLEmployeementTypeDetailsViewController *detailViewController = [[CLEmployeementTypeDetailsViewController alloc] initWithNibName:@"CLEmployeementTypeDetailsViewController" bundle:[NSBundle mainBundle]];
    detailViewController.delegate=self.delegate;
    detailViewController.selectedEmpTypeGroupDict=[self.empTypeGroupArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detailViewController animated:YES];
    
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return NSLocalizedString(@"Employment Type", @"Title for Employeement Type");
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}
@end
