//
//  CLKnowledgeObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLKnowledgeObject : NSObject

//Knowledge Rating..
typedef enum {
    CLKnowledgeStarRatingNone = 0,
    CLKnowledgeStarRatingOne=  1,
    CLKnowledgeStarRatingTwo = 2,
    CLKnowledgeStarRatingThree = 3,
    CLKnowledgeStarRatingFour = 4,
   CLKnowledgeStarRatingFive = 5,
} CLKnowledgeStarRating;

@property(nonatomic,retain)NSNumber* imgWidth;


@property(nonatomic,strong)NSString *author;
@property(nonatomic,strong)NSString *location;
@property(nonatomic,assign)BOOL isBookMarked;
@property(nonatomic,strong)NSString *companyName;
@property(nonatomic,retain)NSString *dateCreated;
@property(nonatomic,strong)NSString *eventDate;
@property(nonatomic,retain)NSNumber* imgHeight;
@property(nonatomic,strong)NSString *Id;
@property(nonatomic,strong)NSString *imgUrl;
@property(nonatomic,assign)BOOL isLiked;
@property(nonatomic,strong)NSString *knowledgeId;
@property(nonatomic,strong)NSNumber *likeCount;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *newsCompany;
@property(nonatomic,strong)NSString *type;
@property(nonatomic,strong)NSString *volDate;
@property(nonatomic,strong)NSString *publishedCreated;

@property(nonatomic,strong)NSString *subType;
@property(nonatomic,strong)NSString *category;
@property(nonatomic,strong)NSString *keyWords;
@property(nonatomic,strong)NSString *desc;



+ (void)cancelknowledgeListingPendingRequests;
+ (void)cancelknowledgeBookmarkListingPendingRequests;

//Method to get knowledge list
+ (void)listKnowledgeForUserId:(NSString*)userId searchString:(NSString *)str pageNumber:(int)page flagOrType:(int)selectedFilter success:(void (^)(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure;

//To Get bookmarked Knowledge List by user id
+ (void)listBookmarkedKnowledgeForUserId:(NSString*)userId searchString:(NSString *)str pageNumber:(int)page success:(void (^)(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure;

//Method to bookmark a particular knowledge
+ (void)bookMarkKnowledgeforUser:(NSString*)knowledgeRecId type:(NSString*)type success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

//Method to like a particular knowledge
+ (void)likeKnowledge:(NSString*)knowledgeId forUser:(NSString *)userId type:(NSString*)kType success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

@end
