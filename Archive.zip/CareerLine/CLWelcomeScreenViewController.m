//
//  CLWelcomeScreenViewController.m
//  CareerLine
//
//  Created by CSG on 1/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLWelcomeScreenViewController.h"
#import "CLGetStartedViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLUserObject.h"
#import "CLPersonalProfileDetailsViewController.h"
#import "CLStatusViewController.h"
#import "CLCRFAboutMeViewController.h"

@interface CLWelcomeScreenViewController ()

@property (weak, nonatomic) IBOutlet UILabel *lblEmail;
@property (weak, nonatomic) IBOutlet UILabel *lblWelcomeHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
@property (weak, nonatomic) IBOutlet UILabel *lblText;
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *messageHeight;

- (IBAction)bttnAction:(id)sender;

@end

@implementation CLWelcomeScreenViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([CLCommon sharedInstance].firstname !=nil) {
        NSLog(@"%@",[NSString stringWithFormat:@"%@ %@",[CLCommon sharedInstance].firstname,[CLCommon sharedInstance].lastname]);
        self.lblEmail.text=[NSString stringWithFormat:@"%@ %@",[CLCommon sharedInstance].firstname,[CLCommon sharedInstance].lastname];
    }else{
        NSLog(@"%@",[NSString stringWithFormat:@"%@ %@",[CLUserObject currentUser].firstName,[CLUserObject currentUser].lastName]);
        self.lblEmail.text=[NSString stringWithFormat:@"%@ %@",[CLUserObject currentUser].firstName,[CLUserObject currentUser].lastName];
        
    }
    
    self.lblWelcomeHeading.font=[UIFont fontWithName:@"Variable" size:26];
    self.lblEmail.font=[UIFont fontWithName:@"Variable" size:17];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    
    if(self.fromPageFlag==CLNavigationFromWelcomePage){
        self.title=NSLocalizedString(@"Welcome", @"Welcome screen page title");
        self.lblDescription.text=NSLocalizedString(@"A Revolutionary Online Service Unlike Anything Else Out There, It Gives You Everything You Need to Help Manage and Progress Your Career. Anytime. Anywhere.", @"Welcome screen page description text");
        [self setNavigationButtons];
        self.button.hidden=YES;
    }
    else if (self.fromPageFlag==CLNavigationFromRegisterPage){
        self.title=NSLocalizedString(@"Register", @"Register success screen page title");
        self.lblDescription.text=NSLocalizedString(@"Please Check Your Email and Verify Your Address.", @"Register success screen page description text");
        self.lblText.text = @"";
        self.button.hidden=NO;
        [self.button setTitle:NSLocalizedString(@"Resend Verification Email", @"Forgot Password screen page resend request button title") forState:UIControlStateNormal];
    }
    else if (self.fromPageFlag==CLNavigationFromForgotPassPage){
        self.title=NSLocalizedString(@"Forgot Your Password", @"Forgot Password screen page title");
        self.lblDescription.text=NSLocalizedString(@"Please Check Your Email To Reset Your Password.", @"Forgot Password screen page description text");
        self.lblWelcomeHeading.text=NSLocalizedString(@"Reset Password_", @"Forgot Password screen page heading text");
        self.button.hidden=NO;
        self.lblText.hidden = YES;
        self.lblEmail.text=[NSString stringWithFormat:@"%@",[CLCommon sharedInstance].userName];
        [self.button setTitle:NSLocalizedString(@"Resend Reset Request", @"Forgot Password screen page resend request button title") forState:UIControlStateNormal];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setNavigationButtons{
//    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Start", @"Text for welcome Screen go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionNextPage:)];
//    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
    if (self.isFirstTime) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Start", @"Text for getting started page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGoToStatusChangePage:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for getting started page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGoToProfileDetailsPage:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }

    
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Log Out", @"Text for welcome Screen logout button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionLogout:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

//#pragma mark IBActions

//-(void)bttnActionNextPage:(id)sender{
//    CLGetStartedViewController *welcomeScreen=[[CLGetStartedViewController alloc] initWithNibName:@"CLGetStartedViewController" bundle:[NSBundle mainBundle]];
//    welcomeScreen.isFirstTime=YES;
//    [self.navigationController pushViewController:welcomeScreen animated:YES];
//}

#pragma mark IBActions

-(void)bttnActionGoToStatusChangePage:(id)sender{
//    CLStatusViewController *statusScreen=[[CLStatusViewController alloc] initWithNibName:@"CLStatusViewController" bundle:[NSBundle mainBundle]];
//    statusScreen.isFromWelcomeScreen=YES;
//    [self.navigationController pushViewController:statusScreen animated:YES];
    CLCRFAboutMeViewController *controller = [[CLCRFAboutMeViewController alloc]initWithNibName:@"CLCRFAboutMeViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)bttnActionGoToProfileDetailsPage:(id)sender{
//    CLPersonalProfileDetailsViewController *profileScreen=[[CLPersonalProfileDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
//    [self.navigationController pushViewController:profileScreen animated:YES];
    CLCRFAboutMeViewController *controller = [[CLCRFAboutMeViewController alloc]initWithNibName:@"CLCRFAboutMeViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:controller animated:YES];
}


-(void)bttnActionLogout:(id)sender{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *logout = [[UIActionSheet alloc]initWithTitle:NSLocalizedString(@"Are You Sure You Want To Logout?", @"Message for logout validation") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"cancel button title") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Yes", @"log out confirm button title"), nil];
        [logout showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Are You Sure You Want To Logout?", @"Message for logout validation") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @" selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *yesAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Yes", @"log out confirm button title") style:UIAlertActionStyleDefault handler:^(UIAlertAction*action){
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:yesAction];
        [self presentViewController:actionSheetController animated:YES completion:nil];
        
    }

}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (IBAction)bttnAction:(id)sender {
    //send verification mail again..
    if (self.fromPageFlag==CLNavigationFromRegisterPage){
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Resending Mail...", @"Text displayed in the loading indicator while resending mail");
        [progressHUD showInView:self.view];
        
        [CLUserObject resendRegisterVerificationMailforUser:[CLCommon sharedInstance].userName
                                                    success:^(){
                                                        [progressHUD hideWithAnimation:YES];
                                                        [self showConformationAlert];
                                                        
                                                    }
                                                    failure:^(NSString *error){
                                                        [progressHUD hideWithAnimation:YES];
                                                        if (![error isEqualToString:@""]) {
                                                            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                                        }
                                                    }];
    }
    else if (self.fromPageFlag==CLNavigationFromForgotPassPage){
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Resending Mail...", @"Text displayed in the loading indicator while resending mail");
        [progressHUD showInView:self.view];
        
        [CLUserObject resendForgotPassVerificationMailforUser:[CLCommon sharedInstance].userName
                                                    success:^(){
                                                        [progressHUD hideWithAnimation:YES];
                                                        [self showConformationAlert];
                                                    }
                                                    failure:^(NSString *error){
                                                        [progressHUD hideWithAnimation:YES];
                                                        if (![error isEqualToString:@""]) {
                                                            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                                        }
                                                    }];
    }
}

-(void)showConformationAlert{
    if ([CLCommon isOSversionLessThan8]) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Mail Has Been Sent", @"title for comformaion alert") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"cancel button title") otherButtonTitles:nil, nil];
        [alertView show];
    }
    else{
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Mail Send", @"title for comformaion alert") message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", @"cancel button title") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                 {
                                    [self.navigationController popToRootViewControllerAnimated:YES];
                                 }];
        
        [controller addAction:action];
        [self presentViewController:controller animated:YES completion:nil];
        
    }
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    [self.navigationController popToRootViewControllerAnimated:YES];
}


@end
