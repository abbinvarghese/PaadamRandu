//
//  CLLocationLoaderCell.m
//  CareerLine
//
//  Created by Abbin on 07/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLLocationLoaderCell.h"

@interface CLLocationLoaderCell()
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

@implementation CLLocationLoaderCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLLocationLoaderCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        self.activityIndicator.hidesWhenStopped = YES;
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

-(void)hideActivityIndicator{
    [self.activityIndicator stopAnimating];
}

-(void)startActivityIndicator{
    [self.activityIndicator startAnimating];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
