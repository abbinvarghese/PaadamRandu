//
//  CLWorkConditionViewController.m
//  CareerLine
//
//  Created by Abbin on 11/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLWorkConditionViewController.h"
#import "CLWorkConsiderationObject.h"


#define kWorkRadiusNameKey @"workPreference"

@interface CLWorkConditionViewController ()

typedef enum {
    CLWorkConsiderationTravelPickerTag = 1,
//    CLWorkConsiderationWorkRadiusPickerTag= 2,
    CLFlexibleWorkTelecomutingPickerTag = 3
} CLWorkConditionPickerViewPickerTag;

typedef enum {
    CLWorkConsiderationIndex = 0,
    CLFlexibleWorkPreferenceIndex= 1
} CLWorkConditionTableSectionIndex;

typedef enum {
    CLWillingnessForTravelIndex = 0,
//    CLWorkRadiusIndex= 1,
} CLWorkConsiderationTableRowIndex;

typedef enum {
    CLFlexibleWorkScheduleIndex = 0,
    CLFlextimeIndex = 1,
    CLCompressedWorkWeekIndex = 2,
    CLJobSharingIndex = 3,
    CLWorkFromHomeIndex = 4,
    CLOtherIndex = 5,
    CLRequireDisabilityIndexWithFirstSwitchOff = 1,
    CLAnthingElseIndexWithFirstSwitchOff = 2,
    CLRequireDisabilityIndexWithFirstSwitchON = 6,
    CLAnthingElseIndexWithFirstSwitchON = 7
} CLFlexibleWorkTableRowIndex;


@property (weak,nonatomic) IBOutlet UITableView *tableView;
@property (strong,nonatomic) IBOutlet UIToolbar *keyboardToolBarWithCancel;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong,nonatomic) IBOutlet UIPickerView *pickerView;
@property (strong,nonatomic) UITextField *txtFirstResponder;

@property (nonatomic,retain) NSArray *travelWillingnessArray;
//@property (nonatomic,retain) NSArray *workRadiusArray;
@property (nonatomic,retain) NSArray *workFromHomeArray;
@property (nonatomic,retain) NSArray *sectionArray;

@property (assign,nonatomic)BOOL flexibleWorkScheduleisON;
@property (assign,nonatomic)BOOL disabilityWorkSpaceisON;
@property (assign,nonatomic)BOOL FlextimeIsON;
@property (assign,nonatomic)BOOL compressedWorkisON;
@property (assign,nonatomic)BOOL jobSharingIsON;

@property (nonatomic,retain) NSMutableDictionary *selectedTravelWillingnessDict;
//@property (nonatomic,retain) NSMutableDictionary *selectedWorkRadiusDict;
@property (nonatomic,retain) NSMutableDictionary *selectedWorkFromHomeDict;
@property (nonatomic,retain) NSString *otherString;
@property (nonatomic,retain) NSString *anythingElseString;
@property(nonatomic,strong)NSNumber *descriptionHeight;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;

@property (strong, nonatomic) HTProgressHUD *activityIndicator;
@property (nonatomic,retain) CLWorkConsiderationObject *workObj;

@end

@implementation CLWorkConditionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setRightNavigationButton];
    [self workConsiderationSummaryDetails];
    [self saveWorkFromHomeArray];
//    [self saveworkRadiusArray];
    [self savetravelWillingnessArray];
    [self setSectionHeader];
    self.title = NSLocalizedString(@"Work Condition Considerations", @"title for Work Condition Considerations");
    
    UIPickerView *businessDivPickerView=[[UIPickerView alloc] init];
    businessDivPickerView.backgroundColor=[UIColor whiteColor];
    businessDivPickerView.tag =1;
    businessDivPickerView.delegate=self;
    businessDivPickerView.dataSource=self;
    businessDivPickerView.showsSelectionIndicator = YES;
    self.pickerView =businessDivPickerView;
    
    self.keyboardToolBarWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"workConsiderationCell"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"flexibleWorkCell"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"flextimeCell"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"compressedWorkWeek"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"jobSharingCell"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"workFromHomeCell"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"OtherCell"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"disabilityCell"];
//    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"anythingElseCell"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionCellIdentifier"];
}

-(void)viewDidDisappear:(BOOL)animated{
    [CLWorkConsiderationObject cancelWorkConsiderationRequest];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Work Condition Considerations"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark UITableView delegate methods


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.workObj) {
        return 2;
    }
    else{
        return 0;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case CLWorkConsiderationIndex:
            return 1;
            break;
        case CLFlexibleWorkPreferenceIndex:{
            int number = 2;
            if (self.flexibleWorkScheduleisON) {
                number = number + 5;
            }
            if (self.disabilityWorkSpaceisON) {
                number = number + 1;
            }
            return number;
        }
            break;
            
        default:
            break;
    };
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLWorkConsiderationIndex:{
            CLSimpleTextCell *workConsiderationCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"workConsiderationCell"];
            [workConsiderationCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [workConsiderationCell setTextInputView:self.pickerView];
            [workConsiderationCell setCellFont:[UIFont systemFontOfSize:13]];
            if (indexPath.row == CLWillingnessForTravelIndex) {
                [workConsiderationCell setPlaceHoldrText:NSLocalizedString(@"Willingness for Business Travel", @"placeholder text for travel Willingness.")];
                [workConsiderationCell setCellText:[self.selectedTravelWillingnessDict objectForKey:kCLWorkconsiderationbusinessTravelkey]];
            }
//            else if (indexPath.row == CLWorkRadiusIndex){
//                [workConsiderationCell setPlaceHoldrText:NSLocalizedString(@"Work Radius Preference", @"placeholder text for Work Radius.")];
//                [workConsiderationCell setCellText:[self.selectedWorkRadiusDict objectForKey:@"workPreference"]];
//            }
            [workConsiderationCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [workConsiderationCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [workConsiderationCell setCellIndexPath:indexPath];
            workConsiderationCell.delegate=self;
            workConsiderationCell.selectionStyle = UITableViewCellSelectionStyleNone;
            return workConsiderationCell;

        }
            break;
        case CLFlexibleWorkPreferenceIndex:{
            if (self.flexibleWorkScheduleisON) {
                switch (indexPath.row) {
                    case CLFlexibleWorkScheduleIndex:{
                        CLTextCheckBoxCell *flexibleWorkCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"flexibleWorkCell"];
                        flexibleWorkCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [flexibleWorkCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [flexibleWorkCell setCellText:NSLocalizedString(@"Flexible Work Schedule/Arrangement?", @"Placeholder for Flexible work schedule")];
                        [flexibleWorkCell setCellFont:[UIFont systemFontOfSize:13]];
                        [flexibleWorkCell setCellTextColor:[UIColor darkGrayColor]];
                        [flexibleWorkCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [flexibleWorkCell setCellIndexPath:indexPath];
                        [flexibleWorkCell disableCelltxtField];
                        [flexibleWorkCell checkBoxClick:self.flexibleWorkScheduleisON];
                        flexibleWorkCell.textCheckBoxdelegate=self;
                        flexibleWorkCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return flexibleWorkCell;
                    }
                        break;
                    case CLFlextimeIndex:{
                        CLTextCheckBoxCell *flextimeCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"flextimeCell"];
                        flextimeCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [flextimeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [flextimeCell setCellText:NSLocalizedString(@"Flexitime", @"Placeholder for Flextime")];
                        [flextimeCell setCellFont:[UIFont systemFontOfSize:13]];
                        [flextimeCell setCellTextColor:[UIColor darkGrayColor]];
                        [flextimeCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [flextimeCell setCellIndexPath:indexPath];
                        [flextimeCell disableCelltxtField];
                        [flextimeCell checkBoxClick:self.FlextimeIsON];
                        flextimeCell.textCheckBoxdelegate=self;
                        flextimeCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return flextimeCell;

                    }
                        break;
                    case CLCompressedWorkWeekIndex:{
                        CLTextCheckBoxCell *compressedWorkWeek = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"compressedWorkWeek"];
                        compressedWorkWeek.selectionStyle=UITableViewCellSelectionStyleNone;
                        [compressedWorkWeek setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [compressedWorkWeek setCellText:NSLocalizedString(@"Compressed Work Week", @"Placeholder for Compressed Work Week")];
                        [compressedWorkWeek setCellFont:[UIFont systemFontOfSize:13]];
                        [compressedWorkWeek setCellTextColor:[UIColor darkGrayColor]];
                        [compressedWorkWeek setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [compressedWorkWeek setCellIndexPath:indexPath];
                        [compressedWorkWeek disableCelltxtField];
                        [compressedWorkWeek checkBoxClick:self.compressedWorkisON];
                        compressedWorkWeek.textCheckBoxdelegate=self;
                        compressedWorkWeek.selectionStyle = UITableViewCellSelectionStyleNone;
                        return compressedWorkWeek;
                    }
                        break;
                    case CLJobSharingIndex:{
                        CLTextCheckBoxCell *jobSharing = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobSharingCell"];
                        jobSharing.selectionStyle=UITableViewCellSelectionStyleNone;
                        [jobSharing setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [jobSharing setCellText:NSLocalizedString(@"Job Sharing", @"Placeholder for Job Sharing")];
                        [jobSharing setCellFont:[UIFont systemFontOfSize:12]];
                        [jobSharing setCellTextColor:[UIColor darkGrayColor]];
                        [jobSharing setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [jobSharing setCellIndexPath:indexPath];
                        [jobSharing disableCelltxtField];
                        [jobSharing checkBoxClick:self.jobSharingIsON];
                        jobSharing.textCheckBoxdelegate=self;
                        jobSharing.selectionStyle = UITableViewCellSelectionStyleNone;
                        return jobSharing;
                    }
                        break;
                    case CLWorkFromHomeIndex:{
                        CLSimpleTextCell *workFromHomeCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"workFromHomeCell"];
                        [workFromHomeCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
                        [workFromHomeCell setTextInputView:self.pickerView];
                        [workFromHomeCell setCellFont:[UIFont systemFontOfSize:13]];
                        [workFromHomeCell setPlaceHoldrText:NSLocalizedString(@"Work from Home/Telecommuting", @"placeholder text for Work from Home.")];
                        [workFromHomeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [workFromHomeCell setCellClearButtonMode:UITextFieldViewModeAlways];
                        [workFromHomeCell setCellText:[self.selectedWorkFromHomeDict objectForKey:kCLWorkconsiderationworkHomekey]];
                        [workFromHomeCell setCellIndexPath:indexPath];
                        workFromHomeCell.delegate=self;
                        workFromHomeCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return workFromHomeCell;

                    }
                        break;
                    case CLOtherIndex:{
                        CLSimpleTextCell *other = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"OtherCell"];
                        [other setTextInputAccesoryView:self.keyboardToolBarWithCancel];
                        [other setCellFont:[UIFont systemFontOfSize:13]];
                        [other setPlaceHoldrText:NSLocalizedString(@"Other - Please Tell Us", @"placeholder text for Other")];
                        [other setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [other setCellClearButtonMode:UITextFieldViewModeAlways];
                        [other setCellText:self.otherString];
                        [other setCellIndexPath:indexPath];
                        other.delegate=self;
                        other.selectionStyle = UITableViewCellSelectionStyleNone;
                        return other;
                    }
                        break;
                    case CLRequireDisabilityIndexWithFirstSwitchON:{
                        CLTextCheckBoxCell *disabilityCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"disabilityCell"];
                        disabilityCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [disabilityCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [disabilityCell setCellText:NSLocalizedString(@"Do You Require a Disability Friendly Workplace?", @"Placeholder for Require a disability friendly workplace")];
                        [disabilityCell setCellFont:[UIFont systemFontOfSize:13]];
                        [disabilityCell setCellTextColor:[UIColor darkGrayColor]];
                        [disabilityCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [disabilityCell setCellIndexPath:indexPath];
                        [disabilityCell disableCelltxtField];
                        [disabilityCell checkBoxClick:self.disabilityWorkSpaceisON];
                        disabilityCell.textCheckBoxdelegate=self;
                        disabilityCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return disabilityCell;

                    }
                        break;
                    case CLAnthingElseIndexWithFirstSwitchON:{
                        CLHeightAdjustTextCell *anythingElseCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
                        anythingElseCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [anythingElseCell setTextInputAccesoryView:self.keyboardResignView];
                        [anythingElseCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say About This?", @"Placeholder for Anything else you want to say about this")];
                        [anythingElseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        anythingElseCell.text=self.anythingElseString;
                        [anythingElseCell setCellFont:[UIFont systemFontOfSize:13]];
                        [anythingElseCell updateCellContents];
                        if(self.descriptionHeight==nil){
                            self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
                        }
                        [anythingElseCell setCellIndexPath:indexPath];
                        anythingElseCell.delegate=self;
                        anythingElseCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return anythingElseCell;
                        
                        
                        return anythingElseCell;

                    }
                        break;
                        
                    default:
                        break;
                }
                
            }
            if (!self.flexibleWorkScheduleisON) {
                switch (indexPath.row) {
                    case CLFlexibleWorkScheduleIndex:{
                        CLTextCheckBoxCell *flexibleWorkCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"flexibleWorkCell"];
                        flexibleWorkCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [flexibleWorkCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [flexibleWorkCell setCellText:NSLocalizedString(@"Flexible work schedule/arrangement?", @"Placeholder for Flexible work schedule")];
                        [flexibleWorkCell setCellFont:[UIFont systemFontOfSize:12]];
                        [flexibleWorkCell setCellTextColor:[UIColor darkGrayColor]];
                        [flexibleWorkCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [flexibleWorkCell setCellIndexPath:indexPath];
                        [flexibleWorkCell disableCelltxtField];
                        [flexibleWorkCell checkBoxClick:self.flexibleWorkScheduleisON];
                        flexibleWorkCell.textCheckBoxdelegate=self;
                        flexibleWorkCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return flexibleWorkCell;

                    }
                        break;
                    case CLRequireDisabilityIndexWithFirstSwitchOff:{
                        CLTextCheckBoxCell *disabilityCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"disabilityCell"];
                        disabilityCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [disabilityCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        [disabilityCell setCellText:NSLocalizedString(@"Do You Require a Disability Friendly Workplace?", @"Placeholder for Require a disability friendly workplace")];
                        [disabilityCell setCellFont:[UIFont systemFontOfSize:12]];
                        [disabilityCell setCellTextColor:[UIColor darkGrayColor]];
                        [disabilityCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                        [disabilityCell setCellIndexPath:indexPath];
                        [disabilityCell disableCelltxtField];
                        [disabilityCell checkBoxClick:self.disabilityWorkSpaceisON];
                        disabilityCell.textCheckBoxdelegate=self;
                        disabilityCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return disabilityCell;
                    }
                        break;
                    case CLAnthingElseIndexWithFirstSwitchOff:{
//                        CLSimpleTextCell *anythingElseCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"anythingElseCell"];
//                        [anythingElseCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
//                        [anythingElseCell setCellFont:[UIFont systemFontOfSize:13]];
//                        [anythingElseCell setPlaceHoldrText:NSLocalizedString(@"Anything else to say about this?", @"placeholder text for Anything else to say about this")];
//                        [anythingElseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//                        [anythingElseCell setCellClearButtonMode:UITextFieldViewModeAlways];
//                        [anythingElseCell setCellText:self.anythingElseString];
//                        [anythingElseCell setCellIndexPath:indexPath];
//                        anythingElseCell.delegate=self;
                        
                        CLHeightAdjustTextCell *anythingElseCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
                        anythingElseCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [anythingElseCell setTextInputAccesoryView:self.keyboardResignView];
                        [anythingElseCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say About This", @"Placeholder for Anything else you want to say about this")];
                        [anythingElseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                        anythingElseCell.text=self.anythingElseString;
                        [anythingElseCell updateCellContents];
                        [anythingElseCell setCellFont:[UIFont systemFontOfSize:13]];
                        if(self.descriptionHeight==nil){
                            self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
                        }
                        [anythingElseCell setCellIndexPath:indexPath];
                        anythingElseCell.delegate=self;
                        anythingElseCell.selectionStyle = UITableViewCellSelectionStyleNone;
                        return anythingElseCell;

                        
                        return anythingElseCell;
                    }
                        break;
                
                    default:
                        break;
                }
            }
        }
            break;
            
        default:
            break;
    }
    return nil;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionArray objectAtIndex:section];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.flexibleWorkScheduleisON) {
        if (indexPath.section == CLFlexibleWorkPreferenceIndex && indexPath.row == CLAnthingElseIndexWithFirstSwitchON) {
            CGFloat ansHeight;
            if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
                ansHeight= [self.descriptionHeight floatValue];
            }
            else{
                ansHeight= [self getTextViewSizeForText:self.anythingElseString];
            }
            return MAX(44, ansHeight+1);
        }
        else{
            return 44;
        }
    }
    else{
        if (indexPath.section == CLFlexibleWorkPreferenceIndex && indexPath.row == CLAnthingElseIndexWithFirstSwitchOff) {
            CGFloat ansHeight;
            if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
                ansHeight= [self.descriptionHeight floatValue];
            }
            else{
                ansHeight= [self getTextViewSizeForText:self.anythingElseString];
            }
            return MAX(44, ansHeight+1);

        }
        else{
            return 44;
        }
    }
    
}





#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.anythingElseString=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

- (IBAction)doneButtonAction:(UIBarButtonItem *)sender {
    [self.txtViewFirstResponder resignFirstResponder];
}


#pragma mark UIPickerView delegate methods

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    switch (self.pickerView.tag) {
        case CLWorkConsiderationTravelPickerTag:
            return [self.travelWillingnessArray count];
            break;
//        case CLWorkConsiderationWorkRadiusPickerTag:
//            return [self.workFromHomeArray count];
//            break;
        case CLFlexibleWorkTelecomutingPickerTag:
            return [self.workFromHomeArray count];
            break;
        default:
            break;
    }
    return 0;
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    
    if (pickerView.tag == CLWorkConsiderationTravelPickerTag) {
        label.text = [[self.travelWillingnessArray objectAtIndex:row] objectForKey:kCLWorkconsiderationbusinessTravelkey];
    }
//    else if (pickerView.tag == CLWorkConsiderationWorkRadiusPickerTag){
//        label.text = [[self.workRadiusArray objectAtIndex:row] objectForKey:kWorkRadiusNameKey];
//    }
    else if (pickerView.tag == CLFlexibleWorkTelecomutingPickerTag){
        label.text = [[self.workFromHomeArray objectAtIndex:row]objectForKey:kCLWorkconsiderationworkHomekey];
    }
    
    return label;
}



#pragma mark CustomeCell delegate methods

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    if (indexPath.section == CLWorkConsiderationIndex && indexPath.row == CLWillingnessForTravelIndex) {
        self.selectedTravelWillingnessDict = nil;
    }
    else if (indexPath.section == CLFlexibleWorkPreferenceIndex && indexPath.row == CLWorkFromHomeIndex){
        self.selectedWorkFromHomeDict = nil;
    }
    else if (indexPath.section == CLFlexibleWorkPreferenceIndex && indexPath.row == CLOtherIndex){
        self.otherString = @"";
    }
    else if (indexPath.section == CLFlexibleWorkPreferenceIndex && (indexPath.row == CLAnthingElseIndexWithFirstSwitchOff || indexPath.row == CLAnthingElseIndexWithFirstSwitchON)){
        self.anythingElseString = @"";
    }
}

-(void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath = cell.cellIndexPath;
    
    if (indexPath.section == CLWorkConsiderationIndex && indexPath.row == CLWillingnessForTravelIndex) {
        self.pickerView.tag = CLWorkConsiderationTravelPickerTag;
    }
//    else if (indexPath.section == CLWorkConsiderationIndex && indexPath.row == CLWorkRadiusIndex){
//        self.pickerView.tag = CLWorkConsiderationWorkRadiusPickerTag;
//        
//    }
    else if (indexPath.section == CLFlexibleWorkPreferenceIndex && indexPath.row == CLWorkFromHomeIndex){
        self.pickerView.tag = CLFlexibleWorkTelecomutingPickerTag;
    }
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    [self.pickerView reloadAllComponents];
}

-(void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath withText:(NSString *)text{
    if (indexPath.section == CLFlexibleWorkPreferenceIndex && self.flexibleWorkScheduleisON) {
        switch (indexPath.row) {
            case CLOtherIndex:
                self.otherString = text;
                break;
            case CLAnthingElseIndexWithFirstSwitchON:
                self.anythingElseString = text;
                break;
                
            default:
                break;
        }
    }
    else if (indexPath.section == CLFlexibleWorkPreferenceIndex && !self.flexibleWorkScheduleisON){
        switch (indexPath.row) {
            case CLAnthingElseIndexWithFirstSwitchOff:
                self.anythingElseString =text;
                break;
                
            default:
                break;
        }
    }
}

-(void)textCheckBoxBgChange:(CLTextCheckBoxCell *)cell withStatus:(BOOL)status{
    
//    [CLCommon doViewAnimation:self.view];
    if (cell.cellIndexPath.section == CLFlexibleWorkPreferenceIndex) {
        if (self.flexibleWorkScheduleisON) {
            switch (cell.cellIndexPath.row) {
                case CLFlexibleWorkScheduleIndex:{
                    self.flexibleWorkScheduleisON = status;
                    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLFlexibleWorkPreferenceIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                    break;
                case CLFlextimeIndex:
                    self.FlextimeIsON = status;
                    break;
                case CLCompressedWorkWeekIndex:
                    self.compressedWorkisON = status;
                    break;
                case CLJobSharingIndex:
                    self.jobSharingIsON = status;
                    break;
                case CLRequireDisabilityIndexWithFirstSwitchON:{
                    self.disabilityWorkSpaceisON = status;
                    [self.tableView reloadData];
                }
                    break;
                    
                default:
                    break;
            }
        }
        else{
            switch (cell.cellIndexPath.row) {
                case CLFlexibleWorkScheduleIndex:
                    self.flexibleWorkScheduleisON = status;
                    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLFlexibleWorkPreferenceIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
                    break;
                case CLRequireDisabilityIndexWithFirstSwitchOff:
                    self.disabilityWorkSpaceisON = status;
                    [self.tableView reloadData];
                    break;
                
                default:
                    break;
            }
        }
    }
}





#pragma mark IBActions

-(IBAction)bttnActionSaveAndDismissModal:(id)sender{
    [self.view endEditing:YES];
    self.anythingElseString = [self.anythingElseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    [self saveWorkConsiderations];
}

- (IBAction)cancelButtonClicked:(UIBarButtonItem *)sender {
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)doneButtonClicked:(UIBarButtonItem *)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    
    if (index.section == CLWorkConsiderationIndex && index.row == CLWillingnessForTravelIndex) {
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        CLSimpleTextCell *empContractTypeCell;
        empContractTypeCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLWillingnessForTravelIndex inSection:CLWorkConsiderationIndex]];
        [empContractTypeCell setCellText:[[self.travelWillingnessArray objectAtIndex:row] objectForKey:kCLWorkconsiderationbusinessTravelkey]];
        self.selectedTravelWillingnessDict = [self.travelWillingnessArray objectAtIndex:row];

    }
//    else if (index.section == CLWorkConsiderationIndex && index.row == CLWorkRadiusIndex){
//        NSInteger row = [self.pickerView selectedRowInComponent:0];
//        CLSimpleTextCell*salaryBasisCell;
//        salaryBasisCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLWorkRadiusIndex inSection:CLWorkConsiderationIndex]];
//        [salaryBasisCell setCellText:[[self.workRadiusArray objectAtIndex:row] objectForKey:kWorkRadiusNameKey]];
//        self.selectedWorkRadiusDict = [self.workRadiusArray objectAtIndex:row];
//
//    }
    else if (index.section == CLFlexibleWorkPreferenceIndex && index.row == CLWorkFromHomeIndex){
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        CLSimpleTextCell*salaryBasisCell;
        salaryBasisCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLWorkFromHomeIndex inSection:CLFlexibleWorkPreferenceIndex]];
        [salaryBasisCell setCellText:[[self.workFromHomeArray objectAtIndex:row] objectForKey:kCLWorkconsiderationworkHomekey]];
        self.selectedWorkFromHomeDict = [self.workFromHomeArray objectAtIndex:row];

    }
    [self.txtFirstResponder resignFirstResponder];
}




#pragma mark Utility

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"WorkConsideration save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)workConsiderationSummaryDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.navigationController.view animated:YES];
    self.navigationItem.rightBarButtonItem.enabled=NO;
   // self.tableView.hidden = YES;
    [CLWorkConsiderationObject workConsiderationSummaryForUser:[CLUserObject currentUser].userID lang:@"en" success:^(CLWorkConsiderationObject *workObj){
        self.workObj = workObj;
        [self setObjectValueTofields];
        [self.tableView reloadData];
        [progressHUD hideWithAnimation:YES];
    //    self.tableView.hidden = NO;
        self.navigationItem.rightBarButtonItem.enabled=YES;
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't Load Work Condition Consideration. Please try again later.", @"Error message when Work Condition Consideration cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }];
    
}

-(void)setObjectValueTofields{
    self.selectedTravelWillingnessDict = self.workObj.businessTravelDict;
//    self.selectedWorkRadiusDict = self.workObj.workRadius;
    self.flexibleWorkScheduleisON = self.workObj.flexibleWorkSchedule;
    self.FlextimeIsON = self.workObj.flexTime;
    self.compressedWorkisON = self.workObj.compressedWorkWeek;
    self.jobSharingIsON = self.workObj.jobsharing;
    self.selectedWorkFromHomeDict = self.workObj.workFromHome;
    self.otherString = self.workObj.other;
    self.disabilityWorkSpaceisON = self.workObj.disabilityWorkSpace;
    self.anythingElseString = self.workObj.anythingElse;
    
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)setSectionHeader{
    self.sectionArray = [[NSArray alloc]initWithObjects:
                         NSLocalizedString(@"Work Consideration",@"Work Consideration heading text"),
                         NSLocalizedString(@"Flexible Work Preferences",@"Flexible Work Preferences heading"),nil];
}

-(void)saveWorkConsiderations{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    self.navigationItem.hidesBackButton=YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    CLWorkConsiderationObject *newWorkObj = [[CLWorkConsiderationObject alloc]init];
    newWorkObj.businessTravelDict = self.selectedTravelWillingnessDict;
//  newWorkObj.workRadius = self.selectedWorkRadiusDict;
    newWorkObj.flexibleWorkSchedule = self.flexibleWorkScheduleisON;
    if (!self.flexibleWorkScheduleisON) {
        newWorkObj.flexTime = NO;
        newWorkObj.compressedWorkWeek = NO;
        newWorkObj.jobsharing =NO;
        newWorkObj.workFromHome = nil;
        newWorkObj.other = nil;
    }
    else {
        newWorkObj.flexTime = self.FlextimeIsON;
        newWorkObj.compressedWorkWeek = self.compressedWorkisON;
        newWorkObj.jobsharing =self.jobSharingIsON;
        newWorkObj.workFromHome = self.selectedWorkFromHomeDict;
        newWorkObj.other = self.otherString;
    }
    newWorkObj.disabilityWorkSpace = self.disabilityWorkSpaceisON;
    if (!self.disabilityWorkSpaceisON) {
        newWorkObj.anythingElse = nil;
    }
    else{
        newWorkObj.anythingElse = self.anythingElseString;
    }
    
    [CLWorkConsiderationObject saveWorkConsideration:newWorkObj forUser:[CLUserObject currentUser].userID forLang:@"en" success:^(NSString *WorkId){
        
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
        
    }failure:^(NSString *error){
        self.navigationItem.hidesBackButton=NO;
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Work Condition Consideration. Please try again later.", @"Error message when Work Condition Consideration cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }];
    
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)savetravelWillingnessArray{
    self.travelWillingnessArray = [[NSArray alloc]initWithObjects:
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"1",@"id",
                                    NSLocalizedString(@"Prefer not to travel", @"Prefer not to travel selection"),kCLWorkconsiderationbusinessTravelkey,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                     @"2",@"id",
                                    NSLocalizedString(@"Happy to travel up to 5 days per month", @"5 day travel selection"),kCLWorkconsiderationbusinessTravelkey,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                     @"3",@"id",
                                    NSLocalizedString(@"Happy to travel 5-9 days per month", @"5-9 day travel selection"),kCLWorkconsiderationbusinessTravelkey,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                     @"4",@"id",
                                    NSLocalizedString(@"Happy to travel 10-14 days per month", @"10-14 day travel selection"),kCLWorkconsiderationbusinessTravelkey,
                                    nil],
                                   [NSDictionary dictionaryWithObjectsAndKeys:
                                     @"5",@"id",
                                    NSLocalizedString(@"Happy to travel 15+ days per month", @"15+ day travel selection"),kCLWorkconsiderationbusinessTravelkey,
                                    nil],nil];
}

//-(void)saveworkRadiusArray {
//    self.workRadiusArray = [[NSArray alloc]initWithObjects:
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"0-10 kms", @"0-10 kms selection"),kWorkRadiusNameKey,
//                             nil],
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"10-20 kms", @"10-20 kms selection"),kWorkRadiusNameKey,
//                             nil],
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"20-30 kms", @"20-30 kms selection"),kWorkRadiusNameKey,
//                             nil],
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"30-40 kms", @"30-40 kms selection"),kWorkRadiusNameKey,
//                             nil],
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"40-50 kms", @"40-50 kms selection"),kWorkRadiusNameKey,
//                             nil],
//                            [NSDictionary dictionaryWithObjectsAndKeys:
//                             NSLocalizedString(@"50+ kms", @"50+ kms selection"),kWorkRadiusNameKey,
//                             nil],nil];
//}

-(void)saveWorkFromHomeArray{
    self.workFromHomeArray = [[NSArray alloc]initWithObjects:
                              [NSDictionary dictionaryWithObjectsAndKeys:
                               @"1",@"id",
                               NSLocalizedString(@"1-2 Days Each Week", @"1-2 days selection"),kCLWorkconsiderationworkHomekey,
                               nil],
                              [NSDictionary dictionaryWithObjectsAndKeys:
                               @"2",@"id",
                               NSLocalizedString(@"3 or More Days Each Week", @"3 or more days selection"),kCLWorkconsiderationworkHomekey,
                               nil],
                              [NSDictionary dictionaryWithObjectsAndKeys:
                               @"3",@"id",
                               NSLocalizedString(@"1-2 Days Per Month", @"1-2 days per month selection"),kCLWorkconsiderationworkHomekey,
                               nil], nil];
}



@end
