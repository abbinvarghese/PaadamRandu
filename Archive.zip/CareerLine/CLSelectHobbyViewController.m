//
//  CLSelectHobbyViewController.m
//  CareerLine
//
//  Created by CSG on 8/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectHobbyViewController.h"
#import "CLInterestObject.h"

#define kCellTextFontSize 14

@interface CLSelectHobbyViewController ()

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property(nonatomic,strong)NSMutableDictionary *selectedHobbyDict;
@property(nonatomic,strong)NSMutableArray *filteredHobbiesArray;
@property(nonatomic,strong)NSString *searchText;

@end

@implementation CLSelectHobbyViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Add Hobby/Interest", @"Select Location page title");
    [self setLeftNavigationButton];
    
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.tableHeaderView=self.searchBar;
    self.selectedHobbyDict=[[NSMutableDictionary alloc] init];
    self.filteredHobbiesArray=[[NSMutableArray alloc] init];
    self.searchText=@"";
    
    [self filterContentForSearchText:self.searchText];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(NSString*)createBlacklistStringForSelectedLocation{
    NSMutableString *string=[[NSMutableString alloc] init];
    if ([self.alreadySelectedHobbies count]>0) {
        for (int i=0; i<[self.alreadySelectedHobbies count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[self.alreadySelectedHobbies objectAtIndex:i] objectForKey:kCLProfileAboutMeInterestIdkey]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
    }
    return string;
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

- (void)filterContentForSearchText:(NSString*)searchText
{
	// Update the filtered array based on the search text.
	[self.filteredHobbiesArray removeAllObjects];
    [self.tableView reloadData];
    
    //[self.activityView startAnimating];
    [CLInterestObject getHobbiesListForSearchString:searchText andBlackListString:[self createBlacklistStringForSelectedLocation]
                                            success:^(NSMutableArray *hobbiesList){
                                                //[self.activityView stopAnimating];
                                                if (hobbiesList!=nil) {
                                                    self.filteredHobbiesArray = hobbiesList;
                                                }
                                                if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
                                                        [self.filteredHobbiesArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,kCLProfileAboutMeInterestTitlekey,@"0",kCLProfileAboutMeInterestIdkey, nil] atIndex:0];
                                                }
                                                [self.tableView reloadData];
                                            }
                                            failure:^(NSString *error){
                                                if (![error isEqualToString:@""]) {
                                                    //[self.activityView stopAnimating];
                                                    [self.tableView reloadData];
                                                }
                                            }];
}

#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [CLInterestObject cancelGetHobbiesRequest];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.filteredHobbiesArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.textLabel.font=[UIFont systemFontOfSize:kCellTextFontSize];
        cell.textLabel.numberOfLines=0;
    }
    
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredHobbiesArray objectAtIndex:indexPath.row];
    if([self.selectedHobbyDict isEqualToDictionary:[self.filteredHobbiesArray objectAtIndex:indexPath.row]]){
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    if (![self.searchText isEqualToString:@""] && indexPath.row==0) {
        cell.textLabel.text=[NSString stringWithFormat:@"\"%@\"",[cellDict objectForKey:kCLProfileAboutMeInterestTitlekey]];
    }
    else{
        cell.textLabel.text=[cellDict objectForKey:kCLProfileAboutMeInterestTitlekey];
    }
    
    
    return cell;
}

#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *expectedText=nil;
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredHobbiesArray objectAtIndex:indexPath.row];
    expectedText=[cellDict objectForKey:kCLProfileAboutMeInterestTitlekey];
    CGRect expectedQuestextFrame = [expectedText boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                       [UIFont systemFontOfSize:kCellTextFontSize], NSFontAttributeName,
                                                                       nil]
                                                              context:nil];
    
    return MAX(44, ceil(expectedQuestextFrame.size.height)+27);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.selectedHobbyDict=[self.filteredHobbiesArray objectAtIndex:indexPath.row];
    [self.tableView reloadData];
    [CLInterestObject cancelGetHobbiesRequest];
    [self dismissViewControllerAnimated:YES completion:^(void){
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(hobbyController:didSelectHobby:)]){
            [self.delegate hobbyController:self didSelectHobby:self.selectedHobbyDict];
        }
    }];
}

#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}

-(void)searchAfterDelay{
    [self filterContentForSearchText:self.searchText];
}

@end
