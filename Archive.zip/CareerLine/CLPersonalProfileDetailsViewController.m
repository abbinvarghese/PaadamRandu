//
//  CLPersonalProfileDetailsViewController.m
//  CareerLine
//
//  Created by CSG on 2/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPersonalProfileDetailsViewController.h"
#import "CLEmploymentDetailsViewController.h"
#import "CLUserObject.h"
#import "NSDate+Utilities.h"
#import "CLCoreDataHelper.h"

#define kSectionHeaderTextColor [UIColor darkGrayColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont [UIFont systemFontOfSize:14]

@interface CLPersonalProfileDetailsViewController ()

//Table section indicator...
typedef enum {
    TableSectionIndexCountry = 0,
	TableSectionIndexNationality = 1,
	TableSectionIndexOthers= 2
} TableSectionIndex;

//Table row indicator...
typedef enum {
	TableRowIndexFirstName= 0,
    TableRowIndexLastName= 1,
    TableRowIndexPreferedName = 2,
    TableRowIndexEmail = 3,
    TableRowIndexGender = 4,
    TableRowIndexBirthDay = 5,
    TableRowIndexEducationLocation = 6,
    TableRowIndexEducation = 7
} TableRowIndex;

@property (strong, nonatomic) IBOutlet UIView *tblHeader;
@property (strong, nonatomic) IBOutlet UIView *tblFooter;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneView;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property(nonatomic,strong)UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardDoneToolbarWithCancel;
@property (strong, nonatomic) UIPickerView *pickerView;

@property(nonatomic,assign)BOOL isDataLoadedFromUserDefaults;
@property(nonatomic,assign)BOOL shouldShowFooter;
@property(nonatomic) BOOL forCountry;
@property (strong, nonatomic) NSMutableArray *selectedNationalityArray;
@property(strong,nonatomic)NSDate *birthDate;
@property(strong,nonatomic)NSString *firstNameText;
@property(strong,nonatomic)NSString *lastNameText;
@property(strong,nonatomic)NSString *preferedNameText;
@property(strong,nonatomic)NSString *emailText;
@property(strong,nonatomic)NSMutableDictionary *selectedEducation;
@property(strong,nonatomic)NSMutableDictionary *selectedEducationLoc;
@property(nonatomic,retain)NSMutableDictionary *selctedCountry;
@property(nonatomic,strong)NSMutableArray *genderArray;
@property(nonatomic,strong)NSMutableDictionary *selectedGenderDict;


- (IBAction)bttnActionAddNationality:(id)sender;
@end

@implementation CLPersonalProfileDetailsViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    
    self.title=NSLocalizedString(@"Profile", @"Profile details page title");
    self.firstNameText=@"";
    self.lastNameText=@"";
    self.preferedNameText=@"";
    self.emailText=@"";
    [self setRightNavButton];
    
    [self regsiterTableForCellReuse];
    self.tableView.tableHeaderView=self.tblHeader;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    
    self.shouldShowFooter=NO;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[[NSDate date] dateBySubtractingYears:13]];
    [datePickr setMinimumDate:[[NSDate date] dateBySubtractingYears:80]];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"mm/dd/yyyy"];
    NSDate *date = [formatter dateFromString:@"01/01/1985"];
    [datePickr setDate:date];
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    self.selectedNationalityArray=[[NSMutableArray alloc] init];
    self.selectedEducation=[[NSMutableDictionary alloc] init];
    self.selectedGenderDict=[[NSMutableDictionary alloc] init];
    
    self.genderArray=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllGenderListFromDB]mutableCopy];
    
    self.isDataLoadedFromUserDefaults=NO;
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - CRF"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    if(!self.isDataLoadedFromUserDefaults){
        if([[NSUserDefaults standardUserDefaults] objectForKey:[CLCommon sharedInstance].userName]){
            [self loadValuesFromUserDefaults];
            [self.tableView reloadData];
            if (self.preferedNameText.length == 0) {
                self.preferedNameText = self.firstNameText;
            }
        }
        else{
            if ([CLUserObject currentUser].firstName) {
                self.firstNameText=[CLUserObject currentUser].firstName;
                self.lastNameText=[CLUserObject currentUser].lastName;
                self.emailText=[CLUserObject currentUser].email;
                if (self.selctedCountry==nil) {
                    NSLog(@"%@",[CLUserObject currentUser].country);
                    self.selctedCountry =[[NSMutableDictionary alloc]init];
                    [self.selctedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"country"] forKey:@"jobLocationCountryName"];
                    [self.selctedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:@"jobLocationCountryCode"];
                }
                
                if (self.selectedEducationLoc==nil) {
                    self.selectedEducationLoc=[[NSMutableDictionary alloc]init];
                    [self.selectedEducationLoc setObject:[[CLUserObject currentUser].country objectForKey:@"country"] forKey:@"jobLocationCountryName"];
                    [self.selectedEducationLoc setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:@"jobLocationCountryCode"];
                }
                if (self.selectedNationalityArray.count == 0) {
                    [self.selectedNationalityArray addObject:[[CLCoreDataHelper sharedCLCoreDataHelper]getNationalityFromCountryCode:[self.selctedCountry objectForKey:@"jobLocationCountryCode"]]];
                    
                    self.shouldShowFooter=YES;
                }
                [self.tableView reloadData];
                if (self.preferedNameText.length == 0) {
                    self.preferedNameText = self.firstNameText;
                }
            }
        }
        self.isDataLoadedFromUserDefaults=YES;
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [self.txtFirstResponder resignFirstResponder];
}

-(void)viewDidAppear:(BOOL)animated{
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.selectedNationalityArray count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Utility Methods

-(void)setRightNavButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for next button title to goto next page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGotoNextPage:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
    if (self.fromLoginPage) {
        UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Log Out", @"Text for log out button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGotoBack:)];
        self.navigationItem.leftBarButtonItem=leftNavBttn;
    }
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    
    //nationality validation..
    if([self.selectedNationalityArray count]==0){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select A Nationality.", @"Error Message for null nationality field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if ([self.selctedCountry count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select A Country.", @"Error Message for null nationality field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //first Name validation..
    if ([self.firstNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter First Name.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.firstNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check First Name Length.", @"Error Message for length of fullName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.firstNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"First Name Should Consist Of Alphanumeric, Hypens And Period.", @"Error Message for alphabets fullName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //last name
    if ([self.lastNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Last Name.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.lastNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Last Name Length.", @"Error Message for length of fullName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.lastNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Last Name Should Consist Of Alphanumeric, Hypens And Period.", @"Error Message for alphabets fullName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if ([self.preferedNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Preferred Name Length.", @"Error Message for length of  field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Gender validation..
    if ([self.selectedGenderDict count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Gender.", @"Error Message for null gender field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Birthday validation..
    if (self.birthDate==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Date Of Birth.", @"Error Message for null birthday field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Education validation..
    if ([self.selectedEducationLoc count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Education Location.", @"Error Message for null education location field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Education validation..
    if ([self.selectedEducation count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Education.", @"Error Message for null education field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(void)loadValuesFromUserDefaults{
    NSDictionary *savedDataDict=[[NSUserDefaults standardUserDefaults] dictionaryForKey:[CLCommon sharedInstance].userName];
    
    //Nationality Array
    self.selectedNationalityArray=[[savedDataDict objectForKey:kCLUserDefaultsProfileNationalityKey] mutableCopy];
    self.shouldShowFooter=YES;
    
    //country
    self.selctedCountry=[savedDataDict objectForKey:kCLUserDefaultsProfileCountryKey];
    
    //FUll name
    self.firstNameText=[savedDataDict objectForKey:kCLUserDefaultsProfileFirstName];
    
    //Nickname
    self.lastNameText=[savedDataDict objectForKey:kCLUserDefaultsProfileLastName];
    
    //Prefered name
    self.preferedNameText=[savedDataDict objectForKey:kCLUserDefaultsProfilePreferedName];
    
    //email
    self.emailText=[CLUserObject currentUser].email;//[savedDataDict objectForKey:kCLUserDefaultsProfileEmail];
    
    //Gender
    self.selectedGenderDict=[[savedDataDict objectForKey:kCLUserDefaultsProfileGenderKey] mutableCopy];
    
    //BirthDate
    self.birthDate=[savedDataDict objectForKey:kCLUserDefaultsProfileBirthDate];
    [self.datePicker setDate:self.birthDate];
    
    //Education
    self.selectedEducation=[savedDataDict objectForKey:kCLUserDefaultsProfileEducation];
    
    //Education Location
    self.selectedEducationLoc=[savedDataDict objectForKey:kCLUserDefaultsProfileEducationLocation];
}

-(void)saveFieldValuesToUserDefaults{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *savedDataDict=nil;
    if ([defaults dictionaryForKey:[CLCommon sharedInstance].userName]) {
        savedDataDict=[[defaults dictionaryForKey:[CLCommon sharedInstance].userName] mutableCopy];
    }
    else{
        savedDataDict=[[NSMutableDictionary alloc] init];
    }
    
    //save Country
    [savedDataDict setObject:self.selctedCountry forKey:kCLUserDefaultsProfileCountryKey];
    
    //save Nationality
    [savedDataDict setObject:self.selectedNationalityArray forKey:kCLUserDefaultsProfileNationalityKey];
    
    //save firstname
    [savedDataDict setObject:self.firstNameText forKey:kCLUserDefaultsProfileFirstName];
    
    //save Lastname
    [savedDataDict setObject:self.lastNameText forKey:kCLUserDefaultsProfileLastName];
    
    //save preffered name
    [savedDataDict setObject:self.preferedNameText forKey:kCLUserDefaultsProfilePreferedName];
    
    //save email
    [savedDataDict setObject:@"" forKey:kCLUserDefaultsProfileEmail];
    
    //save Gender
    if ([self.selectedGenderDict count]>0) {
        [savedDataDict setObject:self.selectedGenderDict forKey:kCLUserDefaultsProfileGenderKey];
    }
    
    //save Birthdate
    [savedDataDict setObject:self.birthDate forKey:kCLUserDefaultsProfileBirthDate];
    
    //save Education
    [savedDataDict setObject:self.selectedEducation forKey:kCLUserDefaultsProfileEducation];
    
    //save Education Location
    [savedDataDict setObject:self.selectedEducationLoc forKey:kCLUserDefaultsProfileEducationLocation];

    [defaults setObject:savedDataDict forKey:[CLCommon sharedInstance].userName];
    
    [defaults synchronize];
}

//-(BOOL) validateAlphabets: (NSString *)alpha{
//    //NSString *abnRegex = @"[A-Za-z]+";    //alphabets only
//    NSString *abnRegex = @"[a-zA-Z][a-zA-Z ]+";    //alphabets and space
//    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
//    BOOL isValid = [abnTest evaluateWithObject:alpha];
//    return isValid;
//}

//-(NSString*)getBirthdayStringForDate:(NSDate*)date{
//    NSString *localFormat = [NSDateFormatter dateFormatFromTemplate:@"MMMMdy" options:0 locale:[NSLocale currentLocale]];
//    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
//    [dateFormatter setLocale:[NSLocale currentLocale]];
//    //dateFormatter.dateStyle=NSDateFormatterMediumStyle;
//    dateFormatter.dateFormat=localFormat;
//    NSString *dateString=[dateFormatter stringFromDate:date];
//    return dateString;
//}

-(void)regsiterTableForCellReuse{
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"firstNameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"lastNameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"preferedNameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"emailTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"genderTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"birthdayTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"educationTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"educationLocationCellIdentifier"];
    
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"nationalityCellIdentifier"];
}

#pragma mark CLTappableCellDelegate Methods

- (void)cellDidTapCellTextField:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==TableSectionIndexNationality) {
        CLSelectNationalityViewController *selectNationalityView=[[CLSelectNationalityViewController alloc] initWithStyle:UITableViewStylePlain];
        selectNationalityView.delegate=self;
        selectNationalityView.alreadyListedNationalities=self.selectedNationalityArray;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectNationalityView];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if(indexPath.section == TableSectionIndexOthers && indexPath.row == TableRowIndexEducation){
        CLSelectEducationViewController *selectEducationView=[[CLSelectEducationViewController alloc] initWithStyle:UITableViewStylePlain];
        selectEducationView.delegate=self;
        selectEducationView.cyCode = [self.selectedEducationLoc objectForKey:@"jobLocationCountryCode"];
        selectEducationView.alreadySelectedEduLevel = self.selectedEducation;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectEducationView];
        [self presentViewController:nav animated:YES completion:nil];
    }else if (indexPath.section == TableSectionIndexOthers && indexPath.row == TableRowIndexEducationLocation){
        
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
        
    }
    else if (indexPath.section == TableSectionIndexCountry){
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        self.forCountry=YES;
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
}

- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField
{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == TableSectionIndexOthers)
    {
        switch (indexPath.row) {
            case TableRowIndexEducation:
                self.selectedEducation = nil;
                break;
                
            case TableRowIndexEducationLocation:
                self.selectedEducationLoc = nil;
                break;
                
            default:
                break;
        }
    }
    [self.tableView reloadData];
}

#pragma mark CLSelectLocationDelegate

- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
        [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
        self.selctedCountry=locDict;
        self.selectedEducationLoc = locDict;
        self.forCountry=NO;
    }
    else{
        self.selectedEducationLoc=locDict;
    }
    
    [self.tableView reloadData];
}
#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

-(void)cellShouldReturn:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    switch (cell.cellIndexPath.row) {
        case TableRowIndexFirstName:{
            CLSimpleTextCell *cell = (CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:1]];
            [cell becomeFirstResponder];
        }
            break;
        case TableRowIndexLastName:{
            CLSimpleTextCell *cell = (CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:1]];
            [cell becomeFirstResponder];
        }
            break;
        case TableRowIndexPreferedName:{
            CLSimpleTextCell *cell = (CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:1]];
            [cell becomeFirstResponder];
        }
            return;
            
        default:
            break;
    }
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    if (indexPath.section==TableSectionIndexOthers) {
        switch (indexPath.row) {
            case TableRowIndexBirthDay:{
                self.birthDate=nil;
                break;
            }
            case TableRowIndexGender:{
                self.selectedGenderDict=nil;
                break;
            }
            default:
                break;
        }
    }
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    if (indexPath.section==TableSectionIndexOthers) {
        switch (indexPath.row) {
            case TableRowIndexFirstName:{
                self.firstNameText=text;
                break;
            }
            case TableRowIndexLastName:{
                self.lastNameText=text;
                break;
            }
            case TableRowIndexPreferedName:{
                self.preferedNameText=text;
                break;
            }
            case TableRowIndexBirthDay:{
                break;
            }
                
            default:
                break;
        }
    }
}

#pragma mark CLSelectNationalityDelegate Methods

- (void)selectNationalityControllerDidSelectNationality:(CLSelectNationalityViewController*)controller withArray:(NSMutableArray *)nationalityArray{
    if([self.selectedNationalityArray count]==0){
        self.selectedNationalityArray=nationalityArray;
    }
    else{
        [self.selectedNationalityArray addObjectsFromArray:nationalityArray];
    }
    self.shouldShowFooter=YES;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:TableSectionIndexNationality] withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.selectedNationalityArray count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)selectEducationControllerDidSelectEducation:(CLSelectEducationViewController*)controller withDict:(NSMutableDictionary *)eduDict{
    self.selectedEducation=eduDict;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:TableSectionIndexOthers] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - IBActions

-(IBAction)bttnActionGotoNextPage:(id)sender{
    if([self isFieldsValid]){
        [self saveFieldValuesToUserDefaults];
        CLEmploymentDetailsViewController *employmentsView=[[CLEmploymentDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:employmentsView animated:YES];
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(IBAction)bttnActionGotoBack:(id)sender{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *logout = [[UIActionSheet alloc]initWithTitle:NSLocalizedString(@"Are You Sure You Want To Logout?", @"Message for logout validation") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"cancel button title") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Yes", @"log out confirm button title"), nil];
        [logout showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Are You Sure You Want To Logout?", @"Message for logout validation") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @" selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *yesAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Yes", @"log out confirm button title") style:UIAlertActionStyleDefault handler:^(UIAlertAction*action){
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:yesAction];
        [self presentViewController:actionSheetController animated:YES completion:nil];
        
    }
}

- (IBAction)bttnActionAddNationality:(id)sender {
    CLSelectNationalityViewController *selectNationalityView=[[CLSelectNationalityViewController alloc] initWithStyle:UITableViewStylePlain];
    selectNationalityView.delegate=self;
    selectNationalityView.alreadyListedNationalities=self.selectedNationalityArray;
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectNationalityView];
    [self presentViewController:nav animated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDone:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if (cell!=nil) {
        if (cell.cellIndexPath.section==TableSectionIndexOthers && cell.cellIndexPath.row==TableRowIndexBirthDay) {
            if (self.birthDate==nil || !([self.birthDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.birthDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        else if(cell.cellIndexPath.section==TableSectionIndexOthers && cell.cellIndexPath.row==TableRowIndexGender){
            if (self.pickerView.tag==1)
            {
                self.selectedGenderDict=[self.genderArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
                [cell setCellText:[[self.genderArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] objectForKey:kGenderOptionTitle]];
            }
            [self.tableView reloadData];
        }
    }
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.birthDate=date;
    
    CLSimpleTextCell *birthdayCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:TableRowIndexBirthDay inSection:TableSectionIndexOthers]];
    [birthdayCell setCellText:[CLCommon getStringForDate:self.birthDate andLocalFormat:@"MMMMdy"]];
    
//    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:TableCellIndexBirthDay]] withRowAnimation:UITableViewRowAnimationAutomatic];
//    [self.txtFirstResponder becomeFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(section==TableSectionIndexNationality){
        if([self.selectedNationalityArray count]==0){
            self.shouldShowFooter=NO;
            return 1;
        }
        else{
            return [self.selectedNationalityArray count];
        }
    }
    else if (section==TableSectionIndexCountry){
        return 1;
    }
    else{
        return 8;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==TableSectionIndexNationality){
        CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nationalityCellIdentifier"];
        cell.delegate=self;
        cell.cellIndexPath=indexPath;
        if([self.selectedNationalityArray count]==0){
            [cell setCellText:@""];
        }
        else{
            [cell setCellText:[[self.selectedNationalityArray objectAtIndex:indexPath.row] objectForKey:knationalityDictName]];
        }
        [cell setPlaceHoldrText:NSLocalizedString(@"Nationality", @"nationality placeholder")];
        [cell updateTapStatus];
        return cell;
    }
    else if (indexPath.section == TableSectionIndexCountry){
        CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nationalityCellIdentifier"];
        cell.delegate=self;
        if (self.selctedCountry!=nil) {
            [cell setCellText:[self.selctedCountry objectForKey:@"jobLocationCountryName"]];
        }
        cell.cellIndexPath=indexPath;
        [cell setPlaceHoldrText:NSLocalizedString(@"Country", @"counrty placeholder")];
        return cell;

    }
    else{
        switch (indexPath.row) {
            case TableRowIndexFirstName:{
                CLSimpleTextCell *firstNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"firstNameTextCellIdentifier"];
                firstNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [firstNameCell setTextInputAccesoryView:self.keyboardDoneView];
                [firstNameCell setPlaceHoldrText:NSLocalizedString(@"First Name", @"Placeholder for name field in profile")];
                [firstNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [firstNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [firstNameCell setCellText:self.firstNameText];
                [firstNameCell setCellIndexPath:indexPath];
                [firstNameCell returnKeyType:UIReturnKeyNext];
                firstNameCell.delegate=self;
                return firstNameCell;
                break;
            }
            case TableRowIndexLastName:{
                CLSimpleTextCell *lastNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"lastNameTextCellIdentifier"];
                lastNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [lastNameCell setTextInputAccesoryView:self.keyboardDoneView];
                [lastNameCell setPlaceHoldrText:NSLocalizedString(@"Last Name", @"Placeholder for name field in profile")];
                [lastNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [lastNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [lastNameCell setCellText:self.lastNameText];
                [lastNameCell setCellIndexPath:indexPath];
                [lastNameCell returnKeyType:UIReturnKeyNext];
                lastNameCell.delegate=self;
                return lastNameCell;
                break;
            }
            case TableRowIndexPreferedName:{
                CLSimpleTextCell *nickNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"preferedNameTextCellIdentifier"];
                nickNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [nickNameCell setTextInputAccesoryView:self.keyboardDoneView];
                [nickNameCell setPlaceHoldrText:NSLocalizedString(@"Preferred Name", @"Placeholder for Preferred field in profile")];
                [nickNameCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [nickNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [nickNameCell setCellText:self.preferedNameText];
                [nickNameCell setCellIndexPath:indexPath];
                [nickNameCell returnKeyType:UIReturnKeyNext];
                nickNameCell.delegate=self;
                return nickNameCell;
                break;
            }
            case TableRowIndexEmail:{
                CLSimpleTextCell *emailCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"emailTextCellIdentifier"];
                emailCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [emailCell disableCellField];
                [emailCell setTextInputAccesoryView:self.keyboardDoneView];
                [emailCell setPlaceHoldrText:NSLocalizedString(@"Email", @"Placeholder for Preferred field in profile")];
                [emailCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [emailCell setCellText:self.emailText];
                [emailCell setCellIndexPath:indexPath];
                emailCell.delegate=self;
                return emailCell;
                break;
            }
            case TableRowIndexGender:{
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"genderTextCellIdentifier"];
                [cell setTextInputView:self.pickerView];
                [cell setTextInputAccesoryView:self.keyboardDoneToolbarWithCancel];
                [cell setPlaceHoldrText:NSLocalizedString(@"Gender", @"Placeholder for gender field in profile")];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                if (!self.selectedGenderDict) {
                    [cell setCellText:@""];
                }
                else{
                    [cell setCellText:[self.selectedGenderDict objectForKey:kGenderOptionTitle]];
                }
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
                break;
            }
            case TableRowIndexBirthDay:{
                CLSimpleTextCell *birthdayCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"birthdayTextCellIdentifier"];
                birthdayCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [birthdayCell setTextInputView:self.datePicker];
                [birthdayCell setTextInputAccesoryView:self.keyboardDoneView];
                [birthdayCell setPlaceHoldrText:NSLocalizedString(@"Date of Birth", @"Placeholder for Birthday field in profile")];
                [birthdayCell setCellClearButtonMode:UITextFieldViewModeAlways];
                //[birthdayCell setCellText:[self getBirthdayStringForDate:self.birthDate]];
                [birthdayCell setCellText:[CLCommon getStringForDate:self.birthDate andLocalFormat:@"MMMMdy"]];
                [birthdayCell setCellIndexPath:indexPath];
                birthdayCell.delegate=self;
                return birthdayCell;
                break;
            }
            case TableRowIndexEducationLocation:{
                CLSimpleTappableTextCell *educationLocCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"educationLocationCellIdentifier"];
                educationLocCell.cellIndexPath=indexPath;
                educationLocCell.delegate=self;
                
                if([self.selectedEducationLoc count]==0){
                    [educationLocCell setCellText:@""];
                    [educationLocCell setCellCloseBtnOption:YES];
                }
                else{
                    [educationLocCell setCellCloseBtnOption:NO];
                    [educationLocCell setCellText:[NSString stringWithFormat:@"%@",[self.selectedEducationLoc objectForKey:kLocationCountryName]]];
                }
                [educationLocCell setPlaceHoldrText:NSLocalizedString(@"Country", @"Country where your education was completed placeholder")];
                [educationLocCell enableTapStatus];
                return educationLocCell;
                break;
            }
            case TableRowIndexEducation:{
                CLSimpleTappableTextCell *educationCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"educationTextCellIdentifier"];
                educationCell.cellIndexPath=indexPath;
                educationCell.delegate=self;
                
                if([self.selectedEducation count]==0){
                    [educationCell setCellText:@""];
                    [educationCell setCellCloseBtnOption:YES];
                }
                else{
                    [educationCell setCellCloseBtnOption:NO];
                    [educationCell setCellText:[self.selectedEducation objectForKey:keducationDictName]];
                }
                [educationCell setPlaceHoldrText:NSLocalizedString(@"Highest Education Level", @"Education placeholder")];
                [educationCell enableTapStatus];
                return educationCell;
                break;
            }
            default:
                return nil;
                break;
        }
    }
}


#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    if([self.selectedNationalityArray count]>0){
        if(indexPath.section==TableSectionIndexNationality){
            return YES;
        }
        else{
            return NO;
        }
    }
    else{
        return NO;
    }
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if(indexPath.section==TableSectionIndexNationality){
            [self.selectedNationalityArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.selectedNationalityArray count]==0){
                [self.tableView reloadData];
            }
            else{
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section==TableSectionIndexNationality){
//        if([self.selectedNationalityArray count]>0){
            return NSLocalizedString(@"NATIONALITY", @"Title for nationality");
//        }
//        else{
//            return nil;
//        }
    }
    else if (section==TableSectionIndexCountry){
        return NSLocalizedString(@"COUNTRY", @"heling");
    }
    else{
        return NSLocalizedString(@"PROFILE", @"Title for profile");
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if(section==TableSectionIndexNationality){
        if (self.shouldShowFooter) {
            return self.tblFooter;
        }
        else{
            return nil;
        }
    }
    else{
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section==TableSectionIndexNationality){
        if (self.shouldShowFooter) {
            if ([self.selectedNationalityArray count]>0) {
                return 44;
            }
            else{
                return 0;
            }
        }
        else{
            return 0;
        }
    }
    else{
        return 0;
    }
}


#pragma mark UIPickerView Methods

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView.tag==1) {
        return [self.genderArray count];
    }
    return 0;
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = ColorCode_CareerLineGreen;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag==1) {
        label.text= [[self.genderArray objectAtIndex:row] objectForKey:kGenderOptionTitle];
    }
    return label;
}


@end
