//
//  CLCareerObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"
#import "CLConstants.h"

#define kDebugMessages 1

@implementation CLCareerObject

static NSOperationQueue *careerListingRequest;
static NSOperationQueue *saveWorkSummaryRequest;

+ (void)cancelCareerListingPendingRequest {
    [careerListingRequest cancelAllOperations];
    careerListingRequest = nil;
}


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.careerHistory= [[NSMutableArray alloc]init];
    self.summary = [dictionary objectForKeyNotNull:kCLCareerSummarykey];

    for (NSDictionary *dict in [dictionary objectForKeyNotNull:kCLCareerHistorykey]) {
        self.history = [[CLCareerHistoryObject alloc] initWithDictionary:dict];
        [self.careerHistory  addObject:self.history];
    }
    return self;
}

//Method for getting a career listing for a particular user...
+ (void)careerListingForUser:(NSString *)userId success:(void (^)(CLCareerObject *careerObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLCareerObject *careerObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [careerListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        careerListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceCareerListingURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"career detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                
                CLCareerObject *career=[[CLCareerObject alloc] initWithDictionary:response];
                success(career);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}
//Method for editing career Summary for a particular user
+(void)editCareerSummaryForUser:(NSString *)userId careerSummary:(NSString*)summary success:(void(^)(NSString *succcesMsg))success failure:(void(^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *succcesMsg){};
    }
    NSDictionary *parameters = @{@"user": userId, @"fields":[CLCareerObject jsonStringForObject:summary]};
    
    [saveWorkSummaryRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveWorkSummaryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceCareerPostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveWorkSummaryRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSString *msg=[response objectForKey:@"message"];
                success(msg);

            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(NSString*)jsonStringForObject:(NSString *)summary{
    
    NSMutableDictionary *careerDict = [[NSMutableDictionary alloc]init];
    
    [careerDict setObject:summary forKey:kCLCareerSummarykey];
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:careerDict];
}

@end
