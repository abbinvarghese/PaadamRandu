//
//  CLTelephoneObject.m
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTelephoneObject.h"
#import "NSDictionary+Additions.h"

@implementation CLTelephoneObject


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.telephoneId=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneNumberIdkey];
    self.telephoneIsdCode=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneISDCodekey];
    self.telephoneAreaCode=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneAreaCodekey];
    self.telephoneContactNumber=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneNumberkey];
    self.formattedTelephoneNumber=[self formattedNumberForDisplay];
    [[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneIsPrimarykey] isEqualToString:@"1"] ? (self.isPrimaryContact=YES) : (self.isPrimaryContact=NO);
    self.contactType=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneContactTypekey];
    
    return self;
}

-(NSDictionary*)dictionaryForObject{
    NSMutableDictionary *tempDict=[[NSMutableDictionary alloc] init];
   
    if (self.telephoneId) {
        [tempDict setObject:self.telephoneId forKey:kCLProfileAboutMeTelephoneNumberIdkey];
    }
    if (self.telephoneIsdCode) {
        [tempDict setObject:self.telephoneIsdCode forKey:kCLProfileAboutMeTelephoneISDCodekey];
    }
    if (self.telephoneAreaCode) {
        [tempDict setObject:self.telephoneAreaCode forKey:kCLProfileAboutMeTelephoneAreaCodekey];
    }
    if (self.telephoneContactNumber) {
        [tempDict setObject:self.telephoneContactNumber forKey:kCLProfileAboutMeTelephoneNumberkey];
    }
    if (self.isPrimaryContact) {
        [tempDict setObject:@"1" forKey:kCLProfileAboutMeTelephoneIsPrimarykey];
    }
    else{
        [tempDict setObject:@"0" forKey:kCLProfileAboutMeTelephoneIsPrimarykey];
    }
    if (self.contactType) {
        [tempDict setObject:self.contactType forKey:kCLProfileAboutMeTelephoneContactTypekey];
    }
    
    return tempDict;
}

-(void)updateFormattedTelephoneNumber{
    self.formattedTelephoneNumber=[self formattedNumberForDisplay];
}

-(NSString*)formattedNumberForDisplay{
    NSMutableString *formattedString=[[NSMutableString alloc] init];
    
    if (self.telephoneIsdCode.length!=0) {
        [formattedString appendFormat:@"%@-",self.telephoneIsdCode];
    }
    if (self.telephoneAreaCode.length!=0) {
        NSString *cleanedStr = [self.telephoneAreaCode stringByReplacingOccurrencesOfString:@"^0+"
                                                           withString:@""
                                                              options:NSRegularExpressionSearch
                                                                range:NSMakeRange(0, self.telephoneAreaCode.length)];
        [formattedString appendFormat:@"%@-",cleanedStr];
    }
    if (self.telephoneContactNumber.length!=0) {
        NSString *cleanedStr = [self.telephoneContactNumber stringByReplacingOccurrencesOfString:@"^0+"
                                                                                 withString:@""
                                                                                    options:NSRegularExpressionSearch
                                                                                      range:NSMakeRange(0, self.telephoneContactNumber.length)];
        [formattedString appendFormat:@"%@-",cleanedStr];
    }
    if (formattedString.length>1) {
        [formattedString deleteCharactersInRange:NSMakeRange([formattedString length]-1, 1)];
    }
    
    return formattedString;
}

- (id)copyWithZone:(NSZone *)zone
{
    id copy = [[[self class] allocWithZone:zone] init];
    
    if (copy) {
        // Copy NSObject subclasses
        [copy setTelephoneId:[self.telephoneId copyWithZone:zone]];
        [copy setTelephoneIsdCode:[self.telephoneIsdCode copyWithZone:zone]];
        [copy setTelephoneAreaCode:[self.telephoneAreaCode copyWithZone:zone]];
        [copy setTelephoneContactNumber:[self.telephoneContactNumber copyWithZone:zone]];
        [copy setFormattedTelephoneNumber:[self.formattedTelephoneNumber copyWithZone:zone]];
        [copy setContactType:[self.contactType copyWithZone:zone]];
        
        // Set primitives
        [copy setIsPrimaryContact:self.isPrimaryContact];
    }
    
    return copy;
}

@end
