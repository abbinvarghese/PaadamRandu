//
//  CLContractPreferencesObject.m
//  CareerLine
//
//  Created by Abbin on 10/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLContractPreferencesObject.h"

@implementation CLContractPreferencesObject

-(id)initWithDictionary:(NSMutableDictionary *)dictionary{
    self = [super init];
    if (self == nil) return nil;
    self.objectId = [dictionary objectForKey:kCLContractPreferenceIDKey];
    self.currencyDict = [dictionary objectForKey:kCLContractPreferenceCurrencykey];
    self.contractTypeDict = [dictionary objectForKey:kCLContractPreferenceemploymentContractkey];
    self.employMentTypeDict = [dictionary objectForKey:kCLContractPreferenceemploymentTypekey];
    self.increaseInSalary = [dictionary objectForKey:kCLContractPreferenceIncreaseSalarykey];
    self.minimumSalary = [dictionary objectForKey:kCLContractPreferenceMinSalarykey];
    self.negotiable = [dictionary objectForKey:kCLContractPreferenceNegotiablekey];
    self.Other = [dictionary objectForKey:kCLContractConsiderationOtherkey];
    self.salaryBasisDict = [dictionary objectForKey:kCLContractPreferenceSalaryBasiskey];
    return self;
}

@end
