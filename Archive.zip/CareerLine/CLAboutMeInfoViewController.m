//
//  CLAboutMeInfoViewController.m
//  CareerLine
//
//  Created by CSG on 7/25/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAboutMeInfoViewController.h"
#import "CLPreviousNameObject.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "NSDate+Utilities.h"
#import "CLLoaderImageVIew.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLCoreDataHelper.h"

#define kSectionHeaderFont 14

#define kSectionFooterBgColor [UIColor whiteColor]
#define kSectionHeaderBgColor [UIColor clearColor]

@interface CLAboutMeInfoViewController ()

//Table section indicator...
typedef enum {
    TableSectionIndexCountry = 0,
    TableSectionIndexWhereDoYouLive = 1,
	TableSectionIndexNationality = 2,
	TableSectionIndexProfile= 3,
    TableSectionIndexPrevName= 4,
    TableSectionIndexHomeNumber= 5,
    TableSectionIndexMobileNumber= 6,
   // TableSectionIndexOtherNumber= 5,
    TableSectionIndexCurrentAddress= 7,
    TableSectionIndexOtherAddress= 8,
    TableSectionTotalCount=9
} TableSectionIndex;

//Table profile row indicator...
typedef enum {
    TableRowProfileIndexGender = 0,
	TableRowProfileIndexSalutation= 1,
    TableRowProfileIndexFirstName = 2,
    TableRowProfileIndexMiddleName = 3,
    TableRowProfileIndexLastName = 4,
    TableRowProfileIndexNickName = 5,
    TableRowProfileIndexBirthDay = 6,
    TableRowProfileIndexEmail = 7,
    TableRowProfileIndexAltEmail = 8,
    TableRowProfileIndexSkypeName = 9,
    TableRowProfileTotalCount=10
} TableProfileRowIndex;

@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *profilePhotoView;
@property (strong, nonatomic) UIPickerView *pickerView;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property(nonatomic,retain)NSMutableDictionary *selectedCountry;

@property(nonatomic,strong)NSMutableArray *selectedNationalityArray;
@property(nonatomic,strong)NSMutableArray *selectedPrevNameArray;
//@property(nonatomic,strong)NSMutableArray *selectedOtherNumberArray;
@property(nonatomic,strong)NSMutableArray *selectedOtherAddressArray;
@property(nonatomic,strong)CLLocationObject *selectedCurrentAddressObj;
@property(nonatomic,strong)CLTelephoneObject *selectedHomeNumberObj;
@property(nonatomic,strong)CLTelephoneObject *selectedMobileNumberObj;

@property(nonatomic,strong)NSMutableArray *salutationList;
@property(nonatomic,strong)NSMutableArray *genderList;
@property(nonatomic,strong)NSMutableDictionary *selectedSalutationDict;
@property(nonatomic,strong)NSMutableDictionary *selectedGenderDict;
@property(nonatomic,retain)NSMutableDictionary *selectedWhereDoYouLive;
@property(nonatomic,strong)NSString *firstNameText;
@property(nonatomic,strong)NSString *middleNameText;
@property(nonatomic,strong)NSString *lastNameText;
@property(nonatomic,strong)NSString *nickNameText;
@property(nonatomic,strong)NSDate *selectedBirthDate;
@property(nonatomic,strong)NSString *emailText;
@property(nonatomic,strong)NSString *altEmailText;
@property(nonatomic,strong)NSString *skypeNameText;
@property(nonatomic,assign) BOOL forCountry;


@end

@implementation CLAboutMeInfoViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=NSLocalizedString(@"Info", @"Info");
    [self setRightNavigationButton];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"empIndustryTextCellIdentifier"];
    
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"wheredoyouliveCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"salutationCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"firstnameCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"middlenameCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"lastnameCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"nicknameCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"birthdayCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"genderCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"emailCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"alternateEmailCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"skypenameCellIdentifier"];
    
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[[NSDate date] dateBySubtractingYears:13]];
    [datePickr setMinimumDate:[[NSDate date] dateBySubtractingYears:80]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setDate:[CLUserObject currentUser].birthDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    [self loadDataSource];
    self.tableView.tableHeaderView=self.tblHeaderView;
    [self updateTableHeaderDetails];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [self.tableView reloadData];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - About Me - Info"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveInfoAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)updateTableHeaderDetails{
    [self.profilePhotoView setImageWithUrlString:self.info.profileImage.file];
}

-(void)loadDataSource{
    //initialize arrays..
    self.selectedWhereDoYouLive=[[NSMutableDictionary alloc]init];
    self.selectedCountry=[[NSMutableDictionary alloc]init];
    //self.selectedNationalityArray=[[NSMutableArray alloc] init];
    self.selectedPrevNameArray=[[NSMutableArray alloc] init];
    //self.selectedOtherNumberArray=[[NSMutableArray alloc] init];
    self.selectedOtherAddressArray=[[NSMutableArray alloc] init];
    self.selectedCurrentAddressObj=[[CLLocationObject alloc] init];
    self.selectedHomeNumberObj=[[CLTelephoneObject alloc] init];
    self.selectedMobileNumberObj=[[CLTelephoneObject alloc] init];
    self.selectedSalutationDict=[[NSMutableDictionary alloc] init];
    self.selectedGenderDict=[[NSMutableDictionary alloc] init];
    
    self.salutationList=[[NSMutableArray alloc] init];
   // self.genderList=[[NSMutableArray alloc] init];
    
    //load arrays from object..
    self.selectedNationalityArray=[self.info.nationalities mutableCopy];
    self.selectedCountry= [self.info.country mutableCopy];
    self.selectedPrevNameArray=[self.info.previousname mutableCopy];
    [self.selectedWhereDoYouLive setObject:self.info.currentLocation.locationCode forKey:@"jobLocationCode"];
    [self.selectedWhereDoYouLive setObject:self.info.currentLocation.countryName forKey:@"jobLocationCountryName"];
    [self.selectedWhereDoYouLive setObject:self.info.currentLocation.adminArea forKey:@"jobLocationAdminArea"];
    [self.selectedWhereDoYouLive setObject:self.info.currentLocation.locationCode forKey:@"jobLocationCountryCode"];
    [self.selectedWhereDoYouLive setObject:self.info.currentLocation.locName forKey:@"jobLocationName"];
    
    //self.selectedOtherNumberArray=[self.info.telephoneNumbers mutableCopy];
    self.selectedOtherAddressArray=[self.info.otherAddresses mutableCopy];
    self.selectedCurrentAddressObj=[self.info.currentLocation copy];
    self.selectedHomeNumberObj=[self.info.homeNumber copy];
    self.selectedMobileNumberObj=[self.info.mobileNumber copy];
    self.selectedSalutationDict=[self.info.salutation mutableCopy];
    self.selectedGenderDict=[self.info.gender mutableCopy];
    self.firstNameText=[self.info.firstName copy];
    self.middleNameText=[self.info.middleName copy];
    self.lastNameText=[self.info.lastName copy];
    self.nickNameText=[self.info.nickname copy];
    self.selectedBirthDate=[self.info.dob copy];
    [self.datePicker setDate:self.selectedBirthDate];
    self.emailText=[self.info.email copy];
    self.altEmailText=[self.info.alternateEmail copy];
    self.skypeNameText= [self.info.skypeName copy];
    
    [self updateSalutaionList];

    self.genderList=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllGenderListFromDB]mutableCopy];
    
    [self.tableView reloadData];
}

-(void)updateSalutaionList{
    self.salutationList=[[CLCoreDataHelper sharedCLCoreDataHelper] getSalutationsListforNationality:[self selectedNationalityCodeStringFromArray:[NSMutableArray arrayWithObject:self.selectedCountry]]];
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    
    //Nationality Validaton..
    if ([self.selectedNationalityArray count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select A Nationality.", @"Error Message for null nationality field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Gender Validation..
    if ([self.selectedGenderDict count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Gender.", @"Error Message for null gender field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Salutation Validation..
    if ([self.selectedSalutationDict count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Salutation.", @"Error Message for null salutation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if (self.selectedSalutationDict!=nil) {
        if ([[self.selectedSalutationDict objectForKey:@"salutationId"] isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Salutation.", @"Error Message for null salutation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
    }
    
    //First Name validation..
    if ([self.firstNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter First Name.", @"Error Message for null firstName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.firstNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check First Name Length.", @"Error Message for length of firstname field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.firstNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"First Name Should Consist Of Alphanumeric,Hypens And Period.", @"Error Message for alphabets firstName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Middle Name validation..
//    if ([self.middleNameText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter middle name.", @"Error Message for null middleName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    if ([self.middleNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Middle Name Length.", @"Error Message for length of middlename field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if(![self.middleNameText isEqualToString:@""]){
        if (![CLCommon validateAlphabetsAndSpace:self.middleNameText]){
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Middle Name Should Consist Of Alphanumeric,Hypens And Period.", @"Error Message for alphabets middle field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
    }
    
    //Last Name validation..
    if ([self.lastNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Last Name.", @"Error Message for null lastName field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.lastNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Last Name Length.", @"Error Message for length of lastname field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.lastNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Last Name Should Consist Of Alphanumeric,Hypens And Period.", @"Error Message for alphabets last field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Nick name validation..
//    if ([self.nickNameText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter nickname.", @"Error Message for null nickname field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    else if ([self.nickNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Nickname Length.", @"Error Message for length of nickname field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Birthday validation..
    if (self.selectedBirthDate==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Birthday.", @"Error Message for null birthday field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Email validation..
    if ([self.emailText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Email Address Is Empty.", @"Error Message for null email address field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
	}
    else if (![CLCommon validateEmailWithString:self.emailText]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Email Address Is Not Valid.", @"Error Message for invalid email address") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Alternate Email Validation..
    if (![self.altEmailText isEqualToString:@""]) {
        if (![CLCommon validateEmailWithString:self.altEmailText]) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter A Valid Alternate Email Address.", @"Error Message for invalid email address") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
    }
    
    //Contact NUmber Validation..
    if (self.selectedHomeNumberObj.telephoneContactNumber==nil && self.selectedMobileNumberObj.telephoneContactNumber==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Home Or Mobile Number", @"Error Message for contact number") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Primary Contact Validation..
    if (!self.selectedHomeNumberObj.isPrimaryContact && !self.selectedMobileNumberObj.isPrimaryContact) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Primary Contact Number", @"Error Message for primary contact number") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Communication Address Validation..
    if (!self.selectedCurrentAddressObj.isCommunicationAddress && ![self isCommnAddressPresentInOtherAddresses]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Your Communication Address", @"Error Message for Communication Address") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
//    if ([CLCommon doesItHaveSpace:[self.skypeNameText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Skype Name", @"Error Message for skype name") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    
    return isValid;
}

-(BOOL)isCommnAddressPresentInOtherAddresses{
    for (int i=0; i<[self.selectedOtherAddressArray count]; i++) {
        if (((CLLocationObject*)[self.selectedOtherAddressArray objectAtIndex:i]).isCommunicationAddress) {
            return YES;
            break;
        }
    }
    return NO;
}


-(NSMutableString*)selectedNationalityCodeStringFromArray:(NSArray*)nationalities{
    NSMutableString *string=[[NSMutableString alloc] init];
    if ([nationalities count]>0) {
        for (int i=0; i<[nationalities count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[nationalities objectAtIndex:i] objectForKey:@"countryCode"]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
    }
    return string;
}

-(NSInteger)getNumberOfRowsforSection:(NSInteger)section{
    switch (section) {
            case TableSectionIndexWhereDoYouLive:
            return 1;
            break;
            case TableSectionIndexCountry:
            return 1;
            break;
        case TableSectionIndexNationality:
        {
            return [self.selectedNationalityArray count];
            break;
        }
        case TableSectionIndexProfile:
            return TableRowProfileTotalCount;
            break;
        case TableSectionIndexPrevName:
            return [self.selectedPrevNameArray count];
            break;
        case TableSectionIndexHomeNumber:
            if (self.selectedHomeNumberObj.telephoneContactNumber==nil || [self.selectedHomeNumberObj.telephoneContactNumber isEqualToString:@""]) {
                return 0;
            }
            return 1;
            break;
        case TableSectionIndexMobileNumber:
            if (self.selectedMobileNumberObj.telephoneContactNumber==nil || [self.selectedMobileNumberObj.telephoneContactNumber isEqualToString:@""]) {
                return 0;
            }
            return 1;
            break;
//        case TableSectionIndexOtherNumber:
//            return [self.selectedOtherNumberArray count];
//            break;
        case TableSectionIndexCurrentAddress:
            return 1;
            break;
        case TableSectionIndexOtherAddress:
            return [self.selectedOtherAddressArray count];
            break;
        default:
            return 0;
            break;
    }
}

-(NSString*)getSectionTitleforSection:(NSInteger)section{
    switch (section) {
            case TableSectionIndexWhereDoYouLive:
            return NSLocalizedString(@"Where Do You Live?", @"section title");
            break;
            case TableSectionIndexCountry:
            return NSLocalizedString(@"Country", @"section title");
            break;
        case TableSectionIndexNationality:
            return NSLocalizedString(@"Nationalities", @"Section Title");
            break;
        case TableSectionIndexProfile:
            return NSLocalizedString(@"Info", @"Section Title");
            break;
        case TableSectionIndexPrevName:
            return NSLocalizedString(@"Previous Name(s)", @"Section Title");
            break;
        case TableSectionIndexHomeNumber:
            return NSLocalizedString(@"Home Number", @"Section Title");
            break;
        case TableSectionIndexMobileNumber:
            return NSLocalizedString(@"Mobile Number", @"Section Title");
            break;
//        case TableSectionIndexOtherNumber:
//            return NSLocalizedString(@"Other Number(s)", @"Section Title");
//            break;
        case TableSectionIndexCurrentAddress:
            return NSLocalizedString(@"Current Address", @"Section Title");
            break;
        case TableSectionIndexOtherAddress:
            return NSLocalizedString(@"Other Address(es)", @"Section Title");
            break;
        default:
            return nil;
            break;
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)saveInfoDetails{
    CLInfoObject *tempInfoObj=[[CLInfoObject alloc] init];
    tempInfoObj.country = self.selectedCountry;
    tempInfoObj.infoId=[self.info.infoId copy];
    tempInfoObj.profileImage=[self.info.profileImage copy];
    tempInfoObj.salutation=self.selectedSalutationDict;
    tempInfoObj.firstName=self.firstNameText;
    tempInfoObj.middleName=self.middleNameText;
    tempInfoObj.lastName=self.lastNameText;
    [tempInfoObj updateFormattedName];
    tempInfoObj.nickname=self.nickNameText;
    tempInfoObj.previousname=self.selectedPrevNameArray;
    tempInfoObj.skypeName=self.skypeNameText;
    tempInfoObj.gender=self.selectedGenderDict;
    tempInfoObj.homeNumber=self.selectedHomeNumberObj;
    tempInfoObj.mobileNumber=self.selectedMobileNumberObj;
    //tempInfoObj.telephoneNumbers=self.selectedOtherNumberArray;
    tempInfoObj.email=self.emailText;
    tempInfoObj.alternateEmail=self.altEmailText;
    tempInfoObj.dob=self.selectedBirthDate;
    tempInfoObj.currentLocation=self.selectedCurrentAddressObj;
    tempInfoObj.otherAddresses=self.selectedOtherAddressArray;
    tempInfoObj.nationalities=self.selectedNationalityArray;
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view animated:YES];
    
    self.navigationItem.hidesBackButton=YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLInfoObject saveInfo:tempInfoObj forUser:[CLUserObject currentUser].userID
                   success:^(){
                       self.info=tempInfoObj;
                       [CLUserObject currentUser].country = tempInfoObj.country;
                       [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                   }
                   failure:^(NSString *error){
                       if (![error isEqualToString:@""]) {
                           self.navigationItem.hidesBackButton=NO;
                           self.navigationItem.rightBarButtonItem.enabled=YES;
                           [progressHUD hideWithAnimation:YES];
                           [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Info. Please try again later.", @"Error message when innfo cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                       }
                   }];
}

-(void)uploadProfilePicture:(UIImage*)image{
    float imageSize=(float)UIImageJPEGRepresentation(image, 1).length/1024.0f/1024.0f;
    if (imageSize<5.0) {
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [progressHUD showInView:self.view];
        self.navigationItem.hidesBackButton=YES;
        self.navigationItem.rightBarButtonItem.enabled=NO;
        
        [CLInfoObject uploadPrimaryImage:image forUser:[CLUserObject currentUser].userID imageId:self.info.profileImage.fileId
                                 success:^(CLFileObject *imageObj){
                                     [progressHUD hideWithAnimation:YES];
                                     self.navigationItem.hidesBackButton=NO;
                                     self.navigationItem.rightBarButtonItem.enabled=YES;
                                     self.info.profileImage=imageObj;
                                     [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterProfileImageChanged object:imageObj];
                                     [self updateTableHeaderDetails];
                                 }
                                 failure:^(NSString *error) {
                                     if (![error isEqualToString:@""]) {
                                         [progressHUD hideWithAnimation:YES];
                                         self.navigationItem.hidesBackButton=NO;
                                         self.navigationItem.rightBarButtonItem.enabled=YES;
                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                     }
                                 }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Image size too large to upload. Please try uploading a smaller image", @"Image upload error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return TableSectionTotalCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self getNumberOfRowsforSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==TableSectionIndexNationality)
    {
        [self.tableView setAllowsSelectionDuringEditing:YES];
        if ([self.selectedNationalityArray count]>0)
            [self.tableView setEditing:YES animated:YES];
    }

    if (indexPath.section==TableSectionIndexNationality) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"nationalityCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"nationalityCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
        }
        cell.textLabel.text=[[self.selectedNationalityArray objectAtIndex:indexPath.row] objectForKey:knationalityDictName];
        return cell;
    }
    
    else if (indexPath.section==TableSectionIndexWhereDoYouLive){
        CLSimpleTappableTextCell *wherelive = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"wheredoyouliveCellIdentifier"];
        [wherelive setPlaceHoldrText:NSLocalizedString(@"Where Do You Live?", @"Placeholder text")];
        wherelive.delegate=self;
        if (self.selectedWhereDoYouLive) {
            [wherelive setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedWhereDoYouLive objectForKey:kLocationName],[self.selectedWhereDoYouLive objectForKey:kLocationAdminArea],[self.selectedWhereDoYouLive objectForKey:kLocationCountryName]]];
        }
        else{
            [wherelive setCellText:@""];
        }
        [wherelive setCellFont:[UIFont systemFontOfSize:13]];
        [wherelive setCellIndexPath:indexPath];
        return wherelive;

    }
    
    else if (indexPath.section == TableSectionIndexCountry){
        CLSimpleTappableTextCell *unctionCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empIndustryTextCellIdentifier"];
        [unctionCell setPlaceHoldrText:NSLocalizedString(@"Country", @"Placeholder text")];
        unctionCell.delegate=self;
        [unctionCell setCellFont:[UIFont systemFontOfSize:13]];
//        if (self.selectedindustry.count  != 0) {
//            [unctionCell setCellText:[NSString stringWithFormat:@"%@ %@",[[self.selectedindustry objectAtIndex:0]objectForKey:@"industry"],[[self.selectedindustry objectAtIndex:0]objectForKey:@"industryGroupName"]]];
//        }
        if (self.selectedCountry) {
            [unctionCell setCellText:[self.selectedCountry objectForKey:@"country"]];
        }
        [unctionCell setCellIndexPath:indexPath];
        return unctionCell;
    }
    
    else if (indexPath.section==TableSectionIndexPrevName){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"prevNameCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"prevNameCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        cell.textLabel.text=((CLPreviousNameObject*)[self.selectedPrevNameArray objectAtIndex:indexPath.row]).name;
        cell.detailTextLabel.text=[CLCommon getStringForDate:((CLPreviousNameObject*)[self.selectedPrevNameArray objectAtIndex:indexPath.row]).nameDate andLocalFormat:@"MMMMdy"];
        return cell;
    }
    else if (indexPath.section==TableSectionIndexHomeNumber){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"homeNumberCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"homeNumberCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        cell.textLabel.text=self.selectedHomeNumberObj.formattedTelephoneNumber;
        if (self.selectedHomeNumberObj.isPrimaryContact) {
            cell.detailTextLabel.text=[NSString stringWithFormat:@"%@ (%@)",[self.selectedHomeNumberObj.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey],NSLocalizedString(@"Primary Contact", @"Primary Contact")];
        }
        else{
            cell.detailTextLabel.text=[self.selectedHomeNumberObj.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey];
        }
        return cell;
    }
    else if (indexPath.section==TableSectionIndexMobileNumber){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"mobileNumberCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"mobileNumberCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        cell.textLabel.text=self.selectedMobileNumberObj.formattedTelephoneNumber;
        if (self.selectedMobileNumberObj.isPrimaryContact) {
            cell.detailTextLabel.text=[NSString stringWithFormat:@"%@ (%@)",[self.selectedMobileNumberObj.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey],NSLocalizedString(@"Primary Contact", @"Primary Contact")];
        }
        else{
            cell.detailTextLabel.text=[self.selectedMobileNumberObj.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey];
        }
        
        
        return cell;
    }
//    else if (indexPath.section==TableSectionIndexOtherNumber){
//        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"otherNumberCellIdentifier"];
//        if (cell==nil) {
//            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"otherNumberCellIdentifier"];
//            cell.selectionStyle=UITableViewCellSelectionStyleNone;
//            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
//            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
//        }
//        cell.textLabel.text=((CLTelephoneObject*)[self.selectedOtherNumberArray objectAtIndex:indexPath.row]).formattedTelephoneNumber;
//        if (((CLTelephoneObject*)[self.selectedOtherNumberArray objectAtIndex:indexPath.row]).isPrimaryContact) {
//            cell.detailTextLabel.text=[NSString stringWithFormat:@"%@ (%@)",[((CLTelephoneObject*)[self.selectedOtherNumberArray objectAtIndex:indexPath.row]).contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey],NSLocalizedString(@"Primary Contact", @"Primary Contact")];
//        }
//        else{
//            cell.detailTextLabel.text=[((CLTelephoneObject*)[self.selectedOtherNumberArray objectAtIndex:indexPath.row]).contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey];
//        }
//        
//        return cell;
//    }
    else if (indexPath.section==TableSectionIndexCurrentAddress){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"currentAddressCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"currentAddressCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        NSLog(@"%@",self.selectedCurrentAddressObj.formattedAddress);
        cell.textLabel.text=self.selectedCurrentAddressObj.formattedAddress;
        if (self.selectedCurrentAddressObj.isCommunicationAddress) {
            cell.detailTextLabel.text=NSLocalizedString(@"Communication Address", @"Communication Address");
        }
        else{
            cell.detailTextLabel.text=@"";
        }
        
        return cell;
    }
    else if (indexPath.section==TableSectionIndexOtherAddress){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"otherAddressCellIdentifier"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"otherAddressCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
            [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        cell.textLabel.text=((CLLocationObject*)[self.selectedOtherAddressArray objectAtIndex:indexPath.row]).formattedAddress;
        if (((CLLocationObject*)[self.selectedOtherAddressArray objectAtIndex:indexPath.row]).isCommunicationAddress) {
            cell.detailTextLabel.text=NSLocalizedString(@"Communication Address", @"Communication Address");
        }
        else{
            cell.detailTextLabel.text=@"";
        }
        return cell;
    }
    else if (indexPath.section==TableSectionIndexProfile){
        switch (indexPath.row) {
            case TableRowProfileIndexSalutation:{
                CLSimpleTextCell *salutationCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"salutationCellIdentifier"];
                salutationCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [salutationCell setTextInputView:self.pickerView];
                [salutationCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [salutationCell setPlaceHoldrText:NSLocalizedString(@"Salutation", @"Placeholder text")];
                [salutationCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [salutationCell setCellText:[self.selectedSalutationDict objectForKey:kSalutationOptionTitle]];
                [salutationCell setCellIndexPath:indexPath];
                salutationCell.delegate=self;
                if ([self.selectedNationalityArray count]==0) {
                    [salutationCell disableCellField];
                }
                else{
                    [salutationCell enableCellField];
                }
                return salutationCell;
                break;
            }
            case TableRowProfileIndexFirstName:{
                CLSimpleTextCell *firstNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"firstnameCellIdentifier"];
                firstNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [firstNameCell setTextInputAccesoryView:self.keyboardResignView];
                [firstNameCell setPlaceHoldrText:NSLocalizedString(@"First Name", @"Placeholder text")];
                [firstNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [firstNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [firstNameCell setCellText:self.firstNameText];
                [firstNameCell setCellIndexPath:indexPath];
                firstNameCell.delegate=self;
                return firstNameCell;
                break;
            }
            case TableRowProfileIndexMiddleName:{
                CLSimpleTextCell *middleNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"middlenameCellIdentifier"];
                middleNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [middleNameCell setTextInputAccesoryView:self.keyboardResignView];
                [middleNameCell setPlaceHoldrText:NSLocalizedString(@"Middle Name", @"Placeholder text")];
                [middleNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [middleNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [middleNameCell setCellText:self.middleNameText];
                [middleNameCell setCellIndexPath:indexPath];
                middleNameCell.delegate=self;
                return middleNameCell;
                break;
            }
            case TableRowProfileIndexLastName:{
                CLSimpleTextCell *lastNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"lastnameCellIdentifier"];
                lastNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [lastNameCell setTextInputAccesoryView:self.keyboardResignView];
                [lastNameCell setPlaceHoldrText:NSLocalizedString(@"Last Name", @"Placeholder text")];
                [lastNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [lastNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [lastNameCell setCellText:self.lastNameText];
                [lastNameCell setCellIndexPath:indexPath];
                lastNameCell.delegate=self;
                return lastNameCell;
                break;
            }
            case TableRowProfileIndexNickName:{
                CLSimpleTextCell *nickNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nicknameCellIdentifier"];
                nickNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [nickNameCell setTextInputAccesoryView:self.keyboardResignView];
                [nickNameCell setPlaceHoldrText:NSLocalizedString(@"Nickname", @"Placeholder text")];
                [nickNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [nickNameCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [nickNameCell setCellText:self.nickNameText];
                [nickNameCell setCellIndexPath:indexPath];
                nickNameCell.delegate=self;
                return nickNameCell;
                break;
            }
            case TableRowProfileIndexBirthDay:{
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"birthdayCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.datePicker];
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                [dateCell setPlaceHoldrText:NSLocalizedString(@"Birthdate", @"Placeholder for date field")];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [dateCell setCellText:[CLCommon getStringForDate:self.selectedBirthDate andLocalFormat:@"MMMMdy"]];
                [dateCell setCellIndexPath:indexPath];
                dateCell.delegate=self;
                return dateCell;
                break;
            }
            case TableRowProfileIndexGender:{
                CLSimpleTextCell *genderCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"genderCellIdentifier"];
                genderCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [genderCell setTextInputView:self.pickerView];
                [genderCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [genderCell setPlaceHoldrText:NSLocalizedString(@"Gender", @"Placeholder text")];
                [genderCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [genderCell setCellText:[self.selectedGenderDict objectForKey:kGenderOptionTitle]];
                [genderCell setCellIndexPath:indexPath];
                genderCell.delegate=self;
                return genderCell;
                break;
            }
            case TableRowProfileIndexEmail:{
                CLSimpleTextCell *emailCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"emailCellIdentifier"];
                emailCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [emailCell setTextInputAccesoryView:self.keyboardResignView];
                [emailCell setPlaceHoldrText:NSLocalizedString(@"Email", @"Placeholder text")];
                [emailCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [emailCell setCellText:self.emailText];
                [emailCell setCellIndexPath:indexPath];
                emailCell.delegate=self;
                [emailCell disableCellField];
                return emailCell;
                break;
            }
            case TableRowProfileIndexAltEmail:{
                CLSimpleTextCell *nickNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"alternateEmailCellIdentifier"];
                nickNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [nickNameCell setTextInputAccesoryView:self.keyboardResignView];
                [nickNameCell setPlaceHoldrText:NSLocalizedString(@"Alternate Email", @"Placeholder text")];
                [nickNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [nickNameCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [nickNameCell setCellText:self.altEmailText];
                [nickNameCell setCellIndexPath:indexPath];
                nickNameCell.delegate=self;
                return nickNameCell;
                break;
            }
            case TableRowProfileIndexSkypeName:{
                CLSimpleTextCell *nickNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"skypenameCellIdentifier"];
                nickNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [nickNameCell setTextInputAccesoryView:self.keyboardResignView];
                [nickNameCell setPlaceHoldrText:NSLocalizedString(@"Skype Name", @"Placeholder text")];
                [nickNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [nickNameCell setCellCapitalization:UITextAutocapitalizationTypeNone];
                [nickNameCell setCellText:self.skypeNameText];
                [nickNameCell setCellIndexPath:indexPath];
                nickNameCell.delegate=self;
                return nickNameCell;
                break;
            }
                
            default:
                return nil;
                break;
        }
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        }
        cell.textLabel.text=@"test";
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case TableSectionIndexOtherAddress:{
            CLInfoAddressViewController *addressController=[[CLInfoAddressViewController alloc] initWithStyle:UITableViewStyleGrouped];
            addressController.delegate=self;
            addressController.isEditMode=YES;
            addressController.locationObj=[self.selectedOtherAddressArray objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:addressController animated:YES];
            break;
        }
        case TableSectionIndexHomeNumber:{
            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
            telephoneController.isEditMode=YES;
            telephoneController.telephoneObj=self.selectedHomeNumberObj;
            telephoneController.currentCountryCode=self.info.currentLocation.countryCode;
            telephoneController.delegate=self;
            [self.navigationController pushViewController:telephoneController animated:YES];
            break;
        }
        case TableSectionIndexMobileNumber:{
            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
            telephoneController.isEditMode=YES;
            telephoneController.telephoneObj=self.selectedMobileNumberObj;
            telephoneController.currentCountryCode=self.info.currentLocation.countryCode;
            telephoneController.delegate=self;
            [self.navigationController pushViewController:telephoneController animated:YES];
            break;
        }
//        case TableSectionIndexOtherNumber:{
//            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
//            telephoneController.isEditMode=YES;
//            telephoneController.telephoneObj=[self.selectedOtherNumberArray objectAtIndex:indexPath.row];
//            [self.navigationController pushViewController:telephoneController animated:YES];
//            break;
//        }
        case TableSectionIndexCurrentAddress:{
            CLInfoAddressViewController *addressController=[[CLInfoAddressViewController alloc] initWithStyle:UITableViewStyleGrouped];
            addressController.delegate=self;
            addressController.isCurrentAddress = YES;
            addressController.isEditMode=YES;
            addressController.locationObj=self.selectedCurrentAddressObj;
            [self.navigationController pushViewController:addressController animated:YES];
            break;
        }
        case TableSectionIndexPrevName:{
            CLInfoPreviousNameViewController *nameController=[[CLInfoPreviousNameViewController alloc] initWithStyle:UITableViewStyleGrouped];
            nameController.isEditMode=YES;
            nameController.previousNameObj=[self.selectedPrevNameArray objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:nameController animated:YES];
            break;
        }
        default:
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section==TableSectionIndexNationality || indexPath.section==TableSectionIndexPrevName || indexPath.section==TableSectionIndexOtherAddress){// || indexPath.section==TableSectionIndexMobileNumber || indexPath.section==TableSectionIndexHomeNumber){
        return YES;
    }
    else{
        return NO;
    }
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if(indexPath.section==TableSectionIndexNationality){
            [self.selectedNationalityArray removeObjectAtIndex:indexPath.row];
            //if(indexPath.row==0 && [self.selectedNationalityArray count]==0){
                [self updateSalutaionList];
                [self.selectedSalutationDict removeAllObjects];
                [self.tableView reloadData];
           // }
           // else{
               // [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //}
        }
        else if(indexPath.section==TableSectionIndexPrevName){
            [self.selectedPrevNameArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.selectedPrevNameArray count]==0){
                [self.tableView reloadData];
            }
            else{
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        else if(indexPath.section==TableSectionIndexOtherAddress){
            if (self.selectedOtherAddressArray.count > 1) {
                [self.selectedOtherAddressArray removeObjectAtIndex:indexPath.row];
                if(indexPath.row==0 && [self.selectedOtherAddressArray count]==0){
                    [self.tableView reloadData];
                }
                else{
                    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:@"Cannot Delete The Last Address" cancelbuttonName:@"Ok"];
            }
            
        }
//        else if(indexPath.section==TableSectionIndexOtherNumber){
//            [self.selectedOtherNumberArray removeObjectAtIndex:indexPath.row];
//            if(indexPath.row==0 && [self.selectedOtherNumberArray count]==0){
//                [self.tableView reloadData];
//            }
//            else{
//                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//            }
//        }
        else if(indexPath.section==TableSectionIndexHomeNumber){
            self.selectedHomeNumberObj=nil;
            [self.tableView reloadData];
            
        }
        else if(indexPath.section==TableSectionIndexMobileNumber){
            self.selectedMobileNumberObj=nil;
            [self.tableView reloadData];
            
        }
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self getSectionTitleforSection:section];
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==TableSectionIndexNationality || section==TableSectionIndexPrevName || section==TableSectionIndexOtherAddress || (section==TableSectionIndexMobileNumber && (self.selectedMobileNumberObj.telephoneContactNumber==nil || [self.selectedMobileNumberObj.telephoneContactNumber isEqualToString:@""])) || (section==TableSectionIndexHomeNumber && (self.selectedHomeNumberObj.telephoneContactNumber==nil || [self.selectedHomeNumberObj.telephoneContactNumber isEqualToString:@""]))) {
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        
        return sectionFooter;
    }
    else{
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section==TableSectionIndexNationality || section==TableSectionIndexPrevName || section==TableSectionIndexOtherAddress || (section==TableSectionIndexMobileNumber && (self.selectedMobileNumberObj.telephoneContactNumber==nil || [self.selectedMobileNumberObj.telephoneContactNumber isEqualToString:@""])) || (section==TableSectionIndexHomeNumber && (self.selectedHomeNumberObj.telephoneContactNumber==nil || [self.selectedHomeNumberObj.telephoneContactNumber isEqualToString:@""]))) {
        return 44;
    }
    else{
        return 0;
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:[UIFont systemFontOfSize:kSectionHeaderFont]];
}


#pragma mark IBActions

-(IBAction)bttnActionSaveInfoAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveInfoDetails];
    }
}

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    switch (sender.tag) {
        case TableSectionIndexNationality:{
            CLSelectNationalityViewController *selectNationalityView=[[CLSelectNationalityViewController alloc] initWithStyle:UITableViewStylePlain];
            selectNationalityView.delegate=self;
            selectNationalityView.alreadyListedNationalities=self.selectedNationalityArray;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectNationalityView];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
        case TableSectionIndexPrevName:{
            CLInfoPreviousNameViewController *nameController=[[CLInfoPreviousNameViewController alloc] initWithStyle:UITableViewStyleGrouped];
            nameController.delegate=self;
            nameController.isEditMode=NO;
            nameController.previousNameObj=nil;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:nameController];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
        case TableSectionIndexHomeNumber:{
            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
            telephoneController.delegate=self;
            telephoneController.isEditMode=NO;
            telephoneController.telephoneObj=self.selectedHomeNumberObj;
            telephoneController.currentCountryCode=self.info.currentLocation.countryCode;
            telephoneController.telephoneObj.contactType=[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:ContactTypeHome],kCLProfileAboutMeTelephoneContactTypeIdkey,kCLProfileAboutMeHomeTelephoneKey,kCLProfileAboutMeTelephoneContactTypeTextkey, nil];
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:telephoneController];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
        case TableSectionIndexMobileNumber:{
            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
            telephoneController.delegate=self;
            telephoneController.isEditMode=NO;
            telephoneController.telephoneObj=self.selectedMobileNumberObj;
            telephoneController.currentCountryCode= [self.selectedCountry objectForKey:@"countryCode"];//self.info.currentLocation.countryCode;
            telephoneController.telephoneObj.contactType=[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:ContactTypeMobile],kCLProfileAboutMeTelephoneContactTypeIdkey,kCLProfileAboutMeMobleTelephoneKey,kCLProfileAboutMeTelephoneContactTypeTextkey, nil];
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:telephoneController];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
//        case TableSectionIndexOtherNumber:{
//            CLInfoTelephoneViewController *telephoneController=[[CLInfoTelephoneViewController alloc] initWithStyle:UITableViewStyleGrouped];
//            telephoneController.delegate=self;
//            telephoneController.isEditMode=NO;
//            telephoneController.telephoneObj=nil;
//            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:telephoneController];
//            [self presentViewController:nav animated:YES completion:nil];
//            break;
//        }
        case TableSectionIndexOtherAddress:{
            CLInfoAddressViewController *addressController=[[CLInfoAddressViewController alloc] initWithStyle:UITableViewStylePlain];
            addressController.delegate=self;
            addressController.isEditMode=NO;
            addressController.locationObj=nil;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:addressController];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
            
        default:
            break;
    }
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.selectedBirthDate=date;
    
    CLSimpleTextCell *dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:TableRowProfileIndexBirthDay inSection:TableSectionIndexProfile]];
    [dateCell setCellText:[CLCommon getStringForDate:self.selectedBirthDate andLocalFormat:@"MMMMdy"]];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    
    if(cell!=nil){
        if (cell.cellIndexPath.section==TableSectionIndexProfile && cell.cellIndexPath.row==TableRowProfileIndexBirthDay) {
            if (self.selectedBirthDate==nil || !([self.selectedBirthDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.selectedBirthDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        else if(cell.cellIndexPath.section==TableSectionIndexProfile && cell.cellIndexPath.row==TableRowProfileIndexSalutation){
            self.selectedSalutationDict=[self.salutationList objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            [cell setCellText:[self.selectedSalutationDict objectForKey:kSalutationOptionTitle]];
            [self.tableView reloadData];
        }
        else if(cell.cellIndexPath.section==TableSectionIndexProfile && cell.cellIndexPath.row==TableRowProfileIndexGender){
            self.selectedGenderDict=[self.genderList objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            [cell setCellText:[self.selectedGenderDict objectForKey:kGenderOptionTitle]];
//            [self updateSalutaionList];
//            [self.selectedSalutationDict removeAllObjects];
//            [self.tableView reloadData];
        }
    }
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)profilePhotoTapped:(id)sender {
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addPhotoActionSheet=[[UIActionSheet alloc] initWithTitle:NSLocalizedString(@"Change Profile Photo", @"Change Profile Photo") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3"), nil];
        addPhotoActionSheet.tag=1;
        [addPhotoActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change Profile Photo", @"Change Profile Photo") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self addPhotoActionSheetPressedWithButtonIndex:0];
                                        }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addPhotoActionSheetPressedWithButtonIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIActionSheet Delegate

-(void)addPhotoActionSheetPressedWithButtonIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //adding new image actionsheet..
    if (actionSheet.tag==1) {
        [self addPhotoActionSheetPressedWithButtonIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}
#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) {
        pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
        [self uploadProfilePicture:pickedImage];
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

//#pragma mark HTProgressHUD delegates
//
//- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
//    [self dismissViewControllerAnimated:YES completion:^(){
//        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(workAchievementController:didAddAchievement:)]){
//            [self.delegate workAchievementController:self didAddAchievement:self.workAchObj];
//        }
//    }];
//}

#pragma mark UIPickerView Methods

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView.tag==1) {
        return [self.salutationList count];
    }
    else if(pickerView.tag==2) {
        return [self.genderList count];
    }
    else{
        return 0;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag==1) {
        label.text= [[self.salutationList objectAtIndex:row] objectForKey:kSalutationOptionTitle];
    }
    else if(pickerView.tag==2) {
        label.text= [[self.genderList objectAtIndex:row] objectForKey:kGenderOptionTitle];
    }
    
    return label;
}

#pragma mark CLTappable cell delegate

-(void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case TableSectionIndexWhereDoYouLive:{
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            selectLocation.locationListType=LocationListingCountryBasedLocation;
            selectLocation.countryCodeforListing = [self.selectedCountry objectForKey:@"countryCode"];
            selectLocation.delegate=self;
            self.forCountry = NO;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];

        }
            break;
        case TableSectionIndexCountry:{
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            selectLocation.locationListType=LocationListingCountryForCRF;
            selectLocation.delegate=self;
            self.forCountry = YES;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark CLLocation delegate

-(void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController *)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        self.selectedWhereDoYouLive=nil;
        [self updateSalutaionList];
        [self.selectedSalutationDict removeAllObjects];
        
    }
    else{
        self.selectedWhereDoYouLive=locDict;
        self.selectedCurrentAddressObj.locationName = [NSString stringWithFormat:@"%@,%@,%@",[self.selectedWhereDoYouLive objectForKey:@"jobLocationName"],[self.selectedWhereDoYouLive objectForKey:@"jobLocationAdminArea"],[self.selectedWhereDoYouLive objectForKey:@"jobLocationCountryName"]];
        self.selectedCurrentAddressObj.locationCode = [locDict objectForKey:@"jobLocationCode"];
        
        self.selectedCurrentAddressObj.formattedAddress = [self formattedAddressForDisplay];
        
    }
    [self.tableView reloadData];
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath=cell.cellIndexPath;
    if (indexPath.section==TableSectionIndexProfile && indexPath.row==TableRowProfileIndexSalutation) {
        self.pickerView.tag=1;
    }
    else if (indexPath.section==TableSectionIndexProfile && indexPath.row==TableRowProfileIndexGender){
        self.pickerView.tag=2;
    }
    [self.pickerView reloadAllComponents];
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    if (indexPath.section==TableSectionIndexProfile) {
        switch (indexPath.row) {
            case TableRowProfileIndexSalutation:{
                self.selectedSalutationDict=nil;
                break;
            }
            case TableRowProfileIndexGender:{
                self.selectedGenderDict=nil;
                break;
            }
            case TableRowProfileIndexBirthDay:{
                self.selectedBirthDate=nil;
                break;
            }
            default:
                break;
        }
    }
    [self.tableView reloadData];
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    if (indexPath.section==TableSectionIndexProfile) {
        switch (indexPath.row) {
            case TableRowProfileIndexFirstName:{
                self.firstNameText=text;
                break;
            }
            case TableRowProfileIndexMiddleName:{
                self.middleNameText=text;
                break;
            }
            case TableRowProfileIndexLastName:{
                self.lastNameText=text;
                break;
            }
            case TableRowProfileIndexNickName:{
                self.nickNameText=text;
                break;
            }
            case TableRowProfileIndexEmail:{
                self.emailText=text;
                break;
            }
            case TableRowProfileIndexAltEmail:{
                self.altEmailText=text;
                break;
            }
            case TableRowProfileIndexSkypeName:{
                self.skypeNameText=text;
                break;
            }
                
            default:
                break;
        }
    }
}

#pragma mark CLSelectNationalityDelegate Methods

- (void)selectNationalityControllerDidSelectNationality:(CLSelectNationalityViewController*)controller withArray:(NSMutableArray *)nationalityArray{
    if([self.selectedNationalityArray count]==0){
        self.selectedNationalityArray=nationalityArray;
        [self updateSalutaionList];
//        [self.selectedSalutationDict removeAllObjects];
        [self.tableView reloadData];
    }
    else{
        [self.selectedNationalityArray addObjectsFromArray:nationalityArray];
        [self updateSalutaionList];
//        [self.selectedSalutationDict removeAllObjects];
        [self.tableView reloadData];
        //[self.tableView reloadSections:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(TableSectionIndexNationality, TableSectionIndexProfile)] withRowAnimation:UITableViewRowAnimationFade];
    }
    
}

#pragma mark CLAddressControllerDelegate Methods

- (void)addressController:(CLInfoAddressViewController *)controller didAddAddress:(CLLocationObject*)locObj{
    [self.selectedOtherAddressArray addObject:locObj];
    
    //reset commmunication address..
    if (locObj.isCommunicationAddress) {
        if (![locObj isEqual:self.selectedCurrentAddressObj]) {
            self.selectedCurrentAddressObj.isCommunicationAddress=NO;
        }
        
        for (int i=0; i<[self.selectedOtherAddressArray count]; i++) {
            if (![locObj isEqual:[self.selectedOtherAddressArray objectAtIndex:i]]) {
                ((CLLocationObject*)[self.selectedOtherAddressArray objectAtIndex:i]).isCommunicationAddress=NO;
            }
        }
    }
    
    
    if ([self.selectedOtherAddressArray count]==1) {
        [self.tableView reloadData];
    }
    else{
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:TableSectionIndexOtherAddress] withRowAnimation:UITableViewRowAnimationFade];
    }
}

- (void)addressController:(CLInfoAddressViewController *)controller didEditAddress:(CLLocationObject *)locObj{
    //reset commmunication address..
    if (locObj.isCommunicationAddress) {
        if (![locObj isEqual:self.selectedCurrentAddressObj]) {
            self.selectedCurrentAddressObj.isCommunicationAddress=NO;
        }
        
        for (int i=0; i<[self.selectedOtherAddressArray count]; i++) {
            if (![locObj isEqual:[self.selectedOtherAddressArray objectAtIndex:i]]) {
                ((CLLocationObject*)[self.selectedOtherAddressArray objectAtIndex:i]).isCommunicationAddress=NO;
            }
        }
        [self.tableView reloadData];
    }
}

#pragma mark CLPreviousNameControllerDelegate Methods

- (void)previousNameController:(CLInfoPreviousNameViewController *)controller didAddName:(CLPreviousNameObject*)nameObj{
    [self.selectedPrevNameArray addObject:nameObj];
    if ([self.selectedPrevNameArray count]==1) {
        [self.tableView reloadData];
    }
    else{
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:TableSectionIndexPrevName] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark CLInfoTelephoneViewController Methods

- (void)telephoneController:(CLInfoTelephoneViewController *)controller didAddTelephoneNumber:(CLTelephoneObject*)telephoneObj forType:(CLTelephoneContactType)type{
    switch (type) {
        case ContactTypeHome:{
            self.selectedHomeNumberObj=telephoneObj;
            //to reset primary contact..
            if (self.selectedHomeNumberObj.isPrimaryContact) {
                if (self.selectedMobileNumberObj!=nil) {
                    self.selectedMobileNumberObj.isPrimaryContact=NO;
                }
            }
            [self.tableView reloadData];
            break;
        }
        case ContactTypeMobile:{
            self.selectedMobileNumberObj=telephoneObj;
            //to reset primary contact..
            if (self.selectedMobileNumberObj.isPrimaryContact) {
                if (self.selectedHomeNumberObj!=nil) {
                    self.selectedHomeNumberObj.isPrimaryContact=NO;
                }
            }
            [self.tableView reloadData];
            break;
        }
            
        default:{
            break;
        }
            
//        default:{
//            [self.selectedOtherNumberArray addObject:telephoneObj];
//            if ([self.selectedOtherNumberArray count]==1) {
//                [self.tableView reloadData];
//            }
//            else{
//                [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:TableSectionIndexOtherNumber] withRowAnimation:UITableViewRowAnimationFade];
//            }
//            break;
//        }
    }
}

- (void)telephoneController:(CLInfoTelephoneViewController *)controller didEditTelephoneNumber:(CLTelephoneObject*)telephoneObj forType:(CLTelephoneContactType)type{
    switch (type) {
        case ContactTypeHome:{
            //to reset primary contact..
            if (self.selectedHomeNumberObj.isPrimaryContact) {
                if (self.selectedMobileNumberObj!=nil) {
                    self.selectedMobileNumberObj.isPrimaryContact=NO;
                }
            }
            [self.tableView reloadData];
            break;
        }
        case ContactTypeMobile:{
            //to reset primary contact..
            if (self.selectedMobileNumberObj.isPrimaryContact) {
                if (self.selectedHomeNumberObj!=nil) {
                    self.selectedHomeNumberObj.isPrimaryContact=NO;
                }
            }
            [self.tableView reloadData];
            break;
        }
            
        default:{
            break;
        }
    }
}

#pragma mark HTProgressHUD Methods

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(infoController:didEditInfo:)]){
        [self.delegate infoController:self didEditInfo:self.info];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

-(NSString*)formattedAddressForDisplay{
    NSMutableString *formattedString=[[NSMutableString alloc] init];
    
    //    if (self.locationApartment.length!=0) {
    //        [formattedString appendFormat:@"%@, ",self.locationApartment];
    //    }
    //    if (self.locationfloor.length!=0) {
    //        [formattedString appendFormat:@"%@, ",self.locationfloor];
    //    }
    //    if (self.locationHouseNumber.length!=0) {
    //        [formattedString appendFormat:@"%@, ",self.locationHouseNumber];
    //    }
    if (self.selectedCurrentAddressObj.locationAddress.length!=0) {
        [formattedString appendFormat:@"%@, ",self.selectedCurrentAddressObj.locationAddress];
    }
    if (self.selectedCurrentAddressObj.locationName.length!=0) {
        [formattedString appendFormat:@"%@, ",self.selectedCurrentAddressObj.locationName];
    }
    if (self.selectedCurrentAddressObj.locationPincode.length!=0) {
        [formattedString appendFormat:@"%@, ",self.selectedCurrentAddressObj.locationPincode];
    }
    if (formattedString.length>1) {
        [formattedString deleteCharactersInRange:NSMakeRange([formattedString length]-2, 2)];
    }
    
    return formattedString;
}



@end
