//
//  CLAboutMeInterestViewController.h
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectHobbyViewController.h"
#import "CLHeightAdjustTextCell.h"
#import "CLInterestObject.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLAboutMeInterestViewController;

//Delegate Methods...
@protocol CLInterestControllerDelegate <NSObject>

@optional
- (void)interestController:(CLAboutMeInterestViewController *)controller didAddInterest:(CLInterestObject*)interestObj;

@end

@interface CLAboutMeInterestViewController : UITableViewController<CLSimpleTextCellDelegate,CLHeightAdjustTextCellDelegate,HTProgressHUDDelegate,CLSelectHobbyDelegate>

@property(nonatomic,weak) id <CLInterestControllerDelegate> delegate;
@property(nonatomic,strong)CLInterestObject *interestObj;
@property(nonatomic,assign)BOOL isEditMode;

@end
