//
//  CLCertificationViewController.h
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCertificationObject.h"
#import "CLSimpleTextCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLProfilePhotoListingGridCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectLocationViewController.h"
#import "CLTextCheckBoxCell.h"

@class CLCertificationViewController;

@protocol CLCertificationDelegate <NSObject>

@optional
-(void)qualificationCertification:(CLCertificationViewController *)controller didAddCertification:(CLCertificationObject *)certificationObj;

@end

@interface CLCertificationViewController : UITableViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLProfilePhotoListingGridCellDelegate,CLHeightAdjustTextCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate,CLTextCheckBoxCellDelegate>

@property (nonatomic, weak) id <CLCertificationDelegate> delegate;
@property (nonatomic, assign) BOOL isEditMode;
@property (nonatomic, retain) CLCertificationObject *certificationObj;
@end
