//
//  CLBorderedTextCell.m
//  CareerLine
//
//  Created by CSG on 9/1/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLBorderedTextCell.h"

@interface CLBorderedTextCell()

@property (weak, nonatomic) IBOutlet UITextField *txtField;

- (IBAction)textFieldDidChangeEditing:(id)sender;
@end

@implementation CLBorderedTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLBorderedTextCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

-(void)isSecureType :(BOOL)isSecure{
    if (isSecure) {
        self.txtField.secureTextEntry=YES;
    }
    else{
        self.txtField.secureTextEntry=NO;
    }
}

-(NSString*)getEnteredText{
    return self.txtField.text;
}

-(void)setCellFont:(UIFont*)font{
    self.txtField.font=font;
}

-(void)setCellText:(NSString*)text{
    self.txtField.text=text;
}

-(void)setPlaceHoldrText:(NSString *)text{
    self.txtField.placeholder=text;
}

-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode{
    self.txtField.autocapitalizationType=capitalizationMode;
}
-(void)setTextInputAccesoryView:(id)view{
    self.txtField.inputAccessoryView=view;
}
-(void)setKeyboardType :(UIKeyboardType)type{
    self.txtField.keyboardType = type;
}

-(void)becomeFirstResponder{
    [self.txtField becomeFirstResponder];
}

-(void)returnKeyType:(UIReturnKeyType)type{
    self.txtField.returnKeyType = type;
}

#pragma mark UITextField Delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellWillBeginEditing:forTextField:)]){
		[self.delegate cellWillBeginEditing:self forTextField:self.txtField];
	}
    return YES;
}

- (IBAction)textFieldDidChangeEditing:(UITextField*)sender {
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellTextDidChange:forIndexPath:withText:)]){
		[self.delegate cellTextDidChange:self forIndexPath:self.cellIndexPath withText:sender.text];
	}
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellShouldReturn:forTextField:)]){
        [self.delegate cellShouldReturn:self forTextField:self.txtField];
    }
    return YES;
}

@end
