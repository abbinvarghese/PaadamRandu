//
//  CLBnefitsViewController.m
//  CareerLine
//
//  Created by RENJITH on 18/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLBnefitsViewController.h"

#define kCLBenefitsOtherText NSLocalizedString(@"Other", @"Other text localization")
#define kSelectedIndex @"selectedIndex"

@interface CLBnefitsViewController ()
@property (weak, nonatomic) IBOutlet UITableView *benefitsTable;
@property (nonatomic, retain) NSMutableArray *benefitsArray;
@property (nonatomic, retain) NSMutableArray *selectedBenefitsArray;
@end

@implementation CLBnefitsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.benefitsTable.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Benefits", @"Benefits page title text");
    
    [self setRightNavigationButton];
    self.selectedBenefitsArray = [[NSMutableArray alloc]initWithArray:self.alreadySelectedBenefits];
    self.benefitsArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllBenefitsListFromDB];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"0",kBenefitsId,kCLBenefitsOtherText,kBenefitsOtherTxt,@"1",kBenefitsOtherFlag, nil];
    [self.benefitsArray insertObject:dict atIndex:[self.benefitsArray count]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods
-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"dismiss Benefits modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionBenefitsSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)bttnActionBenefitsSaveAndDismissModal:(id)sender{
    
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(benefitsController:didAddBenefits:)]){
        [self.delegate benefitsController:self didAddBenefits:self.selectedBenefitsArray];
    }
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.benefitsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    
    if ([self isContainsBenefitDict:[self.benefitsArray objectAtIndex:indexPath.row]]) {
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSMutableDictionary *benefitDict = [self.benefitsArray objectAtIndex:indexPath.row];
    if ([[benefitDict objectForKey:kBenefitsOtherFlag] boolValue]) {
        
        if ([self.selectedBenefitsArray count]>0) {
            
            NSMutableDictionary *dict = [self returnOtherTextIndecAnsValFromSelectedDict];
            if ([[dict objectForKey:kBenefitsOtherFlag] integerValue] == 1) {
                cell.textLabel.text=[dict objectForKey:kBenefitsOtherTxt];
            }else{
                cell.textLabel.text=[benefitDict objectForKey:kBenefitsOtherTxt];
            }
        }else{
            cell.textLabel.text=[benefitDict objectForKey:kBenefitsOtherTxt];
        }
    }else{
        cell.textLabel.text=[benefitDict objectForKey:kBenefitsName];
    }
    return cell;
}
- (NSMutableDictionary *)returnOtherTextIndecAnsValFromSelectedDict{
    
    NSMutableDictionary *resultDict = [[NSMutableDictionary alloc]init];
    for (int i=0;i< [self.selectedBenefitsArray count];i++) {
        if ([[ [self.selectedBenefitsArray objectAtIndex:i] objectForKey:kBenefitsOtherFlag] boolValue]) {
            [resultDict setObject:[[self.selectedBenefitsArray objectAtIndex:i] objectForKey:kBenefitsOtherTxt] forKey:kBenefitsOtherTxt];
            [resultDict setObject:[NSString stringWithFormat:@"%d",i] forKey:kSelectedIndex];
            [resultDict setObject:@"1" forKey:kBenefitsOtherFlag];
            break;
        }
    }
    return resultDict;
}

- (int) getSelectedObjectIndex:(NSMutableDictionary *)dict{
    
    int resultIndex;
    for (int i=0;i< [self.selectedBenefitsArray count];i++) {
        
        if ([[ [self.selectedBenefitsArray objectAtIndex:i] objectForKey:kBenefitsOtherFlag] boolValue]) {
            if ([[ [self.selectedBenefitsArray objectAtIndex:i] objectForKey:kBenefitsOtherFlag] integerValue] == [[dict objectForKey:kBenefitsOtherFlag] integerValue]) {
                resultIndex = i;
                break;
            }else{
                resultIndex =i;
            }
        }else{
            if ([[ [self.selectedBenefitsArray objectAtIndex:i] objectForKey:kBenefitsName] isEqualToString:[dict objectForKey:kBenefitsName]]) {
                resultIndex = i;
                break;
            }else{
                resultIndex =i;
            }
        }
    }
    return resultIndex;
}

- (BOOL) isContainsBenefitDict:(NSMutableDictionary *)dict{
    
    BOOL result = NO;
    for (NSMutableDictionary *selectedDict in self.selectedBenefitsArray) {
        if ([[selectedDict objectForKey:kBenefitsOtherFlag] boolValue]) {
            if ([[selectedDict objectForKey:kBenefitsOtherFlag] integerValue] == [[dict objectForKey:kBenefitsOtherFlag] integerValue]) {
                result = YES;
                break;
            }else{
                result =NO;
            }
        }else{
            if ([[selectedDict objectForKey:kBenefitsName] isEqualToString:[dict objectForKey:kBenefitsName]]) {
                
                result = YES;
                break;
            }else{
                result =NO;
            }
        }
        
    }
    return result;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.navigationItem.rightBarButtonItem.enabled=YES;
    if ([self isContainsBenefitDict:[self.benefitsArray objectAtIndex:indexPath.row]]) {
        int index = [self getSelectedObjectIndex:[self.benefitsArray objectAtIndex:indexPath.row]];
        [self.selectedBenefitsArray removeObjectAtIndex:index];
        if ([[[self.benefitsArray objectAtIndex:indexPath.row] objectForKey:kBenefitsOtherFlag] boolValue]) {
            [self.benefitsArray removeObjectAtIndex:[self.benefitsArray count]-1];
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"0",kBenefitsId,kCLBenefitsOtherText,kBenefitsOtherTxt,@"1",kBenefitsOtherFlag, nil];
            [self.benefitsArray insertObject:dict atIndex:[self.benefitsArray count]];
        }
    }else{
        if ([[[self.benefitsArray objectAtIndex:indexPath.row] objectForKey:kBenefitsOtherFlag] integerValue]) {
            if([CLCommon isOSversionLessThan8])
            {
                UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Enter Your Other Benefit:", @"Enter Your Other Benefit") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];
                enterFuncAlert.tag=88;
                enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
                [enterFuncAlert show];
            }else{
                // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                               message: NSLocalizedString(@"Enter Your Other Benefit:", @"Enter Your Other Benefit")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    
                }];
                UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction * action){
                                                                     //Do Some action here
                                                                     UITextField *textField = alert.textFields[0];
                                                                     NSString *otherFuncText = textField.text;
                                                                     
                                                                     [self.benefitsArray removeObjectAtIndex:[self.benefitsArray count]-1];
                                                                     NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"0",kBenefitsId,otherFuncText,kBenefitsOtherTxt,@"1",kBenefitsOtherFlag, nil];
                                                                     
                                                                     [self.selectedBenefitsArray addObject:dict];
                                                                     [self.benefitsArray insertObject:dict atIndex:[self.benefitsArray count]];
                                                                     [self.benefitsTable reloadData];
                                                                     
                                                                 }];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                       style: UIAlertActionStyleDefault
                                                                     handler: nil];
                
                [alert addAction: cancelAction];
                [alert addAction: okAction];
                [self presentViewController:alert animated:YES completion:nil];
            }
            
        }else{
            [self.selectedBenefitsArray addObject:[self.benefitsArray objectAtIndex:indexPath.row]];
        }
    }
    [self.benefitsTable reloadData];
}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //ENter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            
            NSString *otherFuncText = [[alertView textFieldAtIndex:0] text];
            [self.benefitsArray removeObjectAtIndex:[self.benefitsArray count]-1];
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"0",kBenefitsId,otherFuncText,kBenefitsOtherTxt,@"1",kBenefitsOtherFlag, nil];
            [self.selectedBenefitsArray addObject:dict];
            [self.benefitsArray insertObject:dict atIndex:[self.benefitsArray count]];
            [self.benefitsTable reloadData];
            
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}
@end
