//
//  CLKnowledgeListViewController.h
//  CareerLine
//
//  Created by RENJITH on 19/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCollectionViewMasonryLayout.h"
#import "CLKnowledgeViewCell.h"

@interface CLKnowledgeListViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout, CLCollectionViewDelegateMasonryLayout,CLKnowledgeViewCellDelegate,UIActionSheetDelegate,UISearchBarDelegate>

-(void)clearArraysAndReloadTable;
@end
