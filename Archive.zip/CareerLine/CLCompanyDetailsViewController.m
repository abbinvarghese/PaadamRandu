//
//  CLCompanyDetailsViewController.m
//  CareerLine
//
//  Created by CSG on 6/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCompanyDetailsViewController.h"
#import "UIImageView+WebCache.h"

#define kcelltextFontSize [UIFont systemFontOfSize:12]

@interface CLCompanyDetailsViewController ()

@property (weak, nonatomic) IBOutlet UITableView *companyTable;
@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loadingIndicator;
@property (weak, nonatomic) IBOutlet UIImageView *companyLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *lblCompanyName;
@end

@implementation CLCompanyDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=self.company.companyName;
    [self setRightNavigationButton];
    self.companyTable.tableHeaderView=self.tblHeaderView;
    [self updateTableHeaderDetails];
    [self retreiveCompanyDetails];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark IBAction

-(IBAction)bttnActionDismissModal:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:^{
        [CLCompanyObject cancelCompanyDetailPendingRequests];
    }];
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"CompanyDetails dismiss modal button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)updateTableHeaderDetails{
    self.lblCompanyName.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.lblCompanyName.text=self.company.companyName;
    //old
//    [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:[NSURL URLWithString:[self.company.companyLogoUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] options:SDWebImageDownloaderUseNSURLCache progress:nil completed:^(UIImage *image,NSData *data, NSError *error,BOOL finished){
//        if (image)
//        {
//            self.companyLogoImageView.image=image;
//        }
//        else{
//            self.companyLogoImageView.image=[UIImage imageNamed:@"company_placeholder"];
//        }
//    }];
    [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:[NSURL URLWithString:self.company.companyLogoUrl] options:SDWebImageDownloaderUseNSURLCache progress:nil completed:^(UIImage *image,NSData *data, NSError *error,BOOL finished){
        if (image)
        {
            self.companyLogoImageView.image=image;
        }
        else{
            self.companyLogoImageView.image=[UIImage imageNamed:@"company_placeholder"];
        }
    }];
}

-(void)retreiveCompanyDetails{
    [self.loadingIndicator startAnimating];
    [CLCompanyObject companyDetailsForCompanyId:self.company.companyId
                                        success:^(CLCompanyObject *companyObj){
                                            [self.loadingIndicator stopAnimating];
                                            self.company=companyObj;
                                            [self updateTableHeaderDetails];
                                            [self.companyTable reloadData];
                                        }
                                        failure:^(NSString *error){
                                            [self.loadingIndicator stopAnimating];
                                            if (![error isEqualToString:@""]) {
                                                [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                            }
                                        }];
}

#pragma mark UITableView Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"CompanyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryNone;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:kcelltextFontSize];
        [cell.textLabel setNumberOfLines:0];
    }
    
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text=self.company.companyDescription;
            break;
        case 1:
            cell.textLabel.text=self.company.companyWebsiteUrl;
            break;
        case 2:
            cell.textLabel.text=self.company.companyLocation;
            break;
        default:
            break;
    }
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellText=nil;
    switch (indexPath.row) {
        case 0:
            cellText=self.company.companyDescription;
            break;
        case 1:
            cellText=self.company.companyWebsiteUrl;
            break;
        case 2:
            cellText=self.company.companyLocation;
            break;
        default:
            break;
    }
    
    CGRect expectedtextFrame = [cellText boundingRectWithSize:CGSizeMake(300, 9999)
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                           kcelltextFontSize, NSFontAttributeName,
                                                           nil]
                                                  context:nil];
    return MAX(44, expectedtextFrame.size.height+20);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.company.companyWebsiteUrl]];
    }
}

@end
