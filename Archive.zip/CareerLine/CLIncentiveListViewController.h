//
//  CLIncentiveListViewController.h
//  CareerLine
//
//  Created by RENJITH on 20/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CLIncentiveListViewController;
@protocol CLIncentiveBonusDelegate <NSObject>

@optional

- (void)incentiveBonusController:(CLIncentiveListViewController *)controller didSelect:(NSMutableDictionary *)selectedDict;

@end
@interface CLIncentiveListViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic ,weak) id<CLIncentiveBonusDelegate>delegate;
@property (nonatomic ,retain) NSMutableDictionary*alreadySelectedIncentives;
@end
