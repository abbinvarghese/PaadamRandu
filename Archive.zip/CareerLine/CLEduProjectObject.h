//
//  CLEduProjectObject.h
//  CareerLine
//
//  Created by Abbin on 12/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLEducationObject.h"

@interface CLEduProjectObject : NSObject

@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSMutableArray *documents;
@property(nonatomic,strong)NSMutableDictionary *course;
@property(nonatomic,strong)NSString *day;
@property(nonatomic,strong)NSString *months;
@property(nonatomic,strong)NSString *year;
@property(nonatomic,retain)NSString *idNum;
@property(nonatomic,retain)NSString *remark;
@property(nonatomic,retain)NSString *title;
@property(nonatomic,retain)NSString *type;
@property(nonatomic,retain)NSString *formateddDate;
- (id)initWithDictionary:(NSDictionary*)dictionary;
-(void)updateDate:(NSDate*)date;

+ (void)saveEdu:(CLEduProjectObject*)eduObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *eduId))success failure:(void (^)(NSString *error))failure;

+ (void)deleteEdu:(NSString*)eduId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

+ (void)addDocument:(UIImage*)image forEdu:(NSString*)eduId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
