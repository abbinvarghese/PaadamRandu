//
//  TbIndgroup.h
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbIndgroup : NSManagedObject

@property (nonatomic, retain) NSString * indgroupcode;
@property (nonatomic, retain) NSString * indgroupname;
@property (nonatomic, retain) NSString * indsectcode;

@end
