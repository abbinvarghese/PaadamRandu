//
//  TbIndustry.h
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbIndustry : NSManagedObject

@property (nonatomic, retain) NSNumber * indcode;
@property (nonatomic, retain) NSString * indcodea;
@property (nonatomic, retain) NSString * indgroupcode;
@property (nonatomic, retain) NSString * indname;
@property (nonatomic, retain) NSString * indsectcode;

@end
