//
//  TbLevel.h
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbLevel : NSManagedObject

@property (nonatomic, retain) NSNumber * levelCode;
@property (nonatomic, retain) NSString * levelName;
@property (nonatomic, retain) NSString * lvlDescription;
@property (nonatomic, retain) NSString * lvlGroupCode;

@end
