//
//  TbFunction.h
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbFunction : NSManagedObject

@property (nonatomic, retain) NSNumber * fnCatCode;
@property (nonatomic, retain) NSNumber * fncode;
@property (nonatomic, retain) NSString * fnDescription;
@property (nonatomic, retain) NSString * fnname;
@property (nonatomic, retain) NSNumber * otherFlag;

@end
