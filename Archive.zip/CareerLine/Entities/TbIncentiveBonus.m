//
//  TbIncentiveBonus.m
//  CareerLine
//
//  Created by Abbin on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbIncentiveBonus.h"


@implementation TbIncentiveBonus

@dynamic incentiveBonus;
@dynamic tid;

@end
