//
//  TbSalutation.m
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbSalutation.h"


@implementation TbSalutation

@dynamic clCycode;
@dynamic clGender;
@dynamic clSalutation;
@dynamic clSalutationid;

@end
