//
//  TbAllowancesLoadings.m
//  CareerLine
//
//  Created by Abbin on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbAllowancesLoadings.h"


@implementation TbAllowancesLoadings

@dynamic allowancesLoadings;
@dynamic tid;

@end
