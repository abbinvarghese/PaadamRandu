//
//  TbFunction.m
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbFunction.h"


@implementation TbFunction

@dynamic fnCatCode;
@dynamic fncode;
@dynamic fnDescription;
@dynamic fnname;
@dynamic otherFlag;

@end
