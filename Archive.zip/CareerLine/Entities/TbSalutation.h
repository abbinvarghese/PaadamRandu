//
//  TbSalutation.h
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbSalutation : NSManagedObject

@property (nonatomic, retain) NSString * clCycode;
@property (nonatomic, retain) NSString * clGender;
@property (nonatomic, retain) NSString * clSalutation;
@property (nonatomic, retain) NSNumber * clSalutationid;

@end
