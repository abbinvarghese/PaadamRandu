//
//  TbBenefits.m
//  CareerLine
//
//  Created by Padmam on 19/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbBenefits.h"


@implementation TbBenefits

@dynamic benefits;
@dynamic tid;

@end
