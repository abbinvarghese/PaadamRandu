//
//  TbLanguage.m
//  CareerLine
//
//  Created by Padmam on 22/07/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbLanguage.h"


@implementation TbLanguage

@dynamic cl_langcode;
@dynamic cl_langname;

@end
