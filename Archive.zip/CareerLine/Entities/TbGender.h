//
//  TbGender.h
//  CareerLine
//
//  Created by Padmam on 14/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbGender : NSManagedObject

@property (nonatomic, retain) NSString * clGender;
@property (nonatomic, retain) NSString * clGenderName;

@end
