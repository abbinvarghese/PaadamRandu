//
//  ClCountries.h
//  CareerLine
//
//  Created by Padmam on 13/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface ClCountries : NSManagedObject

@property (nonatomic, retain) NSString * ccFips;
@property (nonatomic, retain) NSString * ccIso;
@property (nonatomic, retain) NSString * cyCode;
@property (nonatomic, retain) NSString * cyCurrencycode;
@property (nonatomic, retain) NSString * cyCurrencyname;
@property (nonatomic, retain) NSString * cyCurrencysymbol;
@property (nonatomic, retain) NSString * cyName;
@property (nonatomic, retain) NSString * cyNationality;
@property (nonatomic, retain) NSNumber * genderLegalYn;
@property (nonatomic, retain) NSString * grType;
@property (nonatomic, retain) NSString * isdcode;
@property (nonatomic, retain) NSNumber * region;
@property (nonatomic, retain) NSString * tld;

@end
