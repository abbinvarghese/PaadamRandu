//
//  TbTypeEmploymentGroup.h
//  CareerLine
//
//  Created by Padmam on 14/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbTypeEmploymentGroup : NSManagedObject

@property (nonatomic, retain) NSNumber * tid;
@property (nonatomic, retain) NSString * typeEmploymentGroup;

@end
