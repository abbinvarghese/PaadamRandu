//
//  TbFunctionCat.h
//  CareerLine
//
//  Created by Padmam on 08/07/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbFunctionCat : NSManagedObject

@property (nonatomic, retain) NSString * fnCategory;
@property (nonatomic, retain) NSString * tid;

@end
