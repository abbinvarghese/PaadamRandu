//
//  TbJobimpactGroup.m
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbJobimpactGroup.h"


@implementation TbJobimpactGroup

@dynamic cyCode;
@dynamic tid;
@dynamic jobImpactGroup;

@end
