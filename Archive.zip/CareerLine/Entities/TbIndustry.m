//
//  TbIndustry.m
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbIndustry.h"


@implementation TbIndustry

@dynamic indcode;
@dynamic indcodea;
@dynamic indgroupcode;
@dynamic indname;
@dynamic indsectcode;

@end
