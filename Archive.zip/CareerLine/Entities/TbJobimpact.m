//
//  TbJobimpact.m
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbJobimpact.h"


@implementation TbJobimpact

@dynamic tid;
@dynamic jobimpact;
@dynamic jobimpactGroup;

@end
