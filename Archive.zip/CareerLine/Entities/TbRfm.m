//
//  TbRfm.m
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbRfm.h"


@implementation TbRfm

@dynamic rfm;
@dynamic rfmId;

@end
