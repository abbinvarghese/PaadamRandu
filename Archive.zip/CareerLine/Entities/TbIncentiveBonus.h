//
//  TbIncentiveBonus.h
//  CareerLine
//
//  Created by Abbin on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbIncentiveBonus : NSManagedObject

@property (nonatomic, retain) NSString * incentiveBonus;
@property (nonatomic, retain) NSNumber * tid;

@end
