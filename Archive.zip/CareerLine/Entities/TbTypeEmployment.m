//
//  TbTypeEmployment.m
//  CareerLine
//
//  Created by Padmam on 14/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbTypeEmployment.h"


@implementation TbTypeEmployment

@dynamic tid;
@dynamic jobMode;
@dynamic typeEmployment;

@end
