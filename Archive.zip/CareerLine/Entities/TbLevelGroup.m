//
//  TbLevelGroup.m
//  CareerLine
//
//  Created by Padmam on 15/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbLevelGroup.h"


@implementation TbLevelGroup

@dynamic groupcode;
@dynamic groupname;

@end
