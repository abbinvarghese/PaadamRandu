//
//  TbRfm.h
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbRfm : NSManagedObject

@property (nonatomic, retain) NSString * rfm;
@property (nonatomic, retain) NSNumber * rfmId;

@end
