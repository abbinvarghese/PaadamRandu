//
//  ClCountries.m
//  CareerLine
//
//  Created by Padmam on 13/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "ClCountries.h"


@implementation ClCountries

@dynamic ccFips;
@dynamic ccIso;
@dynamic cyCode;
@dynamic cyCurrencycode;
@dynamic cyCurrencyname;
@dynamic cyCurrencysymbol;
@dynamic cyName;
@dynamic cyNationality;
@dynamic genderLegalYn;
@dynamic grType;
@dynamic isdcode;
@dynamic region;
@dynamic tld;

@end
