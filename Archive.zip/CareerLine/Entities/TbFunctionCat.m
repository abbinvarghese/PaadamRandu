//
//  TbFunctionCat.m
//  CareerLine
//
//  Created by Padmam on 08/07/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbFunctionCat.h"


@implementation TbFunctionCat

@dynamic fnCategory;
@dynamic tid;

@end
