//
//  TbAllowancesLoadings.h
//  CareerLine
//
//  Created by Abbin on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TbAllowancesLoadings : NSManagedObject

@property (nonatomic, retain) NSString * allowancesLoadings;
@property (nonatomic, retain) NSNumber * tid;

@end
