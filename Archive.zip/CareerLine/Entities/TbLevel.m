//
//  TbLevel.m
//  CareerLine
//
//  Created by Padmam on 18/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "TbLevel.h"


@implementation TbLevel

@dynamic levelCode;
@dynamic levelName;
@dynamic lvlDescription;
@dynamic lvlGroupCode;

@end
