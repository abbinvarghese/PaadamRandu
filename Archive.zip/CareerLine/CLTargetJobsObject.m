//
//  CLTargetJobsObject.m
//  CareerLine
//
//  Created by Abbin on 24/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTargetJobsObject.h"
#import "AFHTTPRequestOperationManager+Timeout.h"

#define kDebugMessages 0

@implementation CLTargetJobsObject

static NSOperationQueue *targetJobsSummeryRequest;
static NSOperationQueue *getPreferredJobsForSearchStringrequest;
static NSOperationQueue *saveTargetJobRequest;


+ (void)cancelGetPreferredJobsRequest{
    [getPreferredJobsForSearchStringrequest cancelAllOperations];
    getPreferredJobsForSearchStringrequest = nil;
}

+(void)cancelTargetjobSummeryRequest{
    [targetJobsSummeryRequest cancelAllOperations];
    targetJobsSummeryRequest = nil;
}

- (id)initWithDictionary:(NSMutableDictionary*)dictionary{
    self = [super init];
    if (self == nil) return nil;
    self.preferredJobArray = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:0] objectForKey:kCLJobPreferencePreferredJobKey];
    self.functionArray = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:1] objectForKey:kCLJobPreferenceFinctionsKey];
    self.functionDict = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:1] objectForKey:kCLJobPreferenceFinctionsKey];
    self.industryArray = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:2] objectForKey:kCLJobPreferenceIndustryKey];
    self.careerLevelArray = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:3] objectForKey:kCLJobPreferenceJoblevelKey];
    self.jobScopeArray = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:4] objectForKey:kCLJobPreferenceJobScopeKey];
    self.anythingElseString = [[[dictionary objectForKey:kCLJobPreferenceTargetJobsKey] objectAtIndex:5] objectForKey:kCLJobPreferenceRemarksKey];
    return self;

}


+ (void)targetJobsSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLTargetJobsObject *targetJobsObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLTargetJobsObject *targetJobsObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"lang": lang};
    
    [targetJobsSummeryRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        targetJobsSummeryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServicetargetJobsSummaryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSMutableDictionary *response= [[NSMutableDictionary alloc]initWithDictionary:responseObject];
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLTargetJobsObject *targetJobsObj=[[CLTargetJobsObject alloc] initWithDictionary:response];
                success(targetJobsObj);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+(void)getPreferredJobsListForSearchString:(NSString*)searchText forUser:(NSString *)userId success:(void (^)(NSMutableArray *preferredJobsList))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *PreferredJobsList){};
    }
    
    NSDictionary *parameters = nil;
    parameters = @{@"str":searchText, @"user": userId,};
    
    [getPreferredJobsForSearchStringrequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getPreferredJobsForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServicePreferredJobsListURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
               
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *prefArray = [[NSMutableArray alloc]initWithArray:[response objectForKey:@"results"]];
                success(prefArray);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"eroorrr=---->%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+ (void)saveTargetJobs:(CLTargetJobsObject*)tarObj forUser:(NSString*)userId forlang:(NSString*)lang success:(void (^)(NSString *tarId))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *tarId){};
    }
    NSDictionary *parameters =@{@"user": userId, @"fields":[CLTargetJobsObject jsonStringForObject:tarObj], @"lang": lang};
    [saveTargetJobRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveTargetJobRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceSaveTargetJobsURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"saveContractConsiderationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                NSLog(@"%@",response);
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:@"id"]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+(NSString*)jsonStringForObject:(CLTargetJobsObject*)tarObj{
    
    NSMutableDictionary *mainDict = [[NSMutableDictionary alloc]init];
    NSMutableArray *insideArray = [[NSMutableArray alloc]init];
    
    NSMutableArray *preferredJobArray = [[NSMutableArray alloc]initWithArray:tarObj.preferredJobArray];
    NSMutableDictionary *preferedjobDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:preferredJobArray, kCLJobPreferencePreferredJobKey, nil];
    
    
    NSMutableArray *functionsArray = [[NSMutableArray alloc]initWithArray:tarObj.functionArray];
    NSMutableDictionary *functionDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:functionsArray, kCLJobPreferenceFinctionsKey, nil];
    
    NSMutableArray *industryArray = [[NSMutableArray alloc]initWithArray:tarObj.industryArray];
    NSMutableDictionary *industryDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:industryArray,kCLJobPreferenceIndustryKey, nil];
    
    NSMutableArray * jobLevelArray = [[NSMutableArray alloc]initWithArray:tarObj.careerLevelArray];
    NSMutableDictionary *jobLevelDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:jobLevelArray,kCLJobPreferenceJoblevelKey, nil];
    
    NSMutableArray *jobScopeArray = [[NSMutableArray alloc]initWithArray:tarObj.jobScopeArray];
    NSMutableDictionary *jobScopeDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:jobScopeArray,kCLTargetJobsJobScopeKey, nil];
    
    NSMutableDictionary * remarks = [[NSMutableDictionary alloc]initWithObjectsAndKeys:tarObj.anythingElseString, kCLJobPreferenceRemarksKey, nil];
    
    [insideArray addObject:preferedjobDict];
    [insideArray addObject:functionDict];
    [insideArray addObject:industryDict];
    [insideArray addObject:jobLevelDict];
    [insideArray addObject:jobScopeDict];
    [insideArray addObject:remarks];
    
    [mainDict setObject:insideArray forKey:kCLJobPreferenceTargetJobsKey];
    NSLog(@"%@",[CLCommon jsonStringWithPrettyPrint:NO foDict:mainDict]);
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:mainDict];
}

@end
