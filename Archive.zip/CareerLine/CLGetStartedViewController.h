//
//  CLGetStartedViewController.h
//  CareerLine
//
//  Created by CSG on 1/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLGetStartedViewController : UIViewController

@property(nonatomic,assign)BOOL isFirstTime;
@end
