//
//  CLKnowledgeListViewController.m
//  CareerLine
//
//  Created by RENJITH on 19/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLKnowledgeListViewController.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLLoaderCell.h"
#import "CLKnowledgeViewCell.h"
#import "CLKnowledgeObject.h"
#import "CLKnowledgeDetailsPage.h"


//knowledge lisitng filter..
typedef enum {
    FilterAllKnowledges = 0,
    FilterWakeEssential = 1,
    FilterPopularReads = 2,
    FilterBookmarked = 3
} KnowledgeFilterOptions;

@interface CLKnowledgeListViewController ()
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UILabel *refreshLbl;
@property (strong, nonatomic) IBOutlet UILabel *dummyLabel;

@property(nonatomic,assign)int nextPageToLoad;                  //holds the next page number to load..
@property(nonatomic,assign)BOOL isLastPageReached;              //whether last page reached(received from backend)..
@property(nonatomic,assign)BOOL shouldPaginate;
@property(nonatomic,assign)BOOL isRetreivingDataForPagination;
@property(nonatomic,retain) NSMutableArray *knowledgeArray;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (nonatomic,retain) UIRefreshControl *refreshControl;
@property(nonatomic) BOOL didPullDownToRefresh;
@property(nonatomic,retain) NSTimer *timer;
@property(nonatomic) BOOL goForTimer;
@property(nonatomic) BOOL timerStarted;
@property(nonatomic) BOOL isNewUser;
@property(nonatomic,assign)KnowledgeFilterOptions selectedFilterButton;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *barBttnKnowledgeFilter;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property(nonatomic,strong)NSString *searchText;
@property (nonatomic) float searchBarBoundsY;
@end

@implementation CLKnowledgeListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"WAKE", @"Knowledge page title");
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    self.goForTimer = NO;
    self.didPullDownToRefresh = YES;
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.tintColor = [UIColor grayColor];
    [self.refreshControl addTarget:self action:@selector(clearArraysAndReloadTableData) forControlEvents:UIControlEventValueChanged];
    [self.collectionView addSubview:self.refreshControl];
    self.collectionView.alwaysBounceVertical = YES;

    self.selectedFilterButton=FilterAllKnowledges;
    [self.collectionView registerClass:[CLLoaderCell class] forCellWithReuseIdentifier:@"CLLoaderCell"];
    self.isLastPageReached = NO;
    self.knowledgeArray = [[NSMutableArray alloc]init];
    self.nextPageToLoad=1;
    self.shouldPaginate = YES;
    [self setupLeftMenuButton];
    [self setupCollectionView];
    self.isNewUser = YES;
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    //[self addSearchBar];
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Wake List"];
}
#pragma mark - prepareVC
-(void)addSearchBar{
    if (!self.searchBar) {
        self.searchBarBoundsY = self.navigationController.navigationBar.frame.size.height + [UIApplication sharedApplication].statusBarFrame.size.height;
        self.searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(0,self.searchBarBoundsY, [UIScreen mainScreen].bounds.size.width, 44)];
        self.searchBar.searchBarStyle    = UISearchBarStyleDefault;
        self.searchBar.showsCancelButton = YES;
        self.searchBar.delegate          = self;
        
        [[UITextField appearanceWhenContainedIn:[UISearchBar class], nil] setTextColor:[UIColor blackColor]];
    }
    
    if (![self.searchBar isDescendantOfView:self.view]) {
        [self.view addSubview:self.searchBar];
    }
}
#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [self filterContentForSearchText:searchBar.text];
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
        [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}

-(void)searchAfterDelay{
    [self filterContentForSearchText:self.searchText];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self addButtonsToToolbar];
    
    self.searchText=@"";
    
    self.refreshLbl.hidden = YES;
    [self.navigationController setToolbarHidden:NO];
     [self.collectionView reloadData];
    if (self.isNewUser) {
        
         self.isNewUser =NO;
    }
    [self clearArraysAndReloadTableData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
    [CLKnowledgeObject cancelknowledgeListingPendingRequests];
    [CLKnowledgeObject cancelknowledgeBookmarkListingPendingRequests];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addButtonsToToolbar{
 
    if (self.selectedFilterButton == FilterAllKnowledges) {
        UIBarButtonItem *knowledgeFilterButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Recommended For You", @"Knowledge filter button title in listing page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionKnowledgeFilterChange:)];
        UIBarButtonItem *firstFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *secondFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        [self setToolbarItems:[NSArray arrayWithObjects:firstFlexibleSpace,knowledgeFilterButton,secondFlexibleSpace, nil] animated:YES];

        self.barBttnKnowledgeFilter=knowledgeFilterButton;
    }else if(self.selectedFilterButton == FilterBookmarked){
        UIBarButtonItem *bookmarkFilterButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"My Bookmarks", @"Knowledge filter button title in listing page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionKnowledgeFilterChange:)];
        UIBarButtonItem *firstBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *secondBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        [self setToolbarItems:[NSArray arrayWithObjects:firstBookemarkFlexibleSpace,bookmarkFilterButton,secondBookemarkFlexibleSpace, nil] animated:YES];
        self.barBttnKnowledgeFilter=bookmarkFilterButton;
    }
    else if (self.selectedFilterButton == FilterWakeEssential){
        UIBarButtonItem *bookmarkFilterButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"WAKE Essentials", @"Knowledge filter button title in listing page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionKnowledgeFilterChange:)];
        UIBarButtonItem *firstBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *secondBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        [self setToolbarItems:[NSArray arrayWithObjects:firstBookemarkFlexibleSpace,bookmarkFilterButton,secondBookemarkFlexibleSpace, nil] animated:YES];
        self.barBttnKnowledgeFilter=bookmarkFilterButton;
    }
    else{
        UIBarButtonItem *bookmarkFilterButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Popular Reads", @"Knowledge filter button title in listing page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionKnowledgeFilterChange:)];
        UIBarButtonItem *firstBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *secondBookemarkFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        [self setToolbarItems:[NSArray arrayWithObjects:firstBookemarkFlexibleSpace,bookmarkFilterButton,secondBookemarkFlexibleSpace, nil] animated:YES];
        self.barBttnKnowledgeFilter=bookmarkFilterButton;
    }
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    float scrollViewHeight = scrollView.frame.size.height;
    float scrollContentSizeHeight = scrollView.contentSize.height;
    float scrollOffset = scrollView.contentOffset.y;
    
    if (self.shouldPaginate) {
        if ((scrollOffset + scrollViewHeight >= scrollContentSizeHeight) && (scrollContentSizeHeight>0))
        {
            self.goForTimer = YES;
            [self retriveKnowledgeWithPagination:YES];
            self.shouldPaginate = NO;
        }
    }
    
}

#pragma mark UICollectionView Methods

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (self.knowledgeArray.count > 0) {
        return [self.knowledgeArray count]+1;
    }
    else{
        return 0;
    }
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //[self changeTheDummylabelSize:indexPath];
    if (indexPath.row==34) {
        
    }
    
    if (indexPath.row == [self.knowledgeArray count]) {
        CLLoaderCell *footercell = (CLLoaderCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"CLLoaderCell" forIndexPath:indexPath];
        [footercell updateLoaderForPage:self.isLastPageReached];
        return footercell;
    }
    else{
        CLKnowledgeViewCell *cell = (CLKnowledgeViewCell *)[self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
        if (self.knowledgeArray.count > 0) {
            cell.knowledgeObj = [self.knowledgeArray objectAtIndex:indexPath.row];
            [cell updateContentsForIndexPath:indexPath];
        }
        cell.delegate=self;
        return cell;
        
    }
    
}

- (CGFloat)collectionView:(UICollectionView *)collectionView
                   layout:(CLCollectionViewMasonryLayout *)collectionViewLayout
 heightForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 34) {
        
    }
    if (!self.isLastPageReached) {
        if (indexPath.row == self.knowledgeArray.count) {
            return 44;
        }
        else{
            return [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell:indexPath];
            //return MAX(1, [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell:indexPath]);
            
        }
    }
    else{
        if (indexPath.row == self.knowledgeArray.count) {
            return 0;
        }
        else{
            return [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell:indexPath];
           // return MAX(1, [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell:indexPath]);
        }
    }
}
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForHeaderInLayout:(CLCollectionViewMasonryLayout *)collectionViewLayout{
    
    return 0;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == self.knowledgeArray.count) {
        
    }
    else{
        CLKnowledgeDetailsPage *controller = [[CLKnowledgeDetailsPage alloc]initWithNibName:@"CLKnowledgeDetailsPage" bundle:[NSBundle mainBundle]];
        controller.knowledgeRecId = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).knowledgeId;
        controller.ktype=((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

#pragma mark Utility Functions

-(void)clearArraysAndReloadTable{
    [self.knowledgeArray removeAllObjects];
    self.isNewUser =YES;
    [self.collectionView reloadData];
}

-(void)clearArraysAndReloadTableData{

    self.goForTimer = NO;
    self.nextPageToLoad = 1;
    self.didPullDownToRefresh = YES;
    self.searchText = @"";
    self.searchBar.text = @"";
    [self.searchBar resignFirstResponder];
    
    if([CLUserObject currentUser].userID != nil)
        [self retriveKnowledgeWithPagination:NO];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}

-(float)getImageHeightForIndexPath:(NSIndexPath*)indexPath{
    float imageWidth =0;
    float imageHeight=0;
    if (indexPath.row == 34) {
        
    }
    float imageViewWidth=158;
    NSLog(@"%@",((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).title);
    imageWidth=[((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).imgWidth floatValue] ;
    imageHeight=[((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).imgHeight floatValue];
   

    float result = 0.0;
    if(imageWidth ==0 && imageHeight ==0){
        imageWidth=0;
        imageHeight=0;
    }
    else
    {
        result=imageHeight/imageWidth*imageViewWidth;
    }
    
    return result;
}

-(float)getTextSectionHeightForCell:(NSIndexPath*)index
{
    return [self changeTheDummylabelSize:index];
}

-(float)getHeightForLabelForText:(NSString*)text :(UILabel*)label :(BOOL)forDiscription{
    
    if (text == nil) {
        text=@"";
    }
    else{
        
    }
    
    NSAttributedString *attributedText = nil;
    if (forDiscription) {
        attributedText = [[NSAttributedString alloc] initWithString:text];
    }
    else{
        attributedText = [[NSAttributedString alloc] initWithString:text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    }
    
    CGRect rect = [attributedText boundingRectWithSize:(CGSize){label.frame.size.width, CGFLOAT_MAX}
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    return rect.size.height;
}

-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(void)setupCollectionView {
    
    [self.collectionView registerClass:[CLKnowledgeViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    self.collectionView.delegate=self;
    self.collectionView.dataSource=self;
    
    
    CLCollectionViewMasonryLayout *masonryLayout = [[CLCollectionViewMasonryLayout alloc] init];
    masonryLayout.sectionInset = UIEdgeInsetsMake(20,10,10,10);
    masonryLayout.delegate = self;
    masonryLayout.columnCount = 2;
    masonryLayout.itemWidth = ([UIScreen mainScreen].bounds.size.width-30)/2;
    
    [self.collectionView setCollectionViewLayout:masonryLayout];
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self.collectionView reloadData];
    
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
-(void)retriveKnowledgeWithPagination:(BOOL)paginate{
    
    if (self.nextPageToLoad == 1 && self.didPullDownToRefresh) {
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Loading WAKE...", @"Text displayed in the loading indicator while loading documents");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [self.activityIndicator showInView:self.view];
    }
//    if (self.selectedFilterButton ==FilterAllKnowledges ) {
        [CLKnowledgeObject cancelknowledgeListingPendingRequests];
        [CLKnowledgeObject listKnowledgeForUserId:[CLUserObject currentUser].userID searchString:self.searchText pageNumber:self.nextPageToLoad flagOrType:self.selectedFilterButton success:^(NSMutableArray *knowledgeList, BOOL isLastPageReached, NSString* knowledgeCount, NSInteger currentPage, NSInteger pages) {
            
                self.refreshLbl.hidden = YES;
                
                if (self.didPullDownToRefresh) {
                    [self.knowledgeArray removeAllObjects];
                }
                self.isLastPageReached = isLastPageReached;
                
                [self.knowledgeArray addObjectsFromArray:knowledgeList];
                
                if (isLastPageReached) {
                    self.shouldPaginate = NO;
                }
                else{
                    self.shouldPaginate = YES;
                }
                [self.searchBar resignFirstResponder];
                self.goForTimer = NO;
                [self.timer invalidate];
                self.timerStarted = NO;
                if (self.nextPageToLoad == 1 && self.didPullDownToRefresh) {
                    [self.activityIndicator hideWithAnimation:YES];
                }
                self.didPullDownToRefresh = NO;
                self.nextPageToLoad++;
                if (self.knowledgeArray.count == 0) {
                    self.refreshLbl.hidden = NO;
                    self.refreshLbl.text = NSLocalizedString(@"No WAKE List Found. Pull down to refresh.", @"Error Message");
                }
         
            [self.collectionView reloadData];
        } failure:^(NSString *error) {

//            if (!self.goForTimer && self.didPullDownToRefresh) {
            if (YES) {
                [self.activityIndicator hideWithAnimation:YES];
//                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Failed to load Knowledge List", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            if (self.goForTimer && !self.timerStarted) {
                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
                self.timerStarted = YES;
            }
            if (self.knowledgeArray.count == 0) {
                
                self.refreshLbl.hidden = NO;
                self.refreshLbl.text = NSLocalizedString(@"No WAKE List Found. Pull Down To Refresh", @"Error Message");
            }
            self.didPullDownToRefresh = NO;
        }];

//    }else if (self.selectedFilterButton == FilterBookmarked){
//        
//        [CLKnowledgeObject cancelknowledgeBookmarkListingPendingRequests];
//        [CLKnowledgeObject listBookmarkedKnowledgeForUserId:[CLUserObject currentUser].userID searchString:self.searchText pageNumber:self.nextPageToLoad success:^(NSMutableArray *knowledgeList, BOOL isLastPageReached, NSString* knowledgeCount, NSInteger currentPage, NSInteger pages) {
//            
//            self.refreshLbl.hidden = YES;
//            
//            if (self.didPullDownToRefresh) {
//                [self.knowledgeArray removeAllObjects];
//            }
//            self.isLastPageReached = isLastPageReached;
//            
//            [self.knowledgeArray addObjectsFromArray:knowledgeList];
//            
//            if (isLastPageReached) {
//                self.shouldPaginate = NO;
//            }
//            else{
//                self.shouldPaginate = YES;
//            }
//            [self.searchBar resignFirstResponder];
//            self.goForTimer = NO;
//            [self.timer invalidate];
//            self.timerStarted = NO;
//            if (self.nextPageToLoad == 1 && self.didPullDownToRefresh) {
//                [self.activityIndicator hideWithAnimation:YES];
//            }
//            self.didPullDownToRefresh = NO;
//            self.nextPageToLoad++;
//            if (self.knowledgeArray.count == 0) {
//                self.refreshLbl.hidden = NO;
//                self.refreshLbl.text = NSLocalizedString(@"No Bookmarked List Found. Pull down to refresh.", @"Error Message");
//            }
//            [self.collectionView reloadData];
//        } failure:^(NSString *error) {
//            
//            if (!self.goForTimer && self.didPullDownToRefresh) {
//                [self.activityIndicator hideWithAnimation:YES];
//               // [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Failed to load Knowledge List", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//            }
//            if (self.goForTimer && !self.timerStarted) {
//                self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
//                self.timerStarted = YES;
//            }
//            if (self.knowledgeArray.count == 0) {
//                
//                self.refreshLbl.hidden = NO;
//                self.refreshLbl.text = NSLocalizedString(@"Pull Down To Refresh.", @"Error Message");
//            }
//            self.didPullDownToRefresh = NO;
//        }];
//    }
}


-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)startTimer{
    [self retriveKnowledgeWithPagination:YES];
}

- (IBAction)bttnActionKnowledgeFilterChange:(id)sender {
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *jobFilterActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"knowledge filtering actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Recommended For You", @"job filtering actionsheet option 1"),NSLocalizedString(@"WAKE Essentials", @"knowledge filtering actionsheet option 2"),NSLocalizedString(@"Popular Reads", @"knowledge filtering actionsheet option 2"),NSLocalizedString(@"My Bookmarks", @"knowledge filtering actionsheet option 2"), nil];
        [jobFilterActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *allKnowledgeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Recommended For You", @"Knowledges filtering actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self actionSheet:nil didDismissWithButtonIndex:FilterAllKnowledges];
                                        }];
        
        UIAlertAction *bookmarkedKnowledgeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"WAKE Essentials", @"Knowledges filtering actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                             {
                                                 [self actionSheet:nil didDismissWithButtonIndex:FilterWakeEssential];
                                             }];
        UIAlertAction *wakeEssestialsKnowledgeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Popular Reads", @"Knowledges filtering actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                    {
                                                        [self actionSheet:nil didDismissWithButtonIndex:FilterPopularReads];
                                                    }];
        UIAlertAction *popularReadsKnowledgeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"My Bookmarks", @"Knowledges filtering actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                    {
                                                        [self actionSheet:nil didDismissWithButtonIndex:FilterBookmarked];
                                                    }];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"knowledge filtering actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        [actionSheetController addAction:allKnowledgeAction];
        [actionSheetController addAction:bookmarkedKnowledgeAction];
        [actionSheetController addAction:wakeEssestialsKnowledgeAction];
        [actionSheetController addAction:popularReadsKnowledgeAction];
        [actionSheetController addAction:cancelAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIActionSheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case FilterAllKnowledges:
            self.selectedFilterButton=FilterAllKnowledges;
            [self.barBttnKnowledgeFilter setTitle:NSLocalizedString(@"Recommended For You", @"Knowledges filtering actionsheet option 1")];
             self.selectedFilterButton=FilterAllKnowledges;
            [CLCommon sentEventNameToGoogleAnalytics:@"Recommended For You - Wake List" screenName:@"IOS - Wake List"];
            break;
        case FilterBookmarked:
            self.selectedFilterButton=FilterBookmarked;
            [self.barBttnKnowledgeFilter setTitle:NSLocalizedString(@"My Bookmarks", @"Knowledges filtering actionsheet option 2")];
             self.selectedFilterButton=FilterBookmarked;
            
            [CLCommon sentEventNameToGoogleAnalytics:@"My Bookmarks - Wake List" screenName:@"IOS - Wake List"];
            break;
        case FilterWakeEssential:
            self.selectedFilterButton=FilterWakeEssential;
            [self.barBttnKnowledgeFilter setTitle:NSLocalizedString(@"WAKE Essentials", @"Knowledges filtering actionsheet option 2")];
            self.selectedFilterButton=FilterWakeEssential;
            [CLCommon sentEventNameToGoogleAnalytics:@"WAKE Essentials - Wake List" screenName:@"IOS - Wake List"];
            break;
        case FilterPopularReads:
            self.selectedFilterButton=FilterPopularReads;
            [self.barBttnKnowledgeFilter setTitle:NSLocalizedString(@"Popular Reads", @"Knowledges filtering actionsheet option 2")];
            self.selectedFilterButton=FilterPopularReads;
            [CLCommon sentEventNameToGoogleAnalytics:@"Popular Reads - Wake List" screenName:@"IOS - Wake List"];
            break;

        default:
            break;
    }
    self.refreshLbl.hidden=YES;
    [self.activityIndicator hideWithAnimation:NO];
    
    [self.knowledgeArray removeAllObjects];
    self.goForTimer = NO;
    self.nextPageToLoad = 1;
    self.didPullDownToRefresh = YES;
   
    [self retriveKnowledgeWithPagination:NO];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

//Search knowledge method
- (void)filterContentForSearchText:(NSString*)searchText
{
    self.nextPageToLoad = 1;
    self.searchText = searchText;
    [self.knowledgeArray removeAllObjects];
    [self retriveKnowledgeWithPagination:NO];
    
}

#pragma mark Collection view cell delagate methods

-(void)cellBookmarkKnowledge:(CLKnowledgeViewCell *)cell{
    NSIndexPath *indexPath = [self.collectionView indexPathForCell:cell];
    
    CLKnowledgeObject *knowObj = [self.knowledgeArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Bookmark...", @"Text displayed in the loading indicator while bookmarking");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:SharedAppDelegate.window];
    [CLKnowledgeObject bookMarkKnowledgeforUser:knowObj.knowledgeId type:knowObj.type success:^{
        [progressHUD hideWithAnimation:YES];
        if ([cell.bookmarkBtn.currentBackgroundImage isEqual:[UIImage imageNamed:@"bookmark.png"]]){
            [cell.bookmarkBtn setBackgroundImage:[UIImage imageNamed:@"bookmarked.png"] forState:UIControlStateNormal];
            knowObj.isBookMarked = YES;
        }else{
            [cell.bookmarkBtn setBackgroundImage:[UIImage imageNamed:@"bookmark.png"] forState:UIControlStateNormal];
            knowObj.isBookMarked = NO;
        }
         [self.collectionView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}
-(void)cellLikeKnowledge:(CLKnowledgeViewCell *)cell{
    
    NSIndexPath *indexPath = [self.collectionView indexPathForCell:cell];

    CLKnowledgeObject *knowObj = [self.knowledgeArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Like...", @"Text displayed in the loading indicator while bookmarking");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:SharedAppDelegate.window];
    [CLKnowledgeObject likeKnowledge:knowObj.knowledgeId forUser:[CLUserObject currentUser].userID type:knowObj.type success:^{
        [progressHUD hideWithAnimation:YES];
        cell.likeLbl.text = [NSString stringWithFormat:@"%d",[knowObj.likeCount intValue]+1];
        cell.likeBtn.enabled = NO;
        int count = [knowObj.likeCount intValue]+1;
        knowObj.likeCount = [NSNumber numberWithInt:count];
        knowObj.isLiked = YES;
        [self.collectionView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
    
}

-(float)changeTheDummylabelSize:(NSIndexPath*)indexPath
{
    float height = 0;
    CGRect currentLabelFrame = self.dummyLabel.frame;
    currentLabelFrame.size.width = ((CLCollectionViewMasonryLayout*)self.collectionView.collectionViewLayout).itemWidth;
    self.dummyLabel.frame = currentLabelFrame;
    
    NSString *title, *newsCompanyName, *lableTwo;

    if (self.knowledgeArray.count>indexPath.row)
    {
        title = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).title;
    }

    if (self.knowledgeArray.count>indexPath.row) {
        if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"W"]) {
            newsCompanyName = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).author;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"E"]){
            newsCompanyName = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).location;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"O"]){
            newsCompanyName = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).companyName;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"V"]){
            newsCompanyName = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).companyName;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"K"]){
            newsCompanyName = [NSString stringWithFormat:@"%@ %@",((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).author,((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).companyName];
        }
        else{
            newsCompanyName = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).author;
        }
    }

    if (self.knowledgeArray.count>indexPath.row)
    {
        if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"W"]) {
            lableTwo = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).publishedCreated;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"E"]){
            lableTwo = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).eventDate;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"O"]){
            lableTwo = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).author;
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"V"]){

            lableTwo = [NSString stringWithFormat:@"%@ %@",((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).location,((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).eventDate];
        }
        else if ([((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).type isEqualToString:@"K"]){

            lableTwo = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).dateCreated;
        }
        else {

            lableTwo = ((CLKnowledgeObject *)[self.knowledgeArray objectAtIndex:indexPath.row]).publishedCreated;
        }
    }

    self.dummyLabel.text = @"";
    
    if([CLCommon trimWhiteSpaces:title].length && [CLCommon trimWhiteSpaces:newsCompanyName].length && [CLCommon trimWhiteSpaces:lableTwo].length)
    {
        self.dummyLabel.text = [NSString stringWithFormat:@"%@\n\n%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:title],[CLCommon trimWhiteSpaces:newsCompanyName], [CLCommon trimWhiteSpaces:lableTwo]];
    }
    else if([CLCommon trimWhiteSpaces:title].length != 0 && [CLCommon trimWhiteSpaces:newsCompanyName].length == 0 && [CLCommon trimWhiteSpaces:lableTwo].length != 0)
    {
        self.dummyLabel.text = [NSString stringWithFormat:@"%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:title], [CLCommon trimWhiteSpaces:lableTwo]];

    }
    else if([CLCommon trimWhiteSpaces:title].length != 0 && [CLCommon trimWhiteSpaces:newsCompanyName].length != 0 && [CLCommon trimWhiteSpaces:lableTwo].length == 0)
    {
        self.dummyLabel.text = [NSString stringWithFormat:@"%@\n\n%@\n\n",[CLCommon trimWhiteSpaces:title],[CLCommon trimWhiteSpaces:newsCompanyName]];
    }

    if(self.dummyLabel.text.length)
    {
        NSMutableAttributedString *attrString = nil;
        UIFont *font = HELVETICA_NEUE_BOLD_FONT_WITH_SIZE(12.0);
        
        attrString = [[NSMutableAttributedString alloc] initWithString:self.dummyLabel.text ];
        
        if([CLCommon trimWhiteSpaces:title].length)
        {
            NSRange titleRange	= [self.dummyLabel.text  rangeOfString:[CLCommon trimWhiteSpaces:title] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:titleRange];
        }
        
        font = HELVETICA_NEUE_REGULAR_FONT_WITH_SIZE(11.0);
        
        if([CLCommon trimWhiteSpaces:newsCompanyName].length)
        {
            NSRange newComRange	= [self.dummyLabel.text rangeOfString:[CLCommon trimWhiteSpaces:newsCompanyName] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:newComRange];
        }
        
        if([CLCommon trimWhiteSpaces:lableTwo].length)
        {
            NSRange lbl2Range	= [self.dummyLabel.text rangeOfString:[CLCommon trimWhiteSpaces:lableTwo] options:NSCaseInsensitiveSearch];
            [attrString addAttribute:NSFontAttributeName value:font range:lbl2Range];
        }
        
        self.dummyLabel.attributedText = attrString;
        
        height = [CLCommon measureHeightOfUILabel:self.dummyLabel] + 30.0f;
    }
    
    return height;
}

@end
