//
//  CLCareerHistoryCell.h
//  CareerLine
//
//  Created by RENJITH on 23/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCareerHistoryObject.h"
@interface CLCareerHistoryCell : UITableViewCell

@property (nonatomic, strong) CLCareerHistoryObject *careerHistoryObj;
@end
