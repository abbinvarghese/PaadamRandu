//
//  CLEmailPickerTableViewController.m
//  CareerLine
//
//  Created by CSG on 7/1/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEmailPickerTableViewController.h"
#import "CLUserObject.h"
@import AddressBook;

@interface CLEmailPickerTableViewController ()

@property (strong, nonatomic) IBOutlet UIView *sectionHeaderView;
@property (weak, nonatomic) IBOutlet UITextField *txtEmailField;

@property(nonatomic, strong)NSMutableArray *contactsArray;
@property(nonatomic, strong)NSMutableArray *filteredArray;
@property(nonatomic,assign) BOOL isSearching;
@end

@implementation CLEmailPickerTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Share via email", @"title for sharing job via email");
    self.tableView.tableHeaderView=self.sectionHeaderView;
    [self setLeftNavigationButton];
    [self setRightNavigationButton];
    
    self.contactsArray=[[NSMutableArray alloc] init];
    self.filteredArray=[[NSMutableArray alloc] init];
    self.isSearching=NO;
    
    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized){
        dispatch_async(dispatch_get_main_queue(), ^{
            [self retreiveEmailListAndPopulateArrayFromContacts];
            [self.tableView reloadData];
        });
    }
    else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined){
        ABAddressBookRequestAccessWithCompletion(ABAddressBookCreateWithOptions(NULL, nil), ^(bool granted, CFErrorRef error) {
            if (granted){
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self retreiveEmailListAndPopulateArrayFromContacts];
                    [self.tableView reloadData];
                });
            }
        });
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"CompanyDetails dismiss modal button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Send", @"CompanyDetails send email button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSendEmail:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)retreiveEmailListAndPopulateArrayFromContacts{
    ABAddressBookRef allPeople = ABAddressBookCreateWithOptions(nil, nil);
    CFArrayRef allContacts = ABAddressBookCopyArrayOfAllPeople(allPeople);
    CFIndex numberOfContacts  = ABAddressBookGetPersonCount(allPeople);
    
    for(int i = 0; i < numberOfContacts; i++){
        ABRecordRef aPerson = CFArrayGetValueAtIndex(allContacts, i);
        
        //creating full name
        NSString *fullname = nil;
        ABMultiValueRef fnameProperty = ABRecordCopyValue(aPerson, kABPersonFirstNameProperty);
        ABMultiValueRef lnameProperty = ABRecordCopyValue(aPerson, kABPersonLastNameProperty);
        if (fnameProperty != nil && lnameProperty==nil) {
            fullname = [NSString stringWithFormat:@"%@", fnameProperty];
        }
        else if (fnameProperty == nil && lnameProperty!=nil){
            fullname = [NSString stringWithFormat:@"%@", lnameProperty];
        }
        else if (fnameProperty != nil && lnameProperty!=nil){
            fullname = [NSString stringWithFormat:@"%@ %@",fnameProperty, lnameProperty];
        }
        else{
            fullname = @"No name";
        }
        
        //creating email..
        ABMultiValueRef emailProperty = ABRecordCopyValue(aPerson, kABPersonEmailProperty);
        NSArray *emailArray = (__bridge NSArray *)ABMultiValueCopyArrayOfAllValues(emailProperty);
        if ([emailArray count] > 0) {
            NSString *email=nil;
            for (int i = 0; i < [emailArray count]; i++) {
                email=[emailArray objectAtIndex:i];
                [self.contactsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:fullname, @"name", email, @"email",aPerson,@"person", nil]];
            }
        }
    }
}

- (void)searchContactEmailWithSubstring:(NSString *)substring {
    self.isSearching=YES;
    [self.filteredArray removeAllObjects];
    if ([substring isEqualToString:@""]) {
        self.isSearching=NO;
    }
    else{
        for(NSDictionary *contactDict in self.contactsArray) {
            NSString *email=[contactDict objectForKey:kCLJobListemailKey];
            NSRange substringRange = [email rangeOfString:substring];
            if (substringRange.location == 0) {
                [self.filteredArray addObject:contactDict];
            }
        }
    }
    //[self.tableView reloadData];
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
}

-(UIImage *)getThumbnailForPerson:(ABRecordRef)person{
    if (ABPersonHasImageData(person)) {
        return [UIImage imageWithData:(__bridge NSData *)ABPersonCopyImageDataWithFormat(person, kABPersonImageFormatThumbnail)];
    }
    else{
        return [UIImage imageNamed:@"user_placeholder"];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isSearching) {
        return [self.filteredArray count];
    }
    else{
        return [self.contactsArray count];
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CompanyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    NSDictionary *userDict=nil;
    if (self.isSearching) {
        userDict=[self.filteredArray objectAtIndex:indexPath.row];
    }
    else{
        userDict=[self.contactsArray objectAtIndex:indexPath.row];
    }
    
    cell.textLabel.text=[userDict objectForKey:kCLJobListNameKey];
    cell.detailTextLabel.text=[userDict objectForKey:kCLJobListemailKey];
    
    ABRecordRef person=(__bridge ABRecordRef)[userDict objectForKey:kCLJobListPersonKey];
    cell.imageView.image=[self getThumbnailForPerson:person];
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *userDict=nil;
    if (self.isSearching) {
        userDict=[self.filteredArray objectAtIndex:indexPath.row];
    }
    else{
        userDict=[self.contactsArray objectAtIndex:indexPath.row];
    }
    self.txtEmailField.text=[userDict objectForKey:kCLJobListemailKey];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

#pragma mark UITextFieldDelegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark IBActions

- (IBAction)bttnActionSendEmail:(id)sender {
    if (![CLCommon validateEmailWithString:self.txtEmailField.text]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Email address.", @"Error Message for invalid email address for login") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^{
            [CLJobsObject shareJobDetailsViaMail:self.txtEmailField.text forJobId:self.job.jobID withUserId:[CLUserObject currentUser].userID
                                         success:nil
                                         failure:^(NSString *error) {
                                             if (![error isEqualToString:@""]) {
                                                 [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                             }
                                         }];
        }];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)textFieldValueChanged:(UITextField *)sender {
    [self searchContactEmailWithSubstring:sender.text];
}

@end
