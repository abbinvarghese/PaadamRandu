//
//  CLProfileReferenceCell.h
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLReviewObject.h"

@interface CLProfileReferenceCell : UITableViewCell

@property(nonatomic,strong)CLReviewObject *revObj;

-(void)updateCellContents;

@end
