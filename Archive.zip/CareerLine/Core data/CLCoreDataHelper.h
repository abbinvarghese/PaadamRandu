//
//  CLCoreDataHelper.h
//  CareerLine
//
//  Created by Padmam on 12/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "ClCountries.h"
#import "TbGender.h"
#import "TbEmpStatus.h"
#import "TbTypeEmployment.h"
#import "TbCyEduEquilent.h"
#import "TbTypeEmploymentGroup.h"
#import "TbTypeEmploymentSub.h"
#import "TbIndsector.h"
#import "TbIndgroup.h"
#import "TbIndustry.h"
#import "TbFunctionCat.h"
#import "TbFunction.h"
#import "TbLevelGroup.h"
#import "TbLevel.h"
#import "TbRfm.h"
#import "TbJobimpactGroup.h"
#import "TbJobimpact.h"
#import "TbAllowancesLoadings.h"
#import "TbFrequency.h"
#import "TbSalutation.h"
#import "TbBenefits.h"
#import "TbLanguage.h"

@interface CLCoreDataHelper : NSObject
{
    NSManagedObjectContext * managedObjectContext;
}

+ (CLCoreDataHelper *)sharedCLCoreDataHelper;

- (void)deleteAllObjects:(NSString *)entityDescription;
- (NSManagedObjectContext *)getManagedObjectContext;

//Methods
- (NSString*)getISDOfCurrentCountry:(NSString*)cyCode; //isd code for current location
- (NSArray*)getAllISDCodeFromDB;    //To get all the ISD Code..
- (NSMutableDictionary*)getNationalityFromCountryCode :(NSString*)cyCode;
- (NSString*)getCountryCodeForCountry :(NSString*)country;

- (NSString*)getFunctionGroupNamefrom:(NSString*)groupCode;

-(NSMutableArray*)getAllBenefitsListFromDB;

//-(NSMutableArray*)getAllLanguageListFromDB;
- (NSMutableArray*)getAllLanguageListFromDB:(id)sender notIn:(NSString *)blackListString andSearchString:(NSString*)searchText;

- (NSMutableArray*)getAllCareerMoveListFromDB;
- (NSMutableArray*)getAllCountryDetailsForCurrency:(NSString*)string;
- (NSMutableArray*)getIncentiveBonusListFromDB;
- (NSMutableArray*)getAllowanceAndLoadingListFromDB;
- (NSArray*)getAllGenderListFromDB; //To get all the Gender list..
- (NSMutableArray*)getAllEmpStatusFromDB;  //To get all the Employment status..
- (NSMutableArray*)getAllEmpTypeFromDB;    //To get all the Employment type..

- (NSMutableArray*)getAllEducationListFromDBForCountry:(NSString*)cyCode;  //To get all the education list ..

- (NSMutableArray*)getAllEmpTypeGroupFromDB;    //To get all employeement group
- (NSMutableArray*)getAllEmpTypeDetailForGroup:(NSDictionary *)empTypeGroup;   //To get all employeement group details

- (NSString*)getIndustrySectionNameFrom:(NSString*)sectionCode;     //to get sectionName
- (NSMutableArray*)getAllIndustrySectorsFromDB:(id)sender notIn:(NSString *)blackListString;    //To get all the Industry sectors..
- (NSMutableArray*)getIndustriesGroupedForSector:(NSMutableDictionary*)sectorDict; //To get all the Industries grouped for sectors..

//To get final industries list for the group selected..

- (NSMutableArray*)getAllJobFunctionsForCategoryId:(NSString*)catId;
- (NSMutableArray*)getAllJobFunctionsForFnId:(NSString*)code;
- (NSMutableArray*)getMainIndustriesListForGroup:(NSMutableDictionary*)groupDict;
- (NSMutableArray*)getMainIndustriesListForGroup:(NSMutableDictionary*)groupDict notIn:(NSString*)blackListString;

- (NSString*)getIndustryGroupNamefrom:(NSString*)groupCode; //To get the groupName

- (NSMutableArray*)getAllJobFunctionsCategory;   //To get all the job Function category ..

- (NSMutableArray*)getAllJobFunctionsForCategory:(NSString*)catId notIn:(NSString*)blackListString;//To get all the job Functions..

- (NSMutableArray*)getAllJobFunctionsForCategoryIncaseAllFunctionIsSelected:(NSString*)catId notIn:(NSString*)blackListString;// to get jobFunction in case of allFunction selected

- (NSMutableArray*)getAllJobLevelGroupFromDB;   //To get all the job level group..

- (NSMutableArray*)getAllJobLevelDetailForJobGroup:(NSDictionary*)jobGroup; ////To get all the job level detail group..
- (NSMutableArray*)getAllEmpJobScopeFromDB:(NSString*)countryCode;

- (NSMutableArray*)getJobScopeGroupedForSector:(NSMutableDictionary*)sectorDict;

//To get all the nationalities from DB except those contained in blackListString..
- (NSMutableArray*)getAllNationalityListFromDBnotIn:(NSString*)blackListString;

//To get the nationalities based on the searchString from DB except those contained in blackListString..
- (NSMutableArray *)getNationalityListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//To get all frequency list
- (NSMutableArray*)getAllFrequencyListFromDB;

//To get the Countries based on the searchString from DB except those contained in blackListString..
- (NSMutableArray *)getCountriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString;

//get the salutation list..
- (NSMutableArray *)getSalutationsListforNationality:(NSMutableString*)nationalityString;

- (NSPredicate *)predicateWithItems:(NSArray *)searchItems andKeyName:(NSString *)keyValue andPredicate:(NSPredicate*)availablePredicate;
@end
