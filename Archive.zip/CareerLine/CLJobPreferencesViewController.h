//
//  CLJobPreferencesViewController.h
//  CareerLine
//
//  Created by Abbin on 31/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLJobPreferencesViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, assign)NSInteger selectedRow;

@end
