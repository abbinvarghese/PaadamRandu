//
//  CLSideMenuViewController.h
//  CareerLine
//
//  Created by CSG on 1/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSideMenuViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

//currently selected tab in side menu..
@property (nonatomic, assign) CLSideMenuViewControllerIndex selectedSideMenuIndex;

//select a tab in side menu..
-(void)selectTabWithIndex:(CLSideMenuViewControllerIndex)index;

//update the side menu details..
-(void)updateSideMenuDetails;

//increment the side menu badge for corresponding push type..
-(void)incrementBadgeForPushType:(CLPushNotificationKeyType)alertType;

//decrement the side menu badge for corresponding page..
-(void)decrementBadgeForPageType:(CLSideMenuViewControllerIndex)index;

//to update side menu badges ansd save user...
-(void)updateBadge:(NSInteger)badgeCount andSaveUserForPageType:(CLSideMenuViewControllerIndex)index;

//navigation when app opened from push notifs..
-(void)pushNavigationForPushType:(CLPushNotificationKeyType)alertType pushId:(NSString*)pushId;

//To change the traffic light status and update user interface accordingly..
- (void)changeTrafficLightAndUpdateInterfaceForStatus:(CLTrafficLightStatus)status success:(void (^)(void))success failure:(void (^)(NSString *error))failure;

@end
