//
//  CLSelectCompanyNameViewController.m
//  CareerLine
//
//  Created by RENJITH on 10/09/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectCompanyNameViewController.h"
#import "CLCareerHistoryObject.h"

#define kCellTextFontSize 13
#define kCLNewComapnyId @"0"

@interface CLSelectCompanyNameViewController ()
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityView;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorMsg;
@property (nonatomic,strong) NSMutableDictionary *selectedCompannyDict;
@property (weak, nonatomic) IBOutlet UITableView *tableViewCompanyName;
@property (nonatomic,strong) NSMutableArray *filteredCompannyNameArray;
@property (nonatomic,strong) NSMutableArray *selectedCompannyDivArray;
@property (nonatomic,strong) NSString *searchText;
@property (nonatomic,assign) BOOL isNewCompany;
@end

@implementation CLSelectCompanyNameViewController

- (void)viewDidLoad
{ 
    [super viewDidLoad];
    self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeWords;
    self.title=NSLocalizedString(@"Search Company Name", @"Select company name page title");
    [self setLeftNavigationButton];
    self.tableViewCompanyName.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableViewCompanyName.tableHeaderView=self.searchBar;
    self.selectedCompannyDict=[[NSMutableDictionary alloc] init];
    self.filteredCompannyNameArray=[[NSMutableArray alloc] init];
    self.selectedCompannyDivArray = [[NSMutableArray alloc] init];
    self.searchText=@"";
    self.activityView.hidden = YES;
    self.lblErrorMsg.hidden = YES;
    //[self filterContentForSearchText:self.searchText withCountry:self.countryCode];
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}
#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [CLCareerHistoryObject cancelGetCompanyNameRequest];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.searchBar becomeFirstResponder];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self.searchBar resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.filteredCompannyNameArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.textLabel.font=[UIFont systemFontOfSize:kCellTextFontSize];
        cell.textLabel.numberOfLines=0;
    }
    
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredCompannyNameArray objectAtIndex:indexPath.row];
    if (![self.searchText isEqualToString:@""] && indexPath.row==0) {
        cell.textLabel.text=[NSString stringWithFormat:@"%@",[cellDict objectForKey:kCLCompanySearchNamekey]];
    }
    else{
        cell.textLabel.text=[cellDict objectForKey:kCLCompanySearchNamekey];
    }
    return cell;
}

#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *expectedText=nil;
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredCompannyNameArray objectAtIndex:indexPath.row];
    expectedText=[cellDict objectForKey:kCLCareerHistoryCompanyNamekey];
    CGRect expectedQuestextFrame = [expectedText boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                       [UIFont systemFontOfSize:kCellTextFontSize], NSFontAttributeName,
                                                                       nil]
                                                              context:nil];
    
    return MAX(44, ceil(expectedQuestextFrame.size.height)+27);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self.selectedCompannyDict setObject:[[self.filteredCompannyNameArray objectAtIndex:indexPath.row] objectForKey:kCLCompanySearchNamekey] forKey:kCLCompanySearchNamekey];
    
    [self.selectedCompannyDict setObject:[[self.filteredCompannyNameArray objectAtIndex:indexPath.row] objectForKey:kCLCompanySearchIdkey] forKey:kCLCompanySearchIdkey];
    
    if ([[[self.filteredCompannyNameArray objectAtIndex:indexPath.row] objectForKey:kCLCompanySearchIdkey] isEqualToString:kCLNewComapnyId]) {
        self.isNewCompany = YES;
    }
    
//    [self.selectedCompannyDict setObject:[[self.filteredCompannyNameArray objectAtIndex:indexPath.row]objectForKey:kCLSearchCompanyIndustryKey] forKey:kCLSearchCompanyIndustryKey];
    
    if (!self.isNewCompany) {
        NSMutableArray *array =[[NSMutableArray alloc]init];
        array=[NSMutableArray arrayWithObject:[[self.filteredCompannyNameArray objectAtIndex:indexPath.row] objectForKey:kCLSearchCompanyIndustryKey]];
        self.selectedCompannyDivArray =array;
    }
    
    [CLCareerHistoryObject cancelGetCompanyNameRequest];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:^(void){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectCompanyNameDidSelectCompanyName:withDict:companyDiv:isNew:)]){
                [self.delegate selectCompanyNameDidSelectCompanyName:self withDict:self.selectedCompannyDict companyDiv:self.selectedCompannyDivArray isNew:self.isNewCompany];
            }
        }];
    });
}

#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}

-(void)searchAfterDelay{
    
    self.searchText = [self.searchText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    [self filterContentForSearchText:self.searchText withCountry:self.countryCode];;
}

- (void)filterContentForSearchText:(NSString*)searchText withCountry:(NSString *)contry
{
    // Update the filtered array based on the search text.
    [self.filteredCompannyNameArray removeAllObjects];
    [self.tableViewCompanyName reloadData];
    self.activityView.hidden = NO;
    [self.activityView startAnimating];
    [CLCareerHistoryObject getCompanyNameListForSearchString:searchText withCountry:contry success:^(NSMutableArray *companyNameList) {
        
        if (companyNameList!=nil) {
            self.filteredCompannyNameArray = companyNameList;
        }
        if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
            NSArray *array = [[NSArray alloc]init];
            [self.filteredCompannyNameArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,kCLCompanySearchNamekey,kCLNewComapnyId,kCLCompanySearchIdkey,array,kCLSearchCompanyDivisionskey, nil] atIndex:0];
        }
        if([self.filteredCompannyNameArray count] ==0){
            self.lblErrorMsg.hidden = NO;
        }else{
            self.lblErrorMsg.hidden = YES;
        }
        [self.activityView stopAnimating];
        self.activityView.hidden = YES;
        [self.tableViewCompanyName reloadData];
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            [self.activityView stopAnimating];
            self.activityView.hidden = YES;
            self.lblErrorMsg.hidden = YES;
            [self.tableViewCompanyName reloadData];
        }
    }];
}

@end
