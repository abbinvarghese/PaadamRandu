//
//  CLConstants.m
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLConstants.h"

#pragma mark - URL's

//Base URL
//NSString *const kCLWebServiceBaseURL    =   @"https://mobile2.careerlinedevelopment.com/index.php?r=webserve";
NSString *const kCLWebServiceBaseURL    =   @"https://dev.careerlinedevelopment.com/index.php?r=webserve";

//Base URL1
//NSString *const kCLWebServiceBaseURL1    =   @"https://mobile2.careerlinedevelopment.com/index.php?r=CareerService";
NSString *const kCLWebServiceBaseURL1    =   @"https://dev.careerlinedevelopment.com/index.php?r=CareerService";

//Base URL2
//NSString *const kCLWebServiceBaseURL2    =   @"https://mobile2.careerlinedevelopment.com/index.php?r=CareerLineService";
NSString *const kCLWebServiceBaseURL2    =   @"https://dev.careerlinedevelopment.com/index.php?r=CareerLineService";

//Webservice authentication credential..
NSString *const kCLWebServiceAuthenticationUsername     =   @"careerline";
NSString *const kCLWebServiceAuthenticationPassword     =   @"Big50";

/*
 The Authorization header is constructed as follows:
    -Username and password are combined into a string "username:password"
    -The resulting string literal is then encoded using the RFC2045-MIME variant of Base64, except not limited to 76 char/line
    -The authorization method and a space i.e. "Basic " is then put before the encoded string.
*/
NSString *const kCLWebServiceHttpAuthenticationHeaderValue  =   @"Basic Y2FyZWVybGluZTpCaWc1MA==";

//Register URL
 NSString *const kCLWebServiceRegisterURL   =   @"/UserRegister";

//Register Verification Mail URL
 NSString *const kCLWebServiceRegisterVerificationMailURL   =   @"/Resendverification";

//Forgot Password URL
 NSString *const kCLWebServiceForgotPasswordURL =   @"/Forgotpassword";

//Forgot pass Verification Mail URL
 NSString *const kCLWebServiceForgotPassVerificationMailURL     =   @"/Forgotpassword";

//Login URL
NSString *const kCLWebServiceLoginURL   =   @"/auth";
//Login WebService Keys
 NSString *const kCLLoginUserIDkey                      =   @"cl_id";
 NSString *const kCLLoginUserFirstNamekey               =   @"firstname";
 NSString *const kCLLoginUserLastNamekey                =   @"lastname";
 NSString *const kCLLoginUserPreferredNamekey           =   @"preferredName";
 NSString *const kCLLoginUserEmailkey                   =   @"email";
 NSString *const kCLLoginUserAgekey                     =   @"age";
 NSString *const kCLLoginUserBirthDatekey               =   @"dob";
 NSString *const kCLLoginUserIconUrlkey                 =   @"image";
 NSString *const kCLLoginUserUnreadJobsCountkey         =   @"jobs_count";
 NSString *const kCLLoginUserUnreadInboxCountkey        =   @"mail_count";
 NSString *const kCLLoginUserFormStatuskey              =   @"form_status";
 NSString *const kCLLoginUserTrafficLightStatuskey      =   @"tl_status";

 NSString *const kCLCRFOneURL        = @"/GetCRFONE_LANG";
 NSString *const kCLCRFOnePostURL     = @"/CRFONE_LANG";

 NSString *const kCLCRFTwoGetURL     = @"/GetCRFTWO";
 NSString *const kCLCRFTwoPostURL    =@"/CRFTWO";

 NSString *const kCLCRFThreeGetURL   = @"/GetCRFTHREE";
 NSString *const kCLCRFThreePostURL  = @"/CRFTHREE";

 NSString *const kCLCRFFourGetURL    = @"/GetCRFFOUR";
 NSString *const kCLCRFFourPostURL    = @"/CRFFOUR";

 NSString *const kCLCRFFivePostURL    = @"/CRFFIVE";

 NSString *const kCLWebServiceLogoutURL                 =   @"/Logout";

//Update user details url
 NSString *const kCLWebServiceUpdateUserDetailsURL    =   @"/userinfo";

//First time profile details..
 NSString *const kCLWebServiceFirstTimeSaveUserDetailsURL   =   @"/CoreRegisteration";

//locations for search string url
 NSString *const kCLWebServiceGetLocHomeSearchString    =   @"/Getlocation";
//company div for search string url
NSString *const kCLWebServiceGetCompanyDivSearchString    =   @"/GetBusinessDiv";
//Home Location WebService Keys
NSString *const kCLGetLocHomeCyNamekey                  =   @"country";
NSString *const kCLGetLocHomeCyCodekey                  =   @"cycode";
NSString *const kCLGetLocHomeLocNamekey                 =   @"loc_name";
NSString *const kCLGetLocHomeLocCodekey                 =   @"loc_code";
NSString *const kCLGetLocHomeRegNamekey                 =   @"region";

//locations for search string url in same country
 NSString *const kCLWebServiceGetLocSameCountrySearchString     =   @"/Getcountrylocations";

//Document Listing URL
 NSString *const kCLWebServiceDocumentListURL  =   @"/GetDocuments";

 NSString *const kCLDocumentsCaptionKey        =   @"caption";
 NSString *const kCLDocumentsclAreaTypeKey     =   @"cl_area_type";
 NSString *const kCLDocumentsDateUpload        =   @"dateupload";
 NSString *const kCLDocumentsDocTypeKey        =   @"doctype";
 NSString *const kCLDocumentsDocTypeIDKey      =   @"doctypeid";
 NSString *const kCLDocumentsFileKey           =   @"file";
 NSString *const kCLDocumentsFileIDKey         =   @"file_id";
 NSString *const kCLDocumentsFileTitleKey      =   @"file_title";
 NSString *const kCLDocumentsFileUrlKey        =   @"file_url";
 NSString *const kCLDocumentsOldNameKey        =   @"oldname";
 NSString *const kCLDocumentsTypeKey           =   @"type";
 NSString *const kCLDocumentsTypeName          =   @"typename";
 NSString *const kCLDocumentsWidthKey          =   @"width";
 NSString *const kCLDocumentsHeightKey         =   @"height";



//Knowledge Listing URL
NSString *const kCLWebServiceKnowledgeListURL  =  @"/GetKnowledge";
NSString *const kCLWebServiceGetWakeURL        =  @"/GetWake";
NSString *const kCLWebServiceKnowledgeBookmarkListURL  =  @"/GetBookmark";
NSString *const kCLWebServiceKnowledgeBookmarkURL =  @"/Bookmark";
NSString *const kCLWebServiceKnowledgeLikeURL    =  @"/Like";
NSString *const kCLWebServiceKnowledgeDetailsURL = @"/GetWakeDetails";
NSString *const kCLWebServiceKnowledgeListKey    =  @"knowledge";
NSString *const kCLWebServiceKnowledgeListPagesKey  =  @"pages";
NSString *const kCLWebServiceKnowledgeListCurrentPageKey  =  @"cur_page";
NSString *const kCLWebServiceKnowledgeListCountKey  =  @"count";

NSString *const kCLKnowledgeRecIDKey           =   @"id";
NSString *const kCLKnowledgeIdKey              =   @"kn_id";
NSString *const kCLKnowledgeTitleKey           =   @"knowledgeTitle";
NSString *const kCLKnowledgeImageUrlKey        =   @"imageurl";
NSString *const kCLKnowledgeTypeKey            =   @"type";
NSString *const kCLKnowledgeSubTypeKey         =   @"knowledgeSubType";
NSString *const kCLKnowledgeCatKey             =   @"knowledgeCategory";
NSString *const kCLKnowledgeBookmarkKey        =   @"bookmark";
NSString *const kCLKnowledgeLikeKey            =   @"isLike";
NSString *const kCKnowledgeKeyWord             =   @"knowledgeKeyWords";
NSString *const kCLKnowledgeDesc               =   @"knowledgeDescription";
NSString *const kCLKnowledgenewsCompany        =   @"newsCompany";
NSString *const kCLKnowledgeImgWidthKey        =   @"width";
NSString *const kCLKnowledgeImgHeightKey       =   @"height";
NSString *const kCLKnowledgeLikeCountKey            =   @"knowledgeLikeCount";
NSString *const kCLKnowledgepublishedCreated   =   @"publishedCreated";

//Job Listing URL
 NSString *const kCLWebServiceJobListURL       =   @"/joblist";
//Job Listing WebService Keys
 NSString *const kCLJobListNameKey             =   @"name";
 NSString *const kCLJobListemailKey            =   @"email";
 NSString *const kCLJobListPersonKey           =   @"person";
 NSString *const kCLJobListjobIDkey            =   @"job_id";
 NSString *const kCLJobListjobReceivedTimekey  =   @"datetime";
 NSString *const kCLJobListjobTitlekey         =   @"job_title";
 NSString *const kCLJobListjobCompanyIdkey     =   @"company_id";
 NSString *const kCLJobListjobCompanyNamekey   =   @"company";
 NSString *const kCLJobListjobLocationkey      =   @"location";
 NSString *const kCLJobListjobCountrykey       =   @"country";
 NSString *const kCLJobListjobIconUrlkey       =   @"image";
 NSString *const kCLJobListjobUnreadStatuskey  =   @"unread";
 NSString *const kCLJobListjobCurrentPagesKey  =   @"cur_page";
 NSString *const kCLJobListjobNoOfPagesKey     =   @"pages";
 NSString *const kCLJobListTotalUnreadJobsKey  =   @"unread_jobs";

//Job Detail URL
 NSString *const kCLWebServiceJobDetailURL          =   @"/job";
//Job Details WebService Keys
NSString *const kCLJobDetailBookmarkStatuskey       =   @"bookmarked";
NSString *const kCLJobDetailAppliedStatuskey        =   @"accrej";
NSString *const kCLJobDetailBasicArraykey           =   @"Basic";
NSString *const kCLJobDetailDescriptionArraykey     =   @"Description";
NSString *const kCLJobDetailQualificationArraykey   =   @"QUALIFICATIONS";
NSString *const kCLJobDetailCompetenciesArraykey    =   @"COMPETENCIES";

//Company Detail URL
 NSString *const kCLWebServiceCompanyDetailURL      =   @"/Getcompany";
//Company Detail WebService Keys
 NSString *const kCLCompanyDetailIDkey              =   @"id";
 NSString *const kCLCompanyDetailNamekey            =   @"name";
 NSString *const kCLCompanyDetailDescriptionkey     =   @"profile";
 NSString *const kCLCompanyDetailLocationkey        =   @"location";
 NSString *const kCLCompanyDetailWebsiteUrlkey      =   @"website";
 NSString *const kCLCompanyDetailLogoUrlkey         =   @"logo";

//Traffic Light status change url
 NSString *const kCLWebServiceTrafficLightChangeURL =   @"/setstatus";

//ResetPassword url

NSString *const kCLWebServiceResetPasswordURL       = @"/ResetFormPassword";

NSString *const kCLWebServiceUpdateCaption          = @"/updateFileCaption";

//Job Bookmark url
 NSString *const kCLWebServiceJobBookmarkURL    =   @"/bookmarkjob";

//Job Reject url
 NSString *const kCLWebServiceJobRejectURL      =   @"/Accrejjob";

//Job Apply url
 NSString *const kCLWebServiceJobApplyURL       =   @"/Accrejjob";

//Share job email URL
 NSString *const kCLWebServiceShareJobEmailURL  =   @"/Emailjob";

//Inbox Listing URL
 NSString *const kCLWebServiceInboxListURL       =   @"/MailBox";
//Inbox Listing WebService Keys
 NSString *const kCLInboxListjobIDkey            =   @"job_id";
 NSString *const kCLInboxListjobTitlekey         =   @"job_title";
 NSString *const kCLInboxListjobCompanykey       =   @"compname";
 NSString *const kCLInboxListjobIconUrlkey       =   @"logo_url";
 NSString *const kCLInboxListLastMsgkey          =   @"message";
 NSString *const kCLInboxListId                  =   @"parentid";
 NSString *const kCLInboxListMsgTimekey          =   @"datetime";
 NSString *const kCLInboxListMailUnreadStatuskey =   @"view";
 NSString *const kCLInboxListTotalUnreadInboxKey =   @"unread_mails";

//Inbox Detail URL
NSString *const kCLWebServiceInboxDetailURL                 =   @"/MailboxDetail";
//Inbox Detail WebService Keys
NSString *const kCLInboxDetailIdkey                         =   @"parentid";
NSString *const kCLInboxDetailjobIDkey                      =   @"job_id";
NSString *const kCLInboxDetailjobTitlekey                   =   @"job_title";
NSString *const kCLInboxDetailjobCompanykey                 =   @"compname";
NSString *const kCLInboxDetailjobIconUrlkey                 =   @"logo_url";
NSString *const kCLInboxDetailMsgIdkey                      =   @"thread";
NSString *const kCLInboxDetailMsgTimekey                    =   @"datetime";
NSString *const kCLInboxDetailMsgTypekey                    =   @"msg_type";
NSString *const kCLInboxDetailMsgTextkey                    =   @"message";
NSString *const kCLInboxDetailMsgSubjectkey                 =   @"subject";
NSString *const kCLInboxDetailQuestionnnaireDueDatekey      =   @"DueDay";
NSString *const kCLInboxDetailQuestionnnairePresentkey      =   @"questionnaire";
NSString *const kCLInboxDetailQuestionnnaireSubmittedkey    =   @"submitted";
NSString *const kCLInboxDetailQuestionnaireIdkey            =   @"ques_id";
NSString *const kCLInboxDetailQuestionnaireQuestkey         =   @"ques";
NSString *const kCLInboxDetailQuestionnaireAnskey           =   @"ans";
NSString *const kCLInboxDetailQuestionnaireRating           =   @"rating";

//Inbox Post reply url..
 NSString *const kCLWebServiceInboxPostReplyURL     =   @"/reply";

//Questionnaire post url..
NSString *const kCLWebServiceQuestionnairePostReplyURL  =   @"/Submitquestionnaire";



//Profile Summary url..
NSString *const kCLWebServiceProfileSummaryURL                =   @"/Profilesummary";
//Profile Summary WebService Keys

NSString *const kCLProfileSummaryFirstNamekey                  =   @"firstname";
NSString *const kCLProfileSummaryLastNamekey                   =   @"last_name";
NSString *const kCLProfileSummaryNickNamekey                   =   @"nick_name";
NSString *const kCLProfileSummaryAgekey                        =   @"dob";
NSString *const kCLProfileSummaryImageUrlkey                   =   @"imageurl";
NSString *const kCLProfileSummaryImagekey                      =   @"images";
NSString *const kCLProfileSummaryAboutMekey                    =   @"AboutMe";
NSString *const kCLProfileSummaryCareerkey                     =   @"Career";
NSString *const kCLProfileSummaryEducationkey                  =   @"Education";
NSString *const kCLProfileSummaryCapabilitieskey               =   @"Capabilities";
NSString *const kCLProfileSummaryPortfoliokey                  =   @"PortFolio";
NSString *const kCLProfileSummaryReferenceskey                 =   @"Reference";
NSString *const kCLProfileSummaryJobPreferencekey              =   @"jobPreference";
NSString *const kCLProfileSummaryGoalskey                      =   @"Goals";
NSString *const kCLProfileSummaryHeadingkey                    =   @"heading";
NSString *const kCLProfileSummaryValuekey                      =   @"value";

NSString *const kCLProfileDaykey                       =   @"Day";
NSString *const kCLProfileMonthkey                     =   @"Month";
NSString *const kCLProfileYearkey                      =   @"Year";


//Job Preferences url......
NSString *const kCLWebServiceJobPreferenceSummaryURL           =  @"/JobPrfrncSummary";
NSString *const kCLWebServiceContractConsiderationsSummaryURL  =  @"/ContractConsideration";
NSString *const kCLWebServicePostContractConsiderationsURL     =  @"/PostContractConsiderations";
NSString *const kCLWebServiceWorkConsiderationsSummaryURL      =  @"/WorkConsideration";
NSString *const kCLWebServicePostWorkConsiderationsURL         =  @"/PostWorkConsider";
NSString *const kCLWebServicetargetJobsSummaryURL              =  @"/GetTargetJobs";
NSString *const kCLWebServicePreferredJobsListURL              =  @"/GetPrfrdJob";
NSString *const kCLWebServiceSaveTargetJobsURL                 =  @"/PostTargetJobs";
NSString *const kCLWebServiceGetRegionListURL                  =  @"/GetCurRelocLocations";
NSString *const kCLWebServiceGetRegionListURLForTwentyField    =  @"/GetProfileWithinLocations";
NSString *const kCLWebServiceGetSecondRegionListURLForTwentyField =  @"/GetProfileOutsideLocations";
NSString *const kCLWebServiceGetSecondRegionListURL            =  @"/GetRelocLocations";
NSString *const kCLWebServiceGetRelocationSummeryURL           =  @"/RelocOption";
NSString *const kCLWebServicePostRelocationURL                 =  @"/PostRelocOption";


//job preference webservice keys....
NSString *const kCLJobPreferenceIdkey                          =   @"id";
NSString *const kCLJobPreferenceTargetJobsKey                  =  @"targetJobs";
NSString *const kCLJobPreferenceContractConsiderationsKey      =  @"contractConsiderations";
NSString *const kCLJobPreferenceRelocConsiderationKey          =  @"relocConsideration";
NSString *const kCLJobPreferenceWorkConsiderationKey           =  @"workConsideration";
NSString *const kCLJobPreferenceSummaryTargetJobsHeadingKey    =  @"heading";
NSString *const kCLJobPreferenceSummaryTargetJobsValueKey      =  @"value";
NSString *const kCLJobPreferenceSummaryContractConsiderationTitleKey = @"title";
NSString *const kCLJobPreferenceSummaryContractConsiderationAvailabilityKey = @"contractPreference";
NSString *const kCLJobPreferenceSummaryWorkConsiderationHeadingKey = @"heading";
NSString *const kCLJobPreferenceSummaryWorkconsiderationValueKey = @"value";
NSString *const kCLJobPreferenceSummaryWorkconsiderationWorkKey = @"work";
NSString *const kCLJobPreferencePreferredJobKey                =  @"preferredJobs";
NSString *const kCLJobPreferenceFinctionsKey                   =  @"function";

NSString *const kCLJobPreferenceIndustryKey                    =  @"Industry";
NSString *const kCLJobPreferenceJoblevelKey                    =  @"jobLevel";
NSString *const kCLJobPreferenceRemarksKey                     =  @"remarks";
NSString *const kCLJobPreferenceJobScopeKey                    =  @"jobScope";

NSString *const kCLJobPreferenceJobFunctionKey                 = @"jobFunction";
NSString *const kCLJobPreferenceJobFunctionIdKey               = @"id";
NSString *const kCLJobPreferenceJobFunctionCode                = @"jobFunctionCode";
NSString *const kCLJobPreferenceJobFunctionOtherFlag           = @"jobFunctionOtherFlag";


NSString *const kCLWorkconsiderationbusinessTravelkey          =  @"businessTravel";
NSString *const kCLWorkconsiderationworkHomekey                =  @"workHome";

NSString *const kCLWorkconsiderationkey                        =  @"workConsideration";
NSString *const kCLWorkConsiderationWorkSchedulekey            =  @"workSchedule";
NSString *const kCLWorkConsiderationFlextimekey                =  @"Flextime";
NSString *const kCLWorkConsiderationWorkWeekkey                =  @"workWeek";
NSString *const kCLWorkConsiderationJobSharingkey              =  @"jobSharing";
NSString *const kCLWorkConsiderationWorkHomeOtherkey           =  @"workHomeOther";
NSString *const kCLWorkConsiderationFriendlyWOrkPlacekey       =  @"friendlyWorkplace";
NSString *const kCLWorkConsiderationFriendlyWorkRemarkkey      =  @"friendlyWorkremarks";

NSString *const kCLContractConsiderationkey                    =  @"contractConsiderations";

NSString *const kCLContractConsiderationavailabilitykey        =  @"availability";
NSString *const kCLContractConsiderationAnythingElsekey        =  @"remarks";
NSString *const kCLContractConsiderationPreferencekey          =  @"preference";

NSString *const kCLContractConsiderationavailabilityNamekey    =  @"availabilityName";
NSString *const kCLContractConsiderationOtherkey               =  @"other";
NSString *const kCLContractConsiderationIdkey                  =  @"id";
NSString *const kCLContractPreferenceemploymentTypekey         =  @"employmentType";
NSString *const kCLContractPreferenceemploymentContractkey     =  @"employmentContract";
NSString *const kCLContractPreferenceSalaryBasiskey            =  @"salaryBasis";
NSString *const kCLContractPreferenceIDKey                     =  @"id";
NSString *const kCLContractPreferenceSalaryBasisID             =  @"id";
NSString *const kCLContractPreferenceEmploymentIdkey           =  @"id";
NSString *const kCLContractPreferenceCountryIdkey              =  @"id";
NSString *const kCLContractPreferenceCurrencykey               =  @"currency";
NSString *const kCLContractPreferenceMinSalarykey              =  @"minSalary";
NSString *const kCLContractPreferenceIncreaseSalarykey         =  @"increaseSalary";
NSString *const kCLContractPreferenceNegotiablekey             =  @"negotiable";
NSString *const kCLContractConsiderationCountryNameKey         =  @"countryName";
NSString *const kCLContractConsiderationCurrencyCode           =  @"currencyCode";
NSString *const kCLContractConsiderationCountryCode            =  @"countryCode";
NSString *const kCLContractConsiderationEmpDetailIdKey         =  @"empDetailId";
NSString *const kCLContractConsiderationNameKey                =  @"name";
NSString *const kCLContractConsiderationEmpDetailNameKey       = @"empDetailName";

NSString *const kCLTargetJobsPreferredJobKey                   = @"preferredJob";
NSString *const kCLTargetJobsPreferredJobIDKey                 = @"id";
NSString *const kCLTargetJobsJobScopeCodeKey                   = @"code";
NSString *const kCLTargetJobsJobScopeScopeIDKey                = @"scopeId";
NSString *const kCLTargetJobsJobScopeKey                       = @"jobScope";
NSString *const kCLTargetJobsJobImpactGroupKey                 = @"jobImpactGroup";
NSString *const kCLTargetJobsJobScopeGroupNameKey              = @"jobScopeGroupName";
NSString *const kCLTargetJobsJobScopeCellKey                   = @"jobScopeCell";
NSString *const kCLTargetJobsJobScopeCountryCodeKey            = @"jobLocationCountryCode";
NSString *const kCLTargetJobsJobScopeScopeNameKey              = @"scopeName";
NSString *const kCLTargetJobsindustry                          = @"industry";
NSString *const kCLTargetJobsNewindustry                       = @"IndGrp";
NSString *const kCLTargetJobsNewFnCategory                     = @"functionCategory";
NSString *const kCLTargetJobsMainindustry                       = @"Industry";
NSString *const kCLTargetJobsindustrySectCode                  = @"industrySectCode";
NSString *const kCLTargetJobsindustrySectName                  = @"industrySectName";
NSString *const kCLTargetJobsindustryGroupNameKey              = @"industryGroupName";
NSString *const kCLTargetJobsIndustryKey                       = @"industry";
NSString *const kCLTargetJobsIndustryOther                     = @"industryOther";
NSString *const kCLTargetJobsIndustryGrpOther                  = @"industryGrpOther";
NSString *const kCLTargetJobsIndustryAll                       = @"industryAll";
NSString *const kCLTargetJobsIndustryGroupCode                 = @"industryGroupCode";


NSString *const kCLRelocationLocationKey                       = @"location";
NSString *const kCLRelocationCheckedKey                        = @"checked";
NSString *const kClRelocationBoolValueKey                      = @"value";
NSString *const kClRelocationRegionKey                         = @"region";
NSString *const kCLRElocationStateKEy                          = @"state";
NSString *const kCLRelocationMetroKEy                          = @"metro";
NSString *const kCLRelocationMetroClusterKey                   = @"metroCluster";
NSString *const kCLRelocationTier2CitiesKey                    = @"tier2Cities";
NSString *const kCLRelocationTownVillages                      = @"townVillages";
NSString *const kCLRelocationRegionOutside                     = @"region";
NSString *const kCLRelocationSubregionKey                      = @"subRegion";
NSString *const kCLRelocationCountryKey                        = @"country";
NSString *const kCLRelocationLocationKeyOutside                = @"locations";
NSString *const kCLRelocationjobLocationCountryCode            = @"jobLocationCountryCode";
NSString *const kCLRelocationjobLocationCountryName            = @"jobLocationCountryName";
NSString *const kCLRelocationjobLocationName                   = @"jobLocationName";
NSString *const kCLRelocationCountryCode                       = @"countryCode";

NSString *const kCLRelocationOptionsKey                        = @"RelocationOption";
NSString *const kCLRelocationWithinCountry                     = @"WithinCountry";
NSString *const kCLRelocationOutSideCountry                    = @"OutsideCountry";

//set image as primary url..
NSString *const kCLWebServiceSetPrimaryImageURL                =   @"/AddimageSetPrim";

//Career Listing url..
NSString *const kCLWebServiceCareerListingURL                =   @"/GetWorkHistory";

//Career Work History Post url..
NSString *const kCLWebServiceCareerPostURL                   =   @"/PostWH";

//Work History document Delete url..
NSString *const kCLCareerDeleteDocumentURL                   =   @"/DeleteQdocs";
//Work History document add url..
NSString *const kCLCareerAddDocumentURL                      =   @"/AddWHDocs";

//Career CompanyNameSearch url..
NSString *const kCLWebServiceCompanyNameSearchURL            =   @"/GetCompanyList";

//Career Listing WebService Keys
NSString *const kCLCareerSummarykey                          =   @"careerSummary";
NSString *const kCLCareerHistorykey                          =   @"CareerHistory";

//Delete work history
NSString *const kCLWorkHistoryDeletekey                      =   @"/DeleteWorkHistory";
//career webservice key start
//Career History ComapanySearch keys
NSString *const kCLCompanySearchNamekey                      =   @"companyName";
NSString *const kCLCompanySearchIdkey                        =   @"id";
NSString *const kCLSearchCompanyDivisionskey                 =   @"companyDivisions";
NSString *const kCLSearchCompanyIndustryKey                  =   @"industry";
NSString *const kCLSearchCompanyDivisionIdkey                =   @"id";
NSString *const kCLSearchCompanyDivisionNamekey              =   @"division";

//Career History WebService Keys
NSString *const kCLCareerHistoryIdkey                        =   @"id";
NSString *const kCLCareerHistoryJobTitlekey                  =   @"jobTitle";
NSString *const kCLCareerHistoryCompanyNamekey               =   @"companyName";
NSString *const kCLCareerHistoryOtherCompanykey              =   @"otherCompany";
NSString *const kCLCareerHistoryOtherCompanyIdkey            =   @"id";
NSString *const kCLCareerHistoryOtherBusDivCompanyIdkey      =   @"companyId";

NSString *const kCLCareerHistoryCompanyDesckey               =   @"companyDescription";
NSString *const kCLCareerHistoryCompanyLockey                =   @"companyLocation";
NSString *const kCLCareerHistoryOtherCompanyLockey           =   @"companyLoc";
NSString *const kCLCareerHistoryOtherCompanyCountrykey       =   @"cycode";

NSString *const kCLCareerHistoryCompanyNameIdkey             =   @"id";
NSString *const kCLCareerHistoryDivisionkey                  =   @"division";
NSString *const kCLCareerHistoryDivisionIdkey                =   @"id";
NSString *const kCLCareerHistoryBusinessDivisionkey          =   @"businessDivision";
NSString *const kCLCareerHistoryCompanyDivisionkey           =   @"companyDivision";
NSString *const kCLCareerHistoryCompanyDivisionskey          =   @"companyDivisions";
NSString *const kCLCareerHistoryCareerDurationFromkey        =   @"durationFrom";
NSString *const kCLCareerHistoryCareerDurationTokey          =   @"durationTo";
NSString *const kCLCareerHistoryCareerDurationCurrentkey     =   @"current";
NSString *const kCLCareerHistoryFunctionkey                  =   @"function";
NSString *const kCLCareerHistoryFunctionIdkey                =   @"id";
NSString *const kCLCareerHistoryFunctionJobIdkey             =   @"jobId";
NSString *const kCLCareerHistoryFunctionOtherFalgkey         =   @"otherFlag";
NSString *const kCLCareerHistoryFunctionOtherTxtkey          =   @"otherText";
NSString *const kCLCareerHistoryAllowancekey                 =   @"Allowance";

//Keys for allowance and incentives common and sal bebefist
NSString *const kCLCareerHistoryAllowanceIdkey               =   @"id";
NSString *const kCLCareerHistoryAllowanceLoadingskey         =   @"allowanceandloadings";
NSString *const kCLCareerHistoryAllowanceFrequencykey        =   @"frequency";
NSString *const kCLCareerHistoryAllowanceGrossSalkey         =   @"grossSalary";
NSString *const kCLCareerHistoryAllowanceActualValkey        =   @"actualValue";
NSString *const kCLCareerHistoryAllowanceCurrencykey         =   @"currency";
NSString *const kCLCareerHistoryAllowanceOtherTxtkey         =   @"otherText";
NSString *const kCLCareerHistoryAllowanceCurrencyIdkey       =   @"id";
NSString *const kCLCareerHistoryIncentivekey                 =   @"Incentive";
NSString *const kCLCareerHistoryIncentiveBonuskey            =   @"incentiveBonus";
//common keys end

NSString *const kCLCareerHistoryLongIncentivekey             =   @"longtermIncentive";
NSString *const kCLCareerHistoryLongFrequencykey             =   @"longtermFrequency";
NSString *const kCLCareerHistoryLongGrossSalkey              =   @"longtermGrossSalary";
NSString *const kCLCareerHistoryLongActualValkey             =   @"longtermActualValue";
NSString *const kCLCareerHistoryLongCurrencykey              =   @"currency";
NSString *const kCLCareerHistoryLongCurrencyPostkey          =   @"longtermCurrency";

NSString *const kCLCareerHistoryDepartmentkey                =   @"department";
NSString *const kCLCareerHistoryJobLevelkey                  =   @"jobLevel";
NSString *const kCLCareerHistoryJobLevelNamekey              =   @"level";
NSString *const kCLCareerHistoryJobLevelCodekey              =   @"levelCode";
NSString *const kCLCareerHistoryJobImpactkey                 =   @"jobImpact";
NSString *const kCLCareerHistoryJobImpactIdkey               =   @"scopeId";
NSString *const kCLCareerHistoryJobImpactjobScopeGroupName   =   @"jobScopeGroupName";
NSString *const kCLCareerHistoryJobImpactjobScope            =   @"jobScope";
NSString *const kCLCareerHistoryJobImpactCodeKey             =   @"code";
NSString *const kCLCareerHistoryJobImpactNamekey             =   @"scopeName";
NSString *const kCLCareerHistoryLocationkey                  =   @"careerLocation";
NSString *const kCLCareerHistoryCountrykey                   =   @"country";
NSString *const kCLCareerHistoryCurrencykey                  =   @"currency";
NSString *const kCLCareerHistoryBenefitskey                  =   @"Benefits";
NSString *const kCLCareerHistoryBenefitsItemkey              =   @"benefit";
NSString *const kCLCareerHistoryBenefitsOtherFlagkey         =   @"otherFlag";
NSString *const kCLCareerHistoryBenefitsOtherTextkey         =   @"otherText";
NSString *const kCLCareerHistoryJobAcntbiltskey              =   @"keyJobAccountabilities";
NSString *const kCLCareerHistoryJobPerformancekey            =   @"keyPerfomanceIndicators";
NSString *const kCLCareerHistoryPermanentDirectkey           =   @"permanentEmpDirect";
NSString *const kCLCareerHistoryPermanentInDirectkey         =   @"permanentEmpInDirect";
NSString *const kCLCareerHistoryTempDirectkey                =   @"temporaryEmpDirect";
NSString *const kCLCareerHistoryTempInDirectkey              =   @"temporaryEmpInDirect";
NSString *const kCLCareerHistoryBudgetResponsibilitykey      =   @"budgetResponsibility";

NSString *const kCLCareerHistoryProjectskey                  =   @"projects";
NSString *const kCLCareerHistoryDocskey                      =   @"attachDocs";
NSString *const kCLCareerHistoryExperiencesGainedkey         =   @"experienceGained";
NSString *const kCLCareerHistoryMajorAchievementskey         =   @"workAchievements";
NSString *const kCLCareerHistoryRemarkskey                   =   @"remarks";
NSString *const kCLCareerHistoryKeyJobFactskey               =   @"keyJobFacts";
NSString *const kCLCareerHistorySalaryBasiskey               =   @"salaryBasis";
NSString *const kCLCareerHistorySalaryCurrencykey            =   @"salaryCurrency";
NSString *const kCLCareerHistorySalarykey                    =   @"salary";
NSString *const kCLCareerHistoryTimeSpentkey                 =   @"timeSpent";
NSString *const kCLCareerHistoryJobTypekey                   =   @"jobType";
NSString *const kCLCareerHistoryJobTypeTxtkey                =   @"jobTypetext";
NSString *const kCLCareerHistoryEmploymentTypeIdkey          =   @"id";
NSString *const kCLCareerHistoryEmploymentTypekey            =   @"employmentType";
NSString *const kCLCareerHistoryEmploymentContractTypekey    =   @"contractType";

NSString *const kCLCareerHistoryReportTokey                  =  @"reportedTo";
NSString *const kCLCareerHistoryReasonForMovekey             =  @"reasonforMove";
NSString *const kCLCareerHistoryReasonForMoveIdkey           =  @"id";
NSString *const kCLCareerHistoryReasonForMoveOtherFlgkey     =  @"otherFlag";
NSString *const kCLCareerHistoryReasonForMoveOtherTxtkey     =  @"otherText";
NSString *const kCLCareerHistoryReasonForMoveReasonkey       =  @"reason";
NSString *const kCLCareerHistoryReasonForMoveReasonIdkey     =  @"reasonId";
//career webservice key end

//Qualification Listing url..
NSString *const kCLWebServiceQualificationListingURL         =   @"/GetQualification";
//Qualification Delete url..
NSString *const kCLQlfitnDeletekey                           =   @"/DeleteQualification";
//Qualification document Delete url..
NSString *const kCLQlfitnDeleteDocumentURL                   =   @"/DeleteQdocs";
//Qualification document Add url..
NSString *const kCLQlfitnUploadDocumentURL                   =   @"/AddQDocs";
//Qualification Listing WebService Keys
NSString *const kCLQlfitnEducationkey                        =   @"Education";
NSString *const kCLQlfitnTrainingkey                         =   @"Training";
NSString *const kCLQlfitnCertificationkey                    =   @"Certification";
NSString *const kCLQlfitnMembershipkey                       =   @"Membership";
NSString *const kCLQlfitnLicensekey                          =   @"License";

//Qualification Education WebService Keys
NSString *const kCLQlfitnEducationIdkey                      =   @"id";
NSString *const kCLQlfitnEducationCoursekey                  =   @"course";
NSString *const kCLQlfitnEducationSpecializationkey          =   @"specialisation";
NSString *const kCLQlfitnEducationInstitutionkey             =   @"institution";
NSString *const kCLQlfitnEducationLocationkey                =   @"location";
NSString *const kCLQlfitnEducationLocationCountrykey         =   @"countryCode";
NSString *const kCLQlfitnEducationLocationCodekey            =   @"loccode";
NSString *const kCLQlfitnEducationFromDatekey                =   @"startDate";
NSString *const kCLQlfitnEducationToDatekey                  =   @"completionDate";
NSString *const kCLQlfitnEducationIsOngoingkey               =   @"ongoing";
NSString *const kCLQlfitnEducationLevelkey                   =   @"educationLevel";
NSString *const kCLQlfitnEducationRatingTypekey              =   @"Rating";

NSString *const kCLQlfitnEducationDescptionkey               =   @"remarks";
NSString *const kCLQlfitnEducationDocumentsUrlkey            =   @"attachDocuments";
NSString *const kCLQlfitnEducationLevelIdkey                 =   @"id";
NSString *const kCLQlfitnEducationLevelDesckey               =   @"level";

//Qualification Training WebService Keys
NSString *const kCLQlfitnTrainingIdkey                       =   @"id";
NSString *const kCLQlfitnTrainingNamekey                     =   @"trainingProgram";
NSString *const kCLQlfitnTrainingInstitutionkey              =   @"institution";
NSString *const kCLQlfitnTrainingLocationkey                 =   @"location";
NSString *const kCLQlfitnTrainingLocationCountrykey          =   @"countryCode";
NSString *const kCLQlfitnTrainingLocationCodekey             =   @"loccode";
NSString *const kCLQlfitnTrainingFromDatekey                 =   @"startDate";
NSString *const kCLQlfitnTrainingNumDayskey                  =   @"numofdays";
NSString *const kCLQlfitnTrainingContentskey                 =   @"remarks";
NSString *const kCLQlfitnTrainingTrainerkey                  =   @"trainer";
NSString *const kCLQlfitnTrainingVendorkey                   =   @"vendor";
NSString *const kCLQlfitnTrainingRelatedTokey                =   @"";
NSString *const kCLQlfitnTrainingDocumentskey                =   @"attachDocuments";
//Qualification Certification WebService Keys
NSString *const kCLQlfitnCertificationIdkey                  =   @"id";
NSString *const kCLQlfitnCertificationTitlekey               =   @"certification";
NSString *const kCLQlfitnCertificationInstitutionkey         =   @"institution";
NSString *const kCLQlfitnCertificationLocationkey            =   @"location";
NSString *const kCLQlfitnCertificationLocationCountrykey     =   @"countryCode";
NSString *const kCLQlfitnCertificationLocationCodekey        =   @"loccode";
NSString *const kCLQlfitnCertificationIssuedOnDatekey            =   @"issuedOn";
NSString *const kCLQlfitnCertificationProgresskey            =   @"certificationProgress";
NSString *const kCLQlfitnCertificationValiditykey            =   @"lifetimeValidity";
NSString *const kCLQlfitnCertificationFromDatekey            =   @"startDate";
NSString *const kCLQlfitnCertificationToDatekey              =   @"expiryDate";
NSString *const kCLQlfitnCertificationCompletionDatekey      =   @"completionDate";
NSString *const kCLQlfitnCertificationContentskey            =   @"remarks";
NSString *const kCLQlfitnCertificationDocumentskey           =   @"attachDocuments";
//Qualification Membership WebService Keys
NSString *const kCLQlfitnMembershipIdkey                     =   @"id";
NSString *const kCLQlfitnMembershipTitlekey                  =   @"association";
NSString *const kCLQlfitnMembershipClaskey                   =   @"type";
NSString *const kCLQlfitnMembershipNumberkey                 =   @"number";
NSString *const kCLQlfitnMembershipLocationkey            =   @"location";
NSString *const kCLQlfitnMembershipLocationCountrykey     =   @"countryCode";
NSString *const kCLQlfitnMembershipLocationCodekey        =   @"loccode";
NSString *const kCLQlfitnMembershipIssuedOnDatekey        =   @"issuedOn";
NSString *const kCLQlfitnMembershipProgresskey            =   @"certificationProgress";
NSString *const kCLQlfitnMembershipValiditykey            =   @"lifetimeValidity";
NSString *const kCLQlfitnMembershipFromDatekey               =   @"startDate";
NSString *const kCLQlfitnMembershipToDatekey                 =   @"expiryDate";
NSString *const kCLQlfitnMembershipCompletionDatekey         =   @"completionDate";
NSString *const kCLQlfitnMembershipContentskey               =   @"remarks";
NSString *const kCLQlfitnMembershipDocumentskey              =   @"attachDocuments";
//Qualification License WebService Keys
NSString *const kCLQlfitnLicenseIdkey                        =   @"id";
NSString *const kCLQlfitnLicenseTitlekey                     =   @"title";
NSString *const kCLQlfitnLicenseClaskey                      =   @"type";
NSString *const kCLQlfitnLicenseNumberkey                    =   @"number";
NSString *const kCLQlfitnLicenseLocationkey            =   @"location";
NSString *const kCLQlfitnLicenseLocationCountrykey     =   @"countryCode";
NSString *const kCLQlfitnLicenseLocationCodekey        =   @"loccode";
NSString *const kCLQlfitnLicenseIssuedOnDatekey            =   @"issuedOn";
NSString *const kCLQlfitnLicenseProgresskey            =   @"certificationProgress";
NSString *const kCLQlfitnLicenseValiditykey            =   @"lifetimeValidity";
NSString *const kCLQlfitnLicenseFromDatekey                  =   @"startDate";
NSString *const kCLQlfitnLicenseToDatekey                    =   @"expiryDate";
NSString *const kCLQlfitnLicenseCompletionDatekey            =   @"completionDate";
NSString *const kCLQlfitnLicenseContentskey                  =   @"remarks";
NSString *const kCLQlfitnLicenseDocumentskey                 =   @"attachDocuments";

//Education-Save/Edit url..
NSString *const kCLWebServiceEducationSaveURL                =   @"/PostQualification";


//About Me url..
 NSString *const kCLWebServiceProfileAboutMeURL                =   @"/Userprofile";
//AboutMe WebService Keys
NSString *const kCLProfileAboutMeInfokey                       =   @"Info";

NSString *const kCLProfileAboutMeInfoIdkey                     =   @"id";
NSString *const kCLProfileAboutMeCountryKey                    =   @"country";
NSString *const kCLProfileAboutMeFirstNamekey                  =   @"first_name";
NSString *const kCLProfileAboutMeLastNamekey                   =   @"last_name";
NSString *const kCLProfileAboutMeNickNamekey                   =   @"preferred_first_name";
NSString *const kCLProfileAboutMePreviousNameArraykey          =   @"PreviousName";
NSString *const kCLProfileAboutMePreviousNameIdkey             =   @"id";
NSString *const kCLProfileAboutMePreviousNamekey               =   @"previous_name";
NSString *const kCLProfileAboutMePreviousNameDatekey           =   @"previous_date";
NSString *const kCLProfileAboutMeMiddleNamekey                 =   @"middle_name";
NSString *const kCLProfileAboutMeSkypeNamekey                  =   @"skype_name";
NSString *const kCLProfileAboutMeProfileImagekey               =   @"profile_image";
NSString *const kCLProfileAboutMeHomeNumberkey                 =   @"HomeNumber";
NSString *const kCLProfileAboutMeMobileNumberkey               =   @"MobileNumber";
NSString *const kCLProfileAboutMeTelephoneNumberArraykey       =   @"TelephoneNumber";
NSString *const kCLProfileAboutMeTelephoneNumberIdkey          =   @"id";
NSString *const kCLProfileAboutMeTelephoneISDCodekey           =   @"countryCode";
NSString *const kCLProfileAboutMeTelephoneAreaCodekey          =   @"areaCode";
NSString *const kCLProfileAboutMeTelephoneNumberkey            =   @"number";
NSString *const kCLProfileAboutMeTelephoneIsPrimarykey         =   @"primary";
NSString *const kCLProfileAboutMeTelephoneContactTypekey       =   @"type";
NSString *const kCLProfileAboutMeTelephoneContactTypeIdkey     =   @"id";
NSString *const kCLProfileAboutMeHomeTelephoneKey              =   @"Home";
NSString *const kCLProfileAboutMeMobleTelephoneKey             =   @"Mobile";
NSString *const kCLProfileAboutMeTelephoneContactTypeTextkey   =   @"contactType";

NSString *const kCLProfileAboutMeEmailkey                      =   @"email";
NSString *const kCLProfileAboutMeAlternateEmailkey             =   @"alternateEmail";
NSString *const kCLProfileAboutMeAgekey                        =   @"dob";



NSString *const kCLProfileAboutMeSalutationDictkey             =   @"salutation";
NSString *const kCLProfileAboutMeSalutationIdkey               =   @"id";
NSString *const kCLProfileAboutMeSalutationTitlekey            =   @"title";

NSString *const kCLProfileAboutMeGenderDictkey                 =   @"gender";
NSString *const kCLProfileAboutMeGenderIdkey                   =   @"id";
NSString *const kCLProfileAboutMeGenderTitlekey                =   @"title";

NSString *const kCLProfileAboutMeNationalityArraykey           =   @"Nationality";
NSString *const kCLProfileAboutMeNationalityCodekey            =   @"code";
NSString *const kCLProfileAboutMeNationalityNamekey            =   @"nationality";

NSString *const kCLProfileAboutMeCurrentLocationDictkey        =   @"Current_Address";
NSString *const kCLProfileAboutMeOtherAddressArraykey          =   @"Other_address";
NSString *const kCLProfileAboutMeLocIdkey                      =   @"id";
NSString *const kCLProfileAboutMeLocApartmentkey               =   @"apartment";
NSString *const kCLProfileAboutMeLocFloorkey                   =   @"floor";
NSString *const kCLProfileAboutMeLocHouseNumberkey             =   @"house_number";
NSString *const kCLProfileAboutMeLocIsCommAddresskey           =   @"communication";
NSString *const kCLProfileAboutMeLocCodekey                    =   @"loccode";
NSString *const kCLProfileAboutMeLocNamekey                    =   @"locname";
NSString *const kCLProfileAboutMeLocAddresskey                 =   @"address";
NSString *const kCLProfileAboutMeLocPincodekey                 =   @"pincode";

NSString *const kCLProfileAboutMePhotosArraykey                =   @"Images";

NSString *const kCLProfileAboutMeDocumentsArraykey             =   @"Docs";

NSString *const kCLProfileAboutMeAchievementsArraykey          =   @"personal_achievements";
NSString *const kCLProfileAboutMeAchievementIdkey              =   @"id";
NSString *const kCLProfileAboutMeAchievementTitlekey           =   @"title";
NSString *const kCLProfileAboutMeAchievementDescriptionkey     =   @"description";
NSString *const kCLProfileAboutMeAchievementDatekey            =   @"date";
NSString *const kCLProfileAboutMeAchievementFilesArraykey      =   @"files";

NSString *const kCLProfileAboutMeMediaArraykey                 =   @"Social";
NSString *const kCLProfileAboutMeMediaIdkey                    =   @"id";
NSString *const kCLProfileAboutMeMediaWebsiteTitlekey          =   @"title";
NSString *const kCLProfileAboutMeMediaWebsiteUrlkey            =   @"value";
NSString *const kCLProfileAboutMeMediaWebsiteDescriptionkey    =   @"description";

NSString *const kCLProfileAboutMeInterestskey                  =   @"Hobbies";
NSString *const kCLProfileAboutMeInterestMainIdkey             =   @"id";
NSString *const kCLProfileAboutMeInterestListArraykey          =   @"title";
NSString *const kCLProfileAboutMeInterestIdkey                 =   @"id";
NSString *const kCLProfileAboutMeInterestTitlekey              =   @"hobbies";
NSString *const kCLProfileAboutMeInterestDescriptionkey        =   @"remarks";

NSString *const kCLProfileFileIdkey                            =   @"file_id";
NSString *const kCLProfileFileTitlekey                         =   @"file_title";
NSString *const kCLProfileFilePreviewUrlkey                    =   @"file_url";
NSString *const kCLProfileFilekey                              =   @"file";


//About Me-Save info url..
NSString *const kCLWebServiceProfileAboutMeSaveInfoURL          =   @"/SaveUserProfile";

//About Me-Save achievement url..
NSString *const kCLWebServiceProfileAboutMeSaveAchievementURL   =   @"/Saveprsnlachiv";
//AboutMe-Save achievement WebService Keys
NSString *const kCLProfileAboutMeSaveAchievementIdkey           =   @"id";


//About Me-Delete achievement url..
NSString *const kCLWebServiceProfileAboutMeDeleteAchievementURL =   @"/Deleteprsnlachiv";
//AboutMe-Delete achievement WebService Keys
NSString *const kCLProfileAboutMeDeleteAchievementIdkey         =   @"id";

//About Me-Delete achievement document url..
NSString *const kCLWebServiceProfileAboutMeSaveAchievementDocURL   =   @"/Addpachivdocs";

//About Me-Delete achievement document url..
NSString *const kCLWebServiceProfileAboutMeDeleteAchievementDocURL =   @"/Deletedocs";


//About Me-Save media url..
 NSString *const kCLWebServiceProfileAboutMeSaveMediaURL        =   @"/Savesocialweb";
//AboutMe-Save achievement WebService Keys
 NSString *const kCLProfileAboutMeSaveMediaIdkey                =   @"id";

//About Me-Delete media url..
 NSString *const kCLWebServiceProfileAboutMeDeleteMediaURL      =   @"/Deletesocialweb";
//AboutMe-Delete media WebService Keys
NSString *const kCLProfileAboutMeDeleteMediaIdkey               =   @"id";


//About Me-Save interest url..
 NSString *const kCLWebServiceProfileAboutMeSaveInterestURL     =   @"/Savehobbies";
//AboutMe-Save Interest WebService Keys
 NSString *const kCLProfileAboutMeSaveInterestIdkey             =   @"id";

//About Me-Delete interest url..
 NSString *const kCLWebServiceProfileAboutMeDeleteInterestURL   =   @"/Deletehobby";
//AboutMe-Delete Interest WebService Keys
 NSString *const kCLProfileAboutMeDeleteInterestIdkey           =   @"id";


//About Me-Get hobbies url..
 NSString *const kCLWebServiceProfileAboutMeListHobbiesURL      =   @"/GetHobbies";
//AboutMe-Get hobbies WebService Keys=same as profile hobbies listing..


//Upload Non-Primary image url..
NSString *const kCLWebServiceProfileAboutMeUploadNonPrimaryImageURL =   @"/Addimage";

//Upload Primary image url..
NSString *const kCLWebServiceProfileAboutMeUploadPrimaryImageURL =   @"/Profileimage";

//Upload document url..
NSString *const kCLWebServiceProfileAboutMeUploadDocumentURL =   @"/Adddocs";

//About Me-Delete photo url..
NSString *const kCLWebServiceProfileAboutMeDeletePhotoURL    =   @"/Deleteimage";

//About Me-Delete document url..
NSString *const kCLWebServiceProfileAboutMeDeleteDocumentURL =   @"/Deletedocs";


//Reference-Listing url..
NSString *const kCLWebServiceProfileReferenceURL                =   @"/GetReferences";
//Reference WebService Keys
NSString *const kCLProfileReferenceArraykey                     =   @"References";
NSString *const kCLProfileReferenceIdkey                        =   @"id";
NSString *const kCLProfileReferenceReferredBykey                =   @"ReferredBy";
NSString *const kCLProfileReferenceJobTitlekey                  =   @"JobTitle";
NSString *const kCLProfileReferenceCompanykey                   =   @"Company";
NSString *const kCLProfileReferenceDatekey                      =   @"Date";
NSString *const kCLProfileReferenceRecommendationkey            =   @"Recommendations";
NSString *const kCLProfileReferenceFilesArraykey                =   @"attachDocuments";

//Reference-Delete url..
NSString *const kCLWebServiceProfileReferenceDeleteURL          =   @"/DeleteReference";

//Reference-Save/Edit url..
NSString *const kCLWebServiceProfileReferenceSaveURL   =   @"/PostReferences";
//AboutMe-Save achievement WebService Keys
NSString *const kCLProfileReferenceSaveIdkey           =   @"id";

//Reference-Upload document url..
NSString *const kCLWebServiceProfileReferenceUploadDocumentURL =   @"/AddRefDocs";

//Reference-Delete document url..
NSString *const kCLWebServiceProfileReferenceDeleteDocumentURL =   @"/DeleteRefdocs";


//Performance Review..
NSString *const kCLProfilePerfReviewArraykey                  =   @"performanceReview";
NSString *const kCLProfilePerfReviewIdkey                     =   @"id";
NSString *const kCLProfilePerfReviewDatekey                   =   @"Date";
NSString *const kCLProfilePerfReviewDescriptionkey            =   @"remarks";
NSString *const kCLProfilePerfReviewCareerSelectedDictkey     =   @"company";
NSString *const kCLProfilePerfReviewCareerArraykey            =   @"companies";
NSString *const kCLProfilePerfReviewCareerIdkey               =   @"id";
NSString *const kCLProfilePerfReviewCareerTitlekey            =   @"company";
NSString *const kCLProfilePerfReviewCareerFromDatekey         =   @"from";
NSString *const kCLProfilePerfReviewCareerToDatekey           =   @"to";
NSString *const kCLProfilePerfReviewFilesArraykey             =   @"attachDocuments";

//Reference-Performance Review Save/Edit url..
NSString *const kCLWebServiceProfilePerfReviewSaveURL   =   @"/SavePerformanceReview";
NSString *const kCLProfilePerfReviewSaveIdkey           =   @"id";

//Reference-Delete Performance url..
NSString *const kCLWebServiceProfileDeletePerfReviewURL =   @"/DeletePerformanceReview";

//Reference-Performance Review Upload document url..
NSString *const kCLWebServiceProfilePerfReviewUploadDocumentURL =   @"/AddRevDocs";

//Reference- Performance Review Delete document url..
NSString *const kCLWebServiceProfilePerfReviewDeleteDocumentURL =   @"/DeleteRefdocs";




//Protfolio-Listing url..
NSString *const kCLWebServiceProfileProtfolioURL                   =   @"/GetPortfolio";
NSString *const kCLWebServiceProfileProtfolioNewURL                =   @"/Portfolio";
//Protfolio WebService Keys
NSString *const kCLProfileProtfolioWorkAchievementArraykey                     =   @"Achievements";
NSString *const kCLProfileProtfolioWorkAchievementIdkey                        =   @"id";
NSString *const kCLProfileProtfolioWorkAchievementAwardskey                    =   @"achievements";
NSString *const kCLProfileProtfolioWorkAchievementDatekey                      =   @"Date";
NSString *const kCLProfileProtfolioWorkAchievementDescriptionkey               =   @"remarks";
NSString *const kCLProfileProtfolioWorkAchievementRelatedToSelectedDictkey     =   @"relatedTo";
NSString *const kCLProfileProtfolioWorkAchievementRelatedToArraykey            =   @"related";
NSString *const kCLProfileProtfolioWorkAchievementRelatedToIdkey               =   @"id";
NSString *const kCLProfileProtfolioWorkAchievementRelatedToTitlekey            =   @"relatedTo";
NSString *const kCLProfileProtfolioWorkAchievementFilesArraykey                =   @"attachDocuments";

NSString *const kCLProfileProtfolioAssessmentArraykey           =   @"Assessments";
NSString *const kCLProfileProtfolioAssessmentIdkey              =   @"id";
NSString *const kCLProfileProtfolioAssessmentTitlekey           =   @"title";
NSString *const kCLProfileProtfolioAssessmentDatekey            =   @"Date";
NSString *const kCLProfileProtfolioAssessmentScorekey           =   @"score";
NSString *const kCLProfileProtfolioAssessmentURLkey             =   @"url";
NSString *const kCLProfileProtfolioAssessmentDescriptionkey     =   @"remarks";
NSString *const kCLProfileProtfolioAssessmentFilesArraykey      =   @"attachDocuments";

//Protfolio-achievement Save/Edit url..
NSString *const kCLWebServiceProfileWorkAchievementSaveURL   =   @"/PostPortfolio";
//AboutMe-Save achievement WebService Keys
NSString *const kCLProfileWorkAchievementSaveIdkey           =   @"id";

//Protfolio-assessment Save/Edit url..
NSString *const kCLWebServiceProfileAssessmentSaveURL   =   @"/PostPortfolio";
//AboutMe-Save achievement WebService Keys
NSString *const kCLProfileAssessmentSaveIdkey           =   @"id";

//Protfolio-Delete achievement url..
NSString *const kCLWebServiceProfileProtfolioDeleteAchievementURL =   @"/DeleteAchvmnt";

//Protfolio-Delete assessment url..
NSString *const kCLWebServiceProfileProtfolioDeleteAssessmentURL =   @"/DeleteAssessmnt";

//Portfolio-WorkAchievement Upload document url..
NSString *const kCLWebServiceProfileWorkAchievementUploadDocumentURL =   @"/AddAchvmntDocs";

//Portfolio- WorkAchievement Delete document url..
NSString *const kCLWebServiceProfileWorkAchievementDeleteDocumentURL =   @"/DeletePortfoliodocs";

//Portfolio-Assessment Upload document url..
NSString *const kCLWebServiceProfileAssessmentUploadDocumentURL =   @"/AddAssessmentDocs";

//Portfolio- Assessment Delete document url..
NSString *const kCLWebServiceProfileAssessmentDeleteDocumentURL =   @"/DeletePortfoliodocs";


//Portfolio changes..
NSString *const kCLProfileProtfolioProjectArraykey                  =   @"Projects";
NSString *const kCLProfileProtfolioProjectIdkey                     =   @"id";
NSString *const kCLProfileProtfolioProjectTitlekey                  =   @"project";
NSString *const kCLProfileProtfolioProjectDatekey                   =   @"date";
NSString *const kCLProfileProtfolioProjectDescriptionkey            =   @"remarks";
NSString *const kCLProfileProtfolioProjectCareerSelectedDictkey     =   @"company";
NSString *const kCLProfileProtfolioProjectCareerArraykey            =   @"companies";
NSString *const kCLProfileProtfolioProjectCareerIdkey               =   @"id";
NSString *const kCLProfileProtfolioProjectCareerTitlekey            =   @"company"; 
NSString *const kCLProfileProtfolioProjectCareerFromDatekey         =   @"from";
NSString *const kCLProfileProtfolioProjectCareerToDatekey           =   @"to";
NSString *const kCLProfileProtfolioProjectFilesArraykey             =   @"attachDocuments";

//Protfolio-project Save/Edit url..
NSString *const kCLWebServiceProfileProjectSaveURL   =   @"/SavePortfolio";

//Protfolio-Delete project url..
NSString *const kCLWebServiceProfileProtfolioDeleteProjectURL =   @"/DeleteProject";

NSString *const kCLWebServiceProfileProtfolioDeleteEduURL     =   @"/DeleteEducationProject";

//Portfolio-project Upload document url..
NSString *const kCLWebServiceProfileProjectUploadDocumentURL  =   @"/AddProjectDocs";

NSString *const kCLWebServiceProfileEduUploadDocumentURL  =   @"/EducationTrainingDocs";

//Portfolio- project Delete document url..
NSString *const kCLWebServiceProfileProjectDeleteDocumentURL  =   @"/DeletePortfoliodocs";

NSString *const kCLWebServiceProfileEDuDeleteDocumentURL  =   @"/DeleteQdocs";


NSString *const kCLProfileProtfolioItemArraykey           =   @"AdditionalItem";
NSString *const kCLProfileProtfolioItemIdkey              =   @"id";
NSString *const kCLProfileProtfolioItemTitlekey           =   @"project";
NSString *const kCLProfileProtfolioItemFilesArraykey      =   @"attachDocuments";
NSString *const kCLProfileProtfolioItemRemarksKey         =   @"remarks";

//Protfolio-item Save/Edit url..
NSString *const kCLWebServiceProfileItemSaveURL   =   @"/SavePortfolio";
NSString *const kCLProfileItemSaveIdkey           =   @"id";

//Protfolio-Delete item url..
NSString *const kCLWebServiceProfileProtfolioDeleteItemURL =   @"/DeleteProjectOther";

//Portfolio-item Upload document url..
NSString *const kCLWebServiceProfileItemUploadDocumentURL  =   @"/AddProjectOtherDocs";

//Portfolio- item Delete document url..
NSString *const kCLWebServiceProfileItemDeleteDocumentURL  =   @"/DeletePortfoliodocs";

#pragma mark UserDefaults Keys

NSString *const kCLUserDefaultUserDetailsDictKey           =   @"userDetailsDictKey";

//20 fields keys..
 NSString *const kCLUserDefaultsProfileCountryKey         =   @"profileDetailsCountryKEy";
 NSString *const kCLUserDefaultsProfileNationalityKey     =   @"profileDetailsNationalityKey";
 NSString *const kCLUserDefaultsProfileFirstName          =   @"profileDetailsFirstName";
 NSString *const kCLUserDefaultsProfileLastName           =   @"profileDetailsLastName";
 NSString *const kCLUserDefaultsProfilePreferedName       =   @"profileDetailsPreferedName";
 NSString *const kCLUserDefaultsProfileEmail              =   @"profileDetailsEmail";
 NSString *const kCLUserDefaultsProfileBirthDate          =   @"profileDetailsBirthDate";
 NSString *const kCLUserDefaultsProfileEducation          =   @"profileDetailsEducation";
 NSString *const kCLUserDefaultsProfileEducationLocation  =   @"profileDetailsEducationLoc";

 NSString *const kCLUserDefaultsProfileEmploymentStatusKey          =   @"ProfileEmploymentStatusKey";
 NSString *const kCLUserDefaultsProfileEmploymentPreviousStatusKey  =   @"ProfileEmploymentPreviousStatusKey";
 NSString *const kCLUserDefaultsProfileEmploymentJobLevelKey        =   @"ProfileEmploymentJobLevelKey";
 NSString *const kCLUserDefaultsProfileEmploymentJobTitleKey        =   @"ProfileEmploymentJobTitleKey";
 NSString *const kCLUserDefaultsProfileEmploymentFunctionKey        =   @"ProfileEmploymentFunctionKey";
 NSString *const kCLUserDefaultsProfileEmploymentTypeKey            =   @"ProfileEmploymentTypeKey";
 NSString *const kCLUserDefaultsProfileEmploymentContractTypeKey    =   @"ProfileEmploymentContractTypeKey";
 NSString *const kCLUserDefaultsProfileEmploymentCountryKey         =   @"ProfileEmploymentCountryKey";
 NSString *const kCLUserDefaultsProfileEmploymentIsCompanyFound     =   @"ProfileEmploymentCompanyFoundKey";
 NSString *const kCLUserDefaultsProfileEmploymentCompanyNameKey     =   @"ProfileEmploymentCompanyNameKey";
 NSString *const kCLUserDefaultsProfileEmploymentBusinessDivKey     =   @"ProfileEmploymentBusinessDivKey";
 NSString *const kCLUserDefaultsPrefileEmploymentIndustryKey        =   @"ProfileEmploymentIndustryKey";
 NSString *const kCLUserDefaultsProfileEmploymentCompanyLocKey      =   @"ProfileEmploymentWorkLocKey";
 NSString *const kCLUserDefaultsProfileEmploymentCompanyDescKey     =   @"ProfileEmploymentWorkDescKey";
 NSString *const kCLUserDefaultsProfileEmploymentJobScopeKey        =   @"ProfileEmploymentJobScopeKey";

 NSString *const kCLUserDefaultsProfileLocationHomeLoc              =   @"ProfileLocationHomeLoc";
 NSString *const kCLUserDefaultsProfileLocationRelocOption          =   @"ProfileRelocationOption";

 NSString *const kCLUserDefaultsProfileLocationRelocSameLoc         =   @"ProfileLocationRelocSameLoc";
 NSString *const kCLUserDefaultsProfileLocationRelocOtherCountry    =   @"ProfileLocationRelocOtherCountry";

 NSString *const kCLUserDefaultsProfileGenderKey            =   @"ProfileGenderKey";
 NSString *const kCLUserDefaultsProfileSalutationKey        =   @"ProfileSalutationKey";

#pragma mark NSNotification Keys

NSString *const kCLNotifCenterJobsApplyCellHeightChange     =   @"notificationCenter.JobsApplyCellHeightChangeNotification";
NSString *const kCLNotifCenterQuestionnaireCellHeightChange =   @"notificationCenter.QuestionnaireCellHeightChangeNotification";
NSString *const kCLNotifCenterTrafficLightChanged           =   @"notificationCenter.TrafficLightChangedNotification";
NSString *const kCLNotifCenterProfileImageChanged           =   @"notificationCenter.ProfileImageChangedNotification";

