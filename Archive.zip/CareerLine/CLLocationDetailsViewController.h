//
//  CLLocationDetailsViewController.h
//  CareerLine
//
//  Created by CSG on 2/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectLocationViewController.h"
#import "CLRelocationViewController.h"

@interface CLLocationDetailsViewController : UITableViewController<UIPickerViewDataSource,UIPickerViewDelegate,CLSimpleTextCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate,RelocationDelegate>

@property(nonatomic,assign)BOOL needCustomBackButtons;

@end
