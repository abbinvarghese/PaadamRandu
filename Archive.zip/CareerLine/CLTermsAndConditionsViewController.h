//
//  CLTermsAndConditionsViewController.h
//  CareerLine
//
//  Created by Abbin on 06/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLTermsAndConditionsViewController : UIViewController<UIWebViewDelegate>
@property(nonatomic,retain)NSString*stringURL;
@property(nonatomic,retain)NSString*titleString;

@end
