//
//  CLSelectNationalityViewController.h
//  CareerLine
//
//  Created by CSG on 2/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectNationalityViewController;

//Delegate Methods...
@protocol CLSelectNationalityDelegate <NSObject>

@required
- (void)selectNationalityControllerDidSelectNationality:(CLSelectNationalityViewController*)controller withArray:(NSMutableArray *)nationalityArray;

@end

@interface CLSelectNationalityViewController : UITableViewController<UISearchBarDelegate, UISearchDisplayDelegate>

@property(nonatomic,weak) id <CLSelectNationalityDelegate> delegate;
@property(nonatomic,strong)NSMutableArray *alreadyListedNationalities;

@end
