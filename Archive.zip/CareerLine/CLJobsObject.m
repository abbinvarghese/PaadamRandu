//
//  CLJobsObject.m
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsObject.h"
#import "AFHTTPRequestOperationManager.h"
#import "NSDictionary+Additions.h"

#define kDebugMessages 0

@implementation CLJobsObject

static NSOperationQueue *jobsListingRequest;
static NSOperationQueue *jobsDetailsRequest;
static NSOperationQueue *jobAcceptRequest;
static NSOperationQueue *jobRejectRequest;
static NSOperationQueue *jobBookmarkRequest;
static NSOperationQueue *jobEmailDetailsRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.companyDetails=[[CLCompanyObject alloc] init];
    self.jobID = [dictionary objectForKeyNotNull:kCLJobListjobIDkey];
    self.jobReceivedDate=[dictionary objectForKeyNotNull:kCLJobListjobReceivedTimekey];
    self.jobTitle = [dictionary objectForKeyNotNull:kCLJobListjobTitlekey];
    self.jobLoc=[dictionary objectForKeyNotNull:kCLJobListjobLocationkey];
    self.jobCountry=[dictionary objectForKeyNotNull:kCLJobListjobCountrykey];
    self.jobUnreadStatus=[[dictionary objectForKeyNotNull:kCLJobListjobUnreadStatuskey] intValue];
    self.companyDetails.companyId=[dictionary objectForKeyNotNull:kCLJobListjobCompanyIdkey];
    self.companyDetails.companyName=[dictionary objectForKeyNotNull:kCLJobListjobCompanyNamekey];
    self.companyDetails.companyLogoUrl=[dictionary objectForKeyNotNull:kCLJobListjobIconUrlkey];
    
    [[dictionary objectForKeyNotNull:kCLJobDetailBookmarkStatuskey] isEqualToString:@"1"] ? (self.jobBookmarkStatus=YES) : (self.jobBookmarkStatus=NO);
    if([[dictionary objectForKeyNotNull:kCLJobDetailAppliedStatuskey] isEqualToString:@"0"]){
        self.jobAppliedStatus=0;
    }
    else if ([[dictionary objectForKeyNotNull:kCLJobDetailAppliedStatuskey] isEqualToString:@"1"]){
        self.jobAppliedStatus=1;
    }
    else if ([[dictionary objectForKeyNotNull:kCLJobDetailAppliedStatuskey] isEqualToString:@"2"]){
        self.jobAppliedStatus=2;
    }
    
    self.jobDetailsArray=[[NSMutableArray alloc] init];
    NSMutableArray *basicArray=[[dictionary objectForKeyNotNull:kCLJobDetailBasicArraykey] mutableCopy];
    NSMutableArray *descriptionArray=[[dictionary objectForKeyNotNull:kCLJobDetailDescriptionArraykey] mutableCopy];
    NSMutableArray *qualificationArray=[[dictionary objectForKeyNotNull:kCLJobDetailQualificationArraykey] mutableCopy];
    NSMutableArray *competenciesArray=[[dictionary objectForKeyNotNull:kCLJobDetailCompetenciesArraykey] mutableCopy];
    if (basicArray!=nil && [basicArray count]!=0) {
        [self.jobDetailsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Basic", @"Basic"),ktableSectionHeadingDictKey,[self formatHTMLtoAttributedStringInArray:basicArray],ktableSectionValueDictKey, nil]];
    }
    
    if (descriptionArray!=nil && [descriptionArray count]!=0) {
        [self.jobDetailsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Description", @"Description"),ktableSectionHeadingDictKey,[self formatHTMLtoAttributedStringInArray:descriptionArray],ktableSectionValueDictKey, nil]];
    }
    
    if (qualificationArray!=nil && [qualificationArray count]!=0) {
        [self.jobDetailsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Qualification", @"Qualification"),ktableSectionHeadingDictKey,[self formatHTMLtoAttributedStringInArray:qualificationArray],ktableSectionValueDictKey, nil]];
    }
    
    if (competenciesArray!=nil && [competenciesArray count]!=0) {
        [self.jobDetailsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Competencies", @"Competencies"),ktableSectionHeadingDictKey,[self formatHTMLtoAttributedStringInArray:competenciesArray],ktableSectionValueDictKey, nil]];
    }
    
    return self;
}

-(NSMutableArray*)formatHTMLtoAttributedStringInArray:(NSMutableArray*)array{
    NSMutableDictionary *dict=nil;
    NSMutableAttributedString *attStr=nil;
    for (int i=0; i<[array count]; i++) {
        dict=[[array objectAtIndex:i] mutableCopy];
        
        NSString *value=nil;
        if ([dict objectForKey:ktableRowValueDictKey]==(id)[NSNull null] || ((NSString *)[dict objectForKey:ktableRowValueDictKey]).length==0) {
            value=@"";
        }
        else{
            value=[dict objectForKey:ktableRowValueDictKey];
        }
        attStr=[[NSMutableAttributedString alloc] initWithData:[value dataUsingEncoding:NSUTF8StringEncoding]
                                                       options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                 NSCharacterEncodingDocumentAttribute: [NSNumber numberWithInt:NSUTF8StringEncoding]}
                                            documentAttributes:nil error:nil];
        [attStr removeAttribute:NSFontAttributeName range:NSMakeRange(0, attStr.length)];
        [attStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:kJobsDetailvalueFont] range:NSMakeRange(0, attStr.length)];
        
        [dict setObject:attStr forKey:ktableRowValueDictKey];
        [array replaceObjectAtIndex:i withObject:dict];
    }
    return array;
}

+ (void)cancelJobListingPendingRequests {
    [jobsListingRequest cancelAllOperations];
    jobsListingRequest = nil;
}

+ (void)cancelJobDetailPendingRequests {
    [jobsDetailsRequest cancelAllOperations];
    jobsDetailsRequest = nil;
}

+ (void)listJobsForUserId:(NSString*)userId selectedFilter:(JobsFilterOptions)selectedFilter pageNumber:(int)page success:(void (^)(NSMutableArray *jobs,BOOL isLastPageReached, NSInteger unreadJobsCount))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *jobs, BOOL isLastPageReached, NSInteger unreadJobsCount){};
    }
    
    if (kDebugMessages) {
        NSLog(@"retreiving page:%d",page);
    }
    
    NSDictionary *parameters = @{@"user": userId,@"status":[NSNumber numberWithInt:selectedFilter], @"page": [NSNumber numberWithInt:page]};
    
    [jobsListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {

        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobsListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceJobListURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"list job JSON: %@", response);
            }
            
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                int currentPage=[[response objectForKeyNotNull:kCLJobListjobCurrentPagesKey] intValue];
                int totalPages=[[response objectForKeyNotNull:kCLJobListjobNoOfPagesKey] intValue];
                
                BOOL isLastPage=NO;
                (currentPage==totalPages) ? (isLastPage=YES) : (isLastPage=NO);
                
                NSMutableArray *jobsList=[[NSMutableArray alloc] init];
                
                NSArray *jobsArr=[response objectForKey:@"results"];
                for (int i=0; i<[jobsArr count]; i++) {
                    CLJobsObject *jobsObj=[[CLJobsObject alloc] initWithDictionary:[jobsArr objectAtIndex:i]];
                    [jobsList addObject:jobsObj];
                }
                
                NSInteger unreadJobsCount=[[response objectForKeyNotNull:kCLJobListTotalUnreadJobsKey] intValue];
                success(jobsList,isLastPage, unreadJobsCount);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ \nresponse string=%@ \n code=%ld \n desc=%@",operation.response,operation.responseString,(long)error.code,error.description);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)jobsDetailsForjobId:(NSString*)jobId andUserId:(NSString *)userId success:(void (^)(CLJobsObject *jobDetail))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLJobsObject *jobDetail){};
    }
    
    NSDictionary *parameters = @{@"job": jobId, @"user": userId};
    
    [jobsDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobsDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceJobDetailURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLJobsObject *jobsObj=[[CLJobsObject alloc] initWithDictionary:response];
                success(jobsObj);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)rejectJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status success:(void (^)(NSString *jobID))success failure:(void (^)(NSString *jobID,NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *jobID,NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *jobID){};
    }
    
     NSDictionary *parameters = @{@"job": jobId, @"user":userId, @"status":status};
    
    [jobRejectRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobRejectRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceJobRejectURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"rejct job JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure(jobId,[response objectForKey:@"message"]);
            }
            else{
                success(jobId);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure(jobId,[CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure(jobId,[CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for accepting a job suggestion...
+ (void)acceptJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status surveyDetails:(NSDictionary*)survey success:(void (^)(NSString *jobId))success failure:(void (^)(NSString *jobId,NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *jobID,NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *jobID){};
    }
    
    NSDictionary *parameters = @{@"job": jobId, @"user":userId, @"status":status, @"qa":survey};
    
    [jobAcceptRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobAcceptRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceJobApplyURL] parameters:parameters
              success:^(AFHTTPRequestOperation *operation, id responseObject){
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"job apply JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure(jobId,[response objectForKey:@"message"]);
                  }
                  else{
                      success(jobId);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure(jobId,[CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure(jobId,[CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)bookmarkJobForJobId:(NSString*)jobId withUserId:(NSString*)userId toggleStatus:(NSString*)status success:(void (^)(NSString *jobID))success failure:(void (^)(NSString *jobID,NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *jobID,NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *jobID){};
    }
    
    NSDictionary *parameters = @{@"job": jobId, @"user":userId, @"status":status};
    
    [jobBookmarkRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobBookmarkRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceJobBookmarkURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"bookmark JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure(jobId,[response objectForKey:@"message"]);
            }
            else{
                success(jobId);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure(jobId,[CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure(jobId,[CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)shareJobDetailsViaMail:(NSString*)mailId forJobId:(NSString*)jobId withUserId:(NSString*)userId success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"email": mailId,@"job": jobId,@"user": userId};
    
    [jobEmailDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        jobEmailDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceShareJobEmailURL]
          parameters:parameters
             success:^(AFHTTPRequestOperation *operation, id responseObject) {
                 NSDictionary *response=(NSDictionary *)responseObject;
                 if (kDebugMessages) {
                     NSLog(@"share via mail JSON: %@", response);
                 }
                 if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                     failure([response objectForKey:@"message"]);
                 }
                 else{
                     success();
                 }
             }
             failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                 if (kDebugMessages) {
                     NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                 }
                 failure([CLCommon getMessageForErrorCode:error.code]);
             }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
