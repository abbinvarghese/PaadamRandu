//
//  CLProjectObject.m
//  CareerLine
//
//  Created by Pravin on 10/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProjectObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLProjectObject

static NSOperationQueue *saveProjectRequest;
static NSOperationQueue *deleteProjectRequest;
static NSOperationQueue *uploadProjectDocumentRequest;
static NSOperationQueue *deleteProjectDocumentRequest;



//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary{
    
    self.projectId=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectIdkey];
    self.projectTitle=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectTitlekey];
    //self.date=[CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementDatekey] andFormat:@"dd-MM-yyyy"];
    self.date=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMy"];
    }
    self.projectDescription=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectDescriptionkey];
    self.careerSelected=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectCareerSelectedDictkey];
    
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectFilesArraykey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    
    return self;
}

-(void)updateDate:(NSDate*)date{
    self.date=date;
    self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
}

+(NSString*)jsonStringForObject:(CLProjectObject*)projObj{
    NSMutableDictionary *projectDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    [insideDict setObject:projObj.projectTitle forKey:kCLProfileProtfolioProjectTitlekey];
    [insideDict setObject:[CLCommon getStringForDate:projObj.date andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileProtfolioProjectDatekey];
    if ([projObj.careerSelected objectForKey:kCLProfileProtfolioProjectCareerIdkey]) {
        [insideDict setObject:projObj.careerSelected forKey:kCLProfileProtfolioProjectCareerSelectedDictkey];
    }
    if (projObj.projectDescription) {
        [insideDict setObject:projObj.projectDescription forKey:kCLProfileProtfolioProjectDescriptionkey];
    }
    
    [projectDict setObject:insideDict forKey:kCLProfileProtfolioProjectArraykey];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:projectDict];
}

//Method for saving project of a particular user...
+ (void)saveProject:(CLProjectObject*)projObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *projId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *projId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": projObj.projectId, @"fields":[CLProjectObject jsonStringForObject:projObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLProjectObject jsonStringForObject:projObj]};
    }
    
    if (kDebugMessages) {
        NSLog(@"parameters passed: %@", parameters);
    }
    
    [saveProjectRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveProjectRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProjectSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveProjectRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileWorkAchievementSaveIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting project for a particular user...
+ (void)deleteProject:(NSString*)projId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": projId};
    if (kDebugMessages) {
        NSLog(@"delete project parameters: %@", parameters);
    }
    
    [deleteProjectRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteProjectRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioDeleteProjectURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete project JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading project document for a particular user...
+ (void)addDocument:(UIImage*)image forProject:(NSString*)projId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": projId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadProjectDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadProjectDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProjectUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"Project" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"work achievement document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting project document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteProjectDocumentRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteProjectDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProjectDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete project document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
