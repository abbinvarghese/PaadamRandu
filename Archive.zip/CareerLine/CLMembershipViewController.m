//
//  CLMembershipViewController.m
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLMembershipViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLUserObject.h"
#import "CLDocumentViewController.h"
#import "CLQualificationObject.h"

#define kAddMembershipDocType @"ME"
#define kCellTextFontsize 14

@interface CLMembershipViewController ()

typedef enum {
    CLMembershipNameIndex = 0,
    CLMembershipTypeIndex= 1,
    CLMemberShipCountryIndex = 2,
    CLMembershipLocationIndex= 3,
    CLMembershipNumberIndex = 4,
    CLMembershipProgressIndex =5,
    CLMembershipStartDateIndex = 6,
    CLMembershipEndDateIndex = 7,
    CLMembershipDescIndex = 8,
    CLMembershipDocsIndex = 9
} CLMembershipTableSectionIndex;

@property(strong,nonatomic)NSString *nameText;
@property(strong,nonatomic)NSString *typeText;
@property(strong,nonatomic)NSString *numberText;
@property(strong,nonatomic)NSDate *startDate;
@property(strong,nonatomic)NSDate *completedDate;
@property(strong,nonatomic)NSDate *endDate;
@property(strong,nonatomic)NSString *descriptionText;
@property(strong,nonatomic)NSString *locationText;
@property(strong,nonatomic)NSDate *issuedOn;
@property(nonatomic, assign)BOOL isProgress;
@property(nonatomic, assign)BOOL isLifeTime;
@property(nonatomic,assign) BOOL forCountry;
@property (nonatomic, strong) NSMutableDictionary *selectedCountry;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (nonatomic,strong) NSNumber *descriptionHeight;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbarWithoutCancel;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property (nonatomic, strong) NSMutableDictionary *selectedCurrentLocation;
@end

@implementation CLMembershipViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Membership"];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"Membership", @"membership detail heading");
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"nameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"typeTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"membershipNumebrTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"startDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"completedDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"endDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"issuedOnDateTextCellIdentifier"];
    
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"expiryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentLocationCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentCountryIdentifier"];
    
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
     self.toolbarWithoutCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        [datePickr setDate:newDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    if (self.isEditMode) {
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:self.membershipObj.location.countryName forKey:@"country"];
        [self.selectedCountry setObject:self.membershipObj.location.countryCode forKey:@"countryCode"];
        self.selectedCurrentLocation = [[NSMutableDictionary alloc]init];
        [self.selectedCurrentLocation setObject:self.membershipObj.location.locationCode forKey:@"jobLocationCode"];
        [self.selectedCurrentLocation setObject:self.membershipObj.location.countryName forKey:@"jobLocationCountryName"];
        [self.selectedCurrentLocation setObject:self.membershipObj.location.adminArea forKey:@"jobLocationAdminArea"];
        [self.selectedCurrentLocation setObject:self.membershipObj.location.countryCode  forKey:@"jobLocationCountryCode"];
        [self.selectedCurrentLocation setObject:self.membershipObj.location.locName forKey:@"jobLocationName"];
        self.nameText = self.membershipObj.title;
        self.typeText = self.membershipObj.clas;
        self.numberText = self.membershipObj.number;
        self.startDate = self.membershipObj.fromDate;
        self.completedDate = self.membershipObj.completionDate;
        self.endDate = self.membershipObj.toDate;
        self.descriptionText = self.membershipObj.contents;
        self.issuedOn = self.membershipObj.issuedOnDate;
        self.isProgress = self.membershipObj.isProgress;
        self.isLifeTime = self.membershipObj.isLifeValid;
        self.locationText = self.membershipObj.location.locationName;
    }else{
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"country"]  forKey:@"country"];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:@"countryCode"];
        self.nameText = @"";
        self.typeText = @"";
        self.numberText = @"";
        self.locationText = @"";
        self.startDate = nil;
        self.completedDate = nil;
        self.endDate = nil;
        self.issuedOn = nil;
        self.descriptionText = @"";
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Membership modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    
    if (datePicker.tag == CLMembershipStartDateIndex) {
        if (self.isProgress) {
            self.startDate=date;
            
            CLSimpleTextCell *startDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLMembershipStartDateIndex]];
            [startDateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
        }else{
            self.issuedOn=date;
            
            CLSimpleTextCell *issuedOnDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLMembershipStartDateIndex]];
            [issuedOnDateCell setCellText:[CLCommon getStringForDate:self.issuedOn andLocalFormat:@"MMMMdy"]];
        }
        
    }else if(datePicker.tag == CLMembershipEndDateIndex){
        if (self.isProgress) {
            
            self.completedDate=date;
            CLSimpleTextCell *endDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLMembershipEndDateIndex]];
            [endDateCell setCellText:[CLCommon getStringForDate:self.completedDate andLocalFormat:@"MMMMdy"]];
        }else{
            
            self.endDate=date;
            CLSimpleTextCell *endDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLMembershipEndDateIndex]];
            [endDateCell setCellText:[CLCommon getStringForDate:self.endDate andLocalFormat:@"MMMMdy"]];
        }
        
    }
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    if(cell.cellIndexPath.section==CLMembershipEndDateIndex){
        if (self.isProgress) {
            if (self.completedDate==nil || !([self.completedDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.completedDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else{
            if (self.endDate==nil || !([self.endDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.endDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }else if (cell.cellIndexPath.section==CLMembershipStartDateIndex){
        if (self.isProgress) {
            if (self.startDate==nil || !([self.startDate compare:self.datePicker.date] == NSOrderedSame)) {
                self.startDate=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else{
            if (self.issuedOn==nil || !([self.issuedOn compare:self.datePicker.date] == NSOrderedSame)) {
                self.issuedOn=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)bttnActionCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)toolbarWithoutCancelAction:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark HTProgressHUD delegates
- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(qualificationMembership:didAddMembership:)]){
                [self.delegate qualificationMembership:self didAddMembership:self.membershipObj];
            }
        }];
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveMembershipForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveMembershipForEdit:NO];
    }
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    
    // Name of proffesional association validation..
    if ([self.nameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Membership Title.", @"Error Message for null Membership Title  field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.nameText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Name of Proffesional Association length.", @"Error Message for length of Name of Proffesional Association field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Type validation..
    if ([self.typeText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Membership Type.", @"Error Message for null Licence Type field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.typeText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Licence Type length.", @"Error Message for length of Licence Type field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Location validation
//    if ([self.selectedCurrentLocation count] ==0 && [self.locationText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }

    //Date validation..
    if (self.isProgress) {
        //Date validation..
        if (self.startDate==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Start Date.", @"Error Message for null start date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        //Date validation..
        if (self.completedDate ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Completed / Expected completion date.", @"Error Message for null Completed / Expected Completion Date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        if (self.startDate!=nil && self.completedDate !=nil) {
            if( [self.startDate timeIntervalSinceDate:self.completedDate] >= 0 ){
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Completion date should greater than Start date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                
                return isValid=NO;
            }
        }
    }else{
        //Date validation..
        if (self.issuedOn ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Issued on date.", @"Error Message for null Issued on field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        //Date validation..
        if (self.endDate==nil && !self.isLifeTime) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Date of expiry.", @"Error Message for null Date of Expiry field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        if (self.issuedOn!=nil && self.endDate !=nil) {
            if( [self.issuedOn timeIntervalSinceDate:self.endDate] >= 0 ){
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"End date should be greater than Issued on date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                
                return isValid=NO;
            }
        }
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)saveMembershipForEdit:(BOOL)isEditMode{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    CLMembershipObject *newMemObj=[[CLMembershipObject alloc] init];
    if (isEditMode) {
        newMemObj.membershipId = self.membershipObj.membershipId;
    }else{
        newMemObj.membershipId = nil;
    }
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]init];
//    if (self.selectedCurrentLocation == nil) {
//        if (self.membershipObj.location.locationName !=nil) {
//            [locDict setObject:self.membershipObj.location.locationName forKey:kCLProfileAboutMeLocNamekey];
//            [locDict setObject:self.membershipObj.location.locationCode forKey:kCLProfileAboutMeLocCodekey];
//            [locDict setObject:self.membershipObj.location.countryCode forKey:kCLQlfitnMembershipLocationCountrykey];
//        }
//        else if (self.selectedCountry){
//            [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnMembershipLocationCountrykey];
//        }
//        
//    }else{
    if (self.selectedCurrentLocation != nil) {
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCountryCode] forKey:kCLQlfitnMembershipLocationCountrykey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCode] forKey:kCLProfileAboutMeLocCodekey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationName] forKey:kCLProfileAboutMeLocNamekey];
    }
    else{
        [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnTrainingLocationCountrykey];
    }
    newMemObj.location = [[CLLocationObject alloc]initWithDictionary:locDict];
    newMemObj.title = self.nameText;
    newMemObj.clas = self.typeText;
    newMemObj.number = self.numberText;
    newMemObj.issuedOnDate = self.issuedOn;
    newMemObj.isProgress = self.isProgress;
    newMemObj.isLifeValid = self.isLifeTime;
    newMemObj.fromDate = self.startDate;
    newMemObj.toDate = self.endDate;
    newMemObj.completionDate = self.completedDate;
    newMemObj.contents = self.descriptionText;
    
    [CLMembershipObject saveMembership:newMemObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *membershipId) {
        
        if (isEditMode) {
            self.membershipObj.title=newMemObj.title;
            self.membershipObj.clas=newMemObj.clas;
            self.membershipObj.number=newMemObj.number;
            self.membershipObj.fromDate=newMemObj.fromDate;
            self.membershipObj.toDate=newMemObj.toDate;
            self.membershipObj.completionDate=newMemObj.completionDate;
            self.membershipObj.contents=newMemObj.contents;
            self.membershipObj.issuedOnDate = newMemObj.issuedOnDate;
            self.membershipObj.isProgress = newMemObj.isProgress;
            self.membershipObj.isLifeValid = newMemObj.isLifeValid;
            self.membershipObj.location = newMemObj.location;
            
        }else{
            newMemObj.membershipId=membershipId;
            self.membershipObj=newMemObj;
        }
        
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save membership. Please try again later.", @"Error message when membership cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 10;
    }
    return 9;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == CLMembershipEndDateIndex && !self.isProgress) {
        return 2;
    }else{
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    switch (indexPath.section) {
        case CLMembershipNameIndex:{
            CLSimpleTextCell *nameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nameTextCellIdentifier"];
            nameCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [nameCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [nameCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [nameCell setPlaceHoldrText:NSLocalizedString(@"Membership Title", @"Placeholder for Membership Title")];
            [nameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [nameCell setCellText:self.nameText];
            [nameCell setCellIndexPath:indexPath];
            nameCell.delegate=self;
            return nameCell;
            break;
        }
            
        case CLMemberShipCountryIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentCountryIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Country", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCountry) {
                [currLoccell setCellText:[NSString stringWithFormat:@"%@",[self.selectedCountry objectForKey:@"country"]]];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
        }
            break;
        case CLMembershipTypeIndex:{
            CLSimpleTextCell *typeCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"typeTextCellIdentifier"];
            typeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [typeCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [typeCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [typeCell setPlaceHoldrText:NSLocalizedString(@"Type", @"Placeholder for Type field")];
            [typeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [typeCell setCellText:self.typeText];
            [typeCell setCellIndexPath:indexPath];
            typeCell.delegate=self;
            return typeCell;
            break;
        }
        case CLMembershipLocationIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentLocationCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Location (City/Town/Village, Country)", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCurrentLocation) {
                if ([[self.selectedCurrentLocation objectForKey:@"jobLocationCode"] isEqualToString:@""]) {
                    [currLoccell setCellText:@""];
                }
                else{
                    [currLoccell setCellCloseBtnOption:NO];
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]]];
                }
                
            }
            else{
                [currLoccell setCellText:@""];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
            break;
        }
            
            
        case CLMembershipNumberIndex:{
            CLSimpleTextCell *membershipNumCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"membershipNumebrTextCellIdentifier"];
            membershipNumCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [membershipNumCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [membershipNumCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [membershipNumCell setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
            [membershipNumCell setPlaceHoldrText:NSLocalizedString(@"Membership Number", @"Placeholder for membership number field")];
            [membershipNumCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [membershipNumCell setCellText:self.numberText];
            [membershipNumCell setCellIndexPath:indexPath];
            membershipNumCell.delegate=self;
            return membershipNumCell;
            break;
        }
        case CLMembershipProgressIndex:{
            
            static NSString *CellIdentifier = @"Cell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            
            UISwitch *btn = [[UISwitch alloc]init];
            btn.onTintColor = [CLCommon sharedInstance].currentTrafficLightColor;
            btn.tag = [[NSNumber numberWithBool:self.isProgress] integerValue];
            [btn setOn:self.isProgress];
            
            [btn addTarget:self action:@selector(progressStatusSwtchAction:) forControlEvents:UIControlEventTouchUpInside];
            cell.selectionStyle = UITableViewCellAccessoryNone;
            cell.textLabel.font = [UIFont systemFontOfSize:kCellTextFontsize];
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.text = NSLocalizedString(@"Membership Is Still in Progress or Being Achieved", @"Placeholder for This Certification is still in progress or being achieved field");
            cell.accessoryView =btn;
            
            return cell;
            break;
        }
        case CLMembershipStartDateIndex:{
            if (self.isProgress) {
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"startDateTextCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.datePicker];
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [dateCell setPlaceHoldrText:NSLocalizedString(@"Start Date", @"Placeholder for date field")];
                [dateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
                [dateCell setCellIndexPath:indexPath];
                dateCell.delegate=self;
                return dateCell;
                break;
            }else{
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"issuedOnDateTextCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.datePicker];
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [dateCell setPlaceHoldrText:NSLocalizedString(@"Issued on", @"Placeholder for Issued on Date field")];
                [dateCell setCellText:[CLCommon getStringForDate:self.issuedOn andLocalFormat:@"MMMMdy"]];
                [dateCell setCellIndexPath:indexPath];
                dateCell.delegate=self;
                return dateCell;
                break;
            }
        }
        case CLMembershipEndDateIndex:{
            if (indexPath.row == 0) {
                if (self.isProgress) {
                    CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"completedDateTextCellIdentifier"];
                    dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [dateCell setTextInputView:self.datePicker];
                    [dateCell setTextInputAccesoryView:self.keyboardResignView];
                    [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                    [dateCell setPlaceHoldrText:NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date field")];
                    [dateCell setCellText:[CLCommon getStringForDate:self.completedDate andLocalFormat:@"MMMMdy"]];
                    [dateCell setCellIndexPath:indexPath];
                    dateCell.delegate=self;
                    return dateCell;
                    break;
                }else{
                    CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"endDateTextCellIdentifier"];
                    dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [dateCell setTextInputView:self.datePicker];
                    [dateCell setTextInputAccesoryView:self.keyboardResignView];
                    [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                    [dateCell setPlaceHoldrText:NSLocalizedString(@"Date of Expiry", @"Placeholder for date field")];
                    
                    if (self.isLifeTime) {
                        [dateCell disableCellField];
                        [dateCell setCellText:@""];
                    }else{
                        [dateCell enableCellField];
                        [dateCell setCellText:[CLCommon getStringForDate:self.endDate andLocalFormat:@"MMMMdy"]];
                    }
                    [dateCell setCellIndexPath:indexPath];
                    dateCell.delegate=self;
                    return dateCell;
                    break;
                }
                
            }else{
                CLTextCheckBoxCell *onGoingCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"expiryTextCellIdentifier"];
                onGoingCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [onGoingCell setTextInputAccesoryView:self.keyboardResignView];
                [onGoingCell setPlaceHoldrText:NSLocalizedString(@"", @" Placeholder")];
                [onGoingCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [onGoingCell setCellText:NSLocalizedString(@"Lifetime Validity", @"Lifetime validity Placeholder")];
                [onGoingCell setCellTextColor:[UIColor darkGrayColor]];
                [onGoingCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [onGoingCell setCellIndexPath:indexPath];
                [onGoingCell disableCelltxtField];
                [onGoingCell checkBoxClick:self.isLifeTime];
                onGoingCell.textCheckBoxdelegate=self;
                return onGoingCell;
                break;
            }
            
        }
        case CLMembershipDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLMembershipDocsIndex:{
            CLProfilePhotoListingGridCell *docCell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            docCell.selectionStyle=UITableViewCellSelectionStyleNone;
            docCell.indexPath=indexPath;
            docCell.delegate=self;
            docCell.photosLimit=-1;
            docCell.placeHolderImageName=@"documentPlaceHolder";
            docCell.photoUrls=self.membershipObj.documentsUrl;
            [docCell updateCollectionViewContents];
            return docCell;
            break;
        }
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLMembershipNameIndex:
            return NSLocalizedString(@"Membership Title", @"Placeholder for Membership Title");
            break;
        case CLMembershipTypeIndex:
            return NSLocalizedString(@"Type", @"Placeholder for Type field");
            break;
        case CLMemberShipCountryIndex:
            return NSLocalizedString(@"Country", @"Placeholder for Institution");
            break;
        case CLMembershipLocationIndex:
            return NSLocalizedString(@"Location(City/Town/Village,country)", @"Placeholder for Location(City/Town/Village,country)");
            break;
        case CLMembershipNumberIndex:
            return NSLocalizedString(@"Membership Number", @"Placeholder for membership number field");
            break;
        case CLMembershipProgressIndex:
            return NSLocalizedString(@"", @"Placeholder for This Membership is still in progress or being achieved field");
            break;
        case CLMembershipStartDateIndex:
            if (self.isProgress) {
                return NSLocalizedString(@"Start Date", @"Placeholder for Start Date");
            }else{
                return NSLocalizedString(@"Issued On", @"Placeholder for Issued On Date");
            }
            break;
        case CLMembershipEndDateIndex:
            if (self.isProgress) {
                return NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date");
            }else{
                return NSLocalizedString(@"Date of Expiry", @"Placeholder for End date field");
            }
            break;
        case CLMembershipDescIndex:
            return NSLocalizedString(@"Description", @"Placeholder for Description field");
            break;
        case CLMembershipDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLMembershipDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else if(indexPath.section==CLMembershipDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.membershipObj.documentsUrl count]+1)/2));
    }else if(indexPath.section == CLMembershipProgressIndex){
        return 54;
    }
    else{
        return 44;
    }
}

#pragma mark CLTappableCellDelegate Methods


- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == CLMembershipLocationIndex) {
        self.membershipObj.location=nil;
        self.selectedCurrentLocation = nil;
    }
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLMembershipLocationIndex) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryBasedLocation;
        selectLocation.delegate=self;
        self.forCountry = NO;
        selectLocation.countryCodeforListing=[self.selectedCountry objectForKey:@"countryCode"];
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if (indexPath.section == CLMemberShipCountryIndex){
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        self.forCountry = YES;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
}

#pragma mark CLSelectLocationDelegate
- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        [self.selectedCountry removeAllObjects];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        self.selectedCurrentLocation =nil;
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLMemberShipCountryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLMembershipLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{
    self.selectedCurrentLocation=locDict;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLMembershipLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods
- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    self.txtFirstResponder = nil;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.datePicker.tag = indexPath.section;
    
    if (indexPath.section == CLMembershipEndDateIndex) {
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate *currentDate = [NSDate date];
        NSDateComponents *comps = [[NSDateComponents alloc] init];
        [comps setYear:30];
        NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
        [self.datePicker setMaximumDate:maxDate];
    }else{
        [self.datePicker setMaximumDate:[NSDate date]];
    }
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLMembershipNameIndex:{
            self.nameText=text;
            break;
        }
        case CLMembershipTypeIndex:{
            self.typeText=text;
            break;
        }
        case CLMembershipNumberIndex:{
            self.numberText=text;
            break;
        }
        case CLMembershipDescIndex:{
            self.descriptionText=text;
            break;
        }
        default:
            break;
    }
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (indexPath.section) {
        case CLMembershipNameIndex:
            self.nameText = @"";
            break;
        case CLMembershipTypeIndex:
            self.typeText = @"";
            break;
        case CLMembershipNumberIndex:
            self.numberText = @"";
            break;
        case CLMembershipStartDateIndex:{
            if (self.isProgress) {
                self.startDate = nil;
            }
            else{
                self.issuedOn = nil;
            }
        }
            break;
        case CLMembershipEndDateIndex:{
            if (self.isProgress) {
                self.completedDate = nil;
            }
            else{
                self.endDate = nil;
            }
        }
            break;
            
        default:
            break;
    }
}


#pragma mark CLProfilePhotoListingGridCellDelegate Methods
- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate
-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject addDocument:image forQualification:self.membershipObj.membershipId andUser:[CLUserObject currentUser].userID withDocType:kAddMembershipDocType andCaption:caption success:^(CLFileObject *fileObj) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.membershipObj.documentsUrl) {
            self.membershipObj.documentsUrl=[[NSMutableArray alloc] init];
        }
        [self.membershipObj.documentsUrl addObject:fileObj];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

#pragma mark UIActionsheet Delegates
-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLFileObject *documentObj=[self.membershipObj.documentsUrl objectAtIndex:indexPath.row];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting education doc");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject deleteQDocument:documentObj.fileId success:^{
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.membershipObj.documentsUrl removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

-(void)progressStatusSwtchAction:(UISwitch*)sender{
    
    BOOL status = [[NSNumber numberWithInteger:sender.tag] boolValue];
    if (status) {
        self.isProgress = NO;
    }else{
        self.isProgress = YES;
    }
    [self reloadTableWithAnimation:YES];
}

-(void)reloadTableWithAnimation:(BOOL)boolVal{
    if (boolVal) {
        [UIView transitionWithView:self.tableView
                          duration:0.4f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^(void) {
                            [self.tableView reloadData];
                        } completion:NULL];
    }else{
        [self.tableView reloadData];
    }
}

#pragma mark CLTextCheckBoxCellDelegate Methods
-(void)textCheckBoxCellWillBeginEditing:(CLTextCheckBoxCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    
}

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    [CLCommon doViewAnimation:self.view];
    if (status) {
        self.isLifeTime = YES;
        self.endDate = nil;
    }else{
        self.isLifeTime = NO;
    }
    [self reloadTableWithAnimation:YES];
}

@end
