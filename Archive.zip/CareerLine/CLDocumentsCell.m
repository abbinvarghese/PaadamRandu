//
//  CLDocumentsCell.m
//  CareerLine
//
//  Created by Abbin on 13/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLDocumentsCell.h"
#import "UIImageView+WebCache.h"
#import "CLLoaderImageVIew.h"

@interface CLDocumentsCell()
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *imageView;
@property (weak, nonatomic) IBOutlet UILabel *fileName;
@property (weak, nonatomic) IBOutlet UILabel *date;

@end

@implementation CLDocumentsCell

- (void)awakeFromNib {
    // Initialization code
}

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLDocumentsCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        self = [arrayOfViews objectAtIndex:0];
        
    }
    
    return self;
    
}

-(void)updateCellForDocuments:(CLDocsObject *)docObj{
    self.fileName.text = docObj.caption;
    self.date.text = docObj.dateUploaded;
    self.fileName.textColor =[CLCommon sharedInstance].currentTrafficLightColor;
    [self.imageView setImageWithUrlString:docObj.fileUrl andPlaceHolderName:@"documentPlaceHolder.png"];
}





@end
