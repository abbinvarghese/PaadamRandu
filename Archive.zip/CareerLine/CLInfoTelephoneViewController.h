//
//  CLInfoTelephoneViewController.h
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLTelephoneObject.h"
#import "CLSimpleTextCell.h"
#import "CLTextCheckBoxCell.h"

@class CLInfoTelephoneViewController;

//Delegate Methods...
@protocol CLTelephoneControllerDelegate <NSObject>

@optional
- (void)telephoneController:(CLInfoTelephoneViewController *)controller didAddTelephoneNumber:(CLTelephoneObject*)telephoneObj forType:(CLTelephoneContactType)type;

@optional
- (void)telephoneController:(CLInfoTelephoneViewController *)controller didEditTelephoneNumber:(CLTelephoneObject*)telephoneObj forType:(CLTelephoneContactType)type;

@end

@interface CLInfoTelephoneViewController : UITableViewController<CLSimpleTextCellDelegate,CLTextCheckBoxCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate>

@property(nonatomic,weak) id <CLTelephoneControllerDelegate> delegate;
@property(nonatomic,strong)CLTelephoneObject *telephoneObj;
@property(nonatomic,strong)NSString *currentCountryCode;
@property(nonatomic,assign)BOOL isEditMode;

@end
