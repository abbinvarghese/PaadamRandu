//
//  CLMediaPresence.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLMediaPresenceObject : NSObject

@property(nonatomic,strong)NSString *mediaPresenceId;
@property(nonatomic,strong)NSString *websiteName;
@property(nonatomic,strong)NSString *websiteUrl;
@property(nonatomic,strong)NSString *websiteDescription;



//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//Method for saving media of a particular user...
+ (void)saveMediaPresence:(NSString*)mediaId forUser:(NSString*)userId websitetitle:(NSString*)title websiteUrl:(NSString *)url remarks:(NSString*)remarks editMode:(BOOL)isEditMode success:(void (^)(NSString *achievementId))success failure:(void (^)(NSString *error))failure;

//Method for deleting media for a particular user...
+ (void)deleteWebsite:(NSString*)mediaId forUser:(NSString*)userId success:(void (^)(NSString *mediaId))success failure:(void (^)(NSString *error))failure;

@end
