//
//  CLProfileViewController.m
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileViewController.h"
#import "CLProfileAboutMeViewController.h"
#import "CLProfileCareerViewController.h"
#import "CLProfileReferenceViewController.h"
#import "CLProfileProtfolioViewController.h"
#import "CLAboutMeThumbCell.h"
#import "CLUserObject.h"
#import "CLAboutMeObject.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
//#import "UIImageView+WebCache.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "NSDictionary+Additions.h"
#import "CLQualificationViewController.h"
#import "CLLoaderImageVIew.h"
#import "CLJobPreferencesViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLInfoObject.h"

#define kProfileCellCotentFont 13
#define kProfileCellHeadingFont 14

@interface CLProfileViewController (){
    
    BOOL isThumbnail;
}

@property (weak, nonatomic) IBOutlet UILabel *pullDownRefreshLbl;
@property (nonatomic,strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) CLProfileObject *profObj;
@property (strong, nonatomic) IBOutlet UIView *tableHeaderAboutMe;
@property (nonatomic, retain) NSArray *sectionHeadings;
@property (weak, nonatomic) IBOutlet UITableView *profileListingTable;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *profileImage;
@property (weak, nonatomic) IBOutlet UILabel *fullNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *nameAgeEmailLbl;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
//Table view number of sections...
typedef enum {
	TableSectionCount = 8
} TableSection;

//Table view sections...
typedef enum {
    CLProfAboutmeIndex = 0,
    CLProfCareerIndex= 1,
    CLProfQualificationIndex = 2,
    CLProfCapabilityIndex = 3,
    CLProfPortfolioIndex = 4,
    CLProfReferencesIndex = 5,
    CLProfGoalsIndex = 6,
    CLProfJobPreferenceIndex = 7
    
} CLProfileTableSectionIndex;

//PhotoThumb row number..
typedef enum{
    CLThumbPhotoIndex = 0
} CLAboutMeThumImageCount;
@end

@implementation CLProfileViewController
@synthesize isAboutMeReload,isCareerReload,isQualiftnReload,isPortfolioReload,isReferenceReload,isJobPreferenceReload;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewDidAppear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    [self.profileListingTable reloadData];
    
    if(([CLUserObject isSessionValid] && self.profObj==nil) || (isAboutMeReload || isCareerReload || isQualiftnReload || isReferenceReload || isPortfolioReload || isJobPreferenceReload)){
        
        self.profileListingTable.tableHeaderView.hidden = YES;
        self.profileListingTable.hidden =YES;
        [self retrieveProfileSummary:YES];
    }
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapped:)];
    [tapRecognizer setNumberOfTapsRequired:1];
    [tapRecognizer setDelegate:self];
    [self.profileImage addGestureRecognizer:tapRecognizer];
    
    UITapGestureRecognizer *tapRecognizerForDetails = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(aboutMeTapped:)];
    [tapRecognizerForDetails setNumberOfTapsRequired:1];
    [tapRecognizerForDetails setDelegate:self];
    
    [self.nameAgeEmailLbl addGestureRecognizer:tapRecognizerForDetails];
    [self.fullNameLbl addGestureRecognizer:tapRecognizerForDetails];
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLProfileObject cancelProfileSummaryPendingRequest];
}
- (void)viewWillAppear:(BOOL)animated{
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Profile"];
}

- (void)imageTapped:(id)sender{
    
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addPhotoActionSheet=[[UIActionSheet alloc] initWithTitle:NSLocalizedString(@"Change Profile Photo", @"Change Profile Photo") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3"),NSLocalizedString(@"Delete", @"photo selection actionsheet delete button"), nil];
        addPhotoActionSheet.tag=1;
        [addPhotoActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change Profile Photo", @"Change Profile Photo") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addPhotoActionSheetPressedWithButtonIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addPhotoActionSheetPressedWithButtonIndex:1];
                                            }];
        UIAlertAction *deleteAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", @"photo selection actionsheet delete button") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self addPhotoActionSheetPressedWithButtonIndex:2];
        }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        [actionSheetController addAction:deleteAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }

}

- (void)aboutMeTapped:(id)sender{

    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:CLThumbPhotoIndex inSection:CLProfAboutmeIndex];
    [self tableView:self.profileListingTable didSelectRowAtIndexPath:(NSIndexPath *)indexPath];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.pullDownRefreshLbl.hidden = YES;
    self.title = NSLocalizedString(@"Profile", @"profile listing heading");
    self.sectionHeadings = [[NSArray alloc]initWithObjects: NSLocalizedString(@"About Me",@"about me heading"),NSLocalizedString(@"Career",@"career heading"),NSLocalizedString(@"Qualifications",@"qualification heading"),NSLocalizedString(@"Capabilities",@"capabilities heading"),NSLocalizedString(@"Portfolio",@"portfolio heading"),NSLocalizedString(@"Reviews",@"reviews heading"),NSLocalizedString(@"Goals",@"goal heading"), NSLocalizedString(@"Job Preferences",@"Job Preferences heading"),nil];
    
    [self setupLeftMenuButton];
    self.profileListingTable.tableHeaderView = self.tableHeaderAboutMe;
    [self setUpRefreshControl];
}

-(void)setUpRefreshControl{
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.profileListingTable;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshProfileSummary:) forControlEvents:UIControlEventValueChanged];
    tableViewController.refreshControl = self.refreshControl;
}

-(void)refreshProfileSummary:(id)sender{

    [self retrieveProfileSummary:YES];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}
#pragma mark Utility Methods

-(void)retrieveProfileSummary:(BOOL)isLoader{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];

    [CLProfileObject profileSummaryForUser:[CLUserObject currentUser].userID success:^(CLProfileObject *profObject) {
        [progressHUD hideWithAnimation:YES];
        self.profObj = profObject;
        if ([profObject.thumbImages count]>0) {
            isThumbnail = YES;
        }else{
            isThumbnail = NO;
        }
        [self updateTableHeaderDetails];
        self.nameAgeEmailLbl.hidden =NO;
        self.fullNameLbl.hidden = NO;
        isAboutMeReload = NO;
        isCareerReload = NO;
        isQualiftnReload = NO;
        isReferenceReload = NO;
        isPortfolioReload = NO;
        isJobPreferenceReload = NO;
        self.profileListingTable.hidden =NO;
        self.pullDownRefreshLbl.hidden = YES;
        self.profileListingTable.tableHeaderView.hidden = NO;
        [self.profileListingTable reloadData];
        
        
    } failure:^(NSString *error) {
        
         [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            [self setUpRefreshControl];
            self.profileListingTable.hidden = NO;
            self.profileListingTable.tableHeaderView.hidden = YES;
            self.profObj = nil;
            [self.profileListingTable reloadData];
            self.pullDownRefreshLbl.hidden = NO;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

#pragma mark -Left menu button set up
-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

#pragma mark -Update contents in header view
-(void)updateTableHeaderDetails{
    
    //name..
    if ([self.profObj.firstName isEqualToString:@""] && [self.profObj.lastName isEqualToString:@""]) {
        self.fullNameLbl.text = @"";
    }
    else if (![self.profObj.firstName isEqualToString:@""] && [self.profObj.lastName isEqualToString:@""]){
        
        self.fullNameLbl.text = self.profObj.firstName;
    }
    else if ([self.profObj.firstName isEqualToString:@""] && ![self.profObj.lastName isEqualToString:@""]){
        self.fullNameLbl.text = self.profObj.lastName;
    }
    else{
        if (self.profObj.firstName.length > 0 && self.profObj.lastName.length > 0) {
            self.fullNameLbl.text = [NSString stringWithFormat:@"%@ %@",self.profObj.firstName,self.profObj.lastName];
        }
    }
    
    //email,age & nickname..
    if ([CLUserObject currentUser].email != nil && self.profObj.nickName.length == 0 && self.profObj.userAge != nil) {
        self.nameAgeEmailLbl.text = [NSString stringWithFormat:@"%@  \n%@ ",self.profObj.userAge,[CLUserObject currentUser].email];;
    }
    //    else if ([CLUserObject currentUser].email != nil && self.profObj.nickName == nil && self.profObj.userAge == nil){
    //        self.nameAgeEmailLbl.text = [CLUserObject currentUser].email;
    //    }
    //    else if ([CLUserObject currentUser].email == nil && self.profObj.userAge == nil && self.profObj.nickName != nil){
    //        self.nameAgeEmailLbl.text = self.profObj.nickName;
    //    }
    //    else if ([CLUserObject currentUser].email == nil && self.profObj.userAge != nil && self.profObj.nickName == nil){
    //        self.nameAgeEmailLbl.text = self.profObj.userAge;
    //    }
    else{
        if (self.profObj.nickName.length > 0 && self.profObj.userAge.length > 0) {
            self.nameAgeEmailLbl.text = [NSString stringWithFormat:@"%@ | %@  %@",self.profObj.nickName,self.profObj.userAge,[NSString stringWithFormat:@"\n%@",[CLUserObject currentUser].email]];
        }
    }
    
    [self.profileImage setImageWithUrlString:self.profObj.profImageUrl];
    
}

#pragma mark -drawe button action
-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

#pragma mark -UITableView Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    if (self.profObj) {
        return TableSectionCount;
    }else{
        return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == CLProfAboutmeIndex) {
        return nil;
    }else{
        return [self.sectionHeadings objectAtIndex:section];
    }
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == CLProfAboutmeIndex){
        return 1.0;
    }else{
        return 32.0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat indentHeight = 16;
    NSString *text = nil;
    NSString *heading = nil;
    
    if(indexPath.section == CLProfAboutmeIndex && indexPath.row == CLThumbPhotoIndex){
        if (isThumbnail) {
            return 111.0;
        }else{
            return 0;
        }
    }else{
        
        if (indexPath.section == CLProfCareerIndex) {
            text = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text == nil) {
                text = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else {
                if (indexPath.row ==0) {
//                    text = @"";
                }else{
                    text = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                }
                
                heading = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if(indexPath.section == CLProfAboutmeIndex){
            text = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text == nil) {
                text = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if(indexPath.section == CLProfQualificationIndex){
            
            text = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text ==nil) {
                text = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if (indexPath.section == CLProfCapabilityIndex){
            
            text = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text ==nil) {
                text = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if(indexPath.section == CLProfPortfolioIndex){
            
            text = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text ==nil) {
                text = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if (indexPath.section == CLProfReferencesIndex){
            heading = @"";
            text = [[self.profObj.referenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
        }else if (indexPath.section == CLProfGoalsIndex){
            
            text = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text ==nil) {
                text = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
            
        }else if (indexPath.section == CLProfJobPreferenceIndex){
            
            text = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            if (text ==nil) {
                text = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }else{
                text = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
                heading = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            }
        }
        
        CGRect expectedDetailedtextFrame = [text boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX)
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                       [UIFont systemFontOfSize:kProfileCellCotentFont], NSFontAttributeName,
                                                                       nil]
                                                              context:nil];
        
        CGRect expectedHeaadingtextFrame = [heading boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX)
                                                                 options:NSStringDrawingUsesLineFragmentOrigin
                                                              attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                          [UIFont systemFontOfSize:kProfileCellHeadingFont], NSFontAttributeName,
                                                                          nil]
                                                                 context:nil];
        
        CGFloat detailHeight = expectedDetailedtextFrame.size.height;
        CGFloat headingHeight = expectedHeaadingtextFrame.size.height;
        CGFloat totalHeight = detailHeight+headingHeight+indentHeight;
        return MAX(45, totalHeight);
        
    }
    
}

- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section {
    
    return [self getRowCountForSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (!(indexPath.section == CLProfAboutmeIndex)) {
        
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        if (indexPath.section == CLProfCareerIndex) {
            
            cell.textLabel.text = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.careerArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if (indexPath.section == CLProfQualificationIndex){
            
            cell.textLabel.text = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.qualificationArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if (indexPath.section == CLProfCapabilityIndex){
            
            cell.textLabel.text = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.capabilityArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if(indexPath.section == CLProfPortfolioIndex){
            
            cell.textLabel.text = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.protfolioArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if (indexPath.section == CLProfReferencesIndex){
            //if ([[[self.profObj.referenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey] isEqualToString:@""]) {
                cell.textLabel.text = [[self.profObj.referenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
           // }else{
               // cell.textLabel.text = @"";
            //}
            cell.detailTextLabel.text = [[self.profObj.referenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if (indexPath.section == CLProfGoalsIndex){
            
            cell.textLabel.text = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.goalsArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }else if (indexPath.section == CLProfJobPreferenceIndex){
            
            cell.textLabel.text = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.jobPreferenceArray objectAtIndex:indexPath.row] objectForKeyNotNull:kCLProfileSummaryValuekey];
        }
        
        if ([cell.detailTextLabel.text isEqualToString:@""]) {
            [cell.textLabel setTextColor:[UIColor lightGrayColor]];
        }else{
            [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
//        if (indexPath.section == CLProfReferencesIndex){
//            cell.detailTextLabel.numberOfLines = 2;
//            cell.detailTextLabel.lineBreakMode = NSLineBreakByWordWrapping | NSLineBreakByTruncatingTail;
//        }else
            if(indexPath.section == CLProfCareerIndex && indexPath.row ==0){
            cell.detailTextLabel.numberOfLines = 0;
            cell.detailTextLabel.lineBreakMode = NSLineBreakByWordWrapping | NSLineBreakByTruncatingTail;
        }else{
            cell.detailTextLabel.numberOfLines = 0;
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
            cell.detailTextLabel.lineBreakMode = NSLineBreakByWordWrapping;
            cell.detailTextLabel.textAlignment =NSTextAlignmentJustified;
            cell.textLabel.textAlignment = NSTextAlignmentJustified;
        }
        return cell;
    }else{
        
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        cell.textLabel.text = @"";
        cell.detailTextLabel.text = @"";
        if (indexPath.row == CLThumbPhotoIndex) {
            
            if(isThumbnail){
                CLAboutMeThumbCell *cell = (CLAboutMeThumbCell *)[tableView dequeueReusableCellWithIdentifier:@"aboutMeThumbCellIdentifier"];
                if (cell == nil) {
                    cell = [[CLAboutMeThumbCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                     reuseIdentifier:@"aboutMeThumbCellIdentifier"];
                }
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                cell.photoUrls = self.profObj.thumbImages;
                [cell updateCollectionViewContents];
                return cell;
            }
        }else{
            
            cell.textLabel.text = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryHeadingkey];
            cell.detailTextLabel.text = [[self.profObj.aboutMeArray objectAtIndex:indexPath.row-1] objectForKeyNotNull:kCLProfileSummaryValuekey];
            
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        if ([cell.detailTextLabel.text isEqualToString:@""]) {
            [cell.textLabel setTextColor:[UIColor lightGrayColor]];
        }else{
            [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        }
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        cell.detailTextLabel.lineBreakMode = NSLineBreakByWordWrapping;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.numberOfLines = 0;
        [cell.detailTextLabel sizeToFit];
        cell.detailTextLabel.textAlignment =NSTextAlignmentJustified;
        cell.textLabel.textAlignment = NSTextAlignmentJustified;
        return cell;
        
    }
    
}

-(int)getSelectedRowFromCell:(UITableViewCell*)cell{
    if ([cell.textLabel.text isEqualToString:@"Target Jobs"]) {
        return 0;
    }
    else if ([cell.textLabel.text isEqualToString:@"Contract Consideration"]){
        return 1;
    }
    else if ([cell.textLabel.text isEqualToString:@"Work Condition Considerations"]){
        return 2;
    }
    else if ([cell.textLabel.text isEqualToString:@"Where Are You Willing to Work?"]) {
        return 3;
    }
    else if ([cell.textLabel.text isEqualToString:@"Education"]) {
        return 0;
    }
    else if ([cell.textLabel.text isEqualToString:@"Training"]) {
        return 1;
    }
    else if ([cell.textLabel.text isEqualToString:@"Certifications"]) {
        return 2;
    }
    else if ([cell.textLabel.text isEqualToString:@"Licences"]) {
        return 3;
    }
    else if ([cell.textLabel.text isEqualToString:@"Memberships"]) {
        return 4;
    }
    else if ([cell.textLabel.text isEqualToString:@"Career Projects/Functional Experiences"]) {
        return 0;
    }
    else if ([cell.textLabel.text isEqualToString:@"Education/Training Projects/Experiences"]) {
        return 1;
    }
    else if ([cell.textLabel.text isEqualToString:@"Additional Portfolio Item"]) {
        return 2;
    }
    else{
        return 0;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (indexPath.section == CLProfAboutmeIndex) {
        
        isAboutMeReload = YES;
        CLProfileAboutMeViewController *profAboutMeController = [[CLProfileAboutMeViewController alloc] initWithNibName:@"CLProfileAboutMeViewController" bundle:[NSBundle mainBundle]];
        
        CLAboutMeObject *aboutMeObj = [[CLAboutMeObject alloc]init];
        aboutMeObj.info.firstName = self.profObj.firstName;
        aboutMeObj.info.lastName = self.profObj.lastName;
        aboutMeObj.info.nickname = self.profObj.nickName;
        aboutMeObj.photos = self.profObj.thumbImages;
        profAboutMeController.aboutMe = aboutMeObj;
        
        [self.navigationController pushViewController:profAboutMeController animated:YES];
        
    }else if (indexPath.section == CLProfCareerIndex){
        
        isCareerReload = YES;
        CLProfileCareerViewController *profCareerController = [[CLProfileCareerViewController alloc] initWithNibName:@"CLProfileCareerViewController" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:profCareerController animated:YES];
    }else if (indexPath.section == CLProfQualificationIndex){
        
        isQualiftnReload = YES;
        CLQualificationViewController *profQualificationController = [[CLQualificationViewController alloc] initWithNibName:@"CLQualificationViewController" bundle:[NSBundle mainBundle]];
        profQualificationController.selectedRow = [self getSelectedRowFromCell:[tableView cellForRowAtIndexPath:indexPath]];
        [self.navigationController pushViewController:profQualificationController animated:YES];
    }
    else if (indexPath.section == CLProfReferencesIndex){
        
        isReferenceReload = YES;
        CLProfileReferenceViewController *profReferenceController = [[CLProfileReferenceViewController alloc] initWithNibName:@"CLProfileReferenceViewController" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:profReferenceController animated:YES];
    }
    else if (indexPath.section == CLProfPortfolioIndex){
      
        isPortfolioReload = YES;
        CLProfileProtfolioViewController *profProtfolioController = [[CLProfileProtfolioViewController alloc] initWithNibName:@"CLProfileProtfolioViewController" bundle:[NSBundle mainBundle]];
        profProtfolioController.selectedRow = [self getSelectedRowFromCell:[tableView cellForRowAtIndexPath:indexPath]];
        [self.navigationController pushViewController:profProtfolioController animated:YES];
    }
    else if (indexPath.section == CLProfJobPreferenceIndex){
        
        isJobPreferenceReload = YES;
        CLJobPreferencesViewController *profJobPreferenceController = [[CLJobPreferencesViewController alloc] initWithNibName:@"CLJobPreferencesViewController" bundle:[NSBundle mainBundle]];
        profJobPreferenceController.selectedRow = [self getSelectedRowFromCell:[tableView cellForRowAtIndexPath:indexPath]];
        [self.navigationController pushViewController:profJobPreferenceController animated:YES];
    }
    else if (indexPath.section == CLProfCapabilityIndex){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Capabilities Not Currently Available in App. Please Visit the Website", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        NSLog(@"CLICKED");
    }
    else if (indexPath.section == CLProfGoalsIndex){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Goals Not Currently Available in App. Please Visit The Website", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        NSLog(@"CLICKED");
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -Helper method
-(NSInteger)getRowCountForSection:(NSInteger)sectionIndex{
    switch (sectionIndex) {
        case CLProfAboutmeIndex:
            
            return [self.profObj.aboutMeArray count]+1;
            
            break;
        case CLProfCareerIndex:
            
            return [self.profObj.careerArray count];
            break;
        case CLProfQualificationIndex:
            
            return [self.profObj.qualificationArray count];
            
            break;
        case CLProfCapabilityIndex:
            
            return [self.profObj.capabilityArray count];
            
            break;
        case CLProfPortfolioIndex:
            
            return [self.profObj.protfolioArray count];
            
            break;
        case CLProfReferencesIndex:
            
            return [self.profObj.referenceArray count];
            
            break;
        case CLProfGoalsIndex:
            
            return [self.profObj.goalsArray count];
            
            break;
        case CLProfJobPreferenceIndex:
            
            return [self.profObj.jobPreferenceArray count];
            
            break;
        default:
            return 0;
            break;
    }
}

#pragma mark UIActionSheet Delegate

-(void)addPhotoActionSheetPressedWithButtonIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                if ([CLCommon HaveCamaraAccess:self.view]) {
                    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                    imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                    imagePicker.allowsEditing = YES;
                    imagePicker.delegate = self;
                    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                    [self presentViewController:imagePicker animated:YES completion:nil];
                }
                else{
                    [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Camara Access Denied. Turn On Camara Privacy in Settings App", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                }
                
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:{
            [self deletePrimaryPhoto];
            break;
        }
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //adding new image actionsheet..
    if (actionSheet.tag==1) {
        [self addPhotoActionSheetPressedWithButtonIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}
#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) {
        pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [self uploadProfilePicture:pickedImage];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark - Utility method
-(void)uploadProfilePicture:(UIImage*)image{
    float imageSize=(float)UIImageJPEGRepresentation(image, 1).length/1024.0f/1024.0f;
    if (imageSize<5.0) {
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [progressHUD showInView:self.view];
        self.navigationItem.hidesBackButton=YES;
        self.navigationItem.rightBarButtonItem.enabled=NO;
        
        [CLInfoObject uploadPrimaryImage:image forUser:[CLUserObject currentUser].userID imageId:@""
                                 success:^(CLFileObject *imageObj){
                                     [progressHUD hideWithAnimation:YES];
                                     self.profObj.profImageUrl = imageObj.file;
                                     [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterProfileImageChanged object:imageObj];
                                     [self updateTableHeaderDetails];
                                 }
                                 failure:^(NSString *error) {
                                     if (![error isEqualToString:@""]) {
                                         [progressHUD hideWithAnimation:YES];
                                         self.navigationItem.hidesBackButton=NO;
                                         self.navigationItem.rightBarButtonItem.enabled=YES;
                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                     }
                                 }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Image size too large to upload. Please try uploading a smaller image", @"Image upload error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

-(void)deletePrimaryPhoto{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    [CLAboutMeObject deletePhoto:self.profObj.profileImageId forUser:[CLUserObject currentUser].userID success:^(){
        [progressHUD hideWithAnimation:YES];
        self.profObj.profImageUrl=@"";
        self.profObj.profileImageId=@"";
        [self.profileImage setImageWithUrlString:@""];
    }failure:^(NSString *error){
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        [progressHUD hideWithAnimation:YES];
    }];
    
}

-(void)clearArraysAndReloadTable{
    self.profileImage.image = nil;
    self.nameAgeEmailLbl.text = nil;
    self.fullNameLbl.text = nil;
    self.profObj = nil;
    isAboutMeReload = NO;
    isCareerReload = NO;
    isJobPreferenceReload = NO;
    isQualiftnReload = NO;
    isReferenceReload = NO;
    isPortfolioReload = NO;
    [self.profileListingTable reloadData];
}
#pragma mark NSNotification Methods
-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self updateTableHeaderDetails];
    [self.profileListingTable reloadData];
}
@end
