//
//  CLWorkAchievementObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLWorkAchievementObject.h"
#import "CLFileObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLWorkAchievementObject

static NSOperationQueue *saveWorkAchievementRequest;
static NSOperationQueue *deleteWorkAchievementRequest;
static NSOperationQueue *uploadWorkAchDocumentRequest;
static NSOperationQueue *deleteWorkAchDocumentRequest;

//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary{
    self.achievementId=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementIdkey];
    self.awards=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementAwardskey];
    //self.date=[CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementDatekey] andFormat:@"dd-MM-yyyy"];
    self.date=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMy"];
    }
    self.workDescription=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementDescriptionkey];
    self.relatedToSelected=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementRelatedToSelectedDictkey];
    
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementFilesArraykey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    
    return self;
}

//get dictionary from object..
- (NSMutableDictionary *)getDictFromObject:(CLWorkAchievementObject *)wrkAchvmntObj{
 
    NSMutableDictionary *dict= [[NSMutableDictionary alloc]init];
 
    if (wrkAchvmntObj.achievementId !=nil) {
          [dict setObject:wrkAchvmntObj.achievementId forKey:kCLProfileProtfolioWorkAchievementIdkey];
    }
    [dict setObject:wrkAchvmntObj.awards forKey:kCLProfileProtfolioWorkAchievementAwardskey];
    [dict setObject:[CLCommon getStringForDate:wrkAchvmntObj.date andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileProtfolioWorkAchievementDatekey];
    [dict setObject:wrkAchvmntObj.workDescription forKey:kCLProfileProtfolioWorkAchievementDescriptionkey];
    if (wrkAchvmntObj.documents!=nil) {
        [wrkAchvmntObj.documents removeAllObjects];
         [dict setObject:wrkAchvmntObj.documents forKey:kCLProfileProtfolioWorkAchievementFilesArraykey];
    }
   
    return dict;
}


-(void)updateDate:(NSDate*)date{
    self.date=date;
    self.formattedDateString=[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"];
}

+(NSString*)jsonStringForObject:(CLWorkAchievementObject*)workAchObj{
    NSMutableDictionary *achievementDict=[[NSMutableDictionary alloc] init];

    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    if (workAchObj.wrkHisId !=nil) {
        [insideDict setObject:workAchObj.wrkHisId forKey:kCLCareerHistoryIdkey];
    }
    [insideDict setObject:workAchObj.awards forKey:kCLProfileProtfolioWorkAchievementAwardskey];
    [insideDict setObject:[CLCommon getStringForDate:workAchObj.date andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileProtfolioWorkAchievementDatekey];
    if ([workAchObj.relatedToSelected objectForKey:kCLProfileProtfolioWorkAchievementRelatedToIdkey]) {
        [insideDict setObject:[workAchObj.relatedToSelected objectForKey:kCLProfileProtfolioWorkAchievementRelatedToIdkey] forKey:kCLProfileProtfolioWorkAchievementRelatedToIdkey];
    }
    if (workAchObj.workDescription) {
        [insideDict setObject:workAchObj.workDescription forKey:kCLProfileProtfolioWorkAchievementDescriptionkey];
    }
    
    [achievementDict setObject:insideDict forKey:kCLProfileProtfolioWorkAchievementArraykey];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:achievementDict];
}

//Method for saving work achievement of a particular user...
+ (void)saveWorkAchievement:(CLWorkAchievementObject*)achObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *workAchId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *workAchId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": achObj.achievementId, @"fields":[CLWorkAchievementObject jsonStringForObject:achObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLWorkAchievementObject jsonStringForObject:achObj]};
    }
    
    if (kDebugMessages) {
        NSLog(@"saveWorkAchievement Params JSON: %@", parameters);
    }
    
    [saveWorkAchievementRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveWorkAchievementRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileWorkAchievementSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveWorkAchievementRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileWorkAchievementSaveIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting work achievement for a particular user...
+ (void)deleteWorkAchievement:(NSString*)achievementId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": achievementId};
    
    [deleteWorkAchievementRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteWorkAchievementRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioDeleteAchievementURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete work achievement JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading work achievement document for a particular user...
+ (void)addDocument:(UIImage*)image forWorkAchievement:(NSString*)achId andUser:(NSString *)userId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": achId};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadWorkAchDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadWorkAchDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileWorkAchievementUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"Achievements" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"work achievement document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting work achievement document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteWorkAchDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteWorkAchDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileWorkAchievementDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete work achievement document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
