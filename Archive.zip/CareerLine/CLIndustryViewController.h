//
//  CLIndustryViewController.h
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLIndustryViewController;

@protocol CLSelectIndustryDelegate <NSObject>

@optional
- (void)selectIndustryControllerDidSelectIndustry:(CLIndustryViewController*)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray;

@end

@interface CLIndustryViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, weak) id<CLSelectIndustryDelegate> delegate;
@property(nonatomic ,strong) NSMutableArray *selectedindustries;
@property (nonatomic, strong) NSMutableDictionary *selectedIndustryDict;

@property (nonatomic, strong) NSString *selectedGroupCode;
@property(nonatomic,assign) BOOL singleSelection;
@property(nonatomic,assign) BOOL isAllSelected;


-(void)rightNavigationButton;

@end
       