//
//  CLSelectBusinessDivViewController.m
//  CareerLine
//
//  Created by RENJITH on 05/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLSelectBusinessDivViewController.h"
#import "CLUserObject.h"
#define kCellTextFontSize 14

@interface CLSelectBusinessDivViewController ()
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property(nonatomic,strong)NSMutableDictionary *selectedBusinessDivDict;
@property(nonatomic,strong)NSMutableArray *filteredBusinessDivArray;
@property(nonatomic,strong)NSString *searchText;

@end

@implementation CLSelectBusinessDivViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeWords;
    self.title=NSLocalizedString(@"Add Business Division", @"add business division page title");
    [self setLeftNavigationButton];
    
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.tableHeaderView=self.searchBar;
    self.selectedBusinessDivDict=[[NSMutableDictionary alloc] init];
    self.filteredBusinessDivArray=[[NSMutableArray alloc] init];
    self.searchText=@"";
    
    [self.searchBar becomeFirstResponder];
    
    //self.completeBusinessDiv = [[NSMutableArray alloc]init];
    
//    if (self.completeBusinessDiv!=nil) {
//        
//        NSMutableArray *array = [self.completeBusinessDiv mutableCopy];
//        
//        for (NSDictionary *dict in array) {
//            NSMutableDictionary *dict1 = [[NSMutableDictionary alloc]init];
//            [dict1 setObject:[dict objectForKey:@"division"] forKey:@"companyDivision"];
//            [dict1 setObject:[dict objectForKey:@"id"] forKey:@"companyId"];
//            [self.filteredBusinessDivArray addObject:dict1];
//            }
//    }
//    
//    NSDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"122",@"companyId",@"testDiv11",@"companyDivision", nil];
//    NSDictionary *dict1 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"123",@"companyId",@"testDiv2",@"companyDivision", nil];
//    NSDictionary *dict2 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"124",@"companyId",@"testDiv3",@"companyDivision", nil];
//    NSDictionary *dict3 = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"125",@"companyId",@"testDiv4",@"companyDivision", nil];
//    
//     [self.array addObject:dict];
//     [self.array addObject:dict1];
//     [self.array addObject:dict2];
//     [self.array addObject:dict3];
    
    
    [self filterContentForSearchText:self.searchText];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [self.searchBar resignFirstResponder];
}

-(NSString*)createBlacklistStringForSelectedBusinessDiv{
    NSMutableString *string=[[NSMutableString alloc] init];
    if ([self.alreadySelectedBusDiv count]>0) {
        for (int i=0; i<[self.alreadySelectedBusDiv count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[self.alreadySelectedBusDiv objectAtIndex:i] objectForKey:kCLCareerHistoryOtherBusDivCompanyIdkey]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
    }
    return string;
}

- (void)filterContentForSearchText:(NSString*)searchText
{
    // Update the filtered array based on the search text.
  //  [self.filteredBusinessDivArray removeAllObjects];
//    [self.tableView reloadData];
//    
//    for(int i =0; i<[self.alreadySelectedBusDiv count]; i++)
//    {
//        if ([self.filteredBusinessDivArray  containsObject:[self.alreadySelectedBusDiv objectAtIndex:i]])
//            [self.filteredBusinessDivArray removeObject: [self.alreadySelectedBusDiv objectAtIndex:i]];
//    }
//
//    if (self.completeBusinessDiv!=nil) {
//        self.filteredBusinessDivArray = [[NSMutableArray alloc]initWithArray:self.completeBusinessDiv];
//    }
//    if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
//        NSMutableArray *resultArray = [[NSMutableArray alloc]init];
//        for (NSDictionary *dict in self.filteredBusinessDivArray) {
//            NSString *string = [dict objectForKey:@"companyDivision"];
//            if ([string rangeOfString:self.searchText].location == NSNotFound) {
//                NSLog(@"string does not contain self.searchText");
//                 [resultArray removeAllObjects];
//            } else {
//                NSLog(@"string contains self.searchText!");
//                
//                [resultArray addObject:dict];
//                [self.filteredBusinessDivArray removeObject:dict];
//            }
//        }
//        if ([resultArray count]>0) {
//            self.filteredBusinessDivArray = resultArray;
//        }
//        
//        [self.filteredBusinessDivArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,@"companyDivision",@"0",@"companyId", nil] atIndex:0];
//    }else{
//        NSMutableArray *array = [self.completeBusinessDiv mutableCopy];
//        
//        for (NSDictionary *dict in array) {
//            NSMutableDictionary *dict1 = [[NSMutableDictionary alloc]init];
//            [dict1 setObject:[dict objectForKey:@"division"] forKey:@"companyDivision"];
//            [dict1 setObject:[dict objectForKey:@"id"] forKey:@"companyId"];
//            [self.filteredBusinessDivArray addObject:dict1];
//        }
//    }
//    [self.tableView reloadData];
    
    
    // Update the filtered array based on the search text.
    //[self.filteredBusinessDivArray removeAllObjects];
   // [self.tableView reloadData];
    
    //[self.activityView startAnimating];
//    [CLUserObject getHobbiesListForSearchString:searchText andBlackListString:[self createBlacklistStringForSelectedBusinessDiv]
//                                            success:^(NSMutableArray *hobbiesList){
//                                                //[self.activityView stopAnimating];
//                                                if (hobbiesList!=nil) {
//                                                    self.filteredHobbiesArray = hobbiesList;
//                                                }
//                                                if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
//                                                    [self.filteredHobbiesArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,kCLProfileAboutMeInterestTitlekey,@"0",kCLProfileAboutMeInterestIdkey, nil] atIndex:0];
//                                                }
//                                                [self.tableView reloadData];
//                                            }
//                                            failure:^(NSString *error){
//                                                if (![error isEqualToString:@""]) {
//                                                    //[self.activityView stopAnimating];
//                                                    [self.tableView reloadData];
//                                                }
//                                            }];
    NSString *companyId = [self.selectedCompany objectForKey:kCLCareerHistoryCompanyNameIdkey];
[CLUserObject getCompanyDivListForSearchString:self.searchText companyId:companyId andBlackListString:[self createBlacklistStringForSelectedBusinessDiv] success:^(NSMutableArray *companyDivList) {
    //[self.activityView stopAnimating];
    if (companyDivList!=nil) {
//        NSMutableArray *array = [companyDivList mutableCopy];
//        
//        for (NSDictionary *dict in array) {
//            NSMutableDictionary *dict1 = [[NSMutableDictionary alloc]init];
//            [dict1 setObject:[dict objectForKey:@"division"] forKey:@"companyDivision"];
//            [dict1 setObject:[dict objectForKey:@"id"] forKey:@"companyId"];
//            [self.filteredBusinessDivArray addObject:dict1];
//        }
        
        self.filteredBusinessDivArray = companyDivList;
    }
    if (self.searchText!=nil && ![self.searchText isEqualToString:@""] ) {
       [self.filteredBusinessDivArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:self.searchText,@"division",@"0",@"id", nil] atIndex:0];
    }
    [self.tableView reloadData];
    
} failure:^(NSString *error) {
    if (![error isEqualToString:@""]) {
        //[self.activityView stopAnimating];
        [self.tableView reloadData];
    }
}];
    
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

     return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.filteredBusinessDivArray count];;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"titleTextCellIdentifier"];
        cell.selectionStyle=UITableViewCellSelectionStyleDefault;
        [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
    }
    NSDictionary *cellDict = [self.filteredBusinessDivArray objectAtIndex:indexPath.row];
    
    if (self.searchText!=nil && ![self.searchText isEqualToString:@""] && indexPath.row==0) {
         cell.textLabel.text=[NSString stringWithFormat:@"%@",[cellDict objectForKey:@"division"]];
    }else{
         cell.textLabel.text=[cellDict objectForKey:@"division"];
    }
   
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *expectedText=nil;
    NSDictionary *cellDict=nil;
    cellDict=[self.filteredBusinessDivArray objectAtIndex:indexPath.row];
    expectedText=[cellDict objectForKey:@"division"];
    CGRect expectedQuestextFrame = [expectedText boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                       [UIFont systemFontOfSize:kCellTextFontSize], NSFontAttributeName,
                                                                       nil]
                                                              context:nil];
    
    return MAX(44, ceil(expectedQuestextFrame.size.height)+27);
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    
    [dict setObject:[[self.filteredBusinessDivArray objectAtIndex:indexPath.row] objectForKey:@"division"] forKey:@"companyDivision"];
    [dict setObject:[[self.filteredBusinessDivArray objectAtIndex:indexPath.row] objectForKey:@"id"] forKey:@"companyId"];
    self.selectedBusinessDivDict= dict;
    [self.tableView reloadData];
    [self dismissViewControllerAnimated:YES completion:^(void){
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(businessDivController:didSelectBusDiv:)]){
            [self.delegate businessDivController:self didSelectBusDiv:self.selectedBusinessDivDict];
        }
    }];
}
#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:1];
}

-(void)searchAfterDelay{
    [self filterContentForSearchText:self.searchText];
}
@end
