//
//  CLConstants.h
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#pragma mark - URL's

//Webservice base URL
extern NSString *const kCLWebServiceBaseURL;

//Webservice base URL1
extern NSString *const kCLWebServiceBaseURL1;

//Webservice base URL2
extern NSString *const kCLWebServiceBaseURL2;

//Webservice authentication..
//credential set in: AFHTTPRequestOperationManager.m-> HTTPRequestOperationWithRequest(){}
extern NSString *const kCLWebServiceAuthenticationUsername;
extern NSString *const kCLWebServiceAuthenticationPassword;

//Webservice HTTP authorization header value..
//header edited in: SDWebImageDownloader.m->(id)init{}
extern NSString *const kCLWebServiceHttpAuthenticationHeaderValue;


//Register URL
extern NSString *const kCLWebServiceRegisterURL;

//Register Verification Mail URL
extern NSString *const kCLWebServiceRegisterVerificationMailURL;

//Forgot Password URL
extern NSString *const kCLWebServiceForgotPasswordURL;

//Forgot pass Verification Mail URL
extern NSString *const kCLWebServiceForgotPassVerificationMailURL;

//Login URL
extern NSString *const kCLWebServiceLoginURL;
extern  NSString *const kCLCRFOneURL;
extern NSString *const kCLCRFOnePostURL;
extern  NSString *const kCLCRFTwoGetURL;
extern NSString *const kCLCRFTwoPostURL;
extern  NSString *const kCLCRFThreeGetURL;
extern NSString *const kCLCRFThreePostURL;
extern  NSString *const kCLCRFFourGetURL;
extern NSString *const kCLCRFFourPostURL ;
extern NSString *const kCLCRFFivePostURL;
//Login WebService Keys
extern NSString *const kCLLoginUserIDkey;
extern NSString *const kCLLoginUserFirstNamekey;
extern NSString *const kCLLoginUserLastNamekey;
extern NSString *const kCLLoginUserPreferredNamekey;
extern NSString *const kCLLoginUserEmailkey;
extern NSString *const kCLLoginUserAgekey;
extern NSString *const kCLLoginUserBirthDatekey;
extern NSString *const kCLLoginUserIconUrlkey;
extern NSString *const kCLLoginUserUnreadJobsCountkey;
extern NSString *const kCLLoginUserUnreadInboxCountkey;
extern NSString *const kCLLoginUserFormStatuskey;
extern NSString *const kCLLoginUserTrafficLightStatuskey;

//Logout URL
extern NSString *const kCLWebServiceLogoutURL;

//Update user details url
extern NSString *const kCLWebServiceUpdateUserDetailsURL;

//First time profile details..
extern NSString *const kCLWebServiceFirstTimeSaveUserDetailsURL;

//locations for search string url
extern NSString *const kCLWebServiceGetLocHomeSearchString;

//company div for search string url
extern NSString *const kCLWebServiceGetCompanyDivSearchString;

//Home Location WebService Keys
extern NSString *const kCLGetLocHomeCyNamekey;
extern NSString *const kCLGetLocHomeCyCodekey;
extern NSString *const kCLGetLocHomeLocNamekey;
extern NSString *const kCLGetLocHomeLocCodekey;
extern NSString *const kCLGetLocHomeRegNamekey;

//locations for search string url in same country
extern NSString *const kCLWebServiceGetLocSameCountrySearchString;

//Document Listing URL
extern NSString *const kCLWebServiceDocumentListURL;
extern NSString *const kCLDocumentsCaptionKey;
extern NSString *const kCLDocumentsclAreaTypeKey;
extern NSString *const kCLDocumentsDateUpload;
extern NSString *const kCLDocumentsDocTypeKey;
extern NSString *const kCLDocumentsDocTypeIDKey;
extern NSString *const kCLDocumentsFileKey;
extern NSString *const kCLDocumentsFileIDKey;
extern NSString *const kCLDocumentsFileTitleKey;
extern NSString *const kCLDocumentsFileUrlKey;
extern NSString *const kCLDocumentsOldNameKey;
extern NSString *const kCLDocumentsTypeKey;
extern NSString *const kCLDocumentsTypeName;
extern NSString *const kCLDocumentsWidthKey;
extern NSString *const kCLDocumentsHeightKey;

//Knoledge Listing URL
extern NSString *const kCLWebServiceKnowledgeListURL;
extern NSString *const kCLWebServiceGetWakeURL;
extern NSString *const kCLWebServiceKnowledgeBookmarkListURL;

extern NSString *const kCLWebServiceKnowledgeBookmarkURL;
extern NSString *const kCLWebServiceKnowledgeLikeURL;
extern NSString *const kCLWebServiceKnowledgeDetailsURL;
extern NSString *const kCLWebServiceKnowledgeListKey;
extern NSString *const kCLWebServiceKnowledgeListPagesKey;
extern NSString *const kCLWebServiceKnowledgeListCurrentPageKey;
extern NSString *const kCLWebServiceKnowledgeListCountKey;

extern NSString *const kCLKnowledgeRecIDKey;
extern NSString *const kCLKnowledgeIdKey;
extern NSString *const kCLKnowledgeTitleKey;
extern NSString *const kCLKnowledgeImageUrlKey;
extern NSString *const kCLKnowledgeTypeKey;
extern NSString *const kCLKnowledgeSubTypeKey;
extern NSString *const kCLKnowledgeCatKey;
extern NSString *const kCLKnowledgeBookmarkKey;
extern NSString *const kCLKnowledgeLikeKey;
extern NSString *const kCKnowledgeKeyWord;
extern NSString *const kCLKnowledgeDesc;
extern NSString *const kCLKnowledgenewsCompany ;
extern NSString *const kCLKnowledgeImgWidthKey;
extern NSString *const kCLKnowledgeImgHeightKey;
extern NSString *const kCLKnowledgeLikeCountKey;
extern NSString *const kCLKnowledgepublishedCreated;

//Job Listing URL
extern NSString *const kCLWebServiceJobListURL;
//Job Listing WebService Keys
extern NSString *const kCLJobListPersonKey;
extern NSString *const kCLJobListNameKey;
extern NSString *const kCLJobListemailKey;
extern NSString *const kCLJobListjobIDkey;
extern NSString *const kCLJobListjobReceivedTimekey;
extern NSString *const kCLJobListjobTitlekey;
extern NSString *const kCLJobListjobCompanyIdkey;
extern NSString *const kCLJobListjobCompanyNamekey;
extern NSString *const kCLJobListjobLocationkey;
extern NSString *const kCLJobListjobCountrykey;
extern NSString *const kCLJobListjobIconUrlkey;
extern NSString *const kCLJobListjobUnreadStatuskey;
extern NSString *const kCLJobListjobCurrentPagesKey;
extern NSString *const kCLJobListjobNoOfPagesKey;
extern NSString *const kCLJobListTotalUnreadJobsKey;


//Job Detail URL.
extern NSString *const kCLWebServiceJobDetailURL;
//Job Details WebService Keys
extern NSString *const kCLJobDetailBookmarkStatuskey;
extern NSString *const kCLJobDetailAppliedStatuskey;
extern NSString *const kCLJobDetailBasicArraykey;
extern NSString *const kCLJobDetailDescriptionArraykey;
extern NSString *const kCLJobDetailQualificationArraykey;
extern NSString *const kCLJobDetailCompetenciesArraykey;

//Company Detail URL
extern NSString *const kCLWebServiceCompanyDetailURL;
//Company Detail WebService Keys
extern NSString *const kCLCompanyDetailIDkey;
extern NSString *const kCLCompanyDetailNamekey;
extern NSString *const kCLCompanyDetailDescriptionkey;
extern NSString *const kCLCompanyDetailLocationkey;
extern NSString *const kCLCompanyDetailWebsiteUrlkey;
extern NSString *const kCLCompanyDetailLogoUrlkey;


//Traffic Light status change url
extern NSString *const kCLWebServiceTrafficLightChangeURL;

//ResetPassword url
extern NSString *const kCLWebServiceResetPasswordURL;

//update caption
extern NSString *const kCLWebServiceUpdateCaption;

//Job Bookmark url
extern NSString *const kCLWebServiceJobBookmarkURL;

//Job Reject url
extern NSString *const kCLWebServiceJobRejectURL;

//Job Apply url
extern NSString *const kCLWebServiceJobApplyURL;

//Share job email URL
extern NSString *const kCLWebServiceShareJobEmailURL;

//Inbox Listing URL
extern NSString *const kCLWebServiceInboxListURL;
//Inbox Listing WebService Keys
extern NSString *const kCLInboxListjobIDkey;
extern NSString *const kCLInboxListjobTitlekey;
extern NSString *const kCLInboxListjobCompanykey;
extern NSString *const kCLInboxListjobIconUrlkey;
extern NSString *const kCLInboxListLastMsgkey;
extern NSString *const kCLInboxListId;
extern NSString *const kCLInboxListMsgTimekey;
extern NSString *const kCLInboxListMailUnreadStatuskey;
extern NSString *const kCLInboxListTotalUnreadInboxKey;

//Inbox Detail URL
extern NSString *const kCLWebServiceInboxDetailURL;
//Inbox Detail WebService Keys
extern NSString *const kCLInboxDetailIdkey;
extern NSString *const kCLInboxDetailjobIDkey;
extern NSString *const kCLInboxDetailjobTitlekey;
extern NSString *const kCLInboxDetailjobCompanykey;
extern NSString *const kCLInboxDetailjobIconUrlkey;
extern NSString *const kCLInboxDetailQuestionnnairePresentkey;
extern NSString *const kCLInboxDetailQuestionnnaireSubmittedkey;
extern NSString *const kCLInboxDetailQuestionnnaireDueDatekey;
extern NSString *const kCLInboxDetailMsgIdkey;
extern NSString *const kCLInboxDetailMsgTimekey;
extern NSString *const kCLInboxDetailMsgTypekey;
extern NSString *const kCLInboxDetailMsgTextkey;
extern NSString *const kCLInboxDetailMsgSubjectkey;
extern NSString *const kCLInboxDetailQuestionnaireIdkey;
extern NSString *const kCLInboxDetailQuestionnaireQuestkey;
extern NSString *const kCLInboxDetailQuestionnaireAnskey;
extern NSString *const kCLInboxDetailQuestionnaireRating;

//Inbox Post reply url..
extern NSString *const kCLWebServiceInboxPostReplyURL;

//Questionnaire post url..
extern NSString *const kCLWebServiceQuestionnairePostReplyURL;


//Profile Summary url..
extern NSString *const kCLWebServiceProfileSummaryURL;
//Profile Summary WebService Keys
extern NSString *const kCLProfileSummaryFirstNamekey;
extern NSString *const kCLProfileSummaryLastNamekey;
extern NSString *const kCLProfileSummaryNickNamekey;
extern NSString *const kCLProfileSummaryAgekey;
extern NSString *const kCLProfileSummaryImageUrlkey;
extern NSString *const kCLProfileSummaryImagekey;
extern NSString *const kCLProfileSummaryAboutMekey;
extern NSString *const kCLProfileSummaryCareerkey;
extern NSString *const kCLProfileSummaryEducationkey;
extern NSString *const kCLProfileSummaryCapabilitieskey;
extern NSString *const kCLProfileSummaryPortfoliokey;
extern NSString *const kCLProfileSummaryReferenceskey;
extern NSString *const kCLProfileSummaryJobPreferencekey;
extern NSString *const kCLProfileSummaryGoalskey;
extern NSString *const kCLProfileSummaryHeadingkey;
extern NSString *const kCLProfileSummaryValuekey;

extern NSString *const kCLProfileDaykey;
extern NSString *const kCLProfileMonthkey;
extern NSString *const kCLProfileYearkey;

//Job Preferences url......
extern NSString *const kCLWebServiceJobPreferenceSummaryURL;
extern NSString *const kCLWebServiceContractConsiderationsSummaryURL;
extern NSString *const kCLWebServicePostContractConsiderationsURL;
extern NSString *const kCLWebServiceWorkConsiderationsSummaryURL;
extern NSString *const kCLWebServicePostWorkConsiderationsURL;
extern NSString *const kCLWebServicetargetJobsSummaryURL;
extern NSString *const kCLWebServicePreferredJobsListURL;
extern NSString *const kCLWebServiceSaveTargetJobsURL;
extern NSString *const kCLWebServiceGetRegionListURL;
extern NSString *const kCLWebServiceGetRegionListURLForTwentyField;
extern NSString *const kCLWebServiceGetSecondRegionListURLForTwentyField;
extern NSString *const kCLWebServiceGetSecondRegionListURL;
extern NSString *const kCLWebServiceGetRelocationSummeryURL;
extern NSString *const kCLWebServicePostRelocationURL;

//job preference webservice keys...
extern NSString *const kCLJobPreferenceIdkey;
extern NSString *const kCLJobPreferenceTargetJobsKey;
extern NSString *const kCLJobPreferenceContractConsiderationsKey;
extern NSString *const kCLJobPreferenceRelocConsiderationKey;
extern NSString *const kCLJobPreferenceWorkConsiderationKey;
extern NSString *const kCLJobPreferenceSummaryTargetJobsHeadingKey;
extern NSString *const kCLJobPreferenceSummaryTargetJobsValueKey;
extern NSString *const kCLJobPreferenceSummaryContractConsiderationTitleKey;
extern NSString *const kCLJobPreferenceSummaryContractConsiderationAvailabilityKey;
extern NSString *const kCLJobPreferenceSummaryWorkConsiderationHeadingKey;
extern NSString *const kCLJobPreferenceSummaryWorkconsiderationValueKey;
extern NSString *const kCLJobPreferenceSummaryWorkconsiderationWorkKey;
extern NSString *const kCLJobPreferencePreferredJobKey;
extern NSString *const kCLJobPreferenceFinctionsKey;
extern NSString *const kCLJobPreferenceIndustryKey;
extern NSString *const kCLJobPreferenceJoblevelKey;
extern NSString *const kCLJobPreferenceRemarksKey;
extern NSString *const kCLJobPreferenceJobScopeKey;
extern NSString *const kCLJobPreferenceJobFunctionKey;
extern NSString *const kCLJobPreferenceJobFunctionIdKey;
extern NSString *const kCLJobPreferenceJobFunctionCode;
extern NSString *const kCLJobPreferenceJobFunctionOtherFlag;

extern NSString *const kCLWorkconsiderationbusinessTravelkey;
extern NSString *const kCLWorkconsiderationworkHomekey;
extern NSString *const kCLWorkconsiderationkey;
extern NSString *const kCLWorkConsiderationWorkSchedulekey;
extern NSString *const kCLWorkConsiderationFlextimekey;
extern NSString *const kCLWorkConsiderationWorkWeekkey;
extern NSString *const kCLWorkConsiderationJobSharingkey;
extern NSString *const kCLWorkConsiderationWorkHomeOtherkey;
extern NSString *const kCLWorkConsiderationFriendlyWOrkPlacekey;
extern NSString *const kCLWorkConsiderationFriendlyWorkRemarkkey;

extern NSString *const kCLContractConsiderationkey;
extern NSString *const kCLContractConsiderationavailabilitykey;
extern NSString *const kCLContractConsiderationAnythingElsekey;
extern NSString *const kCLContractConsiderationPreferencekey;
extern NSString *const kCLContractConsiderationavailabilityNamekey;
extern NSString *const kCLContractConsiderationOtherkey;
extern NSString *const kCLContractConsiderationIdkey;
extern NSString *const kCLContractPreferenceemploymentTypekey;
extern NSString *const kCLContractPreferenceSalaryBasiskey;
extern NSString *const kCLContractPreferenceIDKey;
extern NSString *const kCLContractPreferenceemploymentContractkey;
extern NSString *const kCLContractPreferenceSalaryBasisID;
extern NSString *const kCLContractPreferenceEmploymentIdkey;
extern NSString *const kCLContractPreferenceCountryIdkey;
extern NSString *const kCLContractPreferenceCurrencykey;
extern NSString *const kCLContractPreferenceMinSalarykey;
extern NSString *const kCLContractPreferenceIncreaseSalarykey;
extern NSString *const kCLContractPreferenceNegotiablekey;
extern NSString *const kCLContractConsiderationCountryNameKey;
extern NSString *const kCLContractConsiderationCurrencyCode;
extern NSString *const kCLContractConsiderationCountryCode;
extern NSString *const kCLContractConsiderationEmpDetailIdKey;
extern NSString *const kCLContractConsiderationNameKey;
extern NSString *const kCLContractConsiderationEmpDetailNameKey;

extern NSString *const kCLTargetJobsPreferredJobKey;
extern NSString *const kCLTargetJobsPreferredJobIDKey;
extern NSString *const kCLTargetJobsJobScopeCodeKey;
extern NSString *const kCLTargetJobsJobScopeScopeIDKey;
extern NSString *const kCLTargetJobsJobScopeKey;
extern NSString *const kCLTargetJobsJobImpactGroupKey;
extern NSString *const kCLTargetJobsJobScopeGroupNameKey;
extern NSString *const kCLTargetJobsJobScopeCellKey;
extern NSString *const kCLTargetJobsJobScopeCountryCodeKey;
extern NSString *const kCLTargetJobsJobScopeScopeNameKey;
extern NSString *const kCLTargetJobsindustry;
extern NSString *const kCLTargetJobsNewindustry;
extern NSString *const kCLTargetJobsNewFnCategory;
extern NSString *const kCLTargetJobsMainindustry;
extern NSString *const kCLTargetJobsindustrySectCode;
extern NSString *const kCLTargetJobsindustrySectName;
extern NSString *const kCLTargetJobsindustryGroupNameKey;
extern NSString *const kCLTargetJobsIndustryKey;
extern NSString *const kCLTargetJobsIndustryOther;
extern NSString *const kCLTargetJobsIndustryGrpOther;
extern NSString *const kCLTargetJobsIndustryAll;
extern NSString *const kCLTargetJobsIndustryGroupCode;

extern NSString *const kCLRelocationLocationKey;
extern NSString *const kCLRelocationCheckedKey;
extern NSString *const kClRelocationBoolValueKey;
extern NSString *const kClRelocationRegionKey;
extern NSString *const kCLRElocationStateKEy;
extern NSString *const kCLRelocationMetroKEy;
extern NSString *const kCLRelocationMetroClusterKey;
extern NSString *const kCLRelocationTier2CitiesKey ;
extern NSString *const kCLRelocationTownVillages;
extern NSString *const kCLRelocationRegionOutside;
extern NSString *const kCLRelocationSubregionKey;
extern NSString *const kCLRelocationCountryKey;
extern NSString *const kCLRelocationLocationKeyOutside;
extern NSString *const kCLRelocationjobLocationCountryCode;
extern NSString *const kCLRelocationjobLocationCountryName;
extern NSString *const kCLRelocationjobLocationName;
extern NSString *const kCLRelocationCountryCode;
extern NSString *const kCLRelocationOptionsKey;
extern NSString *const kCLRelocationWithinCountry;
extern NSString *const kCLRelocationOutSideCountry;

//set primary image url..
extern NSString *const kCLWebServiceSetPrimaryImageURL;

//Career Listing url..
extern NSString *const kCLWebServiceCareerListingURL;

//Career Work History Post url..
extern NSString *const kCLWebServiceCareerPostURL;

//Work History document Delete url..
extern NSString *const kCLCareerDeleteDocumentURL;
//Work History document add url..
extern NSString *const kCLCareerAddDocumentURL;

//Career company name search url
extern NSString *const kCLWebServiceCompanyNameSearchURL;

//Career Listing WebService Keys
extern NSString *const kCLCareerSummarykey;
extern NSString *const kCLCareerHistorykey;

//Delete work history
extern NSString *const kCLWorkHistoryDeletekey;
//career keys started
//Career company search webservice keys
extern NSString *const kCLCompanySearchNamekey;
extern NSString *const kCLCompanySearchIdkey;
extern NSString *const kCLSearchCompanyDivisionskey;
extern NSString *const kCLSearchCompanyIndustryKey;
extern NSString *const kCLSearchCompanyDivisionIdkey;
extern NSString *const kCLSearchCompanyDivisionNamekey;
//Career History WebService Keys
extern NSString *const kCLCareerHistoryIdkey;
extern NSString *const kCLCareerHistoryJobTitlekey;
extern NSString *const kCLCareerHistoryCompanyNamekey;
extern NSString *const kCLCareerHistoryOtherCompanykey;
extern NSString *const kCLCareerHistoryOtherCompanyIdkey;
extern NSString *const kCLCareerHistoryOtherBusDivCompanyIdkey;
extern NSString *const kCLCareerHistoryCompanyDesckey;
extern NSString *const kCLCareerHistoryCompanyLockey;
extern NSString *const kCLCareerHistoryOtherCompanyLockey;
extern NSString *const kCLCareerHistoryOtherCompanyCountrykey;
extern NSString *const kCLCareerHistoryCompanyNameIdkey;
extern NSString *const kCLCareerHistoryDivisionkey;
extern NSString *const kCLCareerHistoryDivisionIdkey;
extern NSString *const kCLCareerHistoryBusinessDivisionkey;
extern NSString *const kCLCareerHistoryCompanyDivisionkey;
extern NSString *const kCLCareerHistoryCompanyDivisionskey;
extern NSString *const kCLCareerHistoryCareerDurationFromkey;
extern NSString *const kCLCareerHistoryCareerDurationTokey;
extern NSString *const kCLCareerHistoryCareerDurationCurrentkey;
extern NSString *const kCLCareerHistoryFunctionkey;
extern NSString *const kCLCareerHistoryFunctionIdkey;
extern NSString *const kCLCareerHistoryFunctionJobIdkey;
extern NSString *const kCLCareerHistoryFunctionOtherFalgkey;
extern NSString *const kCLCareerHistoryFunctionOtherTxtkey;

//Keys for allowance and incentives common
extern NSString *const kCLCareerHistoryAllowancekey;
extern NSString *const kCLCareerHistoryAllowanceIdkey;
extern NSString *const kCLCareerHistoryAllowanceLoadingskey;
extern NSString *const kCLCareerHistoryAllowanceFrequencykey;
extern NSString *const kCLCareerHistoryAllowanceGrossSalkey;
extern NSString *const kCLCareerHistoryAllowanceActualValkey;
extern NSString *const kCLCareerHistoryAllowanceCurrencykey;
extern NSString *const kCLCareerHistoryAllowanceOtherTxtkey;
extern NSString *const kCLCareerHistoryAllowanceCurrencyIdkey;
extern NSString *const kCLCareerHistoryIncentivekey;
extern NSString *const kCLCareerHistoryIncentiveBonuskey;
//common keys end

extern NSString *const kCLCareerHistoryLongIncentivekey;
extern NSString *const kCLCareerHistoryLongFrequencykey;
extern NSString *const kCLCareerHistoryLongGrossSalkey;
extern NSString *const kCLCareerHistoryLongActualValkey;
extern NSString *const kCLCareerHistoryLongCurrencykey;
extern NSString *const kCLCareerHistoryLongCurrencyPostkey;

extern NSString *const kCLCareerHistoryDepartmentkey;
extern NSString *const kCLCareerHistoryJobLevelkey;
extern NSString *const kCLCareerHistoryJobLevelNamekey;
extern NSString *const kCLCareerHistoryJobLevelCodekey;
extern NSString *const kCLCareerHistoryJobImpactkey;
extern NSString *const kCLCareerHistoryJobImpactIdkey;
extern NSString *const kCLCareerHistoryJobImpactjobScopeGroupName;
extern NSString *const kCLCareerHistoryJobImpactjobScope;
extern NSString *const kCLCareerHistoryJobImpactCodeKey;
extern NSString *const kCLCareerHistoryJobImpactNamekey;
extern NSString *const kCLCareerHistoryLocationkey;
extern NSString *const kCLCareerHistoryCountrykey;
extern NSString *const kCLCareerHistoryCurrencykey;
extern NSString *const kCLCareerHistoryBenefitskey;
extern NSString *const kCLCareerHistoryBenefitsItemkey;
extern NSString *const kCLCareerHistoryBenefitsOtherFlagkey;
extern NSString *const kCLCareerHistoryBenefitsOtherTextkey;
extern NSString *const kCLCareerHistoryJobAcntbiltskey;
extern NSString *const kCLCareerHistoryJobPerformancekey;
extern NSString *const kCLCareerHistoryPermanentDirectkey;
extern NSString *const kCLCareerHistoryPermanentInDirectkey;
extern NSString *const kCLCareerHistoryTempDirectkey;
extern NSString *const kCLCareerHistoryTempInDirectkey;
extern NSString *const kCLCareerHistoryBudgetResponsibilitykey;
extern NSString *const kCLCareerHistoryProjectskey;
extern NSString *const kCLCareerHistoryDocskey;
extern NSString *const kCLCareerHistoryExperiencesGainedkey;
extern NSString *const kCLCareerHistoryMajorAchievementskey;
extern NSString *const kCLCareerHistoryRemarkskey;
extern NSString *const kCLCareerHistoryKeyJobFactskey;
extern NSString *const kCLCareerHistorySalaryBasiskey;
extern NSString *const kCLCareerHistorySalaryCurrencykey;
extern NSString *const kCLCareerHistorySalarykey;
extern NSString *const kCLCareerHistoryTimeSpentkey;
extern NSString *const kCLCareerHistoryJobTypekey;
extern NSString *const kCLCareerHistoryJobTypeTxtkey;
extern NSString *const kCLCareerHistoryEmploymentTypeIdkey;
extern NSString *const kCLCareerHistoryEmploymentTypekey;
extern NSString *const kCLCareerHistoryEmploymentContractTypekey;
extern NSString *const kCLCareerHistoryReportTokey;
extern NSString *const kCLCareerHistoryReasonForMovekey;
extern NSString *const kCLCareerHistoryReasonForMoveIdkey;
extern NSString *const kCLCareerHistoryReasonForMoveOtherFlgkey ;
extern NSString *const kCLCareerHistoryReasonForMoveOtherTxtkey;
extern NSString *const kCLCareerHistoryReasonForMoveReasonkey;
extern NSString *const kCLCareerHistoryReasonForMoveReasonIdkey;
//career keys ended

//Qualification Listing url..
extern NSString *const kCLWebServiceQualificationListingURL;
//Qualification Delete url..
extern NSString *const kCLQlfitnDeletekey;
//Qualification document Delete url..
extern NSString *const kCLQlfitnDeleteDocumentURL;
//Qualification document Add url..
extern NSString *const kCLQlfitnUploadDocumentURL;
//Qualification Listing WebService Keys
extern NSString *const kCLQlfitnEducationkey;
extern NSString *const kCLQlfitnTrainingkey;
extern NSString *const kCLQlfitnCertificationkey;
extern NSString *const kCLQlfitnMembershipkey;
extern NSString *const kCLQlfitnLicensekey;
//Qualification Education WebService Keys
extern NSString *const kCLQlfitnEducationIdkey;
extern NSString *const kCLQlfitnEducationCoursekey;
extern NSString *const kCLQlfitnEducationSpecializationkey;
extern NSString *const kCLQlfitnEducationInstitutionkey;
extern NSString *const kCLQlfitnEducationLocationkey;
extern NSString *const kCLQlfitnEducationLocationCountrykey;
extern NSString *const kCLQlfitnEducationLocationCodekey;
extern NSString *const kCLQlfitnEducationFromDatekey;
extern NSString *const kCLQlfitnEducationToDatekey;
extern NSString *const kCLQlfitnEducationIsOngoingkey;
extern NSString *const kCLQlfitnEducationLevelkey;
extern NSString *const kCLQlfitnEducationRatingTypekey;
extern NSString *const kCLQlfitnEducationDescptionkey;
extern NSString *const kCLQlfitnEducationDocumentsUrlkey;
extern NSString *const kCLQlfitnEducationLevelIdkey;
extern NSString *const kCLQlfitnEducationLevelDesckey;
//Qualification Training WebService Keys
extern NSString *const kCLQlfitnTrainingIdkey;
extern NSString *const kCLQlfitnTrainingNamekey;
extern NSString *const kCLQlfitnTrainingInstitutionkey;
extern NSString *const kCLQlfitnTrainingLocationkey;
extern NSString *const kCLQlfitnTrainingLocationCountrykey;
extern NSString *const kCLQlfitnTrainingLocationCodekey;
extern NSString *const kCLQlfitnTrainingFromDatekey;
extern NSString *const kCLQlfitnTrainingNumDayskey;
extern NSString *const kCLQlfitnTrainingContentskey;
extern NSString *const kCLQlfitnTrainingTrainerkey;
extern NSString *const kCLQlfitnTrainingVendorkey;
extern NSString *const kCLQlfitnTrainingRelatedTokey;
extern NSString *const kCLQlfitnTrainingDocumentskey;
//Qualification Certification WebService Keys
extern NSString *const kCLQlfitnCertificationIdkey;
extern NSString *const kCLQlfitnCertificationTitlekey;
extern NSString *const kCLQlfitnCertificationInstitutionkey;
extern NSString *const kCLQlfitnCertificationLocationkey;
extern NSString *const kCLQlfitnCertificationLocationCountrykey;
extern NSString *const kCLQlfitnCertificationLocationCodekey;
extern NSString *const kCLQlfitnCertificationIssuedOnDatekey;
extern NSString *const kCLQlfitnCertificationProgresskey;
extern NSString *const kCLQlfitnCertificationValiditykey;
extern NSString *const kCLQlfitnCertificationFromDatekey;
extern NSString *const kCLQlfitnCertificationToDatekey;
extern NSString *const kCLQlfitnCertificationCompletionDatekey;
extern NSString *const kCLQlfitnCertificationContentskey;
extern NSString *const kCLQlfitnCertificationDocumentskey;
//Qualification Membership WebService Keys
extern NSString *const kCLQlfitnMembershipIdkey;
extern NSString *const kCLQlfitnMembershipTitlekey;
extern NSString *const kCLQlfitnMembershipClaskey;
extern NSString *const kCLQlfitnMembershipNumberkey;
extern NSString *const kCLQlfitnMembershipLocationkey;
extern NSString *const kCLQlfitnMembershipLocationCountrykey;
extern NSString *const kCLQlfitnMembershipLocationCodekey;
extern NSString *const kCLQlfitnMembershipIssuedOnDatekey;
extern NSString *const kCLQlfitnMembershipProgresskey;
extern NSString *const kCLQlfitnMembershipValiditykey;
extern NSString *const kCLQlfitnMembershipFromDatekey;
extern NSString *const kCLQlfitnMembershipToDatekey;
extern NSString *const kCLQlfitnMembershipCompletionDatekey;
extern NSString *const kCLQlfitnMembershipContentskey;
extern NSString *const kCLQlfitnMembershipDocumentskey;
//Qualification License WebService Keys
extern NSString *const kCLQlfitnLicenseIdkey;
extern NSString *const kCLQlfitnLicenseTitlekey;
extern NSString *const kCLQlfitnLicenseClaskey;
extern NSString *const kCLQlfitnLicenseNumberkey;
extern NSString *const kCLQlfitnLicenseLocationkey;
extern NSString *const kCLQlfitnLicenseLocationCountrykey;
extern NSString *const kCLQlfitnLicenseLocationCodekey;
extern NSString *const kCLQlfitnLicenseIssuedOnDatekey;
extern NSString *const kCLQlfitnLicenseProgresskey;
extern NSString *const kCLQlfitnLicenseValiditykey;
extern NSString *const kCLQlfitnLicenseFromDatekey;
extern NSString *const kCLQlfitnLicenseToDatekey;
extern NSString *const kCLQlfitnLicenseCompletionDatekey;
extern NSString *const kCLQlfitnLicenseContentskey;
extern NSString *const kCLQlfitnLicenseDocumentskey;
//Education-Save/Edit url..
NSString *const kCLWebServiceEducationSaveURL;

//About Me url..
extern NSString *const kCLWebServiceProfileAboutMeURL;
//AboutMe WebService Keys
extern NSString *const kCLProfileAboutMeInfokey;

extern NSString *const kCLProfileAboutMeInfoIdkey;
extern NSString *const kCLProfileAboutMeCountryKey;
extern NSString *const kCLProfileAboutMeFirstNamekey;
extern NSString *const kCLProfileAboutMeLastNamekey;
extern NSString *const kCLProfileAboutMeNickNamekey;
extern NSString *const kCLProfileAboutMePreviousNameArraykey;
extern NSString *const kCLProfileAboutMePreviousNameIdkey;
extern NSString *const kCLProfileAboutMePreviousNamekey;
extern NSString *const kCLProfileAboutMePreviousNameDatekey;
extern NSString *const kCLProfileAboutMeMiddleNamekey;
extern NSString *const kCLProfileAboutMeSkypeNamekey;
extern NSString *const kCLProfileAboutMeProfileImagekey;
extern NSString *const kCLProfileAboutMeHomeNumberkey;
extern NSString *const kCLProfileAboutMeMobileNumberkey;
extern NSString *const kCLProfileAboutMeTelephoneNumberArraykey;
extern NSString *const kCLProfileAboutMeTelephoneNumberIdkey;
extern NSString *const kCLProfileAboutMeTelephoneNumberkey;
extern NSString *const kCLProfileAboutMeTelephoneISDCodekey;
extern NSString *const kCLProfileAboutMeTelephoneAreaCodekey;
extern NSString *const kCLProfileAboutMeTelephoneIsPrimarykey;
extern NSString *const kCLProfileAboutMeTelephoneContactTypekey;
extern NSString *const kCLProfileAboutMeTelephoneContactTypeIdkey;
extern NSString *const kCLProfileAboutMeHomeTelephoneKey;
extern NSString *const kCLProfileAboutMeMobleTelephoneKey;
extern NSString *const kCLProfileAboutMeTelephoneContactTypeTextkey;

extern NSString *const kCLProfileAboutMeEmailkey;
extern NSString *const kCLProfileAboutMeAlternateEmailkey;
extern NSString *const kCLProfileAboutMeAgekey;

extern NSString *const kCLProfileAboutMeSalutationDictkey;
extern NSString *const kCLProfileAboutMeSalutationIdkey;
extern NSString *const kCLProfileAboutMeSalutationTitlekey;

extern NSString *const kCLProfileAboutMeGenderDictkey;
extern NSString *const kCLProfileAboutMeGenderIdkey;
extern NSString *const kCLProfileAboutMeGenderTitlekey;

extern NSString *const kCLProfileAboutMeNationalityArraykey;
extern NSString *const kCLProfileAboutMeNationalityCodekey;
extern NSString *const kCLProfileAboutMeNationalityNamekey;

extern NSString *const kCLProfileAboutMeCurrentLocationDictkey;
extern NSString *const kCLProfileAboutMeOtherAddressArraykey;
extern NSString *const kCLProfileAboutMeLocIdkey;
extern NSString *const kCLProfileAboutMeLocApartmentkey;
extern NSString *const kCLProfileAboutMeLocFloorkey;
extern NSString *const kCLProfileAboutMeLocHouseNumberkey;
extern NSString *const kCLProfileAboutMeLocIsCommAddresskey;
extern NSString *const kCLProfileAboutMeLocCodekey;
extern NSString *const kCLProfileAboutMeLocNamekey;
extern NSString *const kCLProfileAboutMeLocAddresskey;
extern NSString *const kCLProfileAboutMeLocPincodekey;

extern NSString *const kCLProfileAboutMePhotosArraykey;

extern NSString *const kCLProfileAboutMeDocumentsArraykey;

extern NSString *const kCLProfileAboutMeAchievementsArraykey;
extern NSString *const kCLProfileAboutMeAchievementIdkey;
extern NSString *const kCLProfileAboutMeAchievementTitlekey;
extern NSString *const kCLProfileAboutMeAchievementDescriptionkey;
extern NSString *const kCLProfileAboutMeAchievementDatekey;
extern NSString *const kCLProfileAboutMeAchievementFilesArraykey;

extern NSString *const kCLProfileAboutMeMediaArraykey;
extern NSString *const kCLProfileAboutMeMediaIdkey;
extern NSString *const kCLProfileAboutMeMediaWebsiteTitlekey;
extern NSString *const kCLProfileAboutMeMediaWebsiteUrlkey;
extern NSString *const kCLProfileAboutMeMediaWebsiteDescriptionkey;

extern NSString *const kCLProfileAboutMeInterestskey;
extern NSString *const kCLProfileAboutMeInterestMainIdkey;
extern NSString *const kCLProfileAboutMeInterestListArraykey;
extern NSString *const kCLProfileAboutMeInterestIdkey;
extern NSString *const kCLProfileAboutMeInterestTitlekey;
extern NSString *const kCLProfileAboutMeInterestDescriptionkey;

extern NSString *const kCLProfileFileIdkey;
extern NSString *const kCLProfileFileTitlekey;
extern NSString *const kCLProfileFilePreviewUrlkey;
extern NSString *const kCLProfileFilekey;

//About Me-Save info url..
extern NSString *const kCLWebServiceProfileAboutMeSaveInfoURL;

//About Me-Save achievement url..
extern NSString *const kCLWebServiceProfileAboutMeSaveAchievementURL;
//AboutMe-Save achievement WebService Keys
extern NSString *const kCLProfileAboutMeSaveAchievementIdkey;

//About Me-Delete achievement url..
extern NSString *const kCLWebServiceProfileAboutMeDeleteAchievementURL;
//AboutMe-Delete achievement WebService Keys
extern NSString *const kCLProfileAboutMeDeleteAchievementIdkey;

//About Me-Delete achievement document url..
extern NSString *const kCLWebServiceProfileAboutMeSaveAchievementDocURL;

//About Me-Delete achievement document url..
extern NSString *const kCLWebServiceProfileAboutMeDeleteAchievementDocURL;


//About Me-Save media url..
extern NSString *const kCLWebServiceProfileAboutMeSaveMediaURL;
//AboutMe-Save media WebService Keys
extern NSString *const kCLProfileAboutMeSaveMediaIdkey;

//About Me-Delete media url..
extern NSString *const kCLWebServiceProfileAboutMeDeleteMediaURL;
//AboutMe-Delete media WebService Keys
extern NSString *const kCLProfileAboutMeDeleteMediaIdkey;


//About Me-Save interest url..
extern NSString *const kCLWebServiceProfileAboutMeSaveInterestURL;
//AboutMe-Save Interest WebService Keys
extern NSString *const kCLProfileAboutMeSaveInterestIdkey;

//About Me-Delete interest url..
extern NSString *const kCLWebServiceProfileAboutMeDeleteInterestURL;
//AboutMe-Delete Interest WebService Keys
extern NSString *const kCLProfileAboutMeDeleteInterestIdkey;

//About Me-Get hobbies url..
extern NSString *const kCLWebServiceProfileAboutMeListHobbiesURL;
//AboutMe-Get hobbies WebService Keys
extern NSString *const kCLProfileAboutMeHobbiesIdkey;
extern NSString *const kCLProfileAboutMeHobbiesTextkey;

//Upload Non-Primary image url..
extern NSString *const kCLWebServiceProfileAboutMeUploadNonPrimaryImageURL;

//Upload Primary image url..
extern NSString *const kCLWebServiceProfileAboutMeUploadPrimaryImageURL;

//About Me-Delete document url..
extern NSString *const kCLWebServiceProfileAboutMeUploadDocumentURL;

//About Me-Delete photo url..
extern NSString *const kCLWebServiceProfileAboutMeDeletePhotoURL;

//About Me-Delete document url..
extern NSString *const kCLWebServiceProfileAboutMeDeleteDocumentURL;

//Reference-Listing url..
extern NSString *const kCLWebServiceProfileReferenceURL;
//Reference WebService Keys
extern NSString *const kCLProfileReferenceArraykey;
extern NSString *const kCLProfileReferenceIdkey;
extern NSString *const kCLProfileReferenceReferredBykey;
extern NSString *const kCLProfileReferenceJobTitlekey;
extern NSString *const kCLProfileReferenceCompanykey;
extern NSString *const kCLProfileReferenceDatekey;
extern NSString *const kCLProfileReferenceRecommendationkey;
extern NSString *const kCLProfileReferenceFilesArraykey;

//Reference-Delete url..
extern NSString *const kCLWebServiceProfileReferenceDeleteURL;

//Reference-Save/Edit url..
extern NSString *const kCLWebServiceProfileReferenceSaveURL;
//AboutMe-Save achievement WebService Keys
extern NSString *const kCLProfileReferenceSaveIdkey;

//Reference-Upload document url..
extern NSString *const kCLWebServiceProfileReferenceUploadDocumentURL;

//Reference-Delete document url..
extern NSString *const kCLWebServiceProfileReferenceDeleteDocumentURL;

//Performance Review..
extern NSString *const kCLProfilePerfReviewArraykey;
extern NSString *const kCLProfilePerfReviewIdkey;
extern NSString *const kCLProfilePerfReviewDatekey;
extern NSString *const kCLProfilePerfReviewDescriptionkey;
extern NSString *const kCLProfilePerfReviewCareerSelectedDictkey;
extern NSString *const kCLProfilePerfReviewCareerArraykey;
extern NSString *const kCLProfilePerfReviewCareerIdkey;
extern NSString *const kCLProfilePerfReviewCareerTitlekey;
extern NSString *const kCLProfilePerfReviewCareerFromDatekey;
extern NSString *const kCLProfilePerfReviewCareerToDatekey;
extern NSString *const kCLProfilePerfReviewFilesArraykey;

//Reference-Performance Review Save/Edit url..
extern NSString *const kCLWebServiceProfilePerfReviewSaveURL;
extern NSString *const kCLProfilePerfReviewSaveIdkey;

//Reference-Delete Performance url..
extern NSString *const kCLWebServiceProfileDeletePerfReviewURL;

//Reference-Performance Review Upload document url..
extern NSString *const kCLWebServiceProfilePerfReviewUploadDocumentURL;

//Reference- Performance Review Delete document url..
extern NSString *const kCLWebServiceProfilePerfReviewDeleteDocumentURL;


//Protfolio-Listing url..
extern NSString *const kCLWebServiceProfileProtfolioURL;
extern NSString *const kCLWebServiceProfileProtfolioNewURL;
//Protfolio WebService Keys
extern NSString *const kCLProfileProtfolioWorkAchievementArraykey;
extern NSString *const kCLProfileProtfolioWorkAchievementIdkey;
extern NSString *const kCLProfileProtfolioWorkAchievementAwardskey;
extern NSString *const kCLProfileProtfolioWorkAchievementDatekey;
extern NSString *const kCLProfileProtfolioWorkAchievementDescriptionkey;
extern NSString *const kCLProfileProtfolioWorkAchievementRelatedToSelectedDictkey;
extern NSString *const kCLProfileProtfolioWorkAchievementRelatedToArraykey;
extern NSString *const kCLProfileProtfolioWorkAchievementRelatedToIdkey;
extern NSString *const kCLProfileProtfolioWorkAchievementRelatedToTitlekey;
extern NSString *const kCLProfileProtfolioWorkAchievementFilesArraykey;

extern NSString *const kCLProfileProtfolioAssessmentArraykey;
extern NSString *const kCLProfileProtfolioAssessmentIdkey;
extern NSString *const kCLProfileProtfolioAssessmentTitlekey;
extern NSString *const kCLProfileProtfolioAssessmentDatekey;
extern NSString *const kCLProfileProtfolioAssessmentScorekey;
extern NSString *const kCLProfileProtfolioAssessmentURLkey;
extern NSString *const kCLProfileProtfolioAssessmentDescriptionkey;
extern NSString *const kCLProfileProtfolioAssessmentFilesArraykey;

//Protfolio-achievement Save/Edit url..
extern NSString *const kCLWebServiceProfileWorkAchievementSaveURL;
//AboutMe-Save achievement WebService Keys
extern NSString *const kCLProfileWorkAchievementSaveIdkey;

//Protfolio-assessment Save/Edit url..
extern NSString *const kCLWebServiceProfileAssessmentSaveURL;
//AboutMe-Save achievement WebService Keys
extern NSString *const kCLProfileAssessmentSaveIdkey;

//Protfolio-Delete achievement url..
extern NSString *const kCLWebServiceProfileProtfolioDeleteAchievementURL;

//Protfolio-Delete assessment url..
extern NSString *const kCLWebServiceProfileProtfolioDeleteAssessmentURL;

//Portfolio-WorkAchievement Upload document url..
extern NSString *const kCLWebServiceProfileWorkAchievementUploadDocumentURL;

//Portfolio- WorkAchievement Delete document url..
extern NSString *const kCLWebServiceProfileWorkAchievementDeleteDocumentURL;

//Portfolio-Assessment Upload document url..
extern NSString *const kCLWebServiceProfileAssessmentUploadDocumentURL;

//Portfolio- Assessment Delete document url..
extern NSString *const kCLWebServiceProfileAssessmentDeleteDocumentURL;

//Portfolio changes..
extern NSString *const kCLProfileProtfolioProjectArraykey;
extern NSString *const kCLProfileProtfolioProjectIdkey;
extern NSString *const kCLProfileProtfolioProjectTitlekey;
extern NSString *const kCLProfileProtfolioProjectDatekey;
extern NSString *const kCLProfileProtfolioProjectDescriptionkey;
extern NSString *const kCLProfileProtfolioProjectCareerSelectedDictkey;
extern NSString *const kCLProfileProtfolioProjectCareerArraykey;
extern NSString *const kCLProfileProtfolioProjectCareerIdkey;
extern NSString *const kCLProfileProtfolioProjectCareerTitlekey;
extern NSString *const kCLProfileProtfolioProjectCareerFromDatekey;
extern NSString *const kCLProfileProtfolioProjectCareerToDatekey;
extern NSString *const kCLProfileProtfolioProjectFilesArraykey;

//Protfolio-achievement Save/Edit url..
extern NSString *const kCLWebServiceProfileProjectSaveURL;

//Protfolio-Delete achievement url..
extern NSString *const kCLWebServiceProfileProtfolioDeleteProjectURL;

extern NSString *const kCLWebServiceProfileProtfolioDeleteEduURL;

//Portfolio-project Upload document url..
extern NSString *const kCLWebServiceProfileProjectUploadDocumentURL;

extern NSString *const kCLWebServiceProfileEduUploadDocumentURL;

extern NSString *const kCLWebServiceProfileProjectDeleteDocumentURL;

extern NSString *const kCLWebServiceProfileEDuDeleteDocumentURL;

//Portfolio- project Delete document url..
extern NSString *const kCLWebServiceProfileProjectDeleteDocumentURL;

extern NSString *const kCLProfileProtfolioItemArraykey;
extern NSString *const kCLProfileProtfolioItemIdkey;
extern NSString *const kCLProfileProtfolioItemTitlekey;
extern NSString *const kCLProfileProtfolioItemFilesArraykey;
extern NSString *const kCLProfileProtfolioItemRemarksKey;

//Protfolio-item Save/Edit url..
extern NSString *const kCLWebServiceProfileItemSaveURL;
extern NSString *const kCLProfileItemSaveIdkey;

//Protfolio-Delete item url..
extern NSString *const kCLWebServiceProfileProtfolioDeleteItemURL;

//Portfolio-item Upload document url..
extern NSString *const kCLWebServiceProfileItemUploadDocumentURL;

//Portfolio- item Delete document url..
extern NSString *const kCLWebServiceProfileItemDeleteDocumentURL;

#pragma mark Typedef's

//Side Menu selection index..
typedef enum {
    CLHomeControllerIndex = 30,
    CLProfileControllerIndex = 0,
    CLDocumentsControllerIndex = 1,
    CLInboxControllerIndex = 85,
    CLKnowledgeControllerIndex = 2,
    CLJobsControllerIndex = 94,
    CLCalendarControllerIndex = 96,
    ClJobPreferencesControllerIndex = 25,
    CLSettingsControllerIndex = 97,
    CLLogoutControllerIndex = 3,
    CLMyCareerLineControllerIndex = 10,
    CLTrafficLightControllerIndex = 99
} CLSideMenuViewControllerIndex;


//Traffic light status indicator...
typedef enum {
	CLTrafficLightRedColor = 0,
	CLTrafficLightAmberColor= 1,
    CLTrafficLightGreenColor = 2
} CLTrafficLightStatus;


//Push notifs key type..
typedef enum {
	CLPushNotifKeyTypeJobAlert = 1,
    CLPushNotifKeyTypeInboxAlert = 2
} CLPushNotificationKeyType;


#pragma mark UserDefaults Keys

extern NSString *const kCLUserDefaultUserDetailsDictKey;

//ProfileDetails keys..
extern NSString *const kCLUserDefaultsProfileCountryKey ;
extern NSString *const kCLUserDefaultsProfileNationalityKey;        //[(Dict),(Dict),(Dict),..]
extern NSString *const kCLUserDefaultsProfileFirstName;
extern NSString *const kCLUserDefaultsProfileLastName;
extern NSString *const kCLUserDefaultsProfilePreferedName;
extern NSString *const kCLUserDefaultsProfileEmail;
extern NSString *const kCLUserDefaultsProfileBirthDate;             //(Date)
extern NSString *const kCLUserDefaultsProfileEducation;             //(String)
extern NSString *const kCLUserDefaultsProfileEducationLocation;

extern NSString *const kCLUserDefaultsProfileEmploymentStatusKey;               //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentPreviousStatusKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentTypeKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentContractTypeKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentCountryKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentIsCompanyFound;      //Bool
extern NSString *const kCLUserDefaultsProfileEmploymentCompanyNameKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentBusinessDivKey;
extern NSString *const kCLUserDefaultsPrefileEmploymentIndustryKey;
//(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentCompanyLocKey;       //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentCompanyDescKey;             //(string)
extern NSString *const kCLUserDefaultsProfileEmploymentJobTitleKey;             //(string)
extern NSString *const kCLUserDefaultsProfileEmploymentFunctionKey;             //(Array)
extern NSString *const kCLUserDefaultsProfileEmploymentJobLevelKey;             //(Dict)
extern NSString *const kCLUserDefaultsProfileEmploymentJobScopeKey;             //(Dict)

extern NSString *const kCLUserDefaultsProfileLocationHomeLoc;                   //(Dict)
extern NSString *const kCLUserDefaultsProfileLocationRelocOption;               //(DIct)
extern NSString *const kCLUserDefaultsProfileLocationRelocSameLoc;                   //[(Dict),(Dict),(Dict),..]
extern NSString *const kCLUserDefaultsProfileLocationRelocOtherCountry;              //[(Dict),(Dict),(Dict),..]

extern NSString *const kCLUserDefaultsProfileGenderKey;             //(Dict)
extern NSString *const kCLUserDefaultsProfileSalutationKey;         //(Dict)

#pragma mark NSNotification Keys

extern NSString *const kCLNotifCenterJobsApplyCellHeightChange;
extern NSString *const kCLNotifCenterQuestionnaireCellHeightChange;
extern NSString *const kCLNotifCenterTrafficLightChanged;
extern NSString *const kCLNotifCenterProfileImageChanged;

#pragma mark Macros

//20 fields  macros..
//Nationality keys..
#define knationalityDictCode @"nationalityCode"
#define knationalityDictName @"nationalityName"

//Education keys..
#define keducationDictCode @"educationCode"
#define keducationDictName @"educationName"

//job level keys..
#define kjobLevelGroupDictCode @"jobLevelGroupCode"
#define kjobLevelGroupDictName @"jobLevelGroupName"
#define jobLevelDetailDictCode @"levelCode"
#define jobLevelDetailDictName @"jobLevel"
#define jobLevelDetailDictDesc @"jobLevelDetailDesc"
#define jobLevelDetailCode @"jobLevelDetailCode"

//job function keys..
#define kjobFunctionCategoryCode @"jobFunctionGroupCode"
#define kjobFunctionCategoryName @"jobFunctionGroupName"
#define kjobFunctionId @"jobFunctionId"
#define kjobFunctionName @"function"
#define kjobFunctionCode @"jobFunctionCode"
#define kjobFunctionOtherFlag @"jobFunctionOtherFlag"
#define kjobFunctionOtherText @"jobFunctionOtherText"

#define kcareerJobFunctionId @"id"
  
//employment status key..
#define kemploymentStatusTitleKey @"title"
#define kemploymentStatusIdKey @"id"

//employment type key..
#define kemploymentTypeNameKey @"typeName"
#define kemploymentTypeIdKey @"typeId"
    
//employment contract type key..
#define kemploymentContractTypeNameKey @"contracttypeName"
#define kemploymentContractTypeIdKey @"contracttypeId"

//employment job scope key.. 
#define kemploymentJobScopeNameKey @"scopeName"    
#define kemploymentJobScopeIdKey @"scopeId"


#define kJobPreferenceJobScopeNameKey @"jobScope"
#define kJobPreferenceJobScopeIdKey @"code"

//employment Business DIvision key..
//#define kemploymentBusinessDivisionNameKey @"companyDivisions"
//#define kemploymentBusinessDivisionIdKey @"id"

//employment Company key..
//#define kemploymentCompanyNameKey @"division"
//#define kemploymentCompanyIdKey @"id"

//job industry keys..
#define kIndSectDictName @"industrySectName"
#define kIndSectDictCode @"industrySectCode"
#define kIndOtherFlag @"industryOther"
#define kIndGrpOtherFlag @"industryGrpOther"
//#define kIndSectImageDictname @"kIndSectImageDictname"
//#define kIndustryMainArrayCode @"kIndustryMainArrayCode"
#define kIndustryGrp    @"IndGrp"
#define kIndustryDictName @"industry"
#define kIndustryGrpDictCode @"industryGroupCode"
#define kIndustryGrpDictName @"industryGroupName"
#define kIndustryDictCode @"industryCode"
//#define kIndustryDictDesc @"industryDesc"

//job location keys..
#define kLocationCode @"jobLocationCode"
#define kLocationName @"jobLocationName"
#define kLocationCountryCode @"jobLocationCountryCode"
#define kLocationCountryName @"jobLocationCountryName"
#define kLocationAdminArea @"jobLocationAdminArea"

//salutation keys
#define kGenderOptionId @"genderId"
#define kGenderOptionTitle @"genderTitle"
#define kSalutationOptionId @"salutationId"
#define kSalutationOptionTitle @"salutationTitle"

//isdCode keys
#define kisdCountryCode @"cyCode"
#define kisdCode @"isdcode"

//Reason for career move keys
#define kreasonForMoveDictCode @"id"
#define kreasonForMoveDictId @"reasonId"
#define kreasonForMoveDictName @"reason"
#define kreasonOtherFlag @"otherFlag"
#define kreasonOtherText @"otherText"

//Reported to empContractType Keys
#define kempContractId @"id"
#define kempContractName @"name"

#define kempTypeId @"id"
#define kempTypeName @"name"

#define kempTypeDetailId @"empDetailId"
#define kempTypeGroupId @"empGroupId"
#define kempTypeDetailName @"empDetailName"

//JobPreference
#define kjobPreferenceCountryCode @"countryCode"
#define kjobPreferenceCountryName @"countryName"
#define kjobPreferenceCurrencyCode @"currencyCode"

//Benefits
#define kId @"id"
#define kBenefitsId @"benefit_id"
#define kBenefitsName @"benefit"
#define kBenefitsOtherFlag @"otherFlag"
#define kBenefitsOtherTxt @"otherText"

//Frequency
#define kFrequencyId @"id"
#define kFrequencyName @"frequency"
#define kFrequencyOtherFlag @"otherText"
//Allowances and loading
#define kAllowanceAndLoadingId @"id"
#define kAllowanceAndLoadingName @"allowanceandloadings"
#define kAllowanceAndLoadingOtherFlag @"otherText"

//Allowances and loading
#define kIncentiveBonusId @"id"
#define kIncentiveBonusName @"incentiveBonus"
#define kIncentiveBonusOtherFlag @"otherText"

#define kNetworkNotReachableErr @"Server Error. Please try again later."

#define HELVETICA_NEUE_REGULAR_FONT_WITH_SIZE(fontsize)     [UIFont fontWithName:@"HelveticaNeue" size:(float)fontsize]
#define HELVETICA_NEUE_BOLD_FONT_WITH_SIZE(fontsize)     [UIFont fontWithName:@"HelveticaNeue-Bold" size:(float)fontsize]

#define GOOGLE_ANALATICS_DISPACH_INTERVAL (120)
#define GOOGLE_ANALATICS_TRACKING_ID @"UA-55850461-3"

#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )

#define VERSION_NUMBER  @"Version 2.0"

