//
//  CLBnefitsViewController.h
//  CareerLine
//
//  Created by RENJITH on 18/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLBnefitsViewController;

@protocol CLBenefitDlegate <NSObject>

@optional
- (void)benefitsController:(CLBnefitsViewController *)controller didAddBenefits:(NSMutableArray *)benefitsArray;

@end
@interface CLBnefitsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,weak) id <CLBenefitDlegate> delegate;
@property(nonatomic, retain) NSMutableArray *alreadySelectedBenefits;
@end
