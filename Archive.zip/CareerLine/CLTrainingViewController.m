//
//  CLTrainingViewController.m
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTrainingViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLUserObject.h"
#import "CLDocumentViewController.h"
#import "CLQualificationObject.h"

#define kAddTrainingDocType @"TR"

@interface CLTrainingViewController ()
typedef enum {
    CLTrainingNameIndex = 0,
    CLTrainingInstitutionIndex= 1,
    CLTrainIngCountryIndex = 2,
    CLTrainingLocationIndex = 3,
    CLTrainingStartDateIndex = 4,
    CLTrainingNoOfDaysIndex = 5,
    CLTrainingContentsIndex = 6,
    CLTrainingTrainerIndex = 7,
    CLTrainingVendorIndex = 8,
    CLTrainingDocsIndex = 9
} CLTrainingTableSectionIndex;

@property(strong,nonatomic)NSString *nameText;
@property(strong,nonatomic)NSString *institutionText;
@property(strong,nonatomic)NSDate *startDate;
@property(strong,nonatomic)NSString *numberOfDaysText;
@property(strong,nonatomic)NSString *locationText;
@property(strong,nonatomic)NSString *contentsText;
@property(strong,nonatomic)NSString *trainerText;
@property(strong,nonatomic)NSString *vendorText;
@property(nonatomic,assign) BOOL forCountry;


@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbarWithoutCancel;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property(strong,nonatomic)NSMutableDictionary *selectedCurrentLocation;
@property(nonatomic,retain)NSMutableDictionary *selectedCountry;
@end

@implementation CLTrainingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Training", @"training detail heading");
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Training"];
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"nameTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"institutionTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"startDateTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"numberOfDaysTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"contentsTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"trainerTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"vendorTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentLocationCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentCountryCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.toolbarWithoutCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    [self setRightNavigationButton];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        
        NSDate *currDate = [NSDate date];
        
        switch ([newDate compare:currDate]){
            case NSOrderedAscending:
                [datePickr setDate:newDate];
                
                break;
            case NSOrderedSame:
            case NSOrderedDescending:
                [datePickr setDate:currDate];
                break;
        }
        
        //[datePickr setDate:newDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    if (self.isEditMode) {
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:self.trainingObj.location.countryName forKey:@"country"];
        [self.selectedCountry setObject:self.trainingObj.location.countryCode forKey:@"countryCode"];
        self.selectedCurrentLocation = [[NSMutableDictionary alloc]init];
        [self.selectedCurrentLocation setObject:self.trainingObj.location.locationCode forKey:@"jobLocationCode"];
        [self.selectedCurrentLocation setObject:self.trainingObj.location.countryName forKey:@"jobLocationCountryName"];
        [self.selectedCurrentLocation setObject:self.trainingObj.location.adminArea forKey:@"jobLocationAdminArea"];
        [self.selectedCurrentLocation setObject:self.trainingObj.location.countryCode  forKey:@"jobLocationCountryCode"];
        [self.selectedCurrentLocation setObject:self.trainingObj.location.locName forKey:@"jobLocationName"];

        self.nameText = self.trainingObj.name;
        self.institutionText = self.trainingObj.institution;
        self.startDate= self.trainingObj.fromDate;
        self.numberOfDaysText= self.trainingObj.numberOfDays;
        self.locationText= self.trainingObj.location.locationName;
        self.contentsText= self.trainingObj.contents;
        self.trainerText= self.trainingObj.trainer;
        self.vendorText= self.trainingObj.vendor;
        
    }else{
        self.selectedCountry =[[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"country"]  forKey:@"country"];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:@"countryCode"];
        self.nameText = @"";
        self.institutionText = @"";
        self.startDate= nil;
        self.numberOfDaysText= @"";
        self.locationText= @"";
        self.contentsText= @"";
        self.trainerText= @"";
        self.vendorText= @"";
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Membership modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Membership modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    
    if (datePicker.tag == CLTrainingStartDateIndex) {
        self.startDate=date;
        
        CLSimpleTextCell *startDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0  inSection:CLTrainingStartDateIndex]];
        [startDateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
    }
}
- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if (cell.cellIndexPath.section==CLTrainingStartDateIndex) {
        if (self.startDate==nil || !([self.startDate compare:self.datePicker.date] == NSOrderedSame)) {
            self.startDate=self.datePicker.date;
            [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)bttActionCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)toolbarWithoutCancelAction:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark HTProgressHUD delegates
- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(qualificationTraining:didAddTraining:)]){
                [self.delegate qualificationTraining:self didAddTraining:self.trainingObj];
            }
            
        }];
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self savetrainingForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self savetrainingForEdit:NO];
    }
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Training Name validation..
    if ([self.nameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Name of Training Program.", @"Error Message for null Name of Training Program field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.nameText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Name of Training Program length.", @"Error Message for length of Name of Training Program field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Company validation..
    if ([self.institutionText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Institution.", @"Error Message for null Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.institutionText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Institution length.", @"Error Message for length of Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Location validation
//    if ([self.selectedCurrentLocation count] ==0 && [self.locationText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    
    //Date validation..
    if (self.startDate==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Start Date.", @"Error Message for null start date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //number of days validation..
    if (self.numberOfDaysText != nil && [self.numberOfDaysText length]>4){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Number of Days length.", @"Error Message for length Number of Days field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    return isValid;
}

-(void)savetrainingForEdit:(BOOL)isEditMode{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    CLTrainingObject *newTrainingObj=[[CLTrainingObject alloc] init];
    if (isEditMode) {
        newTrainingObj.trainingId = self.trainingObj.trainingId;
        
    }else{
        newTrainingObj.trainingId = nil;
    }
    newTrainingObj.name = self.nameText;
    newTrainingObj.institution = self.institutionText;
    
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]init];
    
//    if (self.selectedCurrentLocation == nil) {
//        if (self.trainingObj.location.locationName !=nil) {
//            [locDict setObject:self.trainingObj.location.locationName forKey:kCLProfileAboutMeLocNamekey];
//            [locDict setObject:self.trainingObj.location.locationCode forKey:kCLProfileAboutMeLocCodekey];
//            [locDict setObject:self.trainingObj.location.countryCode forKey:kCLQlfitnTrainingLocationCountrykey];
//        }
//        else if (self.selectedCountry!=nil){
//            [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"]  forKey:kCLQlfitnTrainingLocationCountrykey];
//        }
//    }else{
    if (self.selectedCurrentLocation != nil) {
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCountryCode] forKey:kCLQlfitnTrainingLocationCountrykey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCode] forKey:kCLProfileAboutMeLocCodekey];
        [locDict setObject:[NSString stringWithFormat:@"%@/%@,%@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]] forKey:kCLProfileAboutMeLocNamekey];
    }
    else{
        [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnTrainingLocationCountrykey];
//        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCode] forKey:kCLProfileAboutMeLocCodekey];
//        [locDict setObject:[NSString stringWithFormat:@"%@/%@,%@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]] forKey:kCLProfileAboutMeLocNamekey];
    }
//    }
    newTrainingObj.location = [[CLLocationObject alloc]initWithDictionary:locDict];
    newTrainingObj.fromDate = self.startDate;
    newTrainingObj.numberOfDays = self.numberOfDaysText;
    newTrainingObj.trainer = self.trainerText;
    newTrainingObj.vendor = self.vendorText;
    newTrainingObj.contents = self.contentsText;
    
    [CLTrainingObject saveTraining:newTrainingObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *traningId) {
//        if (isEditMode) {
//            self.trainingObj.name = newTrainingObj.name;
//            self.trainingObj.institution = newTrainingObj.institution;
//            self.trainingObj.fromDate = newTrainingObj.fromDate;
//            self.trainingObj.numberOfDays = newTrainingObj.numberOfDays;
//            self.trainingObj.vendor = newTrainingObj.vendor;
//            self.trainingObj.trainer = newTrainingObj.trainer;
//            self.trainingObj.location = newTrainingObj.location;
//            self.trainingObj.contents = newTrainingObj.contents;
//            
//        }else{
//            newTrainingObj.trainingId = traningId;
//            self.trainingObj =newTrainingObj;
//        }
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save training. Please try again later.", @"Error message when training cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 10;
    }
    return 9;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLTrainingNameIndex:{
            CLSimpleTextCell *trainingNameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"nameTextCellIdentifier"];
            trainingNameCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [trainingNameCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [trainingNameCell setPlaceHoldrText:NSLocalizedString(@"Name of Training Program", @"Placeholder for Name of Training Program")];
            [trainingNameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [trainingNameCell setCellText:self.nameText];
            [trainingNameCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [trainingNameCell setCellIndexPath:indexPath];
            trainingNameCell.delegate=self;
            return trainingNameCell;
            break;
        }
        case CLTrainingInstitutionIndex:{
            CLSimpleTextCell *institutionCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"institutionTextCellIdentifier"];
            institutionCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [institutionCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [institutionCell setPlaceHoldrText:NSLocalizedString(@"Institution", @"Placeholder for Institution field")];
            [institutionCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [institutionCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [institutionCell setCellText:self.institutionText];
            [institutionCell setCellIndexPath:indexPath];
            institutionCell.delegate=self;
            return institutionCell;
            break;
        }
        case CLTrainingStartDateIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"startDateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.datePicker];
            [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
            self.datePicker.tag = indexPath.section;
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Start Date", @"Placeholder for date field")];
            [dateCell setCellText:[CLCommon getStringForDate:self.startDate andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
            break;
        }
        case CLTrainingLocationIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentLocationCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Location (City/Town/Village, Country)", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCurrentLocation) {
                
                if ([[self.selectedCurrentLocation objectForKey:@"jobLocationCode"]isEqualToString:@""]) {
                    [currLoccell setCellText:@""];
                }
                else{
                    [currLoccell setCellCloseBtnOption:NO];
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]]];
                }
            }
            else{
                [currLoccell setCellText:@""];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
            break;
        }
            
        case CLTrainIngCountryIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentCountryCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Country", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCountry) {
                [currLoccell setCellText:[self.selectedCountry objectForKey:@"country"]];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;

        }
        case CLTrainingNoOfDaysIndex:{
            CLSimpleTextCell *contentsCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"contentsTextCellIdentifier"];
            contentsCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [contentsCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [contentsCell setPlaceHoldrText:NSLocalizedString(@"Number of Days", @"Placeholder for Number of Days")];
            [contentsCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [contentsCell setKeyboardType:UIKeyboardTypeNumberPad];
            [contentsCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [contentsCell setCellText:self.numberOfDaysText];
            [contentsCell setCellIndexPath:indexPath];
            contentsCell.delegate=self;
            return contentsCell;
            break;
        }
        case CLTrainingContentsIndex:{
            CLSimpleTextCell *contentsCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"contentsTextCellIdentifier"];
            contentsCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [contentsCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [contentsCell setPlaceHoldrText:NSLocalizedString(@"Contents", @"Placeholder for Contents")];
            [contentsCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [contentsCell setCellText:self.contentsText];
            [contentsCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [contentsCell setCellIndexPath:indexPath];
            contentsCell.delegate=self;
            return contentsCell;
            break;
        }
        case CLTrainingTrainerIndex:{
            CLSimpleTextCell *trainerCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"trainerTextCellIdentifier"];
            trainerCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [trainerCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [trainerCell setPlaceHoldrText:NSLocalizedString(@"Trainer", @"Placeholder for Trainer")];
            [trainerCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [trainerCell setCellText:self.trainerText];
            [trainerCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [trainerCell setCellIndexPath:indexPath];
            trainerCell.delegate=self;
            return trainerCell;
            break;
        }
        case CLTrainingVendorIndex:{
            CLSimpleTextCell *vendorCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"vendorTextCellIdentifier"];
            vendorCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [vendorCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [vendorCell setPlaceHoldrText:NSLocalizedString(@"Training Provider", @"Placeholder for Training Provider")];
            [vendorCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [vendorCell setCellText:self.vendorText];
            [vendorCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [vendorCell setCellIndexPath:indexPath];
            vendorCell.delegate=self;
            return vendorCell;
            break;
        }
        case CLTrainingDocsIndex:{
            CLProfilePhotoListingGridCell *docsCell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            docsCell.selectionStyle=UITableViewCellSelectionStyleNone;
            docsCell.indexPath=indexPath;
            docsCell.delegate=self;
            docsCell.photosLimit=-1;
            docsCell.placeHolderImageName=@"documentPlaceHolder";
            docsCell.photoUrls=self.trainingObj.documentsUrl;
            [docsCell updateCollectionViewContents];
            return docsCell;
            break;
        }
        default:{
            return nil;
            break;
        }
    }
    
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLTrainingNameIndex:
            return NSLocalizedString(@"Name of Training Program", @"Placeholder for Training Program");
            break;
        case CLTrainIngCountryIndex:
            return NSLocalizedString(@"Country", @"section header");
            break;
        case CLTrainingInstitutionIndex:
            return NSLocalizedString(@"Institution", @"Placeholder for Institution");
            break;
        case CLTrainingStartDateIndex:
            return NSLocalizedString(@"Start Date", @"Placeholder for Start date field");
            break;
        case CLTrainingLocationIndex:
            return NSLocalizedString(@"Location(City/Town/Village,country)", @"Placeholder for Location(City/Town/Village,country)");
            break;
        case CLTrainingNoOfDaysIndex:
            return NSLocalizedString(@"Number of Days", @"Placeholder for number of days field");
            break;
        case CLTrainingContentsIndex:
            return NSLocalizedString(@"Contents", @"Placeholder for contents field");
            break;
        case CLTrainingTrainerIndex:
            return NSLocalizedString(@"Trainer", @"Placeholder for Trainer field");
            break;
        case CLTrainingVendorIndex:
            return NSLocalizedString(@"Training Provider", @"Placeholder for Training Provider field");
            break;
        case CLTrainingDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.section==CLTrainingDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.trainingObj.documentsUrl count]+1)/2));
    }
    else{
        return 44;
    }
    
}
#pragma mark CLTappableCellDelegate Methods


- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == CLTrainingLocationIndex) {
        self.selectedCurrentLocation = nil;
        self.trainingObj.location = nil;
        
    }
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLTrainingLocationIndex) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryBasedLocation;
        selectLocation.delegate=self;
        selectLocation.countryCodeforListing=[self.selectedCountry objectForKey:@"countryCode"];
        self.forCountry=NO;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if (indexPath.section == CLTrainIngCountryIndex){
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        self.forCountry=YES;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
}

#pragma mark CLSelectLocationDelegate
- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        [self.selectedCountry removeAllObjects];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        self.selectedCurrentLocation =nil;
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLTrainIngCountryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLTrainingLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{

    self.selectedCurrentLocation=locDict;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLTrainingLocationIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (indexPath.section) {
        case CLTrainingNameIndex:
            self.nameText = @"";
            break;
        case CLTrainingInstitutionIndex:
            self.institutionText = @"";
            break;
        case CLTrainingStartDateIndex:
            self.startDate = nil;
            break;
        case CLTrainingNoOfDaysIndex:
            self.numberOfDaysText = @"";
            break;
        case CLTrainingContentsIndex:
            self.contentsText = @"";
            break;
        case CLTrainingTrainerIndex:
            self.trainerText = @"";
            break;
        case CLTrainingVendorIndex:
            self.vendorText = @"";
            break;
            
        default:
            break;
    }
    
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLTrainingNameIndex:{
            self.nameText=text;
            break;
        }
        case CLTrainingInstitutionIndex:{
            self.institutionText=text;
            break;
        }
        case CLTrainingNoOfDaysIndex:{
            self.numberOfDaysText=text;
            break;
        }
        case CLTrainingTrainerIndex:{
            self.trainerText=text;
            break;
        }
        case CLTrainingVendorIndex:{
            self.vendorText=text;
            break;
        }
        case CLTrainingContentsIndex:{
            self.contentsText=text;
            break;
        }
        default:
            break;
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods
- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate
-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*) caption{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject addDocument:image forQualification:self.trainingObj.trainingId andUser:[CLUserObject currentUser].userID withDocType:kAddTrainingDocType andCaption:caption success:^(CLFileObject *fileObj) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.trainingObj.documentsUrl) {
            self.trainingObj.documentsUrl=[[NSMutableArray alloc] init];
        }
        [self.trainingObj.documentsUrl addObject:fileObj];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

#pragma mark UIActionsheet Delegates
-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLFileObject *documentObj=[self.trainingObj.documentsUrl objectAtIndex:indexPath.row];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting education doc");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject deleteQDocument:documentObj.fileId success:^{
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.trainingObj.documentsUrl removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}


@end
