//
//  CLCertificationObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCertificationObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

static NSOperationQueue *saveCertificationRequest;
@implementation CLCertificationObject


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.certificationId = [dictionary objectForKeyNotNull:kCLQlfitnCertificationIdkey];
    self.title = [dictionary objectForKeyNotNull:kCLQlfitnCertificationTitlekey];
    self.institution = [dictionary objectForKeyNotNull:kCLQlfitnCertificationInstitutionkey];
    self.location = [[CLLocationObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLQlfitnCertificationLocationkey]];
    self.isProgress = [[dictionary objectForKeyNotNull:kCLQlfitnCertificationProgresskey] boolValue];
    self.isLifeValid = [[dictionary objectForKeyNotNull:kCLQlfitnCertificationValiditykey] boolValue];
    
    NSString *issuedOnStr = [dictionary objectForKeyNotNull:kCLQlfitnCertificationIssuedOnDatekey];
    NSString *toDateStr = [dictionary objectForKeyNotNull:kCLQlfitnCertificationToDatekey];
    NSString *fromDateStr = [dictionary objectForKeyNotNull:kCLQlfitnCertificationFromDatekey];
    NSString *compltnDateStr = [dictionary objectForKeyNotNull:kCLQlfitnCertificationCompletionDatekey];
    
    if (![fromDateStr isEqualToString:@""]) {
        NSMutableString *startDateStr = [[NSMutableString alloc]init];
        NSArray *startDateArray = [fromDateStr componentsSeparatedByString:@"-"];
        if ([[startDateArray objectAtIndex:0] isEqualToString:@""]) {
            [startDateStr appendString:@"01"];
            [startDateStr appendString:@"-"];
            [startDateStr appendString:[startDateArray objectAtIndex:1]];
            [startDateStr appendString:@"-"];
            [startDateStr appendString:[startDateArray objectAtIndex:2]];
            self.fromDate =[CLCommon getDateForString:startDateStr andFormat:@"dd-MM-yyyy"];
        }else{
            self.fromDate =[CLCommon getDateForString:fromDateStr andFormat:@"dd-MM-yyyy"];
        }
        
        NSMutableString *completionDateStr = [[NSMutableString alloc]init];
        NSArray *completionDateArray = [compltnDateStr componentsSeparatedByString:@"-"];
        if ([[completionDateArray objectAtIndex:0] isEqualToString:@""]) {
            [completionDateStr appendString:@"01"];
            [completionDateStr appendString:@"-"];
            [completionDateStr appendString:[completionDateArray objectAtIndex:1]];
            [completionDateStr appendString:@"-"];
            [completionDateStr appendString:[completionDateArray objectAtIndex:2]];
            self.completionDate = [CLCommon getDateForString:completionDateStr andFormat:@"dd-MM-yyyy"];
        }else{
            self.completionDate = [CLCommon getDateForString:compltnDateStr andFormat:@"dd-MM-yyyy"];
        }
       
       
    }
    if (![issuedOnStr isEqualToString:@""]) {
        NSMutableString *issuedOnDateStr = [[NSMutableString alloc]init];
        
        NSArray *issuedOnDateArray = [issuedOnStr componentsSeparatedByString:@"-"];
        if ([[issuedOnDateArray objectAtIndex:0] isEqualToString:@""]) {
            [issuedOnDateStr appendString:@"01"];
            [issuedOnDateStr appendString:@"-"];
            [issuedOnDateStr appendString:[issuedOnDateArray objectAtIndex:1]];
            [issuedOnDateStr appendString:@"-"];
            [issuedOnDateStr appendString:[issuedOnDateArray objectAtIndex:2]];
            self.issuedOnDate = [CLCommon getDateForString:issuedOnDateStr andFormat:@"dd-MM-yyyy"];
        }else{
            self.issuedOnDate = [CLCommon getDateForString:issuedOnStr andFormat:@"dd-MM-yyyy"];
        }
      
        if (!self.isLifeValid) {
            NSMutableString *endDateStr = [[NSMutableString alloc]init];
            NSArray *endDateArray = [toDateStr componentsSeparatedByString:@"-"];
            if ([[endDateArray objectAtIndex:0] isEqualToString:@""]) {
                [endDateStr appendString:@"01"];
                [endDateStr appendString:@"-"];
                [endDateStr appendString:[endDateArray objectAtIndex:1]];
                [endDateStr appendString:@"-"];
                [endDateStr appendString:[endDateArray objectAtIndex:2]];
                self.toDate = [CLCommon getDateForString:endDateStr andFormat:@"dd-MM-yyyy"];
            }else{
                self.toDate = [CLCommon getDateForString:toDateStr andFormat:@"dd-MM-yyyy"];
            }
        }else{
            self.toDate = nil;
        }
       
    }
    self.contents = [dictionary objectForKeyNotNull:kCLQlfitnCertificationContentskey];
    self.documentsUrl=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLQlfitnCertificationDocumentskey];
    for (int i=0; i<[files count]; i++) {
        [self.documentsUrl addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }

    return self;
}

//Method for saving Certification of a particular user...
+ (void)saveCertification:(CLCertificationObject*)certificationObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *certificationId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *certificationId){};
    }
    
    NSDictionary *parameters =nil;
    
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": certificationObj.certificationId, @"fields":[CLCertificationObject jsonStringForObject:certificationObj]};
        
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLCertificationObject jsonStringForObject:certificationObj]};
    }
   
    [saveCertificationRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveCertificationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceEducationSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveCertificationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLQlfitnCertificationIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"error--->%@",error.description);
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(NSString*)jsonStringForObject:(CLCertificationObject*)certificationObj{
    NSMutableDictionary *certificateDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    
    [insideDict setObject:certificationObj.title forKey:kCLQlfitnCertificationTitlekey];
    [insideDict setObject:certificationObj.institution forKey:kCLQlfitnCertificationInstitutionkey];
    
    if (certificationObj.location) {
        if (certificationObj.location.locationCode !=nil) {
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:certificationObj.location.locationCode forKey:kCLQlfitnCertificationLocationCodekey];
            [locationDict setObject:certificationObj.location.countryCode forKey:kCLQlfitnCertificationLocationCountrykey];
            
            [insideDict setObject:locationDict forKey:kCLQlfitnCertificationLocationkey];
        }
        else if (certificationObj.location.countryCode != nil){
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:certificationObj.location.countryCode forKey:kCLQlfitnCertificationLocationCountrykey];
            
            [insideDict setObject:locationDict forKey:kCLQlfitnCertificationLocationkey];
        }
    }
    [insideDict setObject:[NSString stringWithFormat:@"%d",certificationObj.isProgress] forKey:kCLQlfitnCertificationProgresskey];
    [insideDict setObject:[NSString stringWithFormat:@"%d",certificationObj.isLifeValid] forKey:kCLQlfitnCertificationValiditykey];
    
    if (certificationObj.isProgress) {
        [insideDict setObject:[CLCommon getStringForDate:certificationObj.completionDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnCertificationCompletionDatekey];
        [insideDict setObject:[CLCommon getStringForDate:certificationObj.fromDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnCertificationFromDatekey];
    }else{
        if (certificationObj.isLifeValid) {
            [insideDict setObject:[CLCommon getStringForDate:certificationObj.issuedOnDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnCertificationIssuedOnDatekey];
        }else{
            [insideDict setObject:[CLCommon getStringForDate:certificationObj.issuedOnDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnCertificationIssuedOnDatekey];
            [insideDict setObject:[CLCommon getStringForDate:certificationObj.toDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnCertificationToDatekey];
        }
    }
   
    [insideDict setObject:certificationObj.contents forKey:kCLQlfitnCertificationContentskey];
    [certificateDict setObject:insideDict forKey:kCLQlfitnCertificationkey];
  
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:certificateDict];
}
@end
