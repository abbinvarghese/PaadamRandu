//
//  CLCareerHistoryObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLLocationObject.h"
#import "CLCareerKeyJobFactsObject.h"
#import "CLWorkAchievementObject.h"
#import "CLCareerSalaryBenefitsObject.h"

@interface CLCareerHistoryObject : NSObject


@property (nonatomic, strong) NSDate *durationFrom;
@property (nonatomic, strong) NSDate *durationTo;
@property (nonatomic, assign) BOOL durationCurrent;
@property (nonatomic, assign) BOOL selfEmployed;
@property (nonatomic, assign) BOOL isDesc;
@property (nonatomic, assign) BOOL isJobTypePrimary;
@property (nonatomic, assign) BOOL isOtherCompany;

@property (nonatomic, strong) NSString *wrkHisId;
@property (nonatomic, strong) NSString *jobTitle;
@property (nonatomic, strong) NSString *companyDesc;
@property (nonatomic, strong) NSString *department;
@property (nonatomic, strong) NSString *reportedTo;
@property (nonatomic, strong) NSString *jobType;
@property (nonatomic, strong) NSString *timeSpend;
@property (nonatomic, strong) NSString *salaryAmount;
@property (nonatomic, strong) CLCareerKeyJobFactsObject *keyJobFacts;
@property (nonatomic, strong) CLCareerSalaryBenefitsObject *salBenefitObj;
@property (nonatomic, strong) NSString *keyJobAccountabilities;
@property (nonatomic, strong) NSString *experiencesGained;
@property (nonatomic, strong) NSMutableArray *majorAchievements;
@property (nonatomic, strong) NSString *remarksAbtJob;

@property (nonatomic, strong) NSMutableArray *companyDivisions;
@property (nonatomic, strong) NSMutableArray *multBusinessDiv;
@property (nonatomic, strong) NSMutableArray *reasonForMove;
@property (nonatomic, strong) NSMutableArray *careerHisFunction;
@property (nonatomic, strong) NSMutableArray *careerAllownces;
@property (nonatomic, strong) NSMutableArray *careerIncentives;
@property (nonatomic, strong) NSMutableArray *careerBenefits;
@property (nonatomic, strong) NSMutableArray *careerProjects;
@property (nonatomic, strong) NSMutableArray *documents;

@property (nonatomic, strong) NSMutableDictionary *companyName;
@property (nonatomic, strong) NSMutableDictionary *otherCompanyName;
@property (nonatomic, strong) NSMutableDictionary *companyDivision;
@property (nonatomic, strong) NSMutableDictionary *companyBusinessDivision;
@property (nonatomic, strong) NSMutableDictionary *jobLevel;
@property (nonatomic, strong) NSMutableDictionary *industry;
@property (nonatomic, strong) NSMutableDictionary *jobImpact;
@property (nonatomic, strong) NSMutableDictionary *contractType;
@property (nonatomic, strong) NSMutableDictionary *employmentType;
@property (nonatomic, strong) NSMutableDictionary *employmentContractType;
@property (nonatomic, strong) NSDictionary *salaryBasis;
@property (nonatomic, strong) NSDictionary *salaryAllowances;
@property (nonatomic, strong) NSDictionary *salaryAllowanceFrequency;
@property (nonatomic, strong) NSDictionary *salaryAllowanceType;
@property (nonatomic, strong) NSDictionary *salaryAllowanceActualValue;
@property (nonatomic, strong) NSDictionary *salaryAllowanceCurrency;
@property (nonatomic, strong) NSDictionary *salaryAllowanceGrossSalary;
@property (nonatomic, strong) NSDictionary *salaryIncentives;
@property (nonatomic, strong) NSDictionary *salaryIncentiveFrequency;
@property (nonatomic, strong) NSDictionary *salaryIncentiveType;
@property (nonatomic, strong) NSDictionary *salaryIncentiveActualValue;
@property (nonatomic, strong) NSDictionary *salaryIncentiveCurrency;
@property (nonatomic, strong) NSDictionary *salaryIncentiveGrossSalary;
@property (nonatomic, strong) NSDictionary *salaryCurrency;
@property (nonatomic, strong) NSDictionary *permanentEmplyRprtDirect;
@property (nonatomic, strong) NSDictionary *permanentEmplyRprtInDirect;
@property (nonatomic, strong) NSDictionary *tmpryReportsDirect;
@property (nonatomic, strong) NSDictionary *tmpryReportsInDirect;
@property (nonatomic, strong) NSDictionary *budgetResponsibility;

@property (nonatomic, strong) CLLocationObject *careerCountry;
@property (nonatomic, strong) CLLocationObject *careerLocation;

- (id)initWithDictionary:(NSDictionary*)dictionary;
+ (void)cancelGetCompanyNameRequest;
+ (void)cancelWorkHistoryPendingRequest;
+(void)getCompanyNameListForSearchString:(NSString*)searchText withCountry:(NSString *)countryName success:(void (^)(NSMutableArray *companyNameList))success failure:(void (^)(NSString *error))failure;
+ (void)saveWorkHistory:(CLCareerHistoryObject*)careerHisObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *wrkHisId))success failure:(void (^)(NSString *error))failure;
+ (void)deleteWrkHistory:(NSString*)wrkHisId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;
+ (void)deleteWorkHistoryDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;
+ (void)addDocument:(UIImage*)image forWorkHistory:(NSString*)docId andUser:(NSString *)userId withCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;
@end
