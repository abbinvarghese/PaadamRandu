//
//  CLSimpleTextCell.m
//  CareerLine
//
//  Created by CSG on 2/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSimpleTextCell.h"

@interface CLSimpleTextCell()


@property (weak, nonatomic) IBOutlet UITextField *txtField;

- (IBAction)textFieldDidChangeEditing:(id)sender;
@end

@implementation CLSimpleTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLSimpleTextCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
     self.txtField.clearButtonMode=UITextFieldViewModeNever;
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(NSString*)getEnteredText{
    return self.txtField.text;
}

-(void)setCellFont:(UIFont*)font{
    self.txtField.font=font;
}

-(void)setCellText:(NSString*)text{
    self.txtField.text=text;
}

-(void)setPlaceHoldrText:(NSString *)text{
    self.txtField.placeholder=text;
}

-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode{
    self.txtField.autocapitalizationType=capitalizationMode;
}

-(void)setCellClearButtonMode:(UITextFieldViewMode)mode{
    self.txtField.clearButtonMode=mode;
}

-(void)setTextInputView:(id)picker{
    self.txtField.inputView=picker;
}

-(void)setTextInputAccesoryView:(id)view{
    self.txtField.inputAccessoryView=view;
}

-(BOOL)isCellFirstResponder{
    if ([self.txtField isFirstResponder]) {
        return YES;
    }
    else{
        return NO;
    }
}

-(void)setInputFieldWidth:(CGFloat)width{
    
    CGRect frameRect = self.txtField.frame;
    frameRect.size.width = width;
    self.txtField.frame = frameRect;

}

-(void)setKeyboardType :(UIKeyboardType)type{
    self.txtField.keyboardType = type;
}

-(void)disableCellField{
    self.txtField.enabled=NO;
    self.backgroundColor=[UIColor colorFromHexCode:@"#CCEDEB"];
}

-(void)disableCelltxtField{
    self.txtField.enabled=NO;
}
-(void)changeCelltxtFieldColor:(NSString *)hexCode{
    self.txtField.enabled=NO;
    self.txtField.backgroundColor=[UIColor colorFromHexCode:hexCode];
}
-(void)enableCellField{
    self.txtField.enabled=YES;
    self.backgroundColor=[UIColor whiteColor];
}

-(void)enableCelltxtField{
    self.txtField.enabled=YES;
    self.txtField.backgroundColor=[UIColor whiteColor];
}

-(void)resignCellFirstResponder{
    [self.txtField resignFirstResponder];
}

-(void)returnKeyType:(UIReturnKeyType)returnKeyType{
    self.txtField.returnKeyType = returnKeyType;
}

//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
//    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellWillBeginEditing:forTextField:)]){
//		[self.delegate cellWillBeginEditing:self forTextField:self.txtField];
//	}
//    return YES;
//}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellWillBeginEditing:forTextField:)]){
        [self.delegate cellWillBeginEditing:self forTextField:self.txtField];
    }
}

-(void)becomeFirstResponder{
    [self.txtField becomeFirstResponder];
}

- (void)cellShouldReturn:(UITextField *)textField{
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellShouldReturn:forTextField:)]){
        [self.delegate cellShouldReturn:self forTextField:self.txtField];
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (self.txtField.returnKeyType == UIReturnKeyDefault){
        [self.txtField resignFirstResponder];
    }
    else if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellShouldReturn:forTextField:)]){
        [self.delegate cellShouldReturn:self forTextField:self.txtField];
    }
    return YES;
}

- (IBAction)textFieldDidChangeEditing:(UITextField*)sender {
 
    NSString *trimmedString = [sender.text stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellTextDidChange:forIndexPath:withText:)]){
		[self.delegate cellTextDidChange:self forIndexPath:self.cellIndexPath withText:trimmedString];
	}
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellWillClearContent:forIndexPath:forTextField:)]){
        [self.delegate cellWillClearContent:self forIndexPath:self.cellIndexPath forTextField:self.txtField];
    }
    return YES;
}

@end
