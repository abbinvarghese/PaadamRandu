//
//  CLSelectFunctionCategoryViewController.m
//  CareerLine
//
//  Created by Pravin on 9/19/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectFunctionCategoryViewController.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLSelectFunctionCategoryViewController ()
@property(nonatomic,strong)NSMutableArray *jobFuncCategoryArray;
@property (nonatomic, strong)  NSMutableArray *detailsArray;
@property(nonatomic,assign)BOOL isSelectAll;
@end

@implementation CLSelectFunctionCategoryViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (self.alreadySelectedFunctions.count == 0 && self.enableSelectOption) {
        self.isSelectAll = YES;
        [self setRightNavigationButton];
    }
    else
    {
        [self addFnGroupNameto:self.alreadySelectedFunctions];
        self.isSelectAll = NO;
        [self setRightNavigationButton];
    }
    self.title=NSLocalizedString(@"Job Function", @"Select Job Function page title");
    
    self.detailsArray = [[NSMutableArray alloc]init];
    
    
    
    NSMutableArray *fnCatArray1 = [self.selectedFunctionDict valueForKeyPath:kCLTargetJobsNewFnCategory];
    
    if([fnCatArray1 count])
    {
        for (NSMutableDictionary *dict in fnCatArray1)
        {
            NSString *string = [dict objectForKey:kCLTargetJobsNewFnCategory];
            NSMutableDictionary *newDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:string,@"FnName", [dict objectForKey:@"functionGroupName"], @"functionGroupName", [dict objectForKey:@"functionCategoryCode"], @"jobFunctionGroupCode", nil];
            [self.detailsArray addObject:newDict];
        }
    }
    
    NSMutableArray *fnCatArray2 = [self.selectedFunctionDict valueForKeyPath:kCLJobPreferenceFinctionsKey];
    if([fnCatArray2 count])
    {
        for (NSMutableDictionary *dict in fnCatArray2)
        {
            NSString *string = [dict objectForKey:kCLJobPreferenceFinctionsKey];
            
            NSMutableDictionary *newDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:string,@"FnName", @"", @"functionGroupName", [dict objectForKey:@"jobFunctionCode"], @"jobFunctionCode", nil];
            [self.detailsArray addObject:newDict];
        }
    }
    NSMutableArray *fnCatArray3 = [self.selectedFunctionDict valueForKeyPath:@"OtherFunction"];
    if([fnCatArray3 count])
    {
        for (NSMutableDictionary *dict in fnCatArray3)
        {
            NSString *string = [NSString stringWithFormat:@"%@(%@)",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]];
            NSMutableDictionary *newDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:string,@"FnName", @"", @"functionGroupName", nil];
            
            [self.detailsArray addObject:newDict];
        }
    }
    
    NSMutableArray *fnCatArray4 = [self.selectedFunctionDict valueForKeyPath:@"functionGroup"];
    if([fnCatArray4 count])
    {
        for (NSMutableDictionary *dict in fnCatArray4)
        {
            NSString *string = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLJobPreferenceFinctionsKey]];
            NSMutableDictionary *newDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:string,@"FnName", @"", @"functionGroupName", nil];
            
            [self.detailsArray addObject:newDict];
        }
    }

    [self setleftNavigationButtun];
    self.jobFuncCategoryArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobFunctionsCategory];
}

-(void)viewDidAppear:(BOOL)animated{
    
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.alreadySelectedFunctions count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSMutableArray*)addFnGroupNameto:(NSMutableArray*)array
{
    for (NSMutableDictionary *dict in array)
    {
        NSString *GroupCode = [dict objectForKey:@"jobFunctionGroupCode"];
        NSString *OtherFnName = [dict objectForKey:@"jobFunction"];
        
        if(GroupCode.length && OtherFnName.length == 0)
        {
        NSString *groupName = [[CLCoreDataHelper sharedCLCoreDataHelper] getFunctionGroupNamefrom:GroupCode];
        [dict setValue:groupName forKey:@"functionGroupName"];
        }
    }
    return array;
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    NSString *text = @"";
    if (self.isSelectAll) {
        text = @"Select All";
    }
    else{
        text = @"Done";
    }
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(text, @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionrightBarButtonClick)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)setleftNavigationButtun{
    UIBarButtonItem *leftNavButton = [[UIBarButtonItem alloc]initWithTitle:NSLocalizedString(@"Back", @"test for cancel button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavButton;
}

#pragma mark - IBActions

-(void)bttnActionCancelModal:(id)sender{
    [self.tableView setEditing:NO animated:NO];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)bttnActionrightBarButtonClick{
    if (self.isSelectAll && self.alreadySelectedFunctions.count == 0) {
        
        self.alreadySelectedFunctions = [[NSMutableArray alloc]initWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"jobFunctionCode",@"0",@"jobFunctionOtherFlag",@"All Functions",@"function",@"",@"functionGroupName", @"All Functions",@"functionName",@"",@"id", nil], nil];
        
        [self.selectedFunctionDict setObject:self.alreadySelectedFunctions forKey:@"functionGroup"];
        
        if([self.alreadySelectedFunctions count])
        {
            for (NSMutableDictionary *dict in self.alreadySelectedFunctions)
            {
                NSString *string = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLJobPreferenceFinctionsKey]];
                NSMutableDictionary *newDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:string,@"FnName", @"", @"functionGroupName", nil];
                
                [self.detailsArray addObject:newDict];
            }
        }

        if ([self.alreadySelectedFunctions count]>0) {
            [self.tableView setEditing:YES animated:YES];
        }
        [self.tableView reloadData];
        self.isSelectAll = !self.isSelectAll;
        [self setRightNavigationButton];
        
        if (self.delegate!=nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidSelectJobFromCatogory:withArray:andSelectAllInfo:)]) {
            [self.delegate selectJobFunctionControllerDidSelectJobFromCatogory:self withArray:self.alreadySelectedFunctions andSelectAllInfo:self.selectedFunctionDict];
        }

    }
    else if (!self.isSelectAll && self.alreadySelectedFunctions.count > 0){
        [self dismissViewControllerAnimated:YES completion:^(void)
        {
            if (self.delegate!=nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidSelectJobFromCatogory:withArray:andSelectAllInfo:)]) {
                [self.delegate selectJobFunctionControllerDidSelectJobFromCatogory:self withArray:self.alreadySelectedFunctions andSelectAllInfo:self.selectedFunctionDict];
            }
        }];
    }
    
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if([self.alreadySelectedFunctions count]>0){
        return 2;
    }
    else{
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (!self.enableSelectOption) //career
    {
        if([self.alreadySelectedFunctions count]>0)
        {
            if(section==0)
            {
                return [self.alreadySelectedFunctions count];
            }
            else
            {
                return [self.jobFuncCategoryArray count];
            }
        }
        else
        {
            return [self.jobFuncCategoryArray count];
        }
    }
    else //job preference
    {
        if([self.alreadySelectedFunctions count]>0)
        {
            if(section==0)
            {
                return [self.detailsArray count];
            }
            else
            {
                return [self.jobFuncCategoryArray count];
            }
        }
        else
        {
            return [self.jobFuncCategoryArray count];
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self.alreadySelectedFunctions count]>0)
    {
        if(indexPath.section==0)
        {
            static NSString *CellIdentifier = @"CellSelectedIndustryIdentifier";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
                [cell.textLabel setTextColor:ColorCode_CareerLineGreen];
                [cell.textLabel setNumberOfLines:2];
            }
            if (!self.enableSelectOption)
            {
                if ([[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"]) {
                    cell.textLabel.text=[NSString stringWithFormat:@"%@ (%@)",[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionName],[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionOtherText]];
                }
                else{
                    cell.textLabel.text=[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionName];
                }
            }
            else
            {
                NSString *textString = [[self.detailsArray objectAtIndex:indexPath.row] valueForKey:@"FnName"];
                cell.textLabel.text = textString;//[self.detailsArray objectAtIndex:indexPath.row];
                
//                if ([[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"]) {
//                    cell.textLabel.text=[NSString stringWithFormat:@"%@ (%@)",[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceJobFunctionKey],[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceFinctionsKey]];
//                }
//                else{
//                    cell.textLabel.text=[[self.alreadySelectedFunctions objectAtIndex:indexPath.row] objectForKey:kjobFunctionName];
//                }
            }
            
            return cell;
        }
        else if (indexPath.section == 1){
            static NSString *CellIdentifier = @"Cell";
            UITableViewCell *celltwo = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (celltwo == nil) {
                celltwo = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                celltwo.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
                [celltwo.textLabel setFont:[UIFont systemFontOfSize:12]];
                [celltwo.textLabel setNumberOfLines:2];
            }
            if (self.alreadySelectedFunctions) {
                if ([[[self.alreadySelectedFunctions objectAtIndex:0]objectForKey:kCLJobPreferenceJobFunctionIdKey]isEqualToString:@""] && [[[self.alreadySelectedFunctions objectAtIndex:0]objectForKey:kCLJobPreferenceJobFunctionCode] isEqualToString:@""])  //freezes the second section when all function is selected
                {
                    ///[celltwo.textLabel setTextColor:[UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.098/255.0 alpha:0.22]];
                    celltwo.selectionStyle= UITableViewCellSelectionStyleNone;
                }
                else{
                    [celltwo.textLabel setTextColor:[UIColor blackColor]];
                }
            }
            NSMutableDictionary *jobLevelGroup=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
            celltwo.textLabel.text=[jobLevelGroup objectForKey:kjobFunctionCategoryName];
            
            return celltwo;
            
        }
    }
    else {
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cellthree = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cellthree == nil) {
            cellthree = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cellthree.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
            [cellthree.textLabel setFont:[UIFont systemFontOfSize:12]];
            [cellthree.textLabel setNumberOfLines:2];
            
        }
        
        NSMutableDictionary *jobLevelGroup=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
        cellthree.textLabel.text=[jobLevelGroup objectForKey:kjobFunctionCategoryName];
        [cellthree.textLabel setTextColor:[UIColor blackColor]];
        return cellthree;
    }
    return nil;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell.isEditing == YES)
    {
    }
    else
    {
        if (self.alreadySelectedFunctions.count != 0)
        {
            if ([self isallFunctionSelected]){
                CLSelectFunctionViewController *detailViewController = [[CLSelectFunctionViewController alloc] initWithNibName:@"CLSelectFunctionViewController" bundle:[NSBundle mainBundle]];
                detailViewController.delegate=(id<CLAddJobFunctionDelegate>)self.delegate;
                detailViewController.selectedFunctionDict = self.selectedFunctionDict;
                detailViewController.selectedJobFuncCategoryDict=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
                detailViewController.alreadySelectedFunctions=self.alreadySelectedFunctions;
                [detailViewController setEnableSelectOption:self.enableSelectOption];
                detailViewController.allFunctionSelected = YES;
                [self.navigationController pushViewController:detailViewController animated:YES];
            }
            else
            {
                if([self.alreadySelectedFunctions count]>0)
                {
                    if(indexPath.section==1)
                    {
                        CLSelectFunctionViewController *detailViewController = [[CLSelectFunctionViewController alloc] initWithNibName:@"CLSelectFunctionViewController" bundle:[NSBundle mainBundle]];
                        detailViewController.delegate=(id<CLAddJobFunctionDelegate>)self.delegate;
                        detailViewController.selectedFunctionDict = self.selectedFunctionDict;
                        detailViewController.selectedJobFuncCategoryDict=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
                        detailViewController.alreadySelectedFunctions=self.alreadySelectedFunctions;
                        [detailViewController setEnableSelectOption:self.enableSelectOption];
                        [self.navigationController pushViewController:detailViewController animated:YES];
                    }
                }
                else
                {
                    CLSelectFunctionViewController *detailViewController = [[CLSelectFunctionViewController alloc] initWithNibName:@"CLSelectFunctionViewController" bundle:[NSBundle mainBundle]];
                    detailViewController.delegate=(id<CLAddJobFunctionDelegate>)self.delegate;
                    detailViewController.selectedFunctionDict = self.selectedFunctionDict;
                    detailViewController.selectedJobFuncCategoryDict=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
                    detailViewController.alreadySelectedFunctions=self.alreadySelectedFunctions;
                    [detailViewController setEnableSelectOption:self.enableSelectOption];
                    [self.navigationController pushViewController:detailViewController animated:YES];
                }
                
            }
        }
        else
        {
            if([self.alreadySelectedFunctions count]>0)
            {
                if(indexPath.section==1)
                {
                    CLSelectFunctionViewController *detailViewController = [[CLSelectFunctionViewController alloc] initWithNibName:@"CLSelectFunctionViewController" bundle:[NSBundle mainBundle]];
                    detailViewController.delegate=(id<CLAddJobFunctionDelegate>)self.delegate;
                    detailViewController.selectedFunctionDict = self.selectedFunctionDict;
                    detailViewController.selectedJobFuncCategoryDict=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
                    detailViewController.alreadySelectedFunctions=self.alreadySelectedFunctions;
                    [detailViewController setEnableSelectOption:self.enableSelectOption];
                    [self.navigationController pushViewController:detailViewController animated:YES];
                }
            }
            else
            {
                CLSelectFunctionViewController *detailViewController = [[CLSelectFunctionViewController alloc] initWithNibName:@"CLSelectFunctionViewController" bundle:[NSBundle mainBundle]];
                detailViewController.delegate=(id<CLAddJobFunctionDelegate>)self.delegate;
                detailViewController.selectedFunctionDict = self.selectedFunctionDict;
                detailViewController.selectedJobFuncCategoryDict=[self.jobFuncCategoryArray objectAtIndex:indexPath.row];
                detailViewController.alreadySelectedFunctions=self.alreadySelectedFunctions;
                [detailViewController setEnableSelectOption:self.enableSelectOption];
                [self.navigationController pushViewController:detailViewController animated:YES];
            }
            
        }
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if([self.alreadySelectedFunctions count]>0){
        if(section==0){
            return NSLocalizedString(@"EDIT JOB FUNCTION", @"Title for EDIT JOB FUNCTION");
        }
        else{
            return NSLocalizedString(@"ADD JOB FUNCTIONS", @"Title for ADD JOB FUNCTION");
        }
    }
    else{
        return NSLocalizedString(@"JOB FUNCTIONS", @"Title for OTHER JOB FUNCTION");
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if([self.alreadySelectedFunctions count]>0){
        if(indexPath.section==0){
            return YES;
        }
        else{
            return NO;
        }
    }
    else{
        return NO;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.enableSelectOption)
    {
        if (editingStyle == UITableViewCellEditingStyleDelete)
        {
            BOOL isGroupSelected = NO;
            
            NSString *deletedFn = [[self.detailsArray objectAtIndex:indexPath.row] valueForKey:@"FnName"];
            
            NSMutableDictionary *newDict = [self.selectedFunctionDict mutableCopy];
            
            NSMutableArray *fnCatArray1 = [[self.selectedFunctionDict valueForKeyPath:kCLTargetJobsNewFnCategory]mutableCopy];
            
            if([fnCatArray1 count])
            {
                for (NSMutableDictionary *dict in fnCatArray1)
                {
                    NSString *string = [dict objectForKey:kCLTargetJobsNewFnCategory];
                    if([deletedFn isEqualToString:string])
                    {
                        isGroupSelected = YES;
                        [fnCatArray1 removeObject:dict];
                        [newDict setObject:fnCatArray1 forKey:kCLTargetJobsNewFnCategory];
                        break;
                    }
                }
            }
            
            NSMutableArray *fnCatArray2 = [[self.selectedFunctionDict valueForKeyPath:kCLJobPreferenceFinctionsKey]mutableCopy];
            if([fnCatArray2 count])
            {
                for (NSMutableDictionary *dict in fnCatArray2)
                {
                    NSString *string = [dict objectForKey:kCLJobPreferenceFinctionsKey];
                    if([deletedFn isEqualToString:string])
                    {
                        [fnCatArray2 removeObject:dict];
                        [newDict setObject:fnCatArray2 forKey:kCLJobPreferenceFinctionsKey];
                        break;
                    }
                }
            }
            NSMutableArray *fnCatArray3 = [[self.selectedFunctionDict valueForKeyPath:@"OtherFunction"]mutableCopy];
            if([fnCatArray3 count])
            {
                for (NSMutableDictionary *dict in fnCatArray3)
                {
                    NSString *string = [NSString stringWithFormat:@"%@(%@)",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]];
                    if([deletedFn isEqualToString:string])
                    {
                        [fnCatArray3 removeObject:dict];
                        [newDict setObject:fnCatArray3 forKey:@"OtherFunction"];
                        break;
                    }
                }
            }
            
            NSMutableArray *fnCatArray4 = [[self.selectedFunctionDict valueForKeyPath:@"functionGroup"]mutableCopy];
            if([fnCatArray4 count])
            {
                for (NSMutableDictionary *dict in fnCatArray4)
                {
                    NSString *string = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLJobPreferenceFinctionsKey]];
                    if([deletedFn isEqualToString:string])
                    {
                        [fnCatArray4 removeObject:dict];
                        [newDict setObject:fnCatArray4 forKey:@"functionGroup"];
                        break;
                    }
                }
            }

            
            self.selectedFunctionDict = [newDict mutableCopy];
            

            NSString *deletedFName = [[self.detailsArray objectAtIndex:indexPath.row] valueForKey:@"functionGroupName"];
            NSArray *newArray = nil;
            
            if(deletedFName.length)
            {
                for (NSMutableDictionary *dict in self.alreadySelectedFunctions)
                {
                    NSString *selValue = [dict objectForKey:@"functionGroupName"];
                    
                    if([deletedFName isEqualToString :selValue])
                    {
                        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"not (functionGroupName matches %@)",selValue];
                        newArray = [self.alreadySelectedFunctions filteredArrayUsingPredicate:predicate];
                        break;
                    }
                }
                
                if([newArray count])
                {
                    [self.alreadySelectedFunctions removeAllObjects];
                    self.alreadySelectedFunctions = [newArray mutableCopy];
                }
            }
            else
            {
                BOOL bFound = NO;
                
                deletedFName = [[self.detailsArray objectAtIndex:indexPath.row] valueForKey:@"FnName"];
                
                for (NSMutableDictionary *dict in self.alreadySelectedFunctions)
                {
                    // NSString *selValue = [dict objectForKey:@"jobFunctionCode"];
                     NSString *selValue2 = [NSString stringWithFormat:@"%@(%@)",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]];
                    
                    if([deletedFName isEqualToString :selValue2])
                    {
                        NSString *selValue3 = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLJobPreferenceJobFunctionKey]];
                        
                        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"not (jobFunction matches %@)",selValue3];
                        newArray = [self.alreadySelectedFunctions filteredArrayUsingPredicate:predicate];
                        bFound = YES;
                        break;
                    }
                }
                
                if(bFound)
                {
                    [self.alreadySelectedFunctions removeAllObjects];
                    self.alreadySelectedFunctions = [newArray mutableCopy];
                }
                else
                {
                    
                    NSMutableArray *safeArr = [self.alreadySelectedFunctions mutableCopy];

                    for(NSInteger i = 0; i < [safeArr count]; i++)
                    {
                        NSString *selValue2 = [[safeArr objectAtIndex:i]objectForKey:@"function"];
                         NSString *selValue = [NSString stringWithFormat:@"%@(%@)",[[safeArr objectAtIndex:i] objectForKey:@"functionGroupName"],[[safeArr objectAtIndex:i] objectForKey:kCLJobPreferenceFinctionsKey]];
                        
                        if([deletedFn isEqualToString :selValue])
                        {
                            NSLog(@"Correct Answer");
                            [safeArr removeObjectAtIndex:i];
                            break;
                        }
                        else if([deletedFn isEqualToString :selValue2])
                        {
                            NSLog(@"Correct Answer");
                            [safeArr removeObjectAtIndex:i];
                            break;
                        }
                    }

                    //if([safeArr count])
                    {
                        [self.alreadySelectedFunctions removeAllObjects];
                        self.alreadySelectedFunctions = [safeArr mutableCopy];
                    }
                }
                
//                for (NSMutableDictionary *dict in self.alreadySelectedFunctions)
//                {
//                    NSString *selValue = [dict objectForKey:@"function"];
//                    NSString *selValue2 = [NSString stringWithFormat:@"%@(%@)",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]];
//                    
//                    if([deletedFName isEqualToString :selValue])
//                    {
//                        NSString *selValue3 = [NSString stringWithFormat:@"%@",[dict objectForKey:@"function"]];
//                        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"not (function matches '%@')",selValue3];
//                        newArray = [self.alreadySelectedFunctions filteredArrayUsingPredicate:predicate];
//                        break;
//                    }
//                    else if([deletedFName isEqualToString :selValue2])
//                    {
//                        NSString *selValue3 = [NSString stringWithFormat:@"%@",[dict objectForKey:kCLJobPreferenceJobFunctionKey]];
//                                               
//                        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"not (jobFunction matches %@)",selValue3];
//                        newArray = [self.alreadySelectedFunctions filteredArrayUsingPredicate:predicate];
//                        break;
//                    }
//                }

            }
            
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidDeleteJobFunction:withArray: andDict:)])
            {
                [self.delegate selectJobFunctionControllerDidDeleteJobFunction:self withArray:self.alreadySelectedFunctions andDict:newDict];
            }
            
            [self.detailsArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.detailsArray count]==0)
            {
                [self.tableView setEditing:NO animated:NO];
                [self.tableView reloadData];
            }
            else
            {
                [self.tableView reloadData];
               // [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }

        if (self.alreadySelectedFunctions.count == 0)
        {
            self.isSelectAll = YES;
        }
        else
        {
            self.isSelectAll = NO;
        }
        
        [self setRightNavigationButton];
    }
    else
    {
        if (editingStyle == UITableViewCellEditingStyleDelete)
        {
            [self.alreadySelectedFunctions removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.alreadySelectedFunctions count]==0)
            {
                [self.tableView setEditing:NO animated:NO];
                [self.tableView reloadData];
            }
            else
            {
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidDeleteJobFunction:withArray:)])
            {
                [self.delegate selectJobFunctionControllerDidDeleteJobFunction:self withArray:self.alreadySelectedFunctions];
            }
        }
    }
    
}

-(BOOL)isallFunctionSelected{
    for (NSDictionary *dict in [self.selectedFunctionDict objectForKey:@"functionGroup"]) {
        if ([[dict objectForKey:@"id"]isEqualToString:@""] && [[dict objectForKey:kCLJobPreferenceJobFunctionCode] isEqualToString:@""]) {
            return YES;
        }
    }
    return NO;
}



@end
