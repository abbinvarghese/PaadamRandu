//
//  CLJobsApplyTextCell.h
//  CareerLine
//
//  Created by CSG on 1/28/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLJobsApplyTextCell : UITableViewCell

-(void)setUpCell;

-(NSNumber*)getEstimatedTextViewHeight;
-(NSString*)getCommentText;
-(CGRect)getCursorRectForTextView:(UITableView *)table;
@end
