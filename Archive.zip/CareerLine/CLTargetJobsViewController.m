//
//  CLTargetJobsViewController.m
//  CareerLine
//
//  Created by Abbin on 31/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTargetJobsViewController.h"
#import "TITokenField.h"
#import "CLTargetJobsObject.h"

@interface CLTargetJobsViewController ()

@property (nonatomic,retain) CLTargetJobsObject *targetJobsObject;
@property (strong, nonatomic) HTProgressHUD *activityIndicator;
@property (strong, nonatomic) IBOutlet TITokenField *tokenTxtField;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;

@property(nonatomic,strong)NSNumber *descriptionHeight;
@property(nonatomic,retain) NSMutableArray *selectedpreferredJobsArray;
@property(nonatomic,retain) NSMutableArray *selectedindustry;
@property(nonatomic,retain) NSMutableArray *theSelectedindustry;
@property(nonatomic,retain) NSMutableArray *theSelectedfunction;
@property(nonatomic,retain) NSMutableArray *selectedjobScopeDictArray;
@property(nonatomic,retain) NSMutableArray *selectedCareerlevelDictArray;
@property(nonatomic,retain) NSMutableArray *selecetedJobFunctionArray;
@property(nonatomic,retain) NSMutableDictionary *selectedFunctionDict;
@property(nonatomic,retain) NSString *anythingElseString;
@property(nonatomic,retain) NSArray* sectionHeadings;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;
@property(nonatomic,retain) NSString *industrySelectedItems;

typedef enum {
    CLTargetJobsPreferredJobs = 0,
    CLTargetJobsFunctionIndex= 1,
    CLTargetJobsIndustryIndex = 2,
    CLTargetJobsCareerLevelIndex = 3,
    CLTargetJobsJobScopeIndex = 4,
    CLTargetJobsAnyThingElseIndex = 5
} CLTargetJobsTableSectionIndex;

@end

@implementation CLTargetJobsViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    self.selecetedJobFunctionArray = [[NSMutableArray alloc]init];
    self.selectedjobScopeDictArray =[[NSMutableArray alloc]init];
    self.selectedCareerlevelDictArray=[[NSMutableArray alloc]init];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    [self targetjobsSummaryDetails];
    
    self.sectionHeadings = [[NSArray alloc]initWithObjects: NSLocalizedString(@"Preferred Jobs",@"Preferred Jobs heading text"),NSLocalizedString(@"Function",@"Function heading text"), NSLocalizedString(@"Industry",@"Industry heading text"),NSLocalizedString(@"Career Level",@"Career Level heading text"),NSLocalizedString(@"Job Scope",@"Job Scope heading text"),NSLocalizedString(@"Any thing else to say about this?",@"Any thing else heading text"), nil];
    
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"targetJobsIndustriesCell"];
     [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"targetJobsPrefferedJobCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"customJobScopeCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"customeJobFunctionCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"customeCareerLevelCell"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionCellIdentifier"];
    self.title = NSLocalizedString(@"Target Jobs", @"title for target jobs");
    
    [self setRightNavigationButton];
}

-(void)viewDidDisappear:(BOOL)animated{
    [CLTargetJobsObject cancelTargetjobSummeryRequest];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Target Jobs"];
}

#pragma mark UITableView delegate methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.targetJobsObject) {
        return 6;
    }
    else{
        return 0;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionHeadings objectAtIndex:section];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"targetJobCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:@"targetJobCell"];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
//    NSArray *cellTextLabelArray = [[NSArray alloc]initWithObjects:@"Industry",@"Function",@"Career Level",@"Job Scope",@"Any thing else to say about this?", nil];
    
    switch (indexPath.section) {
        case CLTargetJobsPreferredJobs:{
            CLTappableTextViewCell *targetJobIndustries = (CLTappableTextViewCell*) [self.tableView dequeueReusableCellWithIdentifier:@"targetJobsPrefferedJobCell"];
            targetJobIndustries.selectionStyle=UITableViewCellSelectionStyleNone;
            [targetJobIndustries setCellPlaceHolderText:NSLocalizedString(@"Preferred Jobs", @"placeholder for Preferred Jobs cell")];
            [targetJobIndustries setCellFont:[UIFont systemFontOfSize:13]];
            [targetJobIndustries setCellIndexPath:indexPath];
            [targetJobIndustries setCellText:[self getStringValueForPreferredJobsFromDictionaryArray]];
            targetJobIndustries.delegate = self;
            return targetJobIndustries;

        }
            break;
        case CLTargetJobsIndustryIndex:{
            CLTappableTextViewCell *targetJobIndustries = (CLTappableTextViewCell*) [self.tableView dequeueReusableCellWithIdentifier:@"targetJobsIndustriesCell"];
            targetJobIndustries.selectionStyle=UITableViewCellSelectionStyleNone;
            [targetJobIndustries setCellPlaceHolderText:NSLocalizedString(@"Industries", @"placeholder for Industries cell")];
            [targetJobIndustries setCellFont:[UIFont systemFontOfSize:13]];
            [targetJobIndustries setCellIndexPath:indexPath];
            [targetJobIndustries setCellText:[self getStringValueForindustryFromDictionaryArray]];
            targetJobIndustries.delegate = self;
            return targetJobIndustries;
        }
            break;
        case CLTargetJobsFunctionIndex:{
            CLTappableTextViewCell *jobFunctionArray = (CLTappableTextViewCell*) [self.tableView dequeueReusableCellWithIdentifier:@"customeJobFunctionCell"];
            jobFunctionArray.selectionStyle=UITableViewCellSelectionStyleNone;
            [jobFunctionArray setCellPlaceHolderText:NSLocalizedString(@"Job Function", @"placeholder for job function cell")];
            [jobFunctionArray setCellFont:[UIFont systemFontOfSize:13]];
            [jobFunctionArray setCellIndexPath:indexPath];
            [jobFunctionArray setCellText:[self getStringValueForJobFunctionFromDictionaryArray]];
            jobFunctionArray.delegate = self;
            return jobFunctionArray;

        }
            break;
        case CLTargetJobsCareerLevelIndex:{
            CLTappableTextViewCell *careerLevelCell = (CLTappableTextViewCell*) [self.tableView dequeueReusableCellWithIdentifier:@"customeCareerLevelCell"];
            careerLevelCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [careerLevelCell setCellPlaceHolderText:NSLocalizedString(@"Career Level", @"placeholder for job scope cell")];
            [careerLevelCell setCellFont:[UIFont systemFontOfSize:13]];
            [careerLevelCell setCellIndexPath:indexPath];
            [careerLevelCell setCellText:[self getStringValueForCareerLevelFromDictionaryArray]];
            careerLevelCell.delegate = self;
            return careerLevelCell;

        }
            break;
        case CLTargetJobsJobScopeIndex:{
            CLTappableTextViewCell *jobScopeCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"customJobScopeCell"];
            jobScopeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [jobScopeCell setCellPlaceHolderText:NSLocalizedString(@"Job Scope", @"placeholder for job scope cell")];
            [jobScopeCell setCellText:[self getStringValueForJobScopeFromDictionaryArray]];
            [jobScopeCell setCellFont:[UIFont systemFontOfSize:13]];
            [jobScopeCell setCellIndexPath:indexPath];
            jobScopeCell.delegate = self;
            return jobScopeCell;
        }
            break;
        case CLTargetJobsAnyThingElseIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for Anything else you want to say about this")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            descCell.text=self.anythingElseString;
            [descCell setCellFont:[UIFont systemFontOfSize:13]];
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;

        }
            break;
            
        default:
            break;
    }
        return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLTargetJobsPreferredJobs:
            return MAX(44, [self getHeightForTokenFieldWithText:[self getStringValueForPreferredJobsFromDictionaryArray]]+10);
            break;
        case CLTargetJobsIndustryIndex:
            return MAX(44, [self getHeightForTokenFieldWithText:[self getStringValueForindustryFromDictionaryArray]]+10);
            break;
        case CLTargetJobsJobScopeIndex:
            return MAX(44, [self getHeightForTokenFieldWithText:[self getStringValueForJobScopeFromDictionaryArray]]+10);
            break;
        case CLTargetJobsCareerLevelIndex:
            return MAX(44, [self getHeightForTokenFieldWithText:[self getStringValueForCareerLevelFromDictionaryArray]]+10);
            break;
        case CLTargetJobsFunctionIndex:
            return MAX(44, [self getHeightForTokenFieldWithText:[self getStringValueForJobFunctionFromDictionaryArray]]+10);
            break;
        case CLTargetJobsAnyThingElseIndex:{
            CGFloat ansHeight;
            if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
                ansHeight= [self.descriptionHeight floatValue];
            }
            else{
                ansHeight= [self getTextViewSizeForText:self.anythingElseString];
            }
            return MAX(44, ansHeight+1);
        }
            break;
        default:
            break;
    }
    return 44;
}



#pragma mark CLHeightAdjustTextCellDelegate Methods


- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.anythingElseString=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:13];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}



#pragma mark CustomeCell delegate methods

-(void) cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLTargetJobsJobScopeIndex:{
            CLJobScopeViewController *jobScopeViewController = [[CLJobScopeViewController alloc]initWithNibName:@"CLJobScopeViewController" bundle:[NSBundle mainBundle]];
            [jobScopeViewController setSelectedJobScopeDictArrayForEdit:_selectedjobScopeDictArray];
            jobScopeViewController.delegate=self;
            jobScopeViewController.delegateTwo=self;
            UINavigationController *jobNav = [[UINavigationController alloc]initWithRootViewController:jobScopeViewController];
            [self.navigationController presentViewController:jobNav animated:YES completion:nil];
            
         break;
        }
          
        case CLTargetJobsCareerLevelIndex:{
            CLSelectJobLevelGroupViewController *careerLevelsViewController = [[CLSelectJobLevelGroupViewController alloc]initWithNibName:@"CLSelectJobLevelGroupViewController" bundle:[NSBundle mainBundle]];
            [careerLevelsViewController setSelectedCareerlevelDictArrayTwo:self.selectedCareerlevelDictArray];
            [careerLevelsViewController setMultipleSelectionON:YES];
            careerLevelsViewController.delegate=self;
            careerLevelsViewController.delegateForJobfunction=self;
            UINavigationController *careerLevelsNav = [[UINavigationController alloc]initWithRootViewController:careerLevelsViewController];
            [self.navigationController presentViewController:careerLevelsNav animated:YES completion:nil];
       break;
        }
           
        case CLTargetJobsFunctionIndex:{
            CLSelectFunctionCategoryViewController *controller = [[CLSelectFunctionCategoryViewController alloc]initWithNibName:@"CLSelectFunctionCategoryViewController" bundle:[NSBundle mainBundle]];
            [controller setAlreadySelectedFunctions:self.selecetedJobFunctionArray];
            controller.selectedFunctionDict = self.selectedFunctionDict;
            controller.alreadySelectedFunctions=self.theSelectedfunction;
            controller.delegate =self;
            [controller setEnableSelectOption:YES];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
            [self presentViewController:nav animated:YES completion:nil];
            break;
        }
            
        case CLTargetJobsIndustryIndex:{
            CLIndustrySectorViewController *controller = [[CLIndustrySectorViewController alloc]initWithNibName:@"CLIndustrySectorViewController" bundle:[NSBundle mainBundle]];
            controller.alreadySelectedIndustries=[self.selectedindustry mutableCopy];
            controller.selectedIndustryArray = self.theSelectedindustry;
            controller.delegate =self;
            controller.enableSelectAll=YES;
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
            [self presentViewController:nav animated:YES completion:nil];
             break;
        }
        case CLTargetJobsPreferredJobs:{
            CLPreferredJobsEditViewController *prefferedController = [[CLPreferredJobsEditViewController alloc]initWithNibName:@"CLPreferredJobsEditViewController" bundle:[NSBundle mainBundle]];
            prefferedController.delegate = self;
            [prefferedController setPassedOnPreferredJobsArray:self.selectedpreferredJobsArray];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:prefferedController];
            [self presentViewController:nav animated:YES completion:nil];
        }
            break;
            
        default:
            break;
    }
}

-(void)loadFinalSelectedJobsPreferenceArray:(NSMutableArray *)array{
    if (array.count == 0) {
        self.selectedpreferredJobsArray = nil;
    }
    else{
        self.selectedpreferredJobsArray = array;
    }
    [self.tableView reloadData];
}

-(void)loadSelectedJobScope:(NSMutableArray *)jobScopeDictArray{
    self.selectedjobScopeDictArray = jobScopeDictArray;
    [self.tableView reloadData];
}

-(void)transferSelectedDictionariesArray:(CLSelectJobLevelDetailViewController *)controller withDictonary:(NSMutableArray *)dictArray {
    self.selectedCareerlevelDictArray = dictArray;
    [self.tableView reloadData];
}

- (void)selectJobFunctionControllerDidSelectJobFunction:(CLSelectFunctionViewController*)controller withArray:(NSMutableArray *)jobFunctionArray andSelectAllInfo:(NSMutableDictionary*)dict
{
    self.selectedFunctionDict = dict;
    [self.tableView reloadData];
    
    [self performSelector:@selector(saveValues:) withObject:jobFunctionArray afterDelay:0.5];

}

- (void)saveValues:(NSMutableArray*)arr
{
    [self.theSelectedfunction addObjectsFromArray:arr];
}

-(void)selectJobFunctionControllerDidSelectJobFromCatogory:(CLSelectFunctionCategoryViewController *)controller withArray:(NSMutableArray *)jobFunctionArray andSelectAllInfo:(NSMutableDictionary*)dict
{
    self.theSelectedfunction = jobFunctionArray;
    self.selectedFunctionDict = dict;

    [self.tableView reloadData];
}

-(void)selectJobFunctionControllerDidDeleteJobFunction:(CLSelectFunctionCategoryViewController *)controller withArray:(NSMutableArray *)jobFunctionArray andDict:(NSMutableDictionary*)dict;
{
    [self.theSelectedfunction removeAllObjects];
    self.theSelectedfunction = jobFunctionArray;
    //[self.theSelectedfunction removeObjectsInArray:jobFunctionArray];
    self.selectedFunctionDict = dict;

    
    //self.selecetedJobFunctionArray = jobFunctionArray;
    [self.tableView reloadData];
}

-(void)loadSelectedCareerLevelDictArray:(CLSelectJobLevelGroupViewController *)controller withArray:(NSMutableArray *)Array
{
    self.selectedCareerlevelDictArray = Array;
    [self.tableView reloadData];
}

-(void)loadSelectedJobScopeArray:(NSMutableArray *)jobScopeDictArray
{
    self.selectedjobScopeDictArray = jobScopeDictArray;
    [self.tableView reloadData];
}




#pragma mark Utility methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"target jobs modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveJobscopesAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(IBAction)bttnActionSaveJobscopesAndDismissModal:(id)sender{
    [self.view endEditing:YES];
     self.anythingElseString = [self.anythingElseString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    self.anythingElseString = cutString;
//    if ([self doesItHaveSapce:self.anythingElseString]) {
//        self.anythingElseString = @"";
//    }
    [self saveTargetJobs];
}


- (IBAction)doneButtonAction:(UIBarButtonItem *)sender {
    [self.txtViewFirstResponder resignFirstResponder];
}

-(NSString*)getStringValueForJobScopeFromDictionaryArray{
    NSString *string =[[NSString alloc]init];
    for (NSMutableDictionary *dict in _selectedjobScopeDictArray) {
        if ([dict objectForKey:kCLTargetJobsJobScopeGroupNameKey]) {
            NSString *stringOne = [NSString stringWithFormat:@"%@ (%@)",[dict objectForKey:kCLTargetJobsJobScopeGroupNameKey],[dict objectForKey:kCLTargetJobsJobScopeKey]];
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",stringOne]];
        }
        else{
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kJobPreferenceJobScopeNameKey]]];
        }
        
        
    }
    return string;
}

-(NSString*)getStringValueForCareerLevelFromDictionaryArray{
    NSMutableString *string =[[NSMutableString alloc]init];
    for (NSMutableDictionary *dict in self.selectedCareerlevelDictArray) {
//        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:jobLevelDetailDictName]]];
        [string appendString:[NSString stringWithFormat:@"%@|",[dict objectForKey:jobLevelDetailDictName]]];
    }
    return string;
}

-(NSString*)getStringValueForJobFunctionFromDictionaryArray{
    NSString *string =[[NSString alloc]init];
    
    NSMutableArray *fnCatArray1 = [self.selectedFunctionDict valueForKeyPath:kCLTargetJobsNewFnCategory];
    
    if([fnCatArray1 count])
    {
        for (NSMutableDictionary *dict in fnCatArray1)
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsNewFnCategory]]];
        }
    }
    
    NSMutableArray *fnCatArray2 = [self.selectedFunctionDict valueForKeyPath:kCLJobPreferenceFinctionsKey];
    
    if([fnCatArray2 count])
    {
        for (NSMutableDictionary *dict in fnCatArray2)
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLJobPreferenceFinctionsKey]]];
        }
    }
    
    NSMutableArray *fnCatArray3 = [self.selectedFunctionDict valueForKeyPath:@"OtherFunction"];
    
    if([fnCatArray3 count])
    {
        for (NSMutableDictionary *dict in fnCatArray3)
        {
           string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]]];
        }
    }

    NSMutableArray *fnCatArray4 = [self.selectedFunctionDict valueForKeyPath:@"functionGroup"];
    
    if([fnCatArray4 count])
    {
        for (NSMutableDictionary *dict in fnCatArray4)
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLJobPreferenceFinctionsKey]]];
        }
    }

    
  /*  for (NSMutableDictionary *dict in self.selecetedJobFunctionArray) {
        if ([[dict objectForKey:kCLJobPreferenceJobFunctionOtherFlag]boolValue]) {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLJobPreferenceJobFunctionKey],[dict objectForKey:kCLJobPreferenceFinctionsKey]]];
        }
        else{
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLJobPreferenceFinctionsKey]]];
        }
    }*/
    return string;
}

-(NSString*)getStringValueForPreferredJobsFromDictionaryArray{
    NSString *string = [[NSString alloc]init];
    for (NSMutableDictionary *dict in self.selectedpreferredJobsArray) {
        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsPreferredJobKey]]];
    }
    return string;
}

-(NSString*)getStringValueForindustryFromDictionaryArray
{
    NSString *string = [[NSString alloc]init];
    
    for (NSMutableDictionary *dict in self.selectedindustry)
    {
        if ([[dict objectForKey:@"IndSect"] count])
        {
            NSArray *result = [dict valueForKeyPath:@"IndSect"];
            
            for (NSMutableDictionary *dict in result)
            {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustrySectName]]];
            }
        }
        if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
        {
            NSArray *result = [dict valueForKeyPath:kCLTargetJobsNewindustry];
            
            for (NSMutableDictionary *dict in result)
            {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
            }
        }
        if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
        {
            NSArray *result = [dict valueForKeyPath:kCLTargetJobsMainindustry];
            
            for (NSMutableDictionary *dict in result)
            {
                //otherINside
                if (![[dict objectForKey:kCLTargetJobsindustry] isEqualToString:@""] && [[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] ) {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
                }
                else if ([[dict objectForKey:kCLTargetJobsindustry]isEqualToString:@""] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName],[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
                }
                //simpleSelected
                else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [dict objectForKey:kCLTargetJobsIndustryGrpOther] == nil && [dict objectForKey:kCLTargetJobsindustrySectCode] == nil && [dict objectForKey:kCLTargetJobsindustrySectName] == nil) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
                }
                //sectionOther
                else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue] && [dict objectForKey:kCLTargetJobsindustrySectCode] != nil && [dict objectForKey:kCLTargetJobsindustrySectName] != nil){
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName], [dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
                }
                
                else if ([[dict objectForKey:kCLTargetJobsIndustryAll]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustrySectName]]];
                }
                //main
                else{
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
                }

            }
        }
        if ([[dict objectForKey:@"OtherIndustry"] count])
        {
            NSArray *result = [dict valueForKeyPath:@"OtherIndustry"];
            
            for (NSMutableDictionary *dict in result)
            {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"Other - %@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
            }
        }

//            if([self.theSelectedindustry count])
//            {
//                NSArray *listItems = [string componentsSeparatedByString:@"|"];
//                
//                for (NSMutableDictionary *dict in self.theSelectedindustry)
//                {
//                    NSString *industryGroupName = [dict objectForKey:kCLTargetJobsindustryGroupNameKey];
//                    
//                    if(industryGroupName.length)
//                    {
//                        if (! [listItems containsObject: industryGroupName] )
//                        {
//                             string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
//
//                        }
//                    }
//                }
//
//            }
        
        //otherINside
       /* if (![[dict objectForKey:kCLTargetJobsindustry] isEqualToString:@""] && [[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] )
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
        }
        else if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
        {
            NSArray *result = [dict valueForKeyPath:kCLTargetJobsNewindustry];
            
            for (NSMutableDictionary *dict in result)
            {
                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
            }
        }
        else if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
        {
            NSArray *result = [dict valueForKeyPath:kCLTargetJobsindustry];
            
            for (NSMutableDictionary *dict in result)
            {
                if (![[dict objectForKey:kCLTargetJobsindustry] isEqualToString:@""] && [[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] )
                {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
                }
            }
        }
        else if ([[dict objectForKey:kCLTargetJobsindustry]isEqualToString:@""] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue])
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName],[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
        }

        else if ([[dict objectForKey:kCLTargetJobsindustry]isEqualToString:@""] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue])
        {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName],[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
        }
        
        
        //otherINside
//            if (![[dict objectForKey:kCLTargetJobsindustry] isEqualToString:@""] && [[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] ) {
//                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey],[dict objectForKey:kCLTargetJobsindustry]]];
//            }
//            else if ([[dict objectForKey:kCLTargetJobsindustry]isEqualToString:@""] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
//                string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName],[dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
//            }
        //simpleSelected
        else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [dict objectForKey:kCLTargetJobsIndustryGrpOther] == nil && [dict objectForKey:kCLTargetJobsindustrySectCode] == nil && [dict objectForKey:kCLTargetJobsindustrySectName] == nil) {
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustryGroupNameKey], [dict objectForKey:kCLTargetJobsindustry]]];
        }
        //sectionOther
        else if ([dict objectForKey:kCLTargetJobsIndustryAll] == nil && [[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue] && [dict objectForKey:kCLTargetJobsindustrySectCode] != nil && [dict objectForKey:kCLTargetJobsindustrySectName] != nil){
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@(%@)|",[dict objectForKey:kCLTargetJobsindustrySectName], [dict objectForKey:kCLTargetJobsindustryGroupNameKey]]];
        }
        
        else if ([[dict objectForKey:kCLTargetJobsIndustryAll]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryOther]boolValue] && ![[dict objectForKey:kCLTargetJobsIndustryGrpOther]boolValue]){
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustrySectName]]];
        }
        //main
        else{
            string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLTargetJobsindustry]]];
        }
        */
    }
    
    return string;
}

-(CGFloat)getHeightForTokenFieldWithText:(NSString*)text{
    [self.tokenTxtField setFont:[UIFont systemFontOfSize:13]];
    [self.tokenTxtField setPromptText:nil];
    [self.tokenTxtField removeAllTokens];
    [self.tokenTxtField addTokensWithTitleList:text];
    [self.tokenTxtField layoutTokensAnimated:NO];
    self.tokenTxtField.backgroundColor = [UIColor redColor];
    //NSLog(@"Height = %f",self.tokenTxtField.frame.size.height);
    //return self.tokenTxtField.bounds.size.height;
     return self.tokenTxtField.frame.size.height;
}

-(void)targetjobsSummaryDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.navigationController.view animated:YES];
//    self.tableView.hidden = YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLTargetJobsObject targetJobsSummaryForUser:[CLUserObject currentUser].userID lang:@"en" success:^(CLTargetJobsObject *targetJobsObj){
        self.targetJobsObject = targetJobsObj;
        [self loadtargetObjectIntoTable];
        [self.tableView reloadData];
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:_selectedRow];
        [self.tableView scrollToRowAtIndexPath:indexPath
                              atScrollPosition:UITableViewScrollPositionTop
                                      animated:NO];
        
 //       self.tableView.hidden = NO;;
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.rightBarButtonItem.enabled=YES;

    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't Load Target Jobs. Please try again later.", @"Error message when target jobs cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];

    }];
    

}

-(void)saveTargetJobs{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    self.navigationItem.hidesBackButton=YES;
    self.navigationItem.rightBarButtonItem.enabled=NO;

    CLTargetJobsObject *newTarObj = [[CLTargetJobsObject alloc]init];
    newTarObj.preferredJobArray = self.selectedpreferredJobsArray;
    newTarObj.industryArray = self.theSelectedindustry;
    newTarObj.functionArray = self.theSelectedfunction;
    newTarObj.careerLevelArray = self.selectedCareerlevelDictArray;
    newTarObj.jobScopeArray = self.selectedjobScopeDictArray;
    newTarObj.anythingElseString = self.anythingElseString;
    
    [CLTargetJobsObject saveTargetJobs:newTarObj forUser:[CLUserObject currentUser].userID forlang:@"en" success:^(NSString *tarId){
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    }failure:^(NSString *erreo){
        self.navigationItem.hidesBackButton=NO;
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Target Jobs. Please try again later.", @"Error message when target job cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];

    }];
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)loadtargetObjectIntoTable{
    self.selectedCareerlevelDictArray = self.targetJobsObject.careerLevelArray;
    self.selectedjobScopeDictArray = self.targetJobsObject.jobScopeArray;
    self.selectedFunctionDict = [[NSMutableDictionary alloc]initWithDictionary:self.targetJobsObject.functionDict];
    //self.selecetedJobFunctionArray = self.targetJobsObject.functionArray;
    self.selectedpreferredJobsArray = self.targetJobsObject.preferredJobArray;
    self.selectedindustry = [[[NSMutableArray alloc]initWithArray:self.targetJobsObject.industryArray]mutableCopy];
    self.anythingElseString = self.targetJobsObject.anythingElseString;
    
    //Industry
    self.theSelectedindustry = [[NSMutableArray alloc]init];
    NSMutableArray *theArray = [[NSMutableArray alloc]init];
    
    for (NSMutableDictionary *dict in self.selectedindustry)
    {
        if ([[dict objectForKey:@"IndSect"] count])
        {
            NSMutableArray *result = [[dict valueForKeyPath:@"IndSect"]mutableCopy];
            for (NSMutableDictionary *tempDict in result)
            {
                NSMutableArray *tempArr = [[NSMutableArray alloc]initWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                                       @"1",@"industryAll",
                                                                                       @"0",@"industryOther",
                                                                                       @"0",@"industryGrpOther",
                                                                                       [tempDict objectForKey:@"industrySectCode"],@"industrySectCode",
                                                                                  
                                                                                       [tempDict objectForKey:@"industrySectName"],
                                                                                       @"industrySectName",
                                                                                       @"",@"industry",
                                                                                       @"",@"industryCode",
                                                                                       @"",@"industryGroupCode",
                                                                                       @"",@"industryGroupName",
                                                                                       @"",@"industrySubName",nil], nil];
                
                [theArray addObjectsFromArray:tempArr];

            }
        }
        else
        {
            NSMutableArray *result = [[NSMutableArray alloc]init];
            NSMutableDictionary *newDict1 = [[NSMutableDictionary alloc]init];
            [newDict1 setValue:result forKey:@"IndSect"];
            [self.selectedindustry addObject:newDict1];

        }
        
        
        if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
        {
            NSArray *result = [dict valueForKeyPath:kCLTargetJobsNewindustry];
            
            for (NSMutableDictionary *dict in result)
            {
                NSMutableArray *arr = [[CLCoreDataHelper sharedCLCoreDataHelper] getMainIndustriesListForGroup:dict];
                [self addIndustryGroupNameto:arr];
                [theArray addObjectsFromArray:arr];
            }
        }
        else
        {
            NSMutableArray *result = [[NSMutableArray alloc]init];
            NSMutableDictionary *newDict1 = [[NSMutableDictionary alloc]init];
            [newDict1 setValue:result forKey:kCLTargetJobsNewindustry];
            [self.selectedindustry addObject:newDict1];
            
        }
        
        if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
        {
            NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsMainindustry]mutableCopy];
            [theArray addObjectsFromArray:result];
        }
        else
        {
            NSMutableArray *result = [[NSMutableArray alloc]init];
            NSMutableDictionary *newDict1 = [[NSMutableDictionary alloc]init];
            [newDict1 setValue:result forKey:kCLTargetJobsMainindustry];
            [self.selectedindustry addObject:newDict1];
            
        }
        
        if ([[dict objectForKey:@"OtherIndustry"] count])
        {
            NSMutableArray *result = [[dict valueForKeyPath:@"OtherIndustry"]mutableCopy];
            [theArray addObjectsFromArray:result];
        }
        else
        {
            NSMutableArray *result = [[NSMutableArray alloc]init];
            NSMutableDictionary *newDict1 = [[NSMutableDictionary alloc]init];
            [newDict1 setValue:result forKey:@"OtherIndustry"];
            [self.selectedindustry addObject:newDict1];
            
        }

    }
    
    if([self.selectedindustry count] == 0)
    {
        NSMutableArray *result = [[NSMutableArray alloc]init];

        NSMutableArray *array1=[[NSMutableArray alloc]initWithObjects:result,result,result, result, nil];
        NSMutableArray *array2=[[NSMutableArray alloc]initWithObjects:@"IndSect",kCLTargetJobsNewindustry,kCLTargetJobsMainindustry,@"OtherIndustry", nil];
        
        NSMutableDictionary * dic=[NSMutableDictionary new];
        for(int i=0 ; i< array2.count ; i++ ){
            [dic setObject:array1[i] forKey:array2[i]];
        }
        
        self.selectedindustry = [@[dic]mutableCopy];

    }
    
    //Functions
    self.theSelectedfunction = [[NSMutableArray alloc]init];
    NSMutableArray *fnArray = [[NSMutableArray alloc]init];
    
    NSMutableArray *fnCatArray1 = [self.selectedFunctionDict valueForKeyPath:kCLTargetJobsNewFnCategory];
    
    if([fnCatArray1 count])
    {
        for (NSMutableDictionary *dict in fnCatArray1)
        {
            NSString *code= [dict objectForKey:@"functionCategoryCode"];
            NSString *fnGroupCode = [dict objectForKey:@"functionGroupName"];
            NSMutableArray *arr = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobFunctionsForCategoryId:code];
            
            [arr removeLastObject];
            
            for (NSMutableDictionary *dict in arr)
            {
                [dict setValue:fnGroupCode forKey:@"functionGroupName"];
                
                NSString *fnName = [NSString stringWithFormat:@"%@(%@)",fnGroupCode,[dict objectForKey: @"functionName"]];
                [dict setObject:fnName forKey: @"function"];
            }
            
            [fnArray addObjectsFromArray:arr];

        }
    }
    
    NSMutableArray *fnCatArray2 = [self.selectedFunctionDict valueForKeyPath:@"function"];
    if([fnCatArray2 count])
    {
        for (NSMutableDictionary *dict in fnCatArray2)
        {
            NSString *code= [dict objectForKey:@"functionCode"];
            NSString *fnGroupCode = [dict objectForKey:@"functionGroupName"];
            NSString *fnName= [dict objectForKey:@"function"];
            NSMutableArray *arr = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobFunctionsForFnId:code];
            
            for (NSMutableDictionary *dict in arr)
            {
                [dict setValue:fnGroupCode forKey:@"functionGroupName"];
                [dict setValue:fnName forKey:@"function"];
            }

            [fnArray addObjectsFromArray:arr];
        }
    }
    NSMutableArray *fnCatArray3 = [self.selectedFunctionDict valueForKeyPath:@"OtherFunction"];
    if([fnCatArray3 count])
    {
        for (NSMutableDictionary *dict in fnCatArray3)
        {
            [fnArray addObject:dict];
        }
    }
    
    NSMutableArray *fnCatArray4 = [self.selectedFunctionDict valueForKeyPath:@"functionGroup"];
    if([fnCatArray4 count])
    {
        for (NSMutableDictionary *dict in fnCatArray4)
        {
            [fnArray addObject:dict];
        }
    }

    if([self.selectedFunctionDict count] == 0)
    {
        NSMutableArray *result = [[NSMutableArray alloc]init];
        
        NSMutableArray *array1=[[NSMutableArray alloc]initWithObjects:result,result,result, result, nil];
        NSMutableArray *array2=[[NSMutableArray alloc]initWithObjects:@"IndSect",kCLTargetJobsNewindustry,kCLTargetJobsMainindustry,@"OtherIndustry", nil];
        
        NSMutableDictionary * dic=[NSMutableDictionary new];
        for(int i=0 ; i< array2.count ; i++ ){
            [dic setObject:array1[i] forKey:array2[i]];
        }
        
        self.selectedindustry = [@[dic]mutableCopy];

    }
    
    if([theArray count])
        [self.theSelectedindustry addObjectsFromArray:theArray];
    
    if([fnArray count])
        [self.theSelectedfunction addObjectsFromArray:fnArray];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}
#pragma mark - Delete industry delegate method
- (void)selectIndustryControllerDidDeleteIndustry:(CLIndustrySectorViewController*)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
    
    self.selectedindustry = industryArray;
    self.theSelectedindustry = listArray;
    
    [self.tableView reloadData];
}
#pragma mark - add Other industry group

-(void)industryGroupViewController:(CLIndustryGroupViewController *)controller didAddOtherIndustryGroup:(NSMutableDictionary *)selectedOtherGroup andListArray:(NSMutableArray *)listArray{
    
    self.selectedindustry = listArray;
    [self.theSelectedindustry addObject:selectedOtherGroup];
    [self.tableView reloadData];
}

#pragma mark - select industry delegate
-(void)selectIndustryControllerDidSelectIndustry:(CLIndustryViewController *)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
    
    self.selectedindustry = listArray;
    [self.theSelectedindustry addObjectsFromArray:industryArray];
    
    [self.tableView reloadData];
}

-(NSMutableArray*)addIndustryGroupNameto:(NSMutableArray*)array
{
    for (NSMutableDictionary *dict in array)
    {
        NSString *industryGroupCode = [dict objectForKey:kCLTargetJobsIndustryGroupCode];
        NSString *groupName = [[CLCoreDataHelper sharedCLCoreDataHelper] getIndustryGroupNamefrom:industryGroupCode];
        [dict setValue:groupName forKey:kCLTargetJobsindustryGroupNameKey];
    }
    return array;
}

-(NSMutableArray*)addFnGroupNameto:(NSMutableArray*)array
{
    for (NSMutableDictionary *dict in array)
    {
        NSString *GroupCode = [dict objectForKey:@"jobFunctionGroupCode"];
        NSString *groupName = [[CLCoreDataHelper sharedCLCoreDataHelper] getFunctionGroupNamefrom:GroupCode];
        [dict setValue:groupName forKey:@"functionGroupName"];
    }
    return array;
}



@end
