//
//  CLInboxListingCell.m
//  CareerLine
//
//  Created by CSG on 3/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxListingCell.h"
#import "CLUserObject.h"
#import "UIImageView+WebCache.h"

@interface CLInboxListingCell()

@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property (weak, nonatomic) IBOutlet UIImageView *companyLogoImageView;
@property (weak, nonatomic) IBOutlet UILabel *lblTimeOfPost;
@property (weak, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (weak, nonatomic) IBOutlet UILabel *lblPositionName;
@property (weak, nonatomic) IBOutlet UILabel *lblLastMessage;
@property (weak, nonatomic) IBOutlet UIImageView *imgMailUnreadStatus;
@end

@implementation CLInboxListingCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLInboxListingCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)updateCellContent{
    self.lblTimeOfPost.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.lblTimeOfPost.text=self.inbox.inboxEntryDate;
    self.lblPositionName.text=self.inbox.inboxJob.jobTitle;
    self.lblCompanyName.text=self.inbox.inboxJob.companyDetails.companyName;
    self.lblLastMessage.text=self.inbox.inboxLastMsg;
    
//    [self.companyLogoImageView setImageWithURL:[NSURL URLWithString:[self.inbox.inboxJob.companyDetails.companyLogoUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]]
//                              placeholderImage:[UIImage imageNamed:@"company_placeholder"]
//                                     completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//                                         if (image && cacheType == SDImageCacheTypeNone)
//                                         {
//                                             self.companyLogoImageView.alpha = 0.0;
//                                             [UIView animateWithDuration:1.0
//                                                              animations:^{
//                                                                  self.companyLogoImageView.alpha = 1.0;
//                                                              }];
//                                         }
//                                     }];
    
    [self.companyLogoImageView sd_setImageWithURL:[NSURL URLWithString:self.inbox.inboxJob.companyDetails.companyLogoUrl] placeholderImage:[UIImage imageNamed:@"company_placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (image && cacheType == SDImageCacheTypeNone)
        {
            self.companyLogoImageView.alpha = 0.0;
            [UIView animateWithDuration:1.0
                             animations:^{
                                 self.companyLogoImageView.alpha = 1.0;
                             }];
        }
    }];
    
    self.imgMailUnreadStatus.image=[self getUnreadStatusImageforStatus:self.inbox.inboxThreadReadStatus];
}

-(UIImage*)getUnreadStatusImageforStatus:(int)readStatus{
    if (readStatus==1) {
        return nil;
    }
    else{
        switch ([CLUserObject currentUser].trafficLightStatus) {
            case CLTrafficLightRedColor:
                return [UIImage imageNamed:@"msg_unread_red"];
                break;
            case CLTrafficLightGreenColor:
                return [UIImage imageNamed:@"msg_unread_green"];
                break;
            case CLTrafficLightAmberColor:
                return [UIImage imageNamed:@"msg_unread_orange"];
                break;
            default:
                return [UIImage imageNamed:@"msg_read"];
                break;
        }
    }
}

@end
