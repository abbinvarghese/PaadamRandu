//
//  CLInterest.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInterestObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLInterestObject

static NSOperationQueue *saveInterestRequest;
static NSOperationQueue *deleteInterestRequest;
static NSOperationQueue *getHobbiesForSearchStringrequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.interestId=[dictionary objectForKeyNotNull:kCLProfileAboutMeInterestMainIdkey];
    self.interestArray=[dictionary objectForKeyNotNull:kCLProfileAboutMeInterestListArraykey];
    self.interestDescription=[dictionary objectForKeyNotNull:kCLProfileAboutMeInterestDescriptionkey];
    self.interestFormattedTitle=[self titleFormattedForDisplay];
    
    return self;
}

-(NSString*)titleFormattedForDisplay{
    NSMutableString *formattedString=[[NSMutableString alloc] init];
    
    for (int i=0; i<[self.interestArray count]; i++) {
        NSDictionary *tempDict=[self.interestArray objectAtIndex:i];
        [formattedString appendFormat:@"%@, ",[tempDict objectForKey:kCLProfileAboutMeInterestTitlekey]];
    }
    if (formattedString.length>1) {
        [formattedString deleteCharactersInRange:NSMakeRange([formattedString length]-2, 2)];
    }
    
    return formattedString;
}

-(void)updateFormattedHobbyTitle{
    self.interestFormattedTitle=[self titleFormattedForDisplay];
}

+ (void)cancelGetHobbiesRequest{
    [getHobbiesForSearchStringrequest cancelAllOperations];
    getHobbiesForSearchStringrequest = nil;
}

+(NSString*)jsonStringForObject:(CLInterestObject*)interestObj{
    NSMutableDictionary *interestDict=[[NSMutableDictionary alloc] init];
    
    [interestDict setObject:interestObj.interestDescription forKey:kCLProfileAboutMeInterestDescriptionkey];
    [interestDict setObject:interestObj.interestArray forKey:kCLProfileAboutMeInterestListArraykey];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:interestDict];
}

//Method for saving interest of a particular user...
+ (void)saveInterest:(CLInterestObject *)interestObj ForUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *interestId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *interestId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"id":interestObj.interestId, @"fields":[CLInterestObject jsonStringForObject:interestObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLInterestObject jsonStringForObject:interestObj]};
    }
    
    [saveInterestRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveInterestRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeSaveInterestURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"save interest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAboutMeSaveInterestIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting interest for a particular user...
//+ (void)deleteInterestForUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
//    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
//    if (failure == nil) {
//        failure = ^(NSString *error){};
//    }
//    if (success == nil) {
//        success = ^(){};
//    }
//    
//    NSDictionary *parameters = @{@"user": userId};
//    
//    [deleteInterestRequest cancelAllOperations];
//    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
//    deleteInterestRequest=manager.operationQueue;
//    manager.responseSerializer=[AFJSONResponseSerializer serializer];
//    [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeDeleteInterestURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSDictionary *response=(NSDictionary *)responseObject;
//        if (kDebugMessages) {
//            NSLog(@"delete interest JSON: %@", response);
//        }
//        if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
//            failure([response objectForKey:@"message"]);
//        }
//        else{
//            success([response objectForKey:kCLProfileAboutMeDeleteInterestIdkey]);
//        }
//        
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        if (kDebugMessages) {
//            NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
//        }
//        failure([CLCommon getMessageForErrorCode:error.code]);
//    }];
//}

+(void)getHobbiesListForSearchString:(NSString*)searchText andBlackListString:(NSString*)blackListString success:(void (^)(NSMutableArray *hobbiesList))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *locationList){};
    }
    
    NSDictionary *parameters = @{@"hob_str": searchText, @"id": blackListString};
    
    [getHobbiesForSearchStringrequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getHobbiesForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeListHobbiesURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"hobbies JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *hobbies=[[NSMutableArray alloc] init];
                NSArray *results=[response objectForKey:@"results"];
                for (int i=0; i<[results count]; i++) {
                    NSDictionary *hobDetail=[results objectAtIndex:i];
                    [hobbies addObject:hobDetail];
                }
                success(hobbies);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
