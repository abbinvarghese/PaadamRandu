//
//  CLInboxDetailCell.h
//  CareerLine
//
//  Created by CSG on 3/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLInboxDetailCell : UITableViewCell

@property(strong, nonatomic) NSDictionary *msgDict;
@property(strong, nonatomic) NSString *cmpnyName;

-(void)updateCellContent;

@end
