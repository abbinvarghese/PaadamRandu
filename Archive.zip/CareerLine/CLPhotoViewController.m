//
//  CLPhotoViewController.m
//  CareerLine
//
//  Created by CSG on 7/23/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPhotoViewController.h"
#import "CLFileObject.h"
#import "SDWebImageDownloader.h"
#import "UIImageView+WebCache.h"

@interface CLPhotoViewController ()

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityView;
@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *doubleTapGesture;
//@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *singleTapGesture;

@property(nonatomic,assign)BOOL isZoomed;
@property(nonatomic,assign)BOOL isFullScreen;
@property(nonatomic,assign)BOOL intialCenteringDone;
@property(nonatomic,strong) NSArray *imageUrlArray;
@end

@implementation CLPhotoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    if (!self.intialCenteringDone) {
        //[self.singleTapGesture requireGestureRecognizerToFail:self.doubleTapGesture];
        CLFileObject *photoObj=[self.imageUrlArray objectAtIndex:self.pageIndex];
        //old
        //[NSURL URLWithString:[photoObj.file stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]]
        [self.activityView startAnimating];
        [[SDWebImageDownloader sharedDownloader]
         downloadImageWithURL:[NSURL URLWithString:photoObj.file]
         options:SDWebImageDownloaderUseNSURLCache
         progress:nil
         completed:^(UIImage *image, NSData *data, NSError *error, BOOL finished) {
             [self.activityView stopAnimating];
             if (!error) {
                 self.imageView = [[UIImageView alloc] initWithImage:image];
                 self.imageView.frame = CGRectMake(0, 0, image.size.width, image.size.height);
                 [self.scrollView addSubview:self.imageView];
                 
                 self.scrollView.contentSize = image.size;
                 
                 CGRect scrollViewFrame = self.scrollView.frame;
                 CGFloat scaleWidth = scrollViewFrame.size.width / self.scrollView.contentSize.width;
                 CGFloat scaleHeight = scrollViewFrame.size.height / self.scrollView.contentSize.height;
                 CGFloat minScale = MIN(scaleWidth, scaleHeight);
                 
                 self.scrollView.minimumZoomScale = minScale;
                 self.scrollView.maximumZoomScale = 1.0f;
                 self.scrollView.zoomScale = minScale;
                 
                 [self centerScrollViewContents];
             }
             else{
                 NSLog(@"error=%@",error.localizedDescription);
             }
         }];
         self.intialCenteringDone=YES;
    }
}

#pragma mark Utility Methods

+ (CLPhotoViewController *)photoViewControllerForPageIndex:(NSUInteger)pageIndex andPhotos:(NSArray*)photos
{
    if (pageIndex < [photos count])
    {
        return [[CLPhotoViewController alloc] initWithPageIndex:pageIndex andPhotoUrls:photos];
    }
    return nil;
}

- (id)initWithPageIndex:(NSInteger)pageIndex andPhotoUrls:(NSArray*)photosUrls
{
    self = [super initWithNibName:nil bundle:nil];
    if (self != nil)
    {
        self.scrollView.decelerationRate=UIScrollViewDecelerationRateFast;
        self.isZoomed=NO;
        self.isFullScreen=NO;
        self.intialCenteringDone=NO;
        self.pageIndex = pageIndex;
        self.imageUrlArray=photosUrls;
    }
    return self;
}

- (void)centerScrollViewContents {
    UIView *subView = [self.scrollView.subviews objectAtIndex:0];
    
    CGFloat offsetX = MAX((self.scrollView.bounds.size.width - self.scrollView.contentSize.width) * 0.5, 0.0);
    CGFloat offsetY = MAX((self.scrollView.bounds.size.height - self.scrollView.contentSize.height) * 0.5, 0.0);
    
    subView.center = CGPointMake(self.scrollView.contentSize.width * 0.5 + offsetX,
                                 self.scrollView.contentSize.height * 0.5 + offsetY);
}

#pragma mark UIScrollView Delegate

- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    // Return the view that we want to zoom
    return self.imageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    [self centerScrollViewContents];
}

#pragma mark UIGestureRecognizer Methods

- (IBAction)doubleTapped:(id)sender {
    //on a double tap, set the zoomscale for UIScrollView
    if(self.isZoomed){
        [self.scrollView setZoomScale:self.scrollView.minimumZoomScale animated:YES];
        self.isZoomed=NO;
    }
    else{
        [self.scrollView setZoomScale:self.scrollView.maximumZoomScale animated:YES];
        self.isZoomed=YES;
    }
}

//- (IBAction)singleTapped:(id)sender {
//    if (self.isFullScreen) {
//        [self.activityView setColor:[UIColor grayColor]];
//        [self.view setBackgroundColor:[UIColor whiteColor]];
//        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(photoViewDidSingleTap:forFullScreen:)]){
//            [self.delegate photoViewDidSingleTap:self forFullScreen:NO];
//            self.isFullScreen=NO;
//        }
//    }
//    else{
//        [self.activityView setColor:[UIColor whiteColor]];
//        [self.view setBackgroundColor:[UIColor grayColor]];
//        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(photoViewDidSingleTap:forFullScreen:)]){
//            [self.delegate photoViewDidSingleTap:self forFullScreen:YES];
//            self.isFullScreen=NO;
//        }
//    }
//}

@end
