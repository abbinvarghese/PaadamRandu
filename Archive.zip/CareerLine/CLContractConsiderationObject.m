//
//  CLContractConsiderationObject.m
//  CareerLine
//
//  Created by Abbin on 19/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLContractConsiderationObject.h"
#import "AFHTTPRequestOperationManager+Timeout.h"
#import "CLConstants.h"
#import "CLContractPreferencesObject.h"

#define kDebugMessages 0

@implementation CLContractConsiderationObject

static NSOperationQueue *contractConsiderationsSummeryRequest;
static NSOperationQueue *saveWorkConsiderationRequest;


+(void)cancelContractConsiderationSummeryRequest{
    [contractConsiderationsSummeryRequest cancelAllOperations];
    contractConsiderationsSummeryRequest = nil;
}

- (id)initWithDictionary:(NSDictionary*)dictionary{
    self = [super init];
    if (self == nil) return nil;
    
    self.whenCanYouStartDictionary = [[dictionary objectForKey:kCLContractConsiderationkey] objectForKey:kCLContractConsiderationavailabilitykey];
    self.anythingsElseString = [[dictionary objectForKey:kCLContractConsiderationkey] objectForKey:kCLContractConsiderationAnythingElsekey];
    self.preferenceObjArray = [self initializePreferenceArrayWithObjectsFrom:[[dictionary objectForKey:kCLContractConsiderationkey] objectForKey:kCLContractConsiderationPreferencekey]];
    return self;
}

-(NSMutableArray*)initializePreferenceArrayWithObjectsFrom:(NSMutableArray*)array{
    NSMutableArray * arr = [[NSMutableArray alloc]init];
    for (NSMutableDictionary *dict in array) {
        CLContractPreferencesObject * obj = [[CLContractPreferencesObject alloc]initWithDictionary:dict];
        [arr addObject:obj];
    }
    return arr;
}

+ (void)contractConsiderationSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLContractConsiderationObject *conObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLContractConsiderationObject *conObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"lang": lang};
    
    [contractConsiderationsSummeryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        contractConsiderationsSummeryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceContractConsiderationsSummaryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSMutableDictionary *response=(NSMutableDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLContractConsiderationObject *conObj=[[CLContractConsiderationObject alloc] initWithDictionary:response];
                success(conObj);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}



+ (void)saveContractConsideration:(CLContractConsiderationObject*)conObj forUser:(NSString*)userId forlang:(NSString*)lang success:(void (^)(NSString *conId))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *conId){};
    }
    NSDictionary *parameters =@{@"user": userId, @"fields":[CLContractConsiderationObject jsonStringForObject:conObj], @"lang": lang};
    [saveWorkConsiderationRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveWorkConsiderationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServicePostContractConsiderationsURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveContractConsiderationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLJobPreferenceIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
}

+(NSString*)jsonStringForObject:(CLContractConsiderationObject*)conObj{
    NSMutableDictionary *mainDict = [[NSMutableDictionary alloc]init];
    NSMutableDictionary *insideDict = [[NSMutableDictionary alloc]init];
//    NSMutableDictionary *availabilityDict = [[NSMutableDictionary alloc]init];
//    [availabilityDict setObject:[conObj.whenCanYouStartDictionary objectForKey:@"id"] forKey:@"id"];
//    [availabilityDict setObject:@"1" forKey:@"other"];
//    [availabilityDict setObject:@"" forKey:@"id"];
//    [availabilityDict setObject:@"ygygyggygygy" forKey:@"availabilityName"];
    if (conObj.whenCanYouStartDictionary != nil) {
        [insideDict setObject:conObj.whenCanYouStartDictionary forKey:kCLContractConsiderationavailabilitykey];
    }
    else{
        [insideDict setObject:@"" forKey:kCLContractConsiderationavailabilitykey];
    }
    if (conObj.anythingsElseString != nil) {
        [insideDict setObject:conObj.anythingsElseString forKey:kCLContractConsiderationAnythingElsekey];
    }
    else{
        [insideDict setObject:@"" forKey:kCLContractConsiderationAnythingElsekey];
    }
        if (conObj.preferenceObjArray.count != 0) {
        NSMutableArray *array = [[NSMutableArray alloc]init];
        for (CLContractPreferencesObject*obj in conObj.preferenceObjArray) {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
          //  NSMutableDictionary *employmentDict = [[NSMutableDictionary alloc]init];
          //  [employmentDict setObject:[obj.employMentTypeDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
         //   NSMutableDictionary *contractDict = [[NSMutableDictionary alloc]init];
         //   [contractDict setObject:[obj.contractTypeDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
         //   NSMutableDictionary *currentcyDict = [[NSMutableDictionary alloc]init];
         //   [currentcyDict setObject:[obj.currencyDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
         //   NSString *minimunSalary = obj.minimumSalary;
        //    NSMutableDictionary *salaryBasis = [[NSMutableDictionary alloc]init];
        //    [salaryBasis setValue:[obj.salaryBasisDict objectForKey:kCLContractConsiderationIdkey] forKey:kCLContractConsiderationIdkey];
            
        //    NSString *increaseSalary = obj.increaseInSalary;
       //     NSString *negotiable = obj.negotiable;
       //     NSString *other = obj.Other;
            if (obj.employMentTypeDict != nil) {
                [dict setObject:obj.employMentTypeDict forKey:kCLContractPreferenceemploymentTypekey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceemploymentTypekey];
            }
            
            if (obj.contractTypeDict != nil) {
                [dict setObject:obj.contractTypeDict forKey:kCLContractPreferenceemploymentContractkey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceemploymentContractkey];
            }
            if (obj.currencyDict != nil) {
                [dict setObject:obj.currencyDict forKey:kCLContractPreferenceCurrencykey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceCurrencykey];
            }
            if (obj.minimumSalary != nil) {
                [dict setObject:obj.minimumSalary forKey:kCLContractPreferenceMinSalarykey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceMinSalarykey];
            }
            
            if (obj.salaryBasisDict != nil && obj.salaryBasisDict.count != 0) {
                [dict setObject:obj.salaryBasisDict forKey:kCLContractPreferenceSalaryBasiskey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceSalaryBasiskey];
            }
            if (obj.increaseInSalary != nil) {
                [dict setObject:obj.increaseInSalary forKey:kCLContractPreferenceIncreaseSalarykey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceIncreaseSalarykey];
            }
            if (obj.negotiable != nil) {
                [dict setObject:obj.negotiable forKey:kCLContractPreferenceNegotiablekey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractPreferenceNegotiablekey];
            }
            if (obj.Other != nil) {
                [dict setObject:obj.Other forKey:kCLContractConsiderationOtherkey];
            }
            else{
                [dict setObject:@"" forKey:kCLContractConsiderationOtherkey];
            }
            
            
            
            
            
//            [dict setObject:employmentDict forKey:kCLContractPreferenceemploymentTypekey];
//            [dict setObject:contractDict forKey:kCLContractPreferenceemploymentContractkey];
//            [dict setObject:currentcyDict forKey:kCLContractPreferenceCurrencykey];
//            [dict setObject:minimunSalary forKey:kCLContractPreferenceMinSalarykey];
//            [dict setObject:salaryBasis forKey:kCLContractPreferenceSalaryBasiskey];
//            [dict setObject:increaseSalary forKey:kCLContractPreferenceIncreaseSalarykey];
//            [dict setObject:negotiable forKey:kCLContractPreferenceNegotiablekey];
//            [dict setObject:other forKey:kCLContractConsiderationOtherkey];
            
            
            
            [array addObject:dict];
            
        }
        [insideDict setObject:array forKey:kCLContractConsiderationPreferencekey];
    }
    else{
        NSMutableArray *array = [[NSMutableArray alloc]init];
        [insideDict setObject:array forKey:kCLContractConsiderationPreferencekey];
    }
    
    
    [mainDict setValue:insideDict forKey:kCLContractConsiderationkey];
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:mainDict];
}
@end
