//
//  CLProtfolioAchievementViewController.h
//  CareerLine
//
//  Created by CSG on 7/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLWorkAchievementObject.h"
#import "CLHeightAdjustTextCell.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLWorkAchievementViewController;

//Delegate Methods...
@protocol CLWorkAchievementControllerDelegate <NSObject>

@optional
- (void)workAchievementController:(CLWorkAchievementViewController *)controller didAddAchievement:(CLWorkAchievementObject*)workAchObj;

@end

@interface CLWorkAchievementViewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,UIPickerViewDelegate,UIPickerViewDataSource,CLProfilePhotoListingGridCellDelegate
,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLWorkAchievementControllerDelegate> delegate;
@property(nonatomic,strong)CLWorkAchievementObject *workAchObj;
@property(nonatomic,strong)NSMutableArray *relatedToArray;
@property(nonatomic,strong)NSString *wrkHisId;
@property(nonatomic,assign)BOOL isEditMode;

@end
