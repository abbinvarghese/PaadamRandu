//
//  CLCareerSummaryViewController.m
//  CareerLine
//
//  Created by RENJITH on 22/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerSummaryViewController.h"
#import "CLUserObject.h"

#define kintialTextViewHeight 43

@interface CLCareerSummaryViewController ()


@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;
@end

@implementation CLCareerSummaryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self; 
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = NSLocalizedString(@"Career Summary", @"Career summary edit page heading");
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.descriptionHeight=[[NSNumber alloc] init];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.descriptionText = self.careerSummary.summary;
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionCellIdentifier"];
    [self setRightNavigationButton];
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Career Summary modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCareerSummaryAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
    
}
-(BOOL)isFieldsValid{
    
    BOOL isValid=YES;
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([self.descriptionText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Profile Summary.", @"Error Message for Profile Summary field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return isValid;
}

-(IBAction)bttnActionCareerSummaryAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        [self.txtViewFirstResponder resignFirstResponder];
        [self saveCareerSummary];
    }
}

-(void)saveCareerSummary{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view animated:YES];
    
    self.navigationItem.leftBarButtonItem.enabled=NO;
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLCareerObject editCareerSummaryForUser:[CLUserObject currentUser].userID careerSummary:self.descriptionText success:^(NSString *successMsg) {
        self.careerSummary.summary = self.descriptionText;
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.navigationItem.leftBarButtonItem.enabled=YES;
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Career Summary. Please try again later.", @"Error message when career summary cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
        
    }];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat ansHeight;
    if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
        ansHeight= [self.descriptionHeight floatValue];
    }
    else{
        ansHeight= [self getTextViewSizeForText:self.descriptionText];
    }
    return MAX(44, ansHeight+1);
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CLHeightAdjustTextCell *careerSummaryCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
    careerSummaryCell.selectionStyle=UITableViewCellSelectionStyleNone;
    [careerSummaryCell setTextInputAccesoryView:self.keyboardResignView];
    [careerSummaryCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for Anything else you want to say about this")];
    [careerSummaryCell setCellCapitalization:UITextAutocapitalizationTypeWords];
    careerSummaryCell.text = self.descriptionText;
    [careerSummaryCell updateCellContents];
    if(self.descriptionHeight==nil){
        self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
    }
    [careerSummaryCell setCellIndexPath:indexPath];
    careerSummaryCell.delegate=self;
    return careerSummaryCell;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return NSLocalizedString(@"CAREER SUMMARY", @"career summary heading string");
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:13];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
    
}
#pragma mark Utility Methods
- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    [self.txtViewFirstResponder resignFirstResponder];
    
}
#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
    
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}
#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}
@end
