//
//  CLDocumentViewController.m
//  CareerLine
//
//  Created by CSG on 7/22/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLDocumentViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLDocumentViewController ()

@property (weak, nonatomic) IBOutlet UIWebView *documentWebView;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property(nonatomic,retain) NSMutableData *receivedData;
@property (weak, nonatomic) IBOutlet UITextField *captionField;
@property (weak, nonatomic) IBOutlet UIButton *saveButtonOut;
@property (strong, nonatomic) IBOutlet UIImageView *fileImgView;
@property(nonatomic,retain) NSString *captionString;
@end

@implementation CLDocumentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.captionField.autocapitalizationType = UITextAutocapitalizationTypeSentences;
    self.saveButtonOut.enabled = NO;
    
    self.documentWebView.scalesPageToFit = YES;
    
    // Do any additional setup after loading the view from its nib.
    if (self.fromDocument)
    {
        self.captionField.text = self.docObj.caption;
        self.title = self.docObj.fileTitle;
        NSString *fileExtension=[self.docObj.file substringFromIndex:MAX((int)[self.docObj.file length]-3, 0)];
        if ([fileExtension isEqualToString:@"pdf"])
        {
            NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:self.docObj.file]
                                                      cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                  timeoutInterval:60.0];
            NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
            
            [self startHUD];
            
            if (theConnection) {
                self.receivedData=[NSMutableData data];
            } else {
                // inform the user that the download could not be made
            }

        }
        else if ([fileExtension isEqualToString:@"jpg"] || [fileExtension isEqualToString:@"peg"] || [fileExtension isEqualToString:@"png"])
        {
//            NSURL *url = [NSURL URLWithString:self.docObj.file];
//            NSURLRequest *request = [NSURLRequest requestWithURL:url];
//            [self.documentWebView loadRequest:request];
            [self startHUD];
        }
        else
        {
            NSURL *url = [NSURL URLWithString:self.docObj.file];
            NSURLRequest *request = [NSURLRequest requestWithURL:url];
            [self.documentWebView loadRequest:request];
            
            self.documentWebView.autoresizesSubviews = NO;
            self.documentWebView.contentMode = UIViewContentModeScaleAspectFit; 
        }
    }
    else
    {
        self.captionField.text = self.documentObj.filecaption;
        if (self.documentObj.fileTitle==nil) {
            self.title=NSLocalizedString(@"Document", @"Document Page title");
        }
        else{
            self.title=self.documentObj.fileTitle;
        }
        
        //old
        //NSURL *url = [NSURL URLWithString:[self.documentObj.file stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
        NSURL *url = [NSURL URLWithString:self.documentObj.file];
        
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.documentWebView loadRequest:request];
    }
}

- (void)dealloc {
    //very important
    self.documentWebView = nil;
    self.documentWebView.delegate = nil;
    [self.documentWebView stopLoading];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Document Details"];
    
    if (self.fromDocument)
    {
        
    NSString *fileExtension=[self.docObj.file substringFromIndex:MAX((int)[self.docObj.file length]-3, 0)];
    __block NSData *fileData = nil;
    
    if (![fileExtension isEqualToString:@"pdf"])
    {
        dispatch_async( dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            fileData = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.docObj.file]];
            
            dispatch_async( dispatch_get_main_queue(), ^{
                
                UIImage *image = [UIImage imageWithData:fileData];
                
                self.fileImgView.image = image;
                
                self.fileImgView.userInteractionEnabled = YES;
                self.fileImgView.contentMode = UIViewContentModeScaleAspectFit;
                self.fileImgView.clipsToBounds = YES;
                
                [self.activityIndicator hideWithAnimation:YES];

            });
        });
    }
    
    
//    if (self.fromDocument)
//    {
//        
//        
//        
//            NSData *fileData = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.docObj.file]];
//            
//            UIImage *image = [UIImage imageWithData:fileData];
//            
//            self.fileImgView.image = image;
//            
//            self.fileImgView.userInteractionEnabled = YES;
//            self.fileImgView.contentMode = UIViewContentModeScaleAspectFit;
//            self.fileImgView.clipsToBounds = YES;
//            
//            [self.activityIndicator hideWithAnimation:YES];
//        }
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
}

#pragma mark UIWebView Delegates

- (void)webViewDidStartLoad:(UIWebView *)webView{
    if (!self.receivedData) {
        [self startHUD];
    }
}

-(void)startHUD{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if (!self.receivedData) {
        [self.activityIndicator hideWithAnimation:YES];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self.activityIndicator hideWithAnimation:YES];
    [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error.localizedDescription cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
}

#pragma mark Utility Methods

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}


#pragma mark NSURLConnection Delegates



- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [self.receivedData appendData:data];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    [self.activityIndicator hideWithAnimation:YES];
    [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error.localizedDescription cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    [self.documentWebView loadData:self.receivedData MIMEType:@"application/pdf" textEncodingName:@"utf-8" baseURL:nil];
    [self.activityIndicator hideAfterDelay:1 animated:YES];
    
}

- (IBAction)saveButtonAction:(id)sender {
    [self.view endEditing:YES];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    NSString *fileId;
    if (self.fromDocument) {
        fileId = self.docObj.fileId;
    }
    else{
        fileId = self.documentObj.fileId;
    }
    
    [CLUserObject updateCaption:self.captionField.text forDocId:fileId success:^(){
        self.saveButtonOut.enabled=NO;
        self.docObj.caption = self.captionField.text;
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    }ailure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Caption. Please try again later.", @"Error message when caption cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
    }];
    
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (![self.docObj.caption isEqualToString:textField.text]) {
        self.saveButtonOut.enabled = YES;
    }
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
}

- (IBAction)editingChanged:(UITextField *)sender {
    if (![self.docObj.caption isEqualToString:sender.text]) {
        self.saveButtonOut.enabled = YES;
        self.captionField.returnKeyType = UIReturnKeyGo;
    }
    if ([self.docObj.caption isEqualToString:sender.text]) {
        self.saveButtonOut.enabled = NO;
        self.captionField.returnKeyType = UIReturnKeyDefault;
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.view endEditing:YES];
    return YES;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

@end
