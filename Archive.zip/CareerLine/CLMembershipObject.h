//
//  CLMembershipObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"
#import "CLLocationObject.h"

@interface CLMembershipObject : NSObject

@property(nonatomic,strong)NSString *membershipId;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *clas;
@property(nonatomic,strong)NSString *number;
@property(nonatomic,strong)CLLocationObject *location;
@property(nonatomic,strong)NSDate *issuedOnDate;
@property(nonatomic,strong)NSDate *fromDate;
@property(nonatomic,strong)NSDate *toDate;
@property(nonatomic,strong)NSDate *completionDate;
@property(nonatomic,assign)BOOL isProgress;
@property(nonatomic,assign)BOOL isLifeValid;
@property(nonatomic,strong)NSString *contents;

@property(nonatomic,strong)NSMutableArray *documentsUrl;//[(CLFileObject),(CLFileObject),...]


- (id)initWithDictionary:(NSDictionary*)dictionary;

+ (void)saveMembership:(CLMembershipObject*)membershipObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *membershipId))success failure:(void (^)(NSString *error))failure;
@end
