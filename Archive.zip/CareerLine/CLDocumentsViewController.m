//
//  CLDocumentsViewController.m
//  CareerLine
//
//  Created by RENJITH on 11/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLDocumentsViewController.h"
#import "CLCollectionHomeViewCell.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLLoaderCell.h"
#import "CLDocumentsCell.h"
#import "CLDocumentViewController.h"
#import "CLAboutMeObject.h"

@interface CLDocumentsViewController ()

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UILabel *pullRefreshLabel;

@property(nonatomic,assign)int nextPageToLoad;                  //holds the next page number to load..
@property(nonatomic,assign)BOOL isLastPageReached;              //whether last page reached(received from backend)..
@property(nonatomic,assign)BOOL shouldPaginate;
@property(nonatomic,assign)BOOL isRetreivingDataForPagination;
@property(nonatomic,retain) NSMutableArray *documentsArray;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (nonatomic,retain) UIRefreshControl *refreshControl;
@property(nonatomic) BOOL didPullDownToRefresh;
@property(nonatomic,retain) NSTimer *timer;
@property(nonatomic) BOOL goForTimer;
@property(nonatomic) BOOL timerStarted;
@property(nonatomic) BOOL imagePickerPopped;
@property(nonatomic) NSInteger selectedIndex;

@end

@implementation CLDocumentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setRightNavigationButton];
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.tintColor = [UIColor grayColor];
    [self.refreshControl addTarget:self action:@selector(clearArraysAndReloadTableData) forControlEvents:UIControlEventValueChanged];
    [self.collectionView addSubview:self.refreshControl];
    self.collectionView.alwaysBounceVertical = YES;
}

-(void)viewWillAppear:(BOOL)animated{
   
    [super viewWillAppear:YES];
     [self.collectionView reloadData];
    self.pullRefreshLabel.hidden = YES;
    self.goForTimer = NO;
    self.didPullDownToRefresh = YES;
    [self.collectionView registerClass:[CLLoaderCell class] forCellWithReuseIdentifier:@"CLLoaderCell"];
    self.isLastPageReached = NO;
    self.documentsArray = [[NSMutableArray alloc]init];
    self.nextPageToLoad=1;
    self.shouldPaginate = YES;
    // Do any additional setup after loading the view, typically from a nib.
    self.title=NSLocalizedString(@"Documents", @"Documents page title");
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    [self setupLeftMenuButton];
    [self setupCollectionView];
   // [self retriveDocumentswithPagination:NO];
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    float scrollViewHeight = scrollView.frame.size.height;
    float scrollContentSizeHeight = scrollView.contentSize.height;
    float scrollOffset = scrollView.contentOffset.y;
    
    if (self.shouldPaginate) {
        if ((scrollOffset + scrollViewHeight >= scrollContentSizeHeight) && (scrollContentSizeHeight>0))
        {
            self.goForTimer = YES;
            [self retriveDocumentswithPagination:YES];
            self.shouldPaginate = NO;
        }
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [self.collectionView reloadData];
    if (!self.imagePickerPopped) {
        [self clearArraysAndReloadTableData];
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Document List"];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UICollectionView Methods

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (self.documentsArray.count > 0) {
        return [self.documentsArray count]+1;
    }
    else{
        return 0;
    }
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
//    if (self.isLastPageReached) {
//        CLDocumentsCell *lastcell = (CLDocumentsCell*) [self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
//        return lastcell;
//    }
//    else{
        if (indexPath.row == [self.documentsArray count]) {
            CLLoaderCell *footercell = (CLLoaderCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"CLLoaderCell" forIndexPath:indexPath];
            [footercell updateLoaderForPage:self.isLastPageReached];
            return footercell;
        }
        else{
//            CLCollectionHomeViewCell *cell = (CLCollectionHomeViewCell *)[self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
//            [cell updateContentsForIndexPath:indexPath];
//            return cell;
            
            CLDocumentsCell *cell = (CLDocumentsCell*) [self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
            if (self.documentsArray.count > 0) {
                [cell setDocObj:[self.documentsArray objectAtIndex:indexPath.row]];
                [cell updateCellForDocuments:[self.documentsArray objectAtIndex:indexPath.row]];
            }
            return cell;

        }
//    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView
                   layout:(CLCollectionViewMasonryLayout *)collectionViewLayout
 heightForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.isLastPageReached) {
        if (indexPath.row == self.documentsArray.count) {
            return 44;
        }
        else{
              return MAX(90, [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell]);

        }
    }
    else{
        if (indexPath.row == self.documentsArray.count) {
            return 0;
        }
        else{
       
            return MAX(90, [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell]);
        }
    }
    
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectedIndex = indexPath.row;
    
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *docAction = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"button title to cancel") destructiveButtonTitle:NSLocalizedString(@"Delete", @"button title to delete document") otherButtonTitles:NSLocalizedString(@"View Document", @"button title to view document"), nil];
        [docAction showInView:self.view];
    }
    else{
        UIAlertController *docAlert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *view = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"button title to view doucument") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
            
            CLDocumentViewController *controller = [[CLDocumentViewController alloc]initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            controller.fromDocument = YES;
            controller.docObj = [self.documentsArray objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:controller animated:YES];
            
        }];
        
        UIAlertAction *delet = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", @"button title for delete") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * action){
            [self deleteDocumentOfID:((CLDocsObject*)[self.documentsArray objectAtIndex:indexPath.row]).fileId];
        }];
        
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"cancel") style:UIAlertActionStyleCancel handler:nil];
        [docAlert addAction:delet];
        [docAlert addAction:view];
        [docAlert addAction:cancel];
        docAlert .view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:docAlert animated:YES completion:nil];
        
        
    }
}

#pragma mark UIACTIONSHEET

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        CLDocumentViewController *controller = [[CLDocumentViewController alloc]initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
        controller.fromDocument = YES;
        controller.docObj = [self.documentsArray objectAtIndex:self.selectedIndex];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (buttonIndex == 1){
        [self deleteDocumentOfID:((CLDocsObject*)[self.documentsArray objectAtIndex:self.selectedIndex]).fileId];
    }
}

#pragma mark Utility Functions

-(void)clearArraysAndReloadTable{
    //[self.documentsArray removeAllObjects];

}

-(void)clearArraysAndReloadTableData{
    self.goForTimer = NO;
    self.nextPageToLoad = 1;
    self.didPullDownToRefresh = YES;
    
    [self retriveDocumentswithPagination:NO];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}

-(float)getImageHeightForIndexPath:(NSIndexPath*)indexPath{
    
    if (indexPath.row==2) {
        
    }

    float imageWidth =0;
    float imageHeight=0;
    
    float imageViewWidth=((CLCollectionViewMasonryLayout*)self.collectionView.collectionViewLayout).itemWidth;
    
    NSString *fileExtension=[((CLDocsObject *)[self.documentsArray objectAtIndex:indexPath.row]).file substringFromIndex:MAX((int)[((CLDocsObject *)[self.documentsArray objectAtIndex:indexPath.row]).file length]-3, 0)];
    
    if ([fileExtension isEqualToString:@"doc"]) {
        imageWidth=60;
        imageHeight=60;
    }
    else{
        imageWidth=[((CLDocsObject *)[self.documentsArray objectAtIndex:indexPath.row]).imgWidth  floatValue];
        imageHeight=[((CLDocsObject *)[self.documentsArray objectAtIndex:indexPath.row]).imgHeight floatValue];
    }

    if(imageHeight == 0 && imageWidth == 0)
    {
        imageWidth=60;
        imageHeight=60;
    }
    
    float result=(imageViewWidth*imageHeight)/imageWidth;
    
    return result;
}

-(float)getTextSectionHeightForCell{
    return 70;
}

-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(void)setupCollectionView {
    [self.collectionView registerClass:[CLDocumentsCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    
    self.collectionView.delegate=self;
    self.collectionView.dataSource=self;
    
    CLCollectionViewMasonryLayout *masonryLayout = [[CLCollectionViewMasonryLayout alloc] init];
    masonryLayout.sectionInset = UIEdgeInsetsMake(20,10,10,10);
    masonryLayout.delegate = self;
    masonryLayout.columnCount = 2;
    masonryLayout.itemWidth = ([UIScreen mainScreen].bounds.size.width-30)/2;
    [self.collectionView setCollectionViewLayout:masonryLayout];
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self.collectionView reloadData];
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
             
-(void)retriveDocumentswithPagination:(BOOL)paginate{
 
    if (self.nextPageToLoad == 1 && self.didPullDownToRefresh) {
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Loading Documents...", @"Text displayed in the loading indicator while loading documents");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        [self.activityIndicator showInView:self.view];
    }

    
    [CLUserObject listDocumentsForUserId:[CLUserObject currentUser].userID pageNumber:self.nextPageToLoad success:^(NSMutableArray *documentList, BOOL isLastPageReached, NSInteger documentCount, NSInteger currentPage, NSInteger pages) {
        
        
        if (self.didPullDownToRefresh) {
            [self.documentsArray removeAllObjects];
        }
        self.isLastPageReached = isLastPageReached;
        
        [self.documentsArray addObjectsFromArray:documentList];
        if (isLastPageReached) {
            self.shouldPaginate = NO;
        }
        else{
            self.shouldPaginate = YES;
        }
        
        self.goForTimer = NO;
        [self.timer invalidate];
        self.timerStarted = NO;
        if (self.nextPageToLoad == 1 && self.didPullDownToRefresh) {
            [self.activityIndicator hideWithAnimation:YES];
        }
        self.didPullDownToRefresh = NO;
        self.nextPageToLoad++;
        if (self.documentsArray.count == 0) {
            self.pullRefreshLabel.hidden = NO;
        }
        else{
            self.pullRefreshLabel.hidden = YES;
        }
        [self.collectionView reloadData];
    } failure:^(NSString *error) {
        
        
        
        if (!self.goForTimer && self.didPullDownToRefresh) {
            [self.activityIndicator hideWithAnimation:YES];
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Failed to load Documents", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
        if (self.goForTimer && !self.timerStarted) {
            self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(startTimer) userInfo:nil repeats:YES];
            self.timerStarted = YES;
        }
        if (self.documentsArray.count == 0) {
            
            self.pullRefreshLabel.hidden = NO;
        }
        self.didPullDownToRefresh = NO;
    }];
    

}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)startTimer{
    [self retriveDocumentswithPagination:YES];
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithTitle:NSLocalizedString(@"+  ", @"title for add new documents button") style:UIBarButtonItemStyleBordered target:self action:@selector(buttonaction:)];
    [rightButton setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                        [UIFont fontWithName:@"Helvetica Neue" size:26.0], NSFontAttributeName,
                                        [UIColor whiteColor], NSForegroundColorAttributeName,
                                        nil] 
                              forState:UIControlStateNormal];

     self.navigationItem.rightBarButtonItem=rightButton;
}

-(IBAction)buttonaction:(id)sender{
    self.imagePickerPopped = YES;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
        imagePicker.allowsEditing = YES;
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}
-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
        [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
            
            [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
            
            [CLCommon sentEventNameToGoogleAnalytics:@"Added New Document" screenName:@"IOS - Document List"];
        }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        self.imagePickerPopped = NO;
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
    
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    self.imagePickerPopped = NO;
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    [CLAboutMeObject addDocument:image forUser:[CLUserObject currentUser].userID withCaption:caption success:^(CLFileObject *fileObj){
        [progressHUD hideWithAnimation:YES];
        self.imagePickerPopped = NO;
        if (!self.imagePickerPopped) {
            [self clearArraysAndReloadTableData];
        }
        
    }failure:^(NSString *error){
        NSLog(@"%@",error);
        [progressHUD hideWithAnimation:YES];
        self.imagePickerPopped = NO;
        if (!self.imagePickerPopped) {
            [self clearArraysAndReloadTableData];
        }
    }];
    
}

-(void)deleteDocumentOfID:(NSString*)documentId{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the deleting indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    [CLAboutMeObject deleteDocument:documentId forUser:[CLUserObject currentUser].userID success:^(){
        [progressHUD hideWithAnimation:YES];
        [self clearArraysAndReloadTableData];
        
        [CLCommon sentEventNameToGoogleAnalytics:@"Document Deleted" screenName:@"IOS - Document List"];
    }failure:^(NSString*error){
        NSLog(@"%@",error);
        [progressHUD hideWithAnimation:YES];
    }];
}


@end
