//
//  CLReferencesObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLReferencesObject.h"
#import "CLFileObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"
#import "CLPerformanceReviewObject.h"
#import "CLReviewObject.h"

#define kDebugMessages 0

@implementation CLReferencesObject

static NSOperationQueue *listReferencesRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.reviewArray=[[NSMutableArray alloc] init];
    NSMutableArray *tempRevArray=[dictionary objectForKeyNotNull:kCLProfileReferenceArraykey];
    for (int i=0; i<[tempRevArray count]; i++) {
        [self.reviewArray addObject:[[CLReviewObject alloc] initWithDictionary:[tempRevArray objectAtIndex:i]]];
    }
    
    self.perfRevArray=[[NSMutableArray alloc] init];
    NSMutableArray *tempPerfArray=[dictionary objectForKeyNotNull:kCLProfilePerfReviewArraykey];
    for (int i=0; i<[tempPerfArray count]; i++) {
        [self.perfRevArray addObject:[[CLPerformanceReviewObject alloc] initWithDictionary:[tempPerfArray objectAtIndex:i]]];
    }
    
    self.careerListArray=[dictionary objectForKeyNotNull:kCLProfilePerfReviewCareerArraykey];
    
    return self;
}

//cancel request..
+ (void)cancelReferencePendingRequest{
    [listReferencesRequest cancelAllOperations];
    listReferencesRequest = nil;
}

//Method for getting a references for a particular user...
+ (void)referenceDetailsForUser:(NSString *)userId success:(void (^)(CLReferencesObject *referenceObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLReferencesObject *referenceObj){};
    }
    
    NSDictionary *parameters = @{@"cl_id": userId};
    
    [listReferencesRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        listReferencesRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileReferenceURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"reference listing JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLReferencesObject *reference=[[CLReferencesObject alloc] initWithDictionary:response];
                success(reference);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}



@end
