//
//  CLJobsViewController.h
//  CareerLine
//
//  Created by CSG on 1/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLJobsListingCell.h"

@interface CLJobsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>

-(void)gotoJobsDetailViewFromPushWithJobId:(NSString*)jobId;
-(void)clearArraysAndReloadTable;
@end
