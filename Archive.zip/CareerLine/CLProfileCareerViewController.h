//
//  CLProfileCareerViewController.h
//  CareerLine
//
//  Created by RENJITH on 16/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLAddCareerHistoryViewController.h"

@interface CLProfileCareerViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CLAddCareerDelegate>

@end
