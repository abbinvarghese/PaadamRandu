//
//  CLSelectJobLevelGroupViewController.h
//  CareerLine
//
//  Created by CSG on 2/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectJobLevelDetailViewController.h"

@class CLSelectJobLevelGroupViewController;

@protocol CLSelectJobLevelGroupDelegate <NSObject>

-(void)loadSelectedCareerLevelDictArray:(CLSelectJobLevelGroupViewController*)controller withArray:(NSMutableArray*)Array;

@end

@interface CLSelectJobLevelGroupViewController : UITableViewController

@property(nonatomic,weak) id <CLSelectJobLevelGroupDelegate> delegateForJobfunction;
@property(nonatomic,weak) id <CLSelectJobLevelDelegate> delegate;

@property(nonatomic)BOOL multipleSelectionON;
@property(nonatomic,strong) NSMutableArray *selectedCareerlevelDictArrayTwo;
@property(nonatomic,strong) NSMutableDictionary *selectedCareerlevelDict;
@end
