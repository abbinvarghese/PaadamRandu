//
//  CLProfileObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLAboutMeObject.h"

@interface CLProfileObject : NSObject

@property (nonatomic, retain) NSString *firstName;
@property (nonatomic, retain) NSString *lastName;
@property (nonatomic, retain) NSString *nickName;
@property (nonatomic, retain) NSString *profImageUrl;
@property (nonatomic, retain) NSString *dateOfBirth;
@property (nonatomic, strong) NSString *userAge;
@property (nonatomic, strong) NSString *profileImageId;

@property (nonatomic, strong) NSMutableArray *aboutMeArray;
@property (nonatomic, strong) NSMutableArray *careerArray;
@property (nonatomic, strong) NSMutableArray *qualificationArray;
@property (nonatomic, strong) NSMutableArray *capabilityArray;
@property (nonatomic, strong) NSMutableArray *protfolioArray;
@property (nonatomic, strong) NSMutableArray *referenceArray;
@property (nonatomic, strong) NSMutableArray *goalsArray;
@property (nonatomic, strong) NSMutableArray *jobPreferenceArray;
@property (nonatomic, strong) NSMutableArray *thumbImages;


+ (void)cancelProfileSummaryPendingRequest;
+ (void)profileSummaryForUser:(NSString *)userId success:(void (^)(CLProfileObject *profObj))success failure:(void (^)(NSString *error))failure;
@end
