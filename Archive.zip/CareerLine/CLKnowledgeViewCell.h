//
//  CLKnowledgeViewCell.h
//  CareerLine
//
//  Created by RENJITH on 19/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLKnowledgeObject.h"

@class CLKnowledgeViewCell;

//KnowledgeDelegate
@protocol CLKnowledgeViewCellDelegate <NSObject>

@optional
- (void)cellBookmarkKnowledge:(UICollectionViewCell *)cell;
- (void)cellLikeKnowledge:(UICollectionViewCell *)cell;
@end
@interface CLKnowledgeViewCell : UICollectionViewCell

@property(nonatomic,strong) id<CLKnowledgeViewCellDelegate>delegate;
@property(nonatomic,strong) CLKnowledgeObject *knowledgeObj;
@property (strong, nonatomic) IBOutlet UIButton *bookmarkBtn;
@property (strong, nonatomic) IBOutlet UIButton *likeBtn;
@property (strong, nonatomic) IBOutlet UILabel *likeLbl;
-(void)updateContentsForIndexPath:(NSIndexPath*)indexPath;

@end
