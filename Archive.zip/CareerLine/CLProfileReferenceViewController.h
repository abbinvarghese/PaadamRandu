//
//  CLProfileReferenceViewController.h
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLReferenceDetailViewController.h"
#import "CLPerformanceReviewController.h"
#import "CLReferencesObject.h"
#import "CLReviewObject.h"

@interface CLProfileReferenceViewController : UIViewController<CLReferenceControllerDelegate,CLPerformanceReviewControllerDelegate>

//@property(nonatomic,strong)NSMutableArray *referenceArray;
@property(nonatomic,strong)CLReferencesObject *referenceObj;

@end
