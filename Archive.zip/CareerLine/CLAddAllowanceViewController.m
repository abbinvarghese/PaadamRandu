//
//  CLAddAllowanceViewController.m
//  CareerLine
//
//  Created by RENJITH on 14/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAddAllowanceViewController.h"
#import "NSDictionary+Additions.h"
#define isEditText @"isEdit"

@interface CLAddAllowanceViewController ()

typedef enum {
    CLAllowanceLoadingIndex = 0,
    CLAllowanceFrequencyIndex= 1,
    CLGrossSalaryIndex = 2,
    CLActualValueIndex = 3,
} CLAllowanceTableSectionIndex;

@property (nonatomic, assign) BOOL grossSalSwitch;
@property (nonatomic, assign) BOOL actualValSwitch;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;

@property(nonatomic ,retain) NSMutableDictionary *allowanceDict;
@property(nonatomic ,retain) NSMutableDictionary *selectedAllowanceLoading;
@property(nonatomic ,retain) NSMutableDictionary *selectedAllowanceFrequency;


@property(nonatomic ,retain) NSString *grossSalValText;
@property(nonatomic ,retain) NSString *actualValText;
@end

@implementation CLAddAllowanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Allowances", @"Allowances page title text");
    //Allowance section
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"allowanceTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"actualValueCurrencyCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"frequencyTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"grossSalaryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"actualValueTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"grossSalaryCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"actualValueCellIdentifier"];
    
    if (self.selectedAllowanceForEdit !=nil) {
        self.allowanceDict = [[NSMutableDictionary alloc]initWithDictionary:self.selectedAllowanceForEdit];
    }
    if (self.allowanceDict!=nil) {
        self.grossSalValText = [self.allowanceDict objectForKey:kCLCareerHistoryAllowanceGrossSalkey];
        self.actualValText = [self.allowanceDict objectForKey:kCLCareerHistoryAllowanceActualValkey];
        
        if (![self.grossSalValText isEqualToString:@""]) {
            self.grossSalSwitch = YES;
        }
        if (![self.actualValText isEqualToString:@""]) {
            self.actualValSwitch = YES;
        }
        self.selectedAllowanceLoading = [self.allowanceDict objectForKey:kCLCareerHistoryAllowanceLoadingskey];
        self.selectedAllowanceFrequency = [self.allowanceDict objectForKey:kCLCareerHistoryAllowanceFrequencykey];
        if ([self.allowanceDict objectForKey:kCLCareerHistoryAllowanceCurrencykey]!=nil) {
            self.selectedAllowanceCurrency = [[NSMutableDictionary alloc]initWithDictionary:[self.allowanceDict objectForKey:kCLCareerHistoryAllowanceCurrencykey]];
        }
    }else{
        self.selectedAllowanceLoading = nil;
        self.selectedAllowanceFrequency = nil;
        self.grossSalValText = @"";
        self.actualValText = @"";
    }
    
     [self setRightNavigationButton];
    if (!self.isEdit) {
         [self setLeftNavigationButton];
    }
    
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidDisappear:(BOOL)animated
{
    [self.txtFirstResponder resignFirstResponder];
}

#pragma mark Utility Methods
-(void)setLeftNavigationButton{
    UIBarButtonItem *lefttNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Dismiss allowance and loading modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionBenefitsDismiss:)];
    self.navigationItem.leftBarButtonItem=lefttNavBttn;
}

-(void)bttnActionBenefitsDismiss:(id)sender{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"dismiss Allowance modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
}

-(BOOL)isFieldsValid{
    
    BOOL isValid=YES;
    //Course validation..
    if (self.selectedAllowanceLoading ==nil) {
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Warning", @"Alert title text") alertString:NSLocalizedString(@"Please Select Allowance And Loading.", @"alert msg text") cancelbuttonName:NSLocalizedString(@"OK", @"ok btn text")];
        return isValid=NO;
        
    }
    else if (self.actualValText.length >9){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum Length Of Actual Value Should Be 9", @"Error Message for actual value field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (self.grossSalValText.length > 3){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum Length Of Gross Salary Should Be 3.", @"Error Message for gross salary field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}


-(void)bttnActionSaveAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        CATransition *transition = [CATransition animation];
        transition.duration = 0.25;
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromBottom;
        
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        
        if (self.isEdit) {
            [self.allowanceDict setObject:@"1" forKey:isEditText];
            [self.navigationController popViewControllerAnimated:NO];
        }else{
            if (self.allowanceDict ==nil) {
                self.allowanceDict = [[NSMutableDictionary alloc]init];
            }
            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
        
        [self.allowanceDict setObject:self.grossSalValText forKey:kCLCareerHistoryAllowanceGrossSalkey];
        [self.allowanceDict setObject:self.actualValText forKey:kCLCareerHistoryAllowanceActualValkey];
        
        if ([self.allowanceDict objectForKeyNotNull:kCLCareerHistoryAllowanceIdkey]) {
            [self.allowanceDict setObject:[self.allowanceDict objectForKeyNotNull:kCLCareerHistoryAllowanceIdkey] forKey:kCLCareerHistoryAllowanceIdkey];
        }
        if (self.selectedAllowanceLoading !=nil) {
            [self.allowanceDict setObject:self.selectedAllowanceLoading forKey:kCLCareerHistoryAllowanceLoadingskey];
        }
        if (self.selectedAllowanceFrequency !=nil) {
            [self.allowanceDict setObject:self.selectedAllowanceFrequency forKey:kCLCareerHistoryAllowanceFrequencykey];
        }if (self.selectedAllowanceCurrency !=nil) {
            if ([self.selectedAllowanceCurrency objectForKey:@"ccFips"]) {
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                [dict setObject:[self.selectedAllowanceCurrency objectForKey:@"countryCode"] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@/%@",[self.selectedAllowanceCurrency objectForKey:@"countryName"],[self.selectedAllowanceCurrency objectForKey:@"currencyCode"]] forKey:@"currency"];
                [self.allowanceDict setObject:dict forKey:kCLCareerHistoryAllowanceCurrencykey];
            }
            else{
                [self.allowanceDict setObject:self.selectedAllowanceCurrency forKey:kCLCareerHistoryAllowanceCurrencykey];
            }
        }
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(allowanceController:didAddOrChangeAllowance:isEdit:)]){
            [self.delegate allowanceController:self didAddOrChangeAllowance:self.allowanceDict isEdit:self.isEdit];
        }
    }else{
        
    }
   }

#pragma mark - tableView methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case CLAllowanceLoadingIndex:{
            CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"allowanceTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Allowance and Loading", @"Placeholder for Allowance and Loadings field")];
            if (self.selectedAllowanceLoading ==NULL) {
                
                [relatedToCell setCellText:@""];
            }else{
                [relatedToCell setCellText:[self.selectedAllowanceLoading objectForKey:kCLCareerHistoryAllowanceLoadingskey]];
            }
            [relatedToCell setCellIndexPath:indexPath];
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
        }
        case CLAllowanceFrequencyIndex:{
            CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"frequencyTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Frequency", @"Placeholder for Frequency field")];
            if (self.selectedAllowanceFrequency ==NULL) {
                [relatedToCell setCellText:@""];
            }else{
                [relatedToCell setCellCloseBtnOption:NO];
                [relatedToCell setCellText:[self.selectedAllowanceFrequency objectForKey:kCLCareerHistoryAllowanceFrequencykey]];
            }
            [relatedToCell setCellIndexPath:indexPath];
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
            
        }
        case CLGrossSalaryIndex:{
            if (indexPath.row == 0) {
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"grossSalaryCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.grossSalSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
            }
            else {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"grossSalaryTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary field")];
                [relatedToCell setCellText:self.grossSalValText];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }
        }
        case CLActualValueIndex:{
            if (indexPath.row == 0) {
                
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"actualValueCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.actualValSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
            }
            else if (indexPath.row == 1){
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"actualValueTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value field")];
                [relatedToCell setCellText:self.actualValText];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
                
            }else{
                CLSimpleTappableTextCell *relatedCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"actualValueCurrencyCellIdentifier"];
                relatedCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedCell setPlaceHoldrText:NSLocalizedString(@"Currency", @"Placeholder for Currency field")];
                if (self.selectedAllowanceCurrency ==nil) {
                    
                    [relatedCell setCellText:@""];
                }else{
                    [relatedCell setCellCloseBtnOption:NO];
                    if ([self.selectedAllowanceCurrency objectForKey:kCLCareerHistoryAllowanceCurrencykey]) {
                        [relatedCell setCellText:[self.selectedAllowanceCurrency objectForKey:kCLCareerHistoryAllowanceCurrencykey]];
                    }
                    else{
                        [relatedCell setCellText:[NSString stringWithFormat:@"%@/%@",[self.selectedAllowanceCurrency objectForKey:@"currencyCode"],[self.selectedAllowanceCurrency objectForKey:@"countryName"]]];
                    }
                }
                [relatedCell setCellIndexPath:indexPath];
                relatedCell.delegate=self;
                return relatedCell;
                break;
            }
        }
        default:
            return nil;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLAllowanceLoadingIndex:
            return NSLocalizedString(@"Allowance and Loadings", @"Placeholder for Allowance and Loadings field");
            break;
        case CLAllowanceFrequencyIndex:
            return NSLocalizedString(@"Frequency", @"Placeholder for Frequency field");
            break;
        case CLGrossSalaryIndex:
            return NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary field");
            break;
        case CLActualValueIndex:
            return NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value field");
            break;
        default:
            return nil;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == CLGrossSalaryIndex) {
        
        if (self.grossSalSwitch)
            return 2;
        else
            return 1;
    }else if (section == CLActualValueIndex){
        
        if (self.actualValSwitch)
            return 3;
        else
            return 1;
    }else{
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44;
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLActualValueIndex:{
            self.actualValText=text;
            break;
        }
        case CLGrossSalaryIndex:{
            self.grossSalValText = text;
        }
        default:
            break;
    }
}

#pragma mark CLTappable cell delegate

- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    switch (indexPath.section) {
        case CLAllowanceFrequencyIndex:
            self.selectedAllowanceFrequency = nil;
            break;
        case CLActualValueIndex:{
            if (indexPath.row == 2) {
                self.selectedAllowanceCurrency = nil;
            }
        }
            break;
            
        default:
            break;
    }
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    
    if (indexPath.section == CLAllowanceLoadingIndex) {
        
        CLAllowanceLoadingsViewController *controller = [[CLAllowanceLoadingsViewController alloc]initWithNibName:@"CLAllowanceLoadingsViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedAllowane = self.selectedAllowanceLoading;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }else if (indexPath.section == CLAllowanceFrequencyIndex){
        
        CLFrequencyViewController *controller = [[CLFrequencyViewController alloc]initWithNibName:@"CLFrequencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedFrequency = self.selectedAllowanceFrequency;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
        
    }else if (indexPath.section == CLActualValueIndex){
        
        CLCurrencyViewController *controller = [[CLCurrencyViewController alloc]initWithNibName:@"CLCurrencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedCurrency = self.selectedAllowanceCurrency;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }
}

#pragma mark CLTextCheckBox delegate
- (void)textCheckBoxBgChange:(CLTextCheckBoxCell *)cell withStatus:(BOOL)status{
    
    [CLCommon doViewAnimation:self.view];
    NSIndexPath *index=cell.cellIndexPath;
    if (index.section == CLGrossSalaryIndex){
        if (status) {
            self.grossSalSwitch = YES;
            
            if(self.actualValSwitch)
            {
                self.actualValSwitch = NO;
                self.actualValText = @"";
                
            }
            
        }else{
            self.grossSalSwitch = NO;
            self.grossSalValText = @"";
           
        }
//        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLGrossSalaryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }else if (index.section == CLActualValueIndex){
        if (status) {
            self.actualValSwitch = YES;
            
            if(self.grossSalSwitch)
            {
                self.grossSalSwitch = NO;
                self.grossSalValText = @"";
            }
            
        }else{
            self.actualValSwitch = NO;
             self.actualValText = @"";
        }
//        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLActualValueIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
    [self.tableView reloadData];
}

#pragma mark - frequency delegate method
-(void)frequencyController:(CLFrequencyViewController *)controller didSelect:(NSMutableDictionary *)selectedDict{
    
    self.selectedAllowanceFrequency = selectedDict;
    [self.tableView reloadData];
}

#pragma mark - currency delegate method
-(void)loadSelectedCurrencyDictionary:(NSMutableDictionary *)dictionary{
    
    NSString *string = [NSString stringWithFormat:@"%@/%@",[dictionary objectForKey:kjobPreferenceCurrencyCode],[dictionary objectForKey:kjobPreferenceCountryName]];
    if (self.selectedAllowanceCurrency == nil) {
        self.selectedAllowanceCurrency = [[NSMutableDictionary alloc]init];
    }
    [self.selectedAllowanceCurrency setObject:string forKey:kCLCareerHistoryAllowanceCurrencykey];
    [self.selectedAllowanceCurrency setObject:[dictionary objectForKey:kjobPreferenceCountryCode] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
    
    [self.tableView reloadData];
}

#pragma mark - Allowance and loading delegate
-(void)allowanceAndLoadingController:(CLAllowanceLoadingsViewController *)controller didSelect:(NSMutableDictionary *)selectedDict{
    
    self.selectedAllowanceLoading =selectedDict;
    [self.tableView reloadData];
}

@end
