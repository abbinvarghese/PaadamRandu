//
//  CLCollectionProfileAddDetailCell.m
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCollectionProfileAddDetailCell.h"

@implementation CLCollectionProfileAddDetailCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLCollectionProfileAddDetailCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

@end
