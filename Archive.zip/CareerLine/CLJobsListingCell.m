//
//  CLJobsListingCell.m
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsListingCell.h"
#import "CLUserObject.h"
#import "UIImageView+WebCache.h"

@interface CLJobsListingCell()

@property (weak, nonatomic) IBOutlet UILabel *lblJobPostedTime;
@property (weak, nonatomic) IBOutlet UILabel *lblJobTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblJobCompanyName;
@property (weak, nonatomic) IBOutlet UILabel *lblJobLocation;
@property (weak, nonatomic) IBOutlet UIImageView *imgCompanyLogo;
@property (weak, nonatomic) IBOutlet UIImageView *imgMsgUnreadStatus;
@end

@implementation CLJobsListingCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLJobsListingCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)updateCellContent{
    self.lblJobPostedTime.text=self.job.jobReceivedDate;
    self.lblJobTitle.text=self.job.jobTitle;
    self.lblJobCompanyName.text=self.job.companyDetails.companyName;
    self.lblJobLocation.text=[NSString stringWithFormat:@"%@, %@",self.job.jobLoc,self.job.jobCountry];
    self.lblJobCompanyName.textColor=self.lblJobPostedTime.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
//    [self.imgCompanyLogo setImageWithURL:[NSURL URLWithString:[self.job.companyDetails.companyLogoUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]]
//                        placeholderImage:[UIImage imageNamed:@"company_placeholder"]
//                               completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//                                   if (image && cacheType == SDImageCacheTypeNone)
//                                   {
//                                       self.imgCompanyLogo.alpha = 0.0;
//                                       [UIView animateWithDuration:1.0
//                                                        animations:^{
//                                                            self.imgCompanyLogo.alpha = 1.0;
//                                                        }];
//                                   }
//                               }];
    
    [self.imgCompanyLogo sd_setImageWithURL:[NSURL URLWithString:self.job.companyDetails.companyLogoUrl] placeholderImage:[UIImage imageNamed:@"company_placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        if (image && cacheType == SDImageCacheTypeNone)
        {
            self.imgCompanyLogo.alpha = 0.0;
            [UIView animateWithDuration:1.0
                             animations:^{
                                 self.imgCompanyLogo.alpha = 1.0;
                             }];
        }    }];
    
    self.imgMsgUnreadStatus.image=[self getUnreadStatusImageforStatus:self.job.jobUnreadStatus];
}

-(UIImage*)getUnreadStatusImageforStatus:(int)unreadStatus{
    if (unreadStatus==0) {
        return nil;//[UIImage imageNamed:@"msg_read"];
    }
    else{
        switch ([CLUserObject currentUser].trafficLightStatus) {
            case CLTrafficLightRedColor:
                return [UIImage imageNamed:@"msg_unread_red"];
                break;
            case CLTrafficLightGreenColor:
                return [UIImage imageNamed:@"msg_unread_green"];
                break;
            case CLTrafficLightAmberColor:
                return [UIImage imageNamed:@"msg_unread_orange"];
                break;
            default:
                return [UIImage imageNamed:@"msg_read"];
                break;
        }
    }
}


@end
