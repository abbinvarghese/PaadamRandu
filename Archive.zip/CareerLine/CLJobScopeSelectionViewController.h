//
//  CLJobScopeSelectionViewController.h
//  CareerLine
//
//  Created by Abbin on 30/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol JobScopeSelectionDelegate <NSObject>

@optional
-(void)loadSelectedJobScopeArray:(NSMutableArray*)jobScopeDictArray;
-(void)loadSelectedJobScopeDict:(NSMutableDictionary*)jobScopeDict;
@end

@interface CLJobScopeSelectionViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,retain) NSMutableDictionary *passedOnDict;
@property (nonatomic,retain) NSMutableDictionary *passedOnJobScopeDict;
@property (nonatomic,retain) NSMutableArray *passedOnJobScopeArray;
@property(nonatomic,weak)id <JobScopeSelectionDelegate> delegate;
@property(nonatomic)BOOL singleSelectionOn;

@end
