//
//  CLCRFThreeObject.m
//  CareerLine
//
//  Created by Abbin on 30/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLCRFThreeObject.h"
#import "NSDictionary+Additions.h"

@implementation CLCRFThreeObject

-(id)initWithDictionary:(NSDictionary *)dictionary{
    self = [super init];
    if (self == nil) {
        return nil;
    }
    self.employmentSubStatus = [dictionary objectForKeyNotNull:@"EmploymentSubStatus"];
    self.employmentStatus = [dictionary objectForKeyNotNull:@"EmploymentStatus"];
    self.employmentHistory = [dictionary objectForKeyNotNull:@"EmploymentHistory"];
    self.employmentType = [dictionary objectForKeyNotNull:@"employmentType"];
    self.country = [dictionary objectForKeyNotNull:@"country"];
    self.companyName = [dictionary objectForKeyNotNull:@"companyName"];
    self.industry = [dictionary objectForKeyNotNull:@"industry"];
    self.isOtherCompany = [dictionary objectForKeyNotNull:@"isOtherCompany"];
    self.businessDivision = [dictionary objectForKeyNotNull:@"businessDivision"];
    self.otherCompany = [dictionary objectForKeyNotNull:@"otherCompany"];
    self.jobTitle = [dictionary objectForKey:@"jobTitle"];
    self.function = [dictionary objectForKeyNotNull:@"function"];
    self.jobLevel = [dictionary objectForKeyNotNull:@"jobLevel"];
    self.jobImpact = [dictionary objectForKeyNotNull:@"jobImpact"];
    self.welcomeStat = [dictionary objectForKeyNotNull:@"cl_welcome_stat"];
    return self;
}

@end
