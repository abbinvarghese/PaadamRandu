//
//  CLCRFTwoObject.h
//  CareerLine
//
//  Created by Abbin on 30/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCRFTwoObject : NSObject

@property(nonatomic,strong) NSMutableDictionary *educationLevel;
@property(nonatomic,strong) NSMutableDictionary *country;
@property(nonatomic,strong) NSString *welcome_stat;

-(id)initWithDictionary:(NSDictionary*)dictionary;

@end
