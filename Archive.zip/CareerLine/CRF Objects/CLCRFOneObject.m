//
//  CLCRFOneObject.m
//  CareerLine
//
//  Created by Abbin on 25/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLCRFOneObject.h"
#import "NSDictionary+Additions.h"

@implementation CLCRFOneObject

-(id)initWithDictionary:(NSDictionary *)dictionary{
    self = [super init];
    if (self == nil) {
        return nil;
    }
    self.nationality = [dictionary objectForKeyNotNull:kNationality];
    self.age = [dictionary objectForKeyNotNull:kAge];
    self.welcomeStat = [dictionary objectForKeyNotNull:kWelcomeStat];
    self.country = [dictionary objectForKeyNotNull:kCountry];
    self.dateOfBirth = [dictionary objectForKeyNotNull:kDateOfBirth];
    self.firstName = [dictionary objectForKey:kFirstName];
    self.gender = [dictionary objectForKeyNotNull:kGender];
    self.lastName = [dictionary objectForKeyNotNull:kLastName];
    self.location = [dictionary objectForKeyNotNull:kLocation];
    self.nickName = [dictionary objectForKeyNotNull:kNickName];
    self.languages = [dictionary objectForKeyNotNull:kLanguage];
    
    return self;
}

@end
