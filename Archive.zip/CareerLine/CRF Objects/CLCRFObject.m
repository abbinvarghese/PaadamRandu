//
//  CLCRFObject.m
//  CareerLine
//
//  Created by Abbin on 25/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLCRFObject.h"


#define kDebugMessages 0

@implementation CLCRFObject

static NSOperationQueue *crfOneRequest;
static NSOperationQueue *crfSubmitRequest;
static NSOperationQueue *crfThreeSubmitRequest;
static NSOperationQueue *crfTwoSubmitRequest;
static NSOperationQueue *crfTwoRequest;
static NSOperationQueue *crfThreeRequest;
static NSOperationQueue *crfFourRequest;
static NSOperationQueue *crfFourSubmit;

#pragma mark-
#pragma mark CRF ONE

+ (void)getCRFOneDetailsForUser:(NSString *)userId success:(void (^)(CLCRFOneObject *oneObj))success failure:(void (^)(NSString *error))failure{
    
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLCRFOneObject *oneObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    [crfOneRequest cancelAllOperations];
    if ([CLCommon isNetworkConnected]) {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfOneRequest= manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFOneURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLCRFOneObject *obj = [[CLCRFOneObject alloc]initWithDictionary:response];
                success(obj);
                }
            
        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            NSLog(@"%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    } else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

    
}

+(NSString*)jsonStringforCRFOneObj:(CLCRFOneObject*)obj{
    NSMutableDictionary*mainDict = [[NSMutableDictionary alloc]init];
    NSMutableDictionary *innerOne = [[NSMutableDictionary alloc]init];
    if ([obj.country objectForKey:@"cy_code"]) {
        [innerOne setObject:[obj.country objectForKey:@"cy_code"] forKey:@"cl_curcycode"];
    }
    if ([obj.location objectForKey:@"locCode"]) {
        [innerOne setObject:[obj.location objectForKey:@"locCode"] forKey:@"cl_curlocation"];
    }
    NSMutableArray *nationalityArra = [[NSMutableArray alloc]init];
    for (NSMutableDictionary *dict in obj.nationality) {
        if ([dict objectForKey:@"cy_code"]) {
            [nationalityArra addObject:[dict objectForKey:@"cy_code"]];
        }
    }

    [innerOne setObject:nationalityArra forKey:@"nationalities"];
    
    NSMutableArray *langua = [[NSMutableArray alloc]init];
    
    for (NSMutableDictionary *dict in obj.languages) {
        [langua addObject:[dict objectForKey:@"cl_langcode"]];
    }
    
    [innerOne setObject:langua forKey:@"languages"];
    
    if ([obj.gender objectForKey:@"id"]) {
        [innerOne setObject:[obj.gender objectForKey:@"id"] forKey:@"cl_gender"];
    }
    else{
        [innerOne setObject:[obj.gender objectForKey:@"genderId"] forKey:@"cl_gender"];
    }
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    
    [df setDateFormat:@"dd-MM-yyyy"];
    NSDate *myDate = [df dateFromString:obj.dateOfBirth];
    if (myDate == nil) {
        [df setDateFormat:@"MM/dd/yyyy"];
        myDate = [df dateFromString:obj.dateOfBirth];
    }
    [df setDateFormat:@"dd"];
    [innerOne setObject:[df stringFromDate:myDate] forKey:@"cl_day"];
    
    [df setDateFormat:@"MM"];
    [innerOne setObject:[df stringFromDate:myDate] forKey:@"cl_mnth"];
    
    [df setDateFormat:@"yyyy"];
    [innerOne setObject:[df stringFromDate:myDate] forKey:@"cl_yr"];
    
    NSMutableDictionary *innerTwo = [[NSMutableDictionary alloc]init];
    [innerTwo setObject:obj.firstName forKey:@"cl_firstname"];
    [innerTwo setObject:obj.lastName forKey:@"cl_fullname"];
    [innerTwo setObject:obj.nickName forKey:@"cl_shortname"];
    
    [mainDict setObject:innerOne forKey:@"careerline"];
    [mainDict setObject:innerTwo forKey:@"careerlineLang"];
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:mainDict];
}

+ (void)submitCRFOneForUser:(NSString *)userId withCRFOneObj:(CLCRFOneObject*)CRFOneObj success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"user":userId, @"fields":[CLCRFObject jsonStringforCRFOneObj:CRFOneObj]};
    
    [crfSubmitRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfSubmitRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFOnePostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}


#pragma mark-
#pragma mark CRF TWO

+ (void)getCRFTwoDetailsForUser:(NSString *)userId success:(void (^)(CLCRFTwoObject *twoObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLCRFTwoObject *twoObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    [crfTwoRequest cancelAllOperations];
    if ([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfTwoRequest= manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFTwoGetURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLCRFTwoObject *obj = [[CLCRFTwoObject alloc]initWithDictionary:response];
                success(obj);
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}


+ (void)submitCRFTwoForUser:(NSString *)userId withCRFOneObj:(NSMutableDictionary*)mainDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"user":userId, @"fields":[CLCommon jsonStringWithPrettyPrint:NO foDict:mainDict]};
    
    [crfTwoSubmitRequest cancelAllOperations];
    if([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfTwoSubmitRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFTwoPostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];

    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}


#pragma mark-
#pragma mark CRF THREE


+ (void)getCRFThreeDetailsForUser:(NSString *)userId success:(void (^)(CLCRFThreeObject *threeObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLCRFThreeObject *threeObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    [crfThreeRequest cancelAllOperations];
    if ([CLCommon isNetworkConnected]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfThreeRequest= manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFThreeGetURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLCRFThreeObject *obj = [[CLCRFThreeObject alloc]initWithDictionary:response];
                success(obj);
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            NSLog(@"%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
}

+ (void)submitCRFTHREEForUser:(NSString *)userId withCRFDict:(NSMutableDictionary*)CRFOneDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }

    NSDictionary *parameters = @{@"user":userId, @"fields":[CLCommon jsonStringWithPrettyPrint:NO foDict:CRFOneDict]};
    [crfThreeSubmitRequest cancelAllOperations];
    if([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfThreeSubmitRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        NSLog(@"%@",[CLCommon jsonStringWithPrettyPrint:YES foDict:CRFOneDict]);
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFThreePostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

#pragma mark-
#pragma mark CRF FOUR

+ (void)getCRFFOURDetailsForUser:(NSString *)userId success:(void (^)(NSDictionary *FOURobj,NSMutableDictionary*currentLocationDIct))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSDictionary *FOURobj,NSMutableDictionary*currentLocationDIct){};
    }
    NSDictionary *parameters = @{@"user": userId};
    [crfFourRequest cancelAllOperations];
    if ([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfFourRequest= manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFFourGetURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
 //               CLRelocationObject *relocObj=[[CLRelocationObject alloc] initWithDictionary:response];
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                [dict setObject:[[response objectForKey:@"RelocationOption"]objectForKey:@"country"] forKey:@"jobLocationCountryName"];
                [dict setObject:[[response objectForKey:@"RelocationOption"]objectForKey:@"countryCode"] forKey:@"jobLocationCountryCode"];
                [dict setObject:[[response objectForKey:@"RelocationOption"]objectForKey:@"location"] forKey:@"jobLocationName"];
                success(response,dict);
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            NSLog(@"%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    } else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
}

+ (void)submitCRFFourForUser:(NSString *)userId withCRFOneObj:(NSMutableDictionary*)CRFFourDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"user":userId, @"fields":[CLCommon jsonStringWithPrettyPrint:NO foDict:CRFFourDict]};
    [crfFourSubmit cancelAllOperations];
    if([CLCommon isNetworkConnected]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        crfFourSubmit=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFFourPostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    }
    else{
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
