//
//  CLCRFThreeObject.h
//  CareerLine
//
//  Created by Abbin on 30/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCRFThreeObject : NSObject

@property(nonatomic,strong) NSMutableDictionary *employmentStatus;
@property(nonatomic,strong) NSMutableDictionary *employmentHistory;
@property(nonatomic,strong) NSMutableDictionary *employmentSubStatus;
@property(nonatomic,strong) NSMutableDictionary *employmentType;
@property(nonatomic,strong) NSMutableDictionary *country;
@property(nonatomic,strong) NSMutableDictionary *companyName;
@property(nonatomic,strong) NSMutableDictionary *industry;
@property(nonatomic,strong) NSString *isOtherCompany;
@property(nonatomic,strong) NSMutableArray *businessDivision;
@property(nonatomic,strong) NSMutableDictionary *otherCompany;
@property(nonatomic,strong) NSString *jobTitle;
@property(nonatomic,strong) NSMutableArray *function;
@property(nonatomic,strong) NSMutableDictionary *jobLevel;
@property(nonatomic,strong) NSMutableDictionary *jobImpact;
@property(nonatomic,strong) NSString *welcomeStat;

-(id)initWithDictionary:(NSDictionary *)dictionary;

@end
