//
//  CLCRFTwoObject.m
//  CareerLine
//
//  Created by Abbin on 30/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLCRFTwoObject.h"
#import "NSDictionary+Additions.h"

@implementation CLCRFTwoObject

-(id)initWithDictionary:(NSDictionary*)dictionary{
    self = [super init];
    if (self == nil) {
        return nil;
    }
    self.educationLevel = [dictionary objectForKeyNotNull:@"educationLevel"];
    self.country = [dictionary objectForKeyNotNull:@"Country"];
    self.welcome_stat = [dictionary objectForKeyNotNull:@"cl_welcome_stat"];
    return self;
}


@end
