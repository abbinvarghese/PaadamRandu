//
//  CLCRFOneObject.h
//  CareerLine
//
//  Created by Abbin on 25/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kNationality @"Nationality"
#define kAge @"age"
#define kWelcomeStat @"cl_welcome_stat"
#define kCountry @"country"
#define kDateOfBirth @"dob"
#define kFirstName @"firstname"
#define kGender @"gender"
#define kLastName @"last_name"
#define kLocation @"location"
#define kNickName @"nick_name"
#define kLanguage @"Languages"


@interface CLCRFOneObject : NSObject
@property(nonatomic,retain) NSMutableArray *languages;
@property(nonatomic,retain) NSMutableArray *nationality;
@property(nonatomic,retain) NSString *age;
@property(nonatomic,retain) NSString *welcomeStat;
@property(nonatomic,retain) NSMutableDictionary *country;
@property(nonatomic,retain) NSString *dateOfBirth;
@property(nonatomic,retain) NSString *firstName;
@property(nonatomic,retain) NSMutableDictionary *gender;
@property(nonatomic,retain) NSString *lastName;
@property(nonatomic,retain) NSMutableDictionary *location;
@property(nonatomic,retain) NSString *nickName;


-(id)initWithDictionary:(NSDictionary*)dictionary;

@end
