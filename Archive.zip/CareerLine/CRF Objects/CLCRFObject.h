//
//  CLCRFObject.h
//  CareerLine
//
//  Created by Abbin on 25/06/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLCRFOneObject.h"
#import "CLCRFTwoObject.h"
#import "CLCRFThreeObject.h"
#import "CLRelocationObject.h"

@interface CLCRFObject : NSObject

+ (void)getCRFOneDetailsForUser:(NSString *)userId success:(void (^)(CLCRFOneObject *oneObj))success failure:(void (^)(NSString *error))failure;
+ (void)submitCRFOneForUser:(NSString *)userId withCRFOneObj:(CLCRFOneObject*)CRFOneObj success:(void (^)(void))success failure:(void (^)(NSString *error))failure;
+ (void)getCRFTwoDetailsForUser:(NSString *)userId success:(void (^)(CLCRFTwoObject *twoObj))success failure:(void (^)(NSString *error))failure;
+ (void)submitCRFTwoForUser:(NSString *)userId withCRFOneObj:(NSMutableDictionary*)mainDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure;
+ (void)getCRFThreeDetailsForUser:(NSString *)userId success:(void (^)(CLCRFThreeObject *threeObj))success failure:(void (^)(NSString *error))failure;
+ (void)submitCRFTHREEForUser:(NSString *)userId withCRFDict:(NSMutableDictionary*)CRFOneDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure;
+ (void)getCRFFOURDetailsForUser:(NSString *)userId success:(void (^)(NSDictionary *FOURobj,NSMutableDictionary*currentLocationDIct))success failure:(void (^)(NSString *error))failure;
+ (void)submitCRFFourForUser:(NSString *)userId withCRFOneObj:(NSMutableDictionary*)CRFFourDict success:(void (^)(void))success failure:(void (^)(NSString *error))failure;
@end
