//
//  CLProtfolioObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProtfolioObject.h"
//#import "CLWorkAchievementObject.h"
//#import "CLAssessmentObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#import "CLProjectObject.h"
#import "CLItemObject.h"
#import "CLEduProjectObject.h"

#define kDebugMessages 1

@implementation CLProtfolioObject

//static NSOperationQueue *protfolioDetailsRequest;
//
//+ (void)cancelProtfolioPendingRequest {
//    [protfolioDetailsRequest cancelAllOperations];
//    protfolioDetailsRequest = nil;
//}
//

//
//- (id)initWithDictionary:(NSDictionary*)dictionary {
//    self = [super init];
//    if (self == nil) return nil;
//    
//    self.workAchievementsArray=[[NSMutableArray alloc] init];
//    NSMutableArray *tempAchievmntArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementArraykey];
//    for (int i=0; i<[tempAchievmntArray count]; i++) {
//        [self.workAchievementsArray addObject:[[CLWorkAchievementObject alloc] initWithDictionary:[tempAchievmntArray objectAtIndex:i]]];
//    }
//    
//    self.assessmentsArray=[[NSMutableArray alloc] init];
//    NSMutableArray *tempAssessArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioAssessmentArraykey];
//    for (int i=0; i<[tempAssessArray count]; i++) {
//        [self.assessmentsArray addObject:[[CLAssessmentObject alloc] initWithDictionary:[tempAssessArray objectAtIndex:i]]];
//    }
//    
//    self.relatedToListArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioWorkAchievementRelatedToArraykey];
//    
//    return self;
//}
//
////Method for getting a protfolio detail for a particular user...
//+ (void)getProtfolioDetailsForUser:(NSString *)userId success:(void (^)(CLProtfolioObject *protfolioObj))success failure:(void (^)(NSString *error))failure{
//    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
//    if (failure == nil) {
//        failure = ^(NSString *error){};
//    }
//    if (success == nil) {
//        success = ^(CLProtfolioObject *protfolioObj){};
//    }
//    
//    NSDictionary *parameters = @{@"user": userId};
//    
//    [protfolioDetailsRequest cancelAllOperations];
//    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
//    protfolioDetailsRequest=manager.operationQueue;
//    manager.responseSerializer=[AFJSONResponseSerializer serializer];
//    [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSDictionary *response=(NSDictionary *)responseObject;
//        if (kDebugMessages) {
//            NSLog(@"protfolio JSON: %@", response);
//        }
//        if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
//            failure([response objectForKey:@"message"]);
//        }
//        else{
//            CLProtfolioObject *protfolio=[[CLProtfolioObject alloc] initWithDictionary:response];
//            success(protfolio);
//        }
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        if (kDebugMessages) {
//            NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
//        }
//        failure([CLCommon getMessageForErrorCode:error.code]);
//    }];
//}









static NSOperationQueue *protfolioDetailsRequest;

+ (void)cancelProtfolioPendingRequest {
    [protfolioDetailsRequest cancelAllOperations];
    protfolioDetailsRequest = nil;
}


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.projectsArray=[[NSMutableArray alloc] init];
    NSMutableArray *tempProjArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectArraykey];
    for (int i=0; i<[tempProjArray count]; i++) {
        [self.projectsArray addObject:[[CLProjectObject alloc] initWithDictionary:[tempProjArray objectAtIndex:i]]];
    }
    
    self.itemsArray=[[NSMutableArray alloc] init];
    NSMutableArray *tempItemsArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioItemArraykey];
    for (int i=0; i<[tempItemsArray count]; i++) {
        [self.itemsArray addObject:[[CLItemObject alloc] initWithDictionary:[tempItemsArray objectAtIndex:i]]];
    }
    
    self.educationProjects = [[NSMutableArray alloc]init];
    NSMutableArray *temEduArray = [dictionary objectForKeyNotNull:@"EducationProject"];
    for (NSMutableDictionary *dict in temEduArray) {
        [self.educationProjects addObject:[[CLEduProjectObject alloc]initWithDictionary:dict]];
    }
    
    self.careerListArray=[dictionary objectForKeyNotNull:kCLProfileProtfolioProjectCareerArraykey];
    self.courses=[dictionary objectForKey:@"course"];
    return self;
}

//Method for getting a protfolio detail for a particular user...
+ (void)getProtfolioDetailsForUser:(NSString *)userId success:(void (^)(CLProtfolioObject *protfolioObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLProtfolioObject *protfolioObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [protfolioDetailsRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        protfolioDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceProfileProtfolioNewURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"protfolio JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLProtfolioObject *protfolio=[[CLProtfolioObject alloc] initWithDictionary:response];
                success(protfolio);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
