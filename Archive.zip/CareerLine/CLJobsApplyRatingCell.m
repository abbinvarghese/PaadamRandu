//
//  CLJobsApplyRatingCell.m
//  CareerLine
//
//  Created by CSG on 1/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsApplyRatingCell.h"

@interface CLJobsApplyRatingCell()
//@property (weak, nonatomic) IBOutlet UIButton *bttnSmiley1;
//@property (weak, nonatomic) IBOutlet UIButton *bttnSmiley2;
//@property (weak, nonatomic) IBOutlet UIButton *bttnSmiley3;
//@property (weak, nonatomic) IBOutlet UIButton *bttnSmiley4;
//@property (weak, nonatomic) IBOutlet UIButton *bttnSmiley5;
@property (weak, nonatomic) IBOutlet RateView *rateView;

@property(nonatomic,assign) CLJobSmileyRating selectedRating;

//- (IBAction)bttnActionSmileyClicked:(id)sender;

@end

@implementation CLJobsApplyRatingCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLJobsApplyRatingCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        self.selectedRating=CLJobSmileyRatingNone;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

     self.rateView.notSelectedImage = [UIImage imageNamed:@"star_empty@2x.png"];
     self.rateView.fullSelectedImage = [UIImage imageNamed:@"star_full@2x.png"];
     self.rateView.rating = 0;
     self.rateView.editable = YES;
     self.rateView.maxRating = 5;
     self.rateView.delegate = self;
  
}

-(CLJobSmileyRating)getSelectedRating{
    return self.selectedRating;
}
- (void)rateView:(RateView *)rateView ratingDidChange:(float)rating {
    self.selectedRating= (int)rating;
}


@end
