//
//  CLInboxListingCell.h
//  CareerLine
//
//  Created by CSG on 3/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLInboxObject.h"

@interface CLInboxListingCell : UITableViewCell

@property (nonatomic, strong) CLInboxObject *inbox;

-(void)updateCellContent;

@end
