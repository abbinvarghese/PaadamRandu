//
//  CLCurrencyViewController.m
//  CareerLine
//
//  Created by Abbin on 12/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCurrencyViewController.h"

@interface CLCurrencyViewController ()

@property(nonatomic,strong) NSMutableArray *currencyArray;
@property(nonatomic, strong) NSMutableDictionary *selectedCurrencyDict;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (nonatomic,strong) NSString *searchText;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *noResultLabel;

@end

@implementation CLCurrencyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.tableHeaderView=self.searchBar;
    self.searchText=@"";
    self.noResultLabel.hidden = YES;
    self.noResultLabel.font = [UIFont systemFontOfSize:13];
    
    [self setLeftNavigationButton];
    
    self.title = NSLocalizedString(@"Select Currency", @"title for currency selection");
    
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    
    self.currencyArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:self.searchText];
    
    self.selectedCurrencyDict = [[NSMutableDictionary alloc]initWithDictionary:self.alreadySelectedCurrency];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark UITableView delegate methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.currencyArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"currencyCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"currencyCell"];
        cell.textLabel.font = [UIFont systemFontOfSize:12];
        [cell.textLabel setNumberOfLines:0];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    
    if (self.selectedCurrencyDict !=nil) {
        NSString *selectedString = [self.selectedCurrencyDict objectForKey:kCLContractPreferenceCountryIdkey];
        NSString *rowString = [[self.currencyArray objectAtIndex:indexPath.row] objectForKey:kjobPreferenceCountryCode];
      
        if ([selectedString isEqualToString:rowString] ) {
            
            cell.accessoryType=UITableViewCellAccessoryCheckmark;
            
        }
        else{
            cell.accessoryType=UITableViewCellAccessoryNone;
        }
       
    }
    cell.textLabel.text = [self getstringFromArray:indexPath];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self searchBarCancelButtonClicked:self.searchBar];
    self.selectedCurrencyDict = [self.currencyArray objectAtIndex:indexPath.row];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:^(void){
            if ([_delegate respondsToSelector:@selector(loadSelectedCurrencyDictionary:)]){
                [_delegate loadSelectedCurrencyDictionary:self.selectedCurrencyDict];
            }

        }];
    });
}



#pragma mark - UISearchBar Delegate Methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    self.searchText=searchBar.text;
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    self.searchText=searchBar.text;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(searchAfterDelay) object:nil];
    [self performSelector:@selector(searchAfterDelay) withObject:nil afterDelay:0];
}

-(void)searchAfterDelay{
    [self startSearchWith:self.searchText];
}

-(void)startSearchWith:(NSString*)searchText{
    self.currencyArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllCountryDetailsForCurrency:self.searchText];
    if(self.currencyArray.count == 0){
        self.noResultLabel.hidden = NO;
    }
    else{
        self.noResultLabel.hidden = YES;
    }
    [self.tableView reloadData];
}



#pragma mark Uitility

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Job Scope modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self searchBarCancelButtonClicked:self.searchBar];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(NSString*)getstringFromArray:(NSIndexPath*)indexPath{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    dict = [self.currencyArray objectAtIndex:indexPath.row];
    NSString *string = [NSString stringWithFormat:@"%@/ %@",[dict objectForKey:kjobPreferenceCurrencyCode],[dict objectForKey:kjobPreferenceCountryName]];
    return string;
}


@end
