//
//  CLAppDelegate.h
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMDrawerController.h"
#import "UIAlertView+NSCookbook.h"
#import "CLCoreDataHelper.h"

@interface CLAppDelegate : UIResponder <UIApplicationDelegate>
{
    CLCoreDataHelper    *coreDataHelper;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *loginNav;
@property (strong, nonatomic) UINavigationController *statusNav;
@property (strong, nonatomic) UINavigationController *homeNav;
@property (strong, nonatomic) UINavigationController *jobsNav;
@property (strong, nonatomic) UINavigationController *inboxNav;
@property (strong, nonatomic) UINavigationController *profileNav;
//@property (strong, nonatomic) UINavigationController *jobPreferencesNav;

@property (strong, nonatomic) UINavigationController *documentsNav;
@property (strong, nonatomic) UINavigationController *knowledgeNav;
//@property (strong, nonatomic) UINavigationController *calendarNav;
//@property (strong, nonatomic) UINavigationController *settingsNav;
@property (strong, nonatomic) UINavigationController *comingSoonNav;

@property (nonatomic,strong) MMDrawerController * drawerController;

-(void)updateCurrentTrafficLightColorAndUpdateNav;
-(void)updateNavBarColor;
-(void)setDrawerOpenGesturePanCenterView;
-(void)setDrawerOpenGesturePanNavigationBar;
-(void)popAllControllersAndClearData;

@end
