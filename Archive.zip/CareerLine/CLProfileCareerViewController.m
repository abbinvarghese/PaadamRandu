//
//  CLProfileCareerViewController.m
//  CareerLine
//
//  Created by RENJITH on 16/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileCareerViewController.h"
#import "CLAddCareerHistoryViewController.h"
#import "CLCareerSummaryViewController.h"
#import "CLCareerObject.h"
#import "CLCareerHistoryCell.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

#define kSectionFooterBgColor [UIColor whiteColor]
@interface CLProfileCareerViewController ()

@property (weak, nonatomic) IBOutlet UITableView *careerListTable;
@property (nonatomic, retain) NSArray *sectionHeadings;
@property (nonatomic, retain) CLCareerObject *careerObj;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

//Table view number of sections...
typedef enum {
    TableSectionCount = 2
} TableSection;

typedef enum {
    CLCareerSummaryIndex = 0,
    CLCareerHistoryIndex= 1,
} CLProfileCareerSectionIndex;

@end

@implementation CLProfileCareerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [self.careerListTable reloadData];
    
}

-(void)viewDidAppear:(BOOL)animated{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    [self careerdetailsWebservice];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Career List"];
}

-(void)viewDidDisappear:(BOOL)animated{
    
    [self.careerListTable setEditing:NO animated:NO];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLCareerObject cancelCareerListingPendingRequest];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = NSLocalizedString(@"Career", @"Career listing page heading");
    self.sectionHeadings = [[NSArray alloc]initWithObjects: NSLocalizedString(@"Career Summary",@"career summary heading"),NSLocalizedString(@"Career History",@"career history heading"), nil];
    
//    [self careerdetailsWebservice];
}

-(void)careerdetailsWebservice{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    [CLCareerObject careerListingForUser:[CLUserObject currentUser].userID success:^(CLCareerObject *careerObject) {
        self.careerObj = careerObject;
        [self.careerListTable reloadData];
        [progressHUD hideWithAnimation:YES];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
    
}
-(void)updateProgressHudColor{
    
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLCareerSummaryIndex)
    {
        [tableView setEditing:YES animated:YES];
        [tableView setAllowsSelectionDuringEditing:YES];
    }

    if (indexPath.section == CLCareerSummaryIndex) {
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        cell.detailTextLabel.text = self.careerObj.summary;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.detailTextLabel.numberOfLines = 0;
        [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
        return cell;
    }else{
        CLCareerHistoryCell *cell = (CLCareerHistoryCell *)[tableView dequeueReusableCellWithIdentifier:@"careerHistoryCellIdentifier"];
        if (cell == nil) {
            cell = [[CLCareerHistoryCell alloc] initWithStyle:UITableViewCellStyleDefault
                                              reuseIdentifier:@"careerHistoryCellIdentifier"];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.careerHistoryObj = [self.careerObj.careerHistory objectAtIndex:indexPath.row];
        
        return cell;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [self.sectionHeadings objectAtIndex:section];
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 35.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == CLCareerHistoryIndex) {
        return [self.careerObj.careerHistory count];
    }else{
        return 1;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return TableSectionCount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat indentHeight = 10;
    CGFloat headingHeight = 0;
    NSString *text;
    if (indexPath.section == CLCareerSummaryIndex) {
        text = self.careerObj.summary;
        CGRect expectedtextFrame = [text boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                      options:NSStringDrawingUsesLineFragmentOrigin
                                                   attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                               [UIFont systemFontOfSize:13], NSFontAttributeName,
                                                               nil]
                                                      context:nil];
        
        CGFloat textHeight=expectedtextFrame.size.height;
        CGFloat totalHeight= textHeight+headingHeight+indentHeight;
        return MAX(45, totalHeight);
    }else{
        return 69;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    if (section == CLCareerHistoryIndex) {
        return 37.0;
    }else{
        return 1.0;
    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == CLCareerHistoryIndex) {
        return YES;
    }else{
        return NO;
    }
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if (indexPath.section == CLCareerHistoryIndex) {
            UIAlertView *alertViewMessage = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Warning", @"alert heading") message:NSLocalizedString(@"Deleting this career record will lead to deletion of associated data (which you've created) in your CareerLine such as Projects/Functional Experiences and Performance Reviews. Proceed to delete?", @"alert messgae") delegate:self cancelButtonTitle:NSLocalizedString(@"YES", @"title for cancel button") otherButtonTitles:NSLocalizedString(@"NO", @"title for cancel button"), nil];
            [alertViewMessage showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex){
                
                if (buttonIndex == 0) {
                    [self removeWorkHistoryAtIndexPath:indexPath];
                } else{
                    
                }
                
            }];
        }
    }

    
    
    
    
} 
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLCareerSummaryIndex) {
        CLCareerSummaryViewController *controller=[[CLCareerSummaryViewController alloc] initWithNibName:@"CLCareerSummaryViewController" bundle:[NSBundle mainBundle]];
        controller.careerSummary = self.careerObj;
        [self.navigationController pushViewController:controller animated:YES];
    }else{
        CLAddCareerHistoryViewController *controller=[[CLAddCareerHistoryViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.carrerHisObj = [self.careerObj.careerHistory objectAtIndex:indexPath.row];
        //controller.carrerSummary = self.careerObj.summary;
        controller.delegate=self;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    if (section==CLCareerHistoryIndex){
        
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.careerListTable.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        return sectionFooter;
    }
    else{
        return nil;
    }
}

#pragma mark NSNotification Methods
-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    
    [self updateProgressHudColor];
    [self.careerListTable reloadData];
}

#pragma mark IBActions

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    
    CLAddCareerHistoryViewController *controller=[[CLAddCareerHistoryViewController alloc] initWithStyle:UITableViewStylePlain];
    controller.isEditMode = NO;
    controller.delegate = self;
    UINavigationController *addCareerHistoryNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
    [self presentViewController:addCareerHistoryNavigation animated:YES completion:nil];
    
}
#pragma mark CLAddWorkHistoryDeleagte Methods
-(void)addWorkHistory:(CLAddCareerHistoryViewController *)controller didAddWorkHistory:(CLCareerHistoryObject *)careerHistoryObj{
    
    [self.careerObj.careerHistory addObject:careerHistoryObj];
    [self.careerListTable reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark Delete Work History
-(void)removeWorkHistoryAtIndexPath:(NSIndexPath *)indexPath{
    
    CLCareerHistoryObject *history = [self.careerObj.careerHistory objectAtIndex:indexPath.row];
    NSString *deleteWrkHisId = history.wrkHisId;
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting qualification");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLCareerHistoryObject deleteWrkHistory:deleteWrkHisId forUser:[CLUserObject currentUser].userID success:^{
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.hidesBackButton=NO;
        [self.careerObj.careerHistory removeObjectAtIndex:indexPath.row];
        
        if(indexPath.row==0 && [self.careerObj.careerHistory count]==0){
            [self.careerListTable reloadData];
        }
        else{
            [self.careerListTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.hidesBackButton=NO;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

@end
