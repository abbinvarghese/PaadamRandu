//
//  CLInboxViewController.h
//  CareerLine
//
//  Created by CSG on 2/26/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLInboxViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

-(void)gotoInboxDetailViewFromPushWithInboxId:(NSString*)inboxId;
-(void)clearArraysAndReloadTable;
@end
