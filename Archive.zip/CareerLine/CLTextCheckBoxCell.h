//
//  CLTextCheckBoxCell.h
//  CareerLine
//
//  Created by RENJITH on 12/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLTextCheckBoxCell;

//Delegate Methods...
@protocol CLTextCheckBoxCellDelegate <NSObject>

@optional
- (void)textCheckBoxCellWillBeginEditing:(UITableViewCell *)cell forTextField:(UITextField*)textField;
- (void)textCheckBoxCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text;
- (void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status;
@end

@interface CLTextCheckBoxCell : UITableViewCell

@property(nonatomic,weak) id <CLTextCheckBoxCellDelegate> textCheckBoxdelegate;
@property (strong, nonatomic) NSIndexPath *cellIndexPath;

-(void)checkBoxClick:(BOOL)status;
-(NSString*)getEnteredText;
-(void)setCellText:(NSString*)text;
-(void)setCellTextColor:(UIColor*)color;
-(void)setSwitchColor:(UIColor*)color;
-(void)setCellFont:(UIFont*)font;
-(void)setPlaceHoldrText:(NSString *)text;
-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode;
-(void)setTextInputView:(id)picker;
-(void)setTextInputAccesoryView:(id)view;
-(void)resignCellFirstResponder;
-(void)disableCellField;
-(BOOL)isCellFirstResponder;
-(void)disableCelltxtField;
-(void)setKeyboardType :(UIKeyboardType)type;
-(void)enableCelltxtField;
-(void)enableCellField;
-(void)changeCelltxtFieldColor:(NSString *)hexCode;
@end
