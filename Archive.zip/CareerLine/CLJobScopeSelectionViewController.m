//
//  CLJobScopeSelectionViewController.m
//  CareerLine
//
//  Created by Abbin on 30/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobScopeSelectionViewController.h"
@interface CLJobScopeSelectionViewController ()

@property (nonatomic,retain) NSMutableArray *jobScopeArray;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,retain) NSMutableArray *selectedJobScopeArray;

@end

@implementation CLJobScopeSelectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedJobScopeArray = [[NSMutableArray alloc]initWithArray:self.passedOnJobScopeArray];
    if (self.singleSelectionOn && self.passedOnDict) {
        [self.selectedJobScopeArray addObject:self.passedOnDict];
    }
    if (!self.singleSelectionOn) {
        [self setRightNavigationButton];
    }
    self.title = NSLocalizedString(@"Select Job Scope", @"title for job scope selection view");
    self.jobScopeArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getJobScopeGroupedForSector:self.passedOnJobScopeDict];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.jobScopeArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCLTargetJobsJobScopeCellKey];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCLTargetJobsJobScopeCellKey];
        cell.textLabel.text = [[self.jobScopeArray objectAtIndex:indexPath.row]objectForKey:kCLTargetJobsJobScopeKey];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
    }
    if ([self doesSelectedJobScopeArrayContain:[self.jobScopeArray objectAtIndex:indexPath.row]]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.singleSelectionOn) {
        [self dismissViewControllerAnimated:YES completion:^(){
            if ([_delegate respondsToSelector:@selector(loadSelectedJobScopeDict:)]) {
                
                [_delegate loadSelectedJobScopeDict:[self objectwithAddedGroupName:[self.jobScopeArray objectAtIndex:indexPath.row]]];
            }
        }];

    }
    else{
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        if ([self doesSelectedJobScopeArrayContain:[self.jobScopeArray objectAtIndex:indexPath.row]]) {
            [self removeDictionaryFromSelectedJobScopeArray:[self.jobScopeArray objectAtIndex:indexPath.row]];
        }
        else{
            [self.selectedJobScopeArray addObject:[self objectwithAddedGroupName:[self.jobScopeArray objectAtIndex:indexPath.row]]];
        }
        [self.tableView reloadData];
    }
}

-(NSMutableDictionary*)objectwithAddedGroupName:(NSMutableDictionary*)dictionary{
    [dictionary setValue:[self.passedOnJobScopeDict objectForKey:kCLTargetJobsJobScopeKey] forKey:kCLTargetJobsJobScopeGroupNameKey];
    return dictionary;
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Job Scope modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveJobscopesAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(IBAction)bttnActionSaveJobscopesAndDismissModal:(id)sender{
    if (!self.singleSelectionOn) {
        [self dismissViewControllerAnimated:YES completion:^(){
            if ([_delegate respondsToSelector:@selector(loadSelectedJobScopeArray:)]) {
                [_delegate loadSelectedJobScopeArray:_selectedJobScopeArray];
            }
        }];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

-(BOOL)doesSelectedJobScopeArrayContain:(NSMutableDictionary*)dictionary{
    BOOL doesit = NO;
    for (NSMutableDictionary *dict in self.selectedJobScopeArray) {
        if ([[dict objectForKey:kCLTargetJobsJobScopeCodeKey] isEqualToString:[dictionary objectForKey:kCLTargetJobsJobScopeCodeKey]] || [[dict objectForKey:kCLTargetJobsJobScopeScopeIDKey] isEqualToString:[dictionary objectForKey:kCLTargetJobsJobScopeCodeKey]]) {
            doesit = YES;
        }
    }
    return doesit;
}

-(void)removeDictionaryFromSelectedJobScopeArray:(NSMutableDictionary*)dictionary{
    for (int i = 0; i < self.selectedJobScopeArray.count; i++) {
        if ([[[self.selectedJobScopeArray objectAtIndex:i] objectForKey:kCLTargetJobsJobScopeCodeKey] isEqualToString:[dictionary objectForKey:kCLTargetJobsJobScopeCodeKey]]) {
            [self.selectedJobScopeArray removeObjectAtIndex:i];
        }
    }
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
