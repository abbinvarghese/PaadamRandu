//
//  CLInboxDetailTableViewController.h
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLInboxObject.h"


@interface CLInboxDetailTableViewController : UITableViewController<UITextViewDelegate>

@property(strong,nonatomic) CLInboxObject *inbox;

//when navigating from questionnaire submission..
@property(nonatomic,assign)BOOL isFromQuestionnaireSubmission;

//To determine whether from push notifs..
@property(nonatomic,assign)BOOL isFromPushNotifications;
@end
