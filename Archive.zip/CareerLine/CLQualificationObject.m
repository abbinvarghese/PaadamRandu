//
//  CLQualificationObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLQualificationObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 1
@implementation CLQualificationObject
static NSOperationQueue *qualificationDetailsRequest;
static NSOperationQueue *deleteQualificationRequest;
static NSOperationQueue *deleteDocumentRequest;
static NSOperationQueue *uploadQDocumentRequest;


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.educationArray=[[NSMutableArray alloc] init];
    NSMutableArray *education=[dictionary objectForKeyNotNull:kCLQlfitnEducationkey];
    for (int i=0; i<[education count]; i++) {
        [self.educationArray addObject:[[CLEducationObject alloc] initWithDictionary:[education objectAtIndex:i]]];
    }
    self.trainingArray=[[NSMutableArray alloc] init];
    NSMutableArray *training=[dictionary objectForKeyNotNull:kCLQlfitnTrainingkey];
    for (int i=0; i<[training count]; i++) {
        [self.trainingArray addObject:[[CLTrainingObject alloc] initWithDictionary:[training objectAtIndex:i]]];
    }
    self.certificationArray=[[NSMutableArray alloc] init];
    NSMutableArray *certification=[dictionary objectForKeyNotNull:kCLQlfitnCertificationkey];
    for (int i=0; i<[certification count]; i++) {
        [self.certificationArray addObject:[[CLCertificationObject alloc] initWithDictionary:[certification objectAtIndex:i]]];
    }
    self.membershipArray=[[NSMutableArray alloc] init];
    NSMutableArray *membership=[dictionary objectForKeyNotNull:kCLQlfitnMembershipkey];
    for (int i=0; i<[membership count]; i++) {
        [self.membershipArray addObject:[[CLMembershipObject alloc] initWithDictionary:[membership objectAtIndex:i]]];
    }
    self.licenseArray=[[NSMutableArray alloc] init];
    NSMutableArray *license=[dictionary objectForKeyNotNull:kCLQlfitnLicensekey];
    for (int i=0; i<[license count]; i++) {
        [self.licenseArray addObject:[[CLLicenseObject alloc] initWithDictionary:[license objectAtIndex:i]]];
    }
    return self;
}

+ (void)cancelQualificationPendingRequest {
    [qualificationDetailsRequest cancelAllOperations];
    qualificationDetailsRequest = nil;
}

//Method for getting a Qualification detail for a particular user...
+ (void)qualificationDetailsForUser:(NSString *)userId success:(void (^)(CLQualificationObject *qualificationObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLQualificationObject *qualificationObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [qualificationDetailsRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        qualificationDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceQualificationListingURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"qualifiaction detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLQualificationObject *qualification=[[CLQualificationObject alloc] initWithDictionary:response];
                success(qualification);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting qualification for a particular user...
+ (void)deleteQualification:(NSString*)qualifiactionId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": qualifiactionId};
    
    [deleteQualificationRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteQualificationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLQlfitnDeletekey] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete reference JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading qualification document for a particular user...
+ (void)addDocument:(UIImage*)image forQualification:(NSString*)docId andUser:(NSString *)userId withDocType:(NSString *)docType andCaption :(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": docId,@"type":docType, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadQDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadQDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLQlfitnUploadDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"QualificationDocs" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"reference document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}
//Method for deleting qualification document for a particular user...
+ (void)deleteQDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteDocumentRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLQlfitnDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete assessment document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
