//
//  CLCareerKeyJobFactsObject.m
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerKeyJobFactsObject.h"
#import "NSDictionary+Additions.h"

@implementation CLCareerKeyJobFactsObject

@end
