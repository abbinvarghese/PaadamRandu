//
//  CLTappableTextViewCell.h
//  CareerLine
//
//  Created by CSG on 2/21/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TITokenField.h"
#import "CLSimpleTappableTextCell.h"

@interface CLTappableTextViewCell : UITableViewCell<TITokenFieldDelegate>

@property (strong, nonatomic) NSIndexPath *cellIndexPath;
@property(nonatomic,weak) id <CLTappableCellDelegate> delegate;

-(NSString*)getEnteredText;
-(void)setCellText:(NSString*)text;
-(void)setCellFont:(UIFont*)font;
-(void)setCellPlaceHolderText:(NSString*)text;
-(void)disableCellField;

@end
