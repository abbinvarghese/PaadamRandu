//
//  CLCompanyObject.h
//  CareerLine
//
//  Created by CSG on 6/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCompanyObject : NSObject

@property (nonatomic, strong) NSString *companyId;
@property (nonatomic, strong) NSString *companyName;
@property (nonatomic, strong) NSString *companyDescription;
@property (nonatomic, strong) NSString *companyLocation;
@property (nonatomic, strong) NSString *companyWebsiteUrl;
@property (nonatomic, strong) NSString *companyLogoUrl;

//To cancel pending requests before a new request..
+ (void)cancelCompanyDetailPendingRequests;

//Method for getting company detail for a particular job...
+ (void)companyDetailsForCompanyId:(NSString*)companyId success:(void (^)(CLCompanyObject *companyDetailObj))success failure:(void (^)(NSString *error))failure;


@end
