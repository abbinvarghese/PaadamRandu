//
//  CLAboutMeInfoViewController.h
//  CareerLine
//
//  Created by CSG on 7/25/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectNationalityViewController.h"
#import "CLInfoAddressViewController.h"
#import "CLInfoTelephoneViewController.h"
#import "CLInfoPreviousNameViewController.h"
#import "CLInfoObject.h"
#import "HTProgressHUD.h"

@class CLAboutMeInfoViewController;

//Delegate Methods...
@protocol CLInfoControllerDelegate <NSObject>

@optional
- (void)infoController:(CLAboutMeInfoViewController *)controller didEditInfo:(CLInfoObject*)infoObj;

@end

@interface CLAboutMeInfoViewController : UITableViewController<CLSimpleTextCellDelegate,CLSelectNationalityDelegate,CLAddressControllerDelegate,CLTelephoneControllerDelegate,CLPreviousNameControllerDelegate,HTProgressHUDDelegate,UIAlertViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLTappableCellDelegate,CLSelectLocationDelegate>

@property(nonatomic,weak) id <CLInfoControllerDelegate> delegate;
@property(nonatomic,strong)CLInfoObject *info;

@end
