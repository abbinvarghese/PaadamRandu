//
//  CLJobsDetailViewController.m
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsDetailViewController.h"
#import "CLJobsApplyViewController.h"
#import "CLJobsViewController.h"
#import "CLSideMenuViewController.h"
#import "CLCompanyDetailsViewController.h"
#import "CLEmailPickerTableViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "UIImageView+WebCache.h"
#import "CLUserObject.h"

#define kJobsDetailheadingFont 12

@interface CLJobsDetailViewController ()<UINavigationControllerDelegate>

//Job lisitng filter..
typedef enum {
    TrafficLightOptionFind = 0,
    TrafficLightOptionOpen = 1,
    TrafficLightOptionNone = 2
} TrafficLightChangeOptions;

@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (weak, nonatomic) IBOutlet UITableView *jobDetailsTable;
//@property (weak, nonatomic) IBOutlet UIImageView *jobImageView;
@property (weak, nonatomic) IBOutlet UILabel *jobPostedTime;
@property (weak, nonatomic) IBOutlet UILabel *lblJobTitle;
@property (weak, nonatomic) IBOutlet UIButton *bttnJobCompany;
@property (weak, nonatomic) IBOutlet UILabel *lblJobLocation;
@property (strong, nonatomic)HTProgressHUD *hudIndicator;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barBttnEmailJob;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *barBttnBookmarkJob;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *barBttnRejectJob;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *flexibleBarBttnRejectSpace;

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property(nonatomic,assign)BOOL isJobsDataLoaded;
@property(nonatomic,assign)BOOL isBttnBookmarkEnabled;

- (IBAction)bttnActionEmail:(id)sender;
- (IBAction)bttnActionBookmark:(id)sender;
- (IBAction)bttnActionReject:(id)sender;
@end

@implementation CLJobsDetailViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self updateTableHeaderDetails];
    if (!self.isFromPushNotifications) {
        self.title=self.job.jobTitle;
        self.jobDetailsTable.tableHeaderView=self.tblHeaderView;
    }
    else{
        self.title=NSLocalizedString(@"Job Details", @"Job detail page title");
    }
    
    self.isJobsDataLoaded=NO;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
}

-(void)viewDidAppear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    
    //if job is unread then decrement badge and set the job as read..
    if (self.job.jobUnreadStatus==1) {
        self.job.jobUnreadStatus=0;
        [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) decrementBadgeForPageType:CLJobsControllerIndex];
    }
    
    self.navigationController.toolbarHidden=NO;
    if(!self.isJobsDataLoaded){
        [self.activityIndicator startAnimating];
        [CLJobsObject jobsDetailsForjobId:self.job.jobID andUserId:[CLUserObject currentUser].userID
                                  success:^(CLJobsObject *jobObj){
                                      self.jobDetailsTable.tableHeaderView=nil;
                                      [self.activityIndicator stopAnimating];
                                      self.job=jobObj;
                                      self.isJobsDataLoaded=YES;
                                      [self addButtonsToToolbar];
                                      [self updateTableHeaderDetails];
                                      [self updateTableFooterDetails:self.job.jobAppliedStatus];
                                      [self.jobDetailsTable reloadData];
                                  }
                                  failure:^(NSString *error){
                                      //self.jobDetailsTable.tableHeaderView=nil;
                                      [self.activityIndicator stopAnimating];
                                      if (![error isEqualToString:@""]) {
                                          [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                      }
                                  }];
    }
    else{
        [self updateTableFooterDetails:self.job.jobAppliedStatus];
    }
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLJobsObject cancelJobDetailPendingRequests];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)addButtonsToToolbar{
    UIBarButtonItem *emailButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Email", @"job details page bottom butoon name") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionEmail:)];
    UIBarButtonItem *bookmarkButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Bookmark", @"job details page bottom butoon name") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionBookmark:)];
    UIBarButtonItem *rejectButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Reject", @"job details page bottom butoon name") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionReject:)];
    UIBarButtonItem *firstFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *secondFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [self setToolbarItems:[NSArray arrayWithObjects:emailButton,firstFlexibleSpace,bookmarkButton,secondFlexibleSpace,rejectButton, nil] animated:YES];
    self.barBttnBookmarkJob=bookmarkButton;
    self.barBttnEmailJob=emailButton;
    self.barBttnRejectJob=rejectButton;
    self.flexibleBarBttnRejectSpace=secondFlexibleSpace;
}

-(void)removeRejectButtonFromToolbar{
    NSMutableArray *items = [self.toolbarItems mutableCopy];
    [items removeObject:self.barBttnRejectJob];
    [items removeObject:self.flexibleBarBttnRejectSpace];
    [self setToolbarItems:items animated:YES];
}

-(void)setRightNavigationButtonWithJobStatus:(CLJobDetailsStatus)jobstatus{
    if(jobstatus==CLJobStatusNone){
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Apply", @"Text for job apply button before applied") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionApplyJob:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else if (jobstatus==CLJobStatusRejected){
        //No bar button..
        self.navigationItem.rightBarButtonItem=nil;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Applied", @"Text for job apply button after applied") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionApplyJob:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
        self.navigationItem.rightBarButtonItem.enabled=NO;
    }
}

-(void)updateTableHeaderDetails{
    self.jobPostedTime.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    [self.bttnJobCompany setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
    self.jobPostedTime.text=self.job.jobReceivedDate;
    self.lblJobTitle.text=self.job.jobTitle;
    [self.bttnJobCompany setTitle:self.job.companyDetails.companyName forState:UIControlStateNormal];
    if (self.job.jobLoc) {
        self.lblJobLocation.text=[NSString stringWithFormat:@"%@, %@",self.job.jobLoc,self.job.jobCountry];
    }
    else{
        self.lblJobLocation.text=@"";
    }
}

-(void)updateTableFooterDetails:(CLJobDetailsStatus)jobStatus{
    self.job.jobBookmarkStatus ? ([self setBookMarkButtonEnabled:NO]) : ([self setBookMarkButtonEnabled:YES]);
    
    switch (jobStatus) {
        case CLJobStatusNone:{
            [self setRightNavigationButtonWithJobStatus:CLJobStatusNone];
            self.barBttnRejectJob.title=NSLocalizedString(@"Reject", @"Text for reject button after rejection");
            self.barBttnRejectJob.enabled=YES;
            break;
        }
        case CLJobStatusApplied:{
            [self setRightNavigationButtonWithJobStatus:CLJobStatusApplied];
            self.barBttnRejectJob.title=NSLocalizedString(@"Reject", @"Text for reject button after rejection");
            self.barBttnRejectJob.enabled=NO;
            break;
        }
        case CLJobStatusRejected:{
            [self setRightNavigationButtonWithJobStatus:CLJobStatusRejected];
            self.barBttnRejectJob.title=NSLocalizedString(@"Rejected", @"Text for reject button after rejection");
            self.barBttnRejectJob.enabled=NO;
            break;
        }
        default:
            break;
    }
}

-(NSInteger)getRowCountForSection:(NSInteger)section{
    return [[[self.job.jobDetailsArray objectAtIndex:section] objectForKey:ktableSectionValueDictKey] count];
}

-(void)setBookMarkButtonEnabled:(BOOL)isEnabled{
    if(isEnabled){
        //self.barBttnBookmarkJob.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
        self.barBttnBookmarkJob.title=NSLocalizedString(@"Bookmark", @"Tiltle of book mark button when enabled");
        self.isBttnBookmarkEnabled=YES;
    }
    else{
        //self.barBttnBookmarkJob.tintColor=[UIColor lightGrayColor];
        self.barBttnBookmarkJob.title=NSLocalizedString(@"Bookmarked", @"Tiltle of book mark button when disabled");
        self.isBttnBookmarkEnabled=NO;
    }
}

-(void)updateProgressHudColor{
    self.hudIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.hudIndicator.hudView.alpha=0.9;
}

#pragma mark UITableView Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [self.job.jobDetailsArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger count=0;
    (self.isJobsDataLoaded) ? (count=[self getRowCountForSection:section]) : (count=0);
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"jobDetailsCellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:kJobsDetailvalueFont]];
        [cell.detailTextLabel setFont:[UIFont systemFontOfSize:kJobsDetailheadingFont]];
        [cell.textLabel setNumberOfLines:0];
        [cell.detailTextLabel setNumberOfLines:0];
        [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
        [cell.detailTextLabel setTextAlignment:NSTextAlignmentLeft];
    }
    [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
    NSDictionary *cellDict=[[[self.job.jobDetailsArray objectAtIndex:indexPath.section] objectForKey:ktableSectionValueDictKey] objectAtIndex:indexPath.row];
    NSMutableAttributedString *value=[cellDict objectForKey:ktableRowValueDictKey];
    NSString *heading=[cellDict objectForKey:ktableRowHeadingDictKey];
    
    cell.textLabel.attributedText=value;
    
    if (heading==(id)[NSNull null] || heading.length==0) {
        cell.detailTextLabel.text=@"";
    }
    else{
        cell.detailTextLabel.text=heading;
    }
    return cell;
}

//- (NSString *) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    if (section==0) {
//        return nil;
//    }
//    return [[self.job.jobDetailsArray objectAtIndex:section] objectForKey:ktableSectionHeadingDictKey];
//}


- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return self.tblHeaderView;
    }
    else{
        NSString *title=[[self.job.jobDetailsArray objectAtIndex:section] objectForKey:ktableSectionHeadingDictKey];
        //CGSize labelSize=[self getLabelSizeforText:title withFont:kSectionHeaderFont];
        
        UIImageView *sectionHeader=[[UIImageView alloc] initWithFrame:CGRectZero];
        sectionHeader.backgroundColor=[UIColor groupTableViewBackgroundColor];
        sectionHeader.alpha=0.95;
        
        UILabel *label=[[UILabel alloc] initWithFrame:CGRectMake(10, 2, 300, 30)];
        label.numberOfLines=1;
        label.translatesAutoresizingMaskIntoConstraints=NO;
        label.font=[UIFont boldSystemFontOfSize:14];
        label.lineBreakMode=NSLineBreakByWordWrapping;
        label.text=title;
        
        [sectionHeader addSubview:label];
        
        NSDictionary *viewsDictionary = NSDictionaryOfVariableBindings (label);
        NSString *visualFormat = @"H:|-10-[label]-10-|";
        NSArray *horizontalConstraints = [NSLayoutConstraint
                                          constraintsWithVisualFormat: visualFormat
                                          options: 0
                                          metrics: nil
                                          views: viewsDictionary];
        visualFormat = @"V:|-2-[label]-2-|";
        NSArray *verticalConstraints = [NSLayoutConstraint
                                        constraintsWithVisualFormat: visualFormat
                                        options: 0
                                        metrics: nil
                                        views: viewsDictionary];
        [sectionHeader addConstraints:horizontalConstraints];
        [sectionHeader addConstraints:verticalConstraints];
        
        return sectionHeader;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return 86;
    }
    else{
        return 34;
    }
}



-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat valueHeight;
    CGFloat headingHeight;
    CGFloat indentHeight=10;
    
    NSDictionary *cellDict=[[[self.job.jobDetailsArray objectAtIndex:indexPath.section] objectForKey:ktableSectionValueDictKey] objectAtIndex:indexPath.row];
    
    //to get the value height..
    NSMutableAttributedString *value=nil;
    if ([cellDict objectForKey:ktableRowValueDictKey]==(id)[NSNull null] || ((NSMutableAttributedString*)[cellDict objectForKey:ktableRowValueDictKey]).length==0) {
        value=[[NSMutableAttributedString alloc] initWithString:@""];
    }
    else{
        value=[cellDict objectForKey:ktableRowValueDictKey];
    }
    
    CGRect expectedValuetextFrame=[value boundingRectWithSize:CGSizeMake(300, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin context:nil];
    valueHeight=expectedValuetextFrame.size.height;
    
    
    //to get the heading height..
    NSString *heading=nil;
    if ([cellDict objectForKey:ktableRowHeadingDictKey]==(id)[NSNull null] || ((NSString*)[cellDict objectForKey:ktableRowHeadingDictKey]).length==0) {
        heading=@"";
    }
    else{
        heading=[cellDict objectForKey:ktableRowHeadingDictKey];
    }
    
    CGRect expectedHeadingtextFrame = [heading boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                            options:NSStringDrawingUsesLineFragmentOrigin
                                                         attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                     [UIFont systemFontOfSize:kJobsDetailheadingFont], NSFontAttributeName,
                                                                     nil]
                                                            context:nil];
    headingHeight=expectedHeadingtextFrame.size.height;
    
    CGFloat totalHeight=valueHeight+headingHeight+indentHeight;
    
    return MAX(44, totalHeight);
}

//#pragma mark MFMailComposeViewControllerDelegate
//
//-(void)mailComposeController:(MFMailComposeViewController *)controller
//         didFinishWithResult:(MFMailComposeResult)result
//                       error:(NSError *)error{
//    [self dismissViewControllerAnimated:YES completion:nil];
//}

#pragma mark IBActions

- (IBAction)bttnActionDisplayCompanyDetails:(id)sender {
    CLCompanyDetailsViewController *companyDetails=[[CLCompanyDetailsViewController alloc] initWithNibName:@"CLCompanyDetailsViewController" bundle:[NSBundle mainBundle]];
    companyDetails.company=self.job.companyDetails;
    UINavigationController *companyNav=[[UINavigationController alloc] initWithRootViewController:companyDetails];
    [companyNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self presentViewController:companyNav animated:YES completion:nil];
}

-(void)bttnActionApplyJob:(id)sender{
    if ([CLUserObject currentUser].trafficLightStatus == CLTrafficLightRedColor) {
        if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *changeTrafficStatusSheet=[[UIActionSheet alloc] initWithTitle:NSLocalizedString(@"To apply for a job, your status should be either READY or OPEN. Please change your status to continue.", @"ActionSheet message shown when job applied with Happy Status") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"apply job actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Ready", @"apply job actionsheet option 1"),NSLocalizedString(@"Open", @"apply job actionsheet option 3"), nil];
        [changeTrafficStatusSheet showInView:self.view];
        }
        else{
            UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"To apply for a job, your status should be either READY or OPEN. Please change your status to continue.", @"ActionSheet message shown when job applied with Happy Status") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"apply job actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
            
            UIAlertAction *readyAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Ready", @"apply job actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self actionSheet:nil didDismissWithButtonIndex:TrafficLightOptionFind];
                                            }];
            
            UIAlertAction *openAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Open", @"apply job actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                              {
                                                  [self actionSheet:nil didDismissWithButtonIndex:TrafficLightOptionOpen];
                                              }];
            
            [actionSheetController addAction:cancelAction];
            [actionSheetController addAction:readyAction];
            [actionSheetController addAction:openAction];
            actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
            [self presentViewController:actionSheetController animated:YES completion:nil];
        }
    }
    else{
        CLJobsApplyViewController *applyJobController=[[CLJobsApplyViewController alloc] initWithStyle:UITableViewStylePlain];
        applyJobController.job=self.job;
        [self.navigationController pushViewController:applyJobController animated:YES];
    }
}

- (IBAction)bttnActionEmail:(id)sender {
//    if ([MFMailComposeViewController canSendMail]) {
//        MFMailComposeViewController *mailComposer = [[MFMailComposeViewController alloc] init];
//        [[mailComposer navigationBar] setTintColor:[UIColor whiteColor]];
//        [mailComposer setSubject:@"CareerLine-Job"];
//        NSString *message = @"Job details goes here..";
//        [mailComposer setMessageBody:message isHTML:YES];
//        mailComposer.mailComposeDelegate = self;
//        [self presentViewController:mailComposer animated:YES completion:nil];
//    }
    
    
    CLEmailPickerTableViewController *emailPicker=[[CLEmailPickerTableViewController alloc] initWithStyle:UITableViewStylePlain];
    emailPicker.job=self.job;
    UINavigationController *emailPickerNav=[[UINavigationController alloc] initWithRootViewController:emailPicker];
    [self presentViewController:emailPickerNav animated:YES completion:nil];
}

- (IBAction)bttnActionBookmark:(id)sender {
    if(self.isBttnBookmarkEnabled){
        [self setBookMarkButtonEnabled:NO];
        [CLJobsObject bookmarkJobForJobId:self.job.jobID withUserId:[CLUserObject currentUser].userID toggleStatus:@"1"
                                  success:^(NSString *jobID){
                                      NSLog(@"job bookmark success for %@",jobID);
                                      self.job.jobBookmarkStatus=YES;
                                  }
                                  failure:^(NSString *jobID,NSString *error){
                                      if (![error isEqualToString:@""]) {
                                          if([[self.navigationController visibleViewController] isKindOfClass:[self class]] && [self.job.jobID isEqualToString:jobID]){
                                              [self setBookMarkButtonEnabled:YES];
                                          }
                                          [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't bookmark job. Please try again.", @"Error message when job cannot be bookmarked") cancelbuttonName:NSLocalizedString(@"OK", @"alert cancel button title")];
                                      }
                                  }];
    }
    else{
        [self setBookMarkButtonEnabled:YES];
        [CLJobsObject bookmarkJobForJobId:self.job.jobID withUserId:[CLUserObject currentUser].userID toggleStatus:@"0"
                                  success:^(NSString *jobID){
                                      NSLog(@"job bookmark success for %@",jobID);
                                      self.job.jobBookmarkStatus=NO;
                                  }
                                  failure:^(NSString *jobID,NSString *error){
                                      if (![error isEqualToString:@""]) {
                                          if([[self.navigationController visibleViewController] isKindOfClass:[self class]] && [self.job.jobID isEqualToString:jobID]){
                                              [self setBookMarkButtonEnabled:NO];
                                          }
                                          [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't bookmark job. Please try again.", @"Error message when job cannot be bookmarked") cancelbuttonName:NSLocalizedString(@"OK", @"alert cancel button title")];
                                      }
                                  }];
    }
}

- (IBAction)bttnActionReject:(id)sender {
    [self updateTableFooterDetails:CLJobStatusRejected];
    [CLJobsObject rejectJobForJobId:self.job.jobID withUserId:[CLUserObject currentUser].userID toggleStatus:@"2"
                            success:^(NSString *jobID){
                                NSLog(@"job reject success for %@",jobID);
                            }
                            failure:^(NSString *jobID,NSString *error){
                                if (![error isEqualToString:@""]) {
                                    if([[self.navigationController visibleViewController] isKindOfClass:[self class]] && [self.job.jobID isEqualToString:jobID]){
                                        [self updateTableFooterDetails:self.job.jobAppliedStatus];
                                    }
                                    [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't reject job. Please try again.", @"Error message when job cannot be rejected") cancelbuttonName:NSLocalizedString(@"OK", @"alert cancel button title")];
                                }
                            }];
}

#pragma mark UIActionSheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    CLTrafficLightStatus status;
    switch (buttonIndex) {
        case TrafficLightOptionFind:
            status=CLTrafficLightGreenColor;
            break;
        case TrafficLightOptionOpen:
            status=CLTrafficLightAmberColor;
            break;
        case TrafficLightOptionNone:
            //cancel clicked
            return;
            break;
        default:
            return;
            break;
    }
    
    [self.hudIndicator hideWithAnimation:YES];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while applying status");
    self.hudIndicator=progressHUD;
    [self updateProgressHudColor];
    [self.hudIndicator showInView:self.view];
    [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) changeTrafficLightAndUpdateInterfaceForStatus:status success:^(void){
        [self.hudIndicator hideWithAnimation:YES];
        CLJobsApplyViewController *applyJobController=[[CLJobsApplyViewController alloc] initWithStyle:UITableViewStylePlain];
        applyJobController.job=self.job;
        [self.navigationController pushViewController:applyJobController animated:YES];
    }failure:^(NSString *error){
        [self.hudIndicator hideWithAnimation:YES];
    }];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            switch (button.tag) {
                case 1:
                    [button setTitleColor:ColorCode_SideMenuTextGreen forState:UIControlStateNormal];
                    [button setImage:[UIImage imageNamed:@"icon_find_actionSheet"] forState:UIControlStateNormal];
                    break;
                case 2:
                    [button setTitleColor:ColorCode_SideMenuTextAmber forState:UIControlStateNormal];
                    [button setImage:[UIImage imageNamed:@"icon_open_actionSheet"] forState:UIControlStateNormal];
                    break;
                case 3:
                    [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                    break;
                default:
                    [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
                    break;
            }
        }
    }
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self updateTableHeaderDetails];
    [self.jobDetailsTable reloadData];
}

@end
