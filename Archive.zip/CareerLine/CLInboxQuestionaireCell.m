//
//  CLInboxQuestionaireCell.m
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxQuestionaireCell.h"

@interface CLInboxQuestionaireCell()

@property (weak, nonatomic) IBOutlet UILabel *lblDaysLeft;

@end

@implementation CLInboxQuestionaireCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLInboxQuestionaireCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)updateCellContent{
    self.lblDaysLeft.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.lblDaysLeft.text=self.daysLeft;
}

@end
