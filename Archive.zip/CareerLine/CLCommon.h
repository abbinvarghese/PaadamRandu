//
//  CLCommon.h
//  CareerLine
//
//  Created by CSG on 1/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "AFHTTPRequestOperationManager.h"
#import "GAI.h"
#import "GAIFields.h"
#import "GAITracker.h"
#import "GAIDictionaryBuilder.h"

#ifndef BEGIN_BLOCK
#define	BEGIN_BLOCK	do
#define	END_BLOCK	while(false);
#define	LEAVE_BLOCK	break;
#endif

@interface CLCommon : NSObject

//adds a caption to phots
+(void)ImageSelectionWithCaptionWithImagePicker:(UIImagePickerController *)controller withSuccess:(void (^)(NSString *captionTxt))success;

//Holds the device token string for push notifications
@property(nonatomic,strong)NSString *deviceTokenString;

//Holds the username temporarily..
@property(nonatomic,strong)NSString *userName;

//Holds the firstname temporarily..
@property(nonatomic,strong)NSString *firstname;

//Holds the lastname temporarily..
@property(nonatomic,strong)NSString *lastname;

//Holds the password temporarily..
@property(nonatomic,strong)NSString *passWord;

//Holds the path of database..
@property(nonatomic,strong)NSString *dbPath;

//Holds the current traffic light color to be used..
@property(nonatomic,strong)UIColor *currentTrafficLightColor;

//return a shared instance..
+ (CLCommon*)sharedInstance;

+(BOOL)HaveCamaraAccess:(UIView*)view;

+(BOOL)isOSversionLessThan8;

//Google Analytics
+ (void)sentScreenNameToGoogleAnalytics:(NSString*)aScreenName;
+ (void)sentEventNameToGoogleAnalytics:(NSString*)aEventName screenName:(NSString*)aScreenName;

//check network status
+ (BOOL) isNetworkConnected;
+ (void)setOnLineStatus:(BOOL)status;
+ (BOOL)isOnLine;

//fill an image with preferred color
+ (UIImage *)filledImageFrom:(UIImage *)source withColor:(UIColor *)color;

//To trim white space and newline
+ (NSString *)trimWhiteSpaces:(NSString *)text;

//To get height of String
+ (CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font;

//measure the height of UILabel with content
+ (CGFloat)measureHeightOfUILabel:(UILabel *)labelView;
+ (CGSize)measureString:(NSString *)stringToMeasure withFont:(UIFont *)font andConstraintWidth:(CGFloat)constraintWidth andConstraintHeight:(CGFloat)constraintHeight;

//to perform an animation in view
+(void)doViewAnimation:(UIView*)theView;

//Display alert messageß
+ (void)showAlert:(NSString *)aMessage;

//check if field is complete space

+(BOOL)doesItHaveSpace:(NSString*)string;

//initalize header for web
+(void)initialiseHeaderForWeb:(AFHTTPRequestSerializer*)forRequest;

//get device id
+(NSString*)deviceID;

//validate email string..
+ (BOOL)validateEmailWithString:(NSString*)email;

//validate alphabets and space..
+(BOOL)validateAlphabetsAndSpace:(NSString *)alpha;

//validate numbers only..
+(BOOL)validateNumbersOnly: (NSString *)number;

//validate alphabets only..
+(BOOL)validateAlphabetsOnly:(NSString *)alpha;

//validate password with alphanumerals and min 8 characters only..
+(BOOL)isPasswordStrong:(NSString *)password;

//show alerts..
+(void)showAlertwithTitle:(NSString *)title alertString:(NSString*)alertStr cancelbuttonName:(NSString*)cancel;

//json string for dict..
+(NSString*) jsonStringWithPrettyPrint:(BOOL) prettyPrint foDict:(NSMutableDictionary*)dict;

+(BOOL)isSizeLessThan5MBForImage:(UIImage*)image;

//get the corresponding alert message for error codes..
+(NSString*) getMessageForErrorCode:(long)code;

//get the corresponding string for date and format(same format as given - for webservice)..
+(NSString*) getStringForDate:(NSDate*)date andExactFormat:(NSString*)format;

//get the corresponding string for date and format(according to localization)..
+(NSString*) getStringForDate:(NSDate*)date andLocalFormat:(NSString*)format;

//get the corresponding date for string and format..
+(NSDate*) getDateForString:(NSString*)string andFormat:(NSString*)format;

//To load the DB.
-(void)loadCareerLineDB;

+(NSMutableDictionary*)getcountryFromDevice;

+ (BOOL) validateUrl: (NSString *) candidate;

//+(NSString*)getLocationFromTimeZone;
//+(NSString*)getLocationFromNetwork;

@end
