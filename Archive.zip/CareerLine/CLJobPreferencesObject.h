//
//  CLJobPreferencesObject.h
//  CareerLine
//
//  Created by Abbin on 13/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLJobPreferencesObject : NSObject

+ (void)jobSummaryForUser:(NSString *)userId success:(void (^)(NSMutableDictionary *jobPreDict))success failure:(void (^)(NSString *error))failure;

+(void)cancelJobSummeryRequest;

@end
