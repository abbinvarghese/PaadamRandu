//
//  CLPortfolioItemViewController.m
//  CareerLine
//
//  Created by Pravin on 10/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPortfolioItemViewController.h"
#import "CLDocumentViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

#import <MobileCoreServices/MobileCoreServices.h>

@interface CLPortfolioItemViewController ()

typedef enum {
    CLItemTitleIndex = 0,
    CLItemDocsIndex = 2,
    CLItemAnythingelseINdex = 1
} CLItemTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property(strong,nonatomic)NSString *titleText;
@property(strong,nonatomic)NSString *remarkText;
@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property(nonatomic,strong)NSNumber *descriptionHeight;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;



@end

@implementation CLPortfolioItemViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Additional Portfolio Item", @"Additional Portfolio Item edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"titleTextCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
        [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.descriptionHeight=[[NSNumber alloc] init];
    if (self.isEditMode) {
        self.titleText=self.itemObj.itemTitle;
        self.remarkText = self.itemObj.itemRemarks;
    }
    else{
        self.titleText=@"";
        self.remarkText=@"";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Items modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Items modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Items modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Reffered by validation..
    if ([self.titleText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Portfolio Item Title.", @"Error Message for null Project Title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.titleText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Portfolio Item Title length.", @"Error Message for length of Project Title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.remarkText = [self.remarkText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}
-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)saveItemForEdit:(BOOL)isEditMode{
    CLItemObject *newItemObj=[[CLItemObject alloc] init];
    if (isEditMode) {
        newItemObj.itemId=self.itemObj.itemId;
    }
    else{
        newItemObj.itemId=nil;
    }
    newItemObj.itemTitle=self.titleText;
    newItemObj.itemRemarks=self.remarkText;
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLItemObject saveItem:newItemObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *itemId){
        if (isEditMode) {
            self.itemObj.itemTitle=newItemObj.itemTitle;
            self.itemObj.itemRemarks=newItemObj.itemRemarks;
        }
        else{
            newItemObj.itemId=itemId;
            self.itemObj=newItemObj;
        }
        
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    }
                   failure:^(NSString *error){
                       if (![error isEqualToString:@""]) {
                           self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                           self.navigationItem.rightBarButtonItem.enabled=YES;
                           [progressHUD hideWithAnimation:YES];
                           [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Portfolio Item. Please try again later.", @"Error message when project cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                       }
                   }];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLItemObject addDocument:image forItem:self.itemObj.itemId andUser:[CLUserObject currentUser].userID andCaption:caption success:^(CLFileObject *fileObj){
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.itemObj.documents) {
            self.itemObj.documents=[[NSMutableArray alloc] init];
        }
        [self.itemObj.documents addObject:fileObj];
        [self.tableView reloadData];
    }
                      failure:^(NSString *error) {
                          if (![error isEqualToString:@""]) {
                              [progressHUD hideWithAnimation:YES];
                              self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                              self.navigationItem.rightBarButtonItem.enabled=YES;
                              [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                          }
                      }];
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *documentObj=[self.itemObj.documents objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLItemObject deleteDocument:documentObj.fileId success:^(){
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.itemObj.documents removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    }
                         failure:^(NSString *error){
                             if (![error isEqualToString:@""]) {
                                 [progressHUD hideWithAnimation:YES];
                                 self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                 self.navigationItem.rightBarButtonItem.enabled=YES;
                                 [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                             }
                         }];
}

#pragma mark IBActions

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self.txtViewFirstResponder resignFirstResponder];
        [self saveItemForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self.txtViewFirstResponder resignFirstResponder];
        [self saveItemForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.isEditMode) {
        return 3;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case CLItemTitleIndex:{
            CLSimpleTextCell *titleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            titleCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [titleCell setTextInputAccesoryView:self.keyboardResignView];
            [titleCell setPlaceHoldrText:NSLocalizedString(@"Title", @"Placeholder for Titles")];
            [titleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [titleCell setCellText:self.titleText];
            [titleCell setCellIndexPath:indexPath];
            [titleCell setCellClearButtonMode:UITextFieldViewModeAlways];
            titleCell.delegate=self;
            return titleCell;
            break;
        }
        case CLItemDocsIndex:{
            CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.indexPath=indexPath;
            cell.delegate=self;
            cell.photosLimit=-1;
            cell.placeHolderImageName=@"documentPlaceHolder";
            cell.photoUrls=self.itemObj.documents;
            [cell updateCollectionViewContents];
            return cell;
            break;
        }
        case CLItemAnythingelseINdex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.remarkText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        
            
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLItemTitleIndex:
            return NSLocalizedString(@"Portfolio Item Title", @"Placeholder for Portfolio Item Title");
            break;
        case CLItemDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==CLItemDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.itemObj.documents count]+1)/2));
    }
    else if (indexPath.section==CLItemAnythingelseINdex){
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.remarkText];
        }
        return MAX(44, ansHeight+1);
    }
    else{
        return 44;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.remarkText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLItemTitleIndex:{
            self.titleText=text;
            break;
        }
            
        default:
            break;
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark UIActionsheet Delegates

-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(itemsController:didAddItem:)]){
                [self.delegate itemsController:self didAddItem:self.itemObj];
            }
        }];
    }
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

@end
