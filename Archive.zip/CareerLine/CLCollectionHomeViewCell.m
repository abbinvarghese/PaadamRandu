//
//  CLCollectionCell.m
//  testProj
//
//  Created by CSG on 1/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCollectionHomeViewCell.h"
#import "UIImage+RoundedCorner.h"

@interface CLCollectionHomeViewCell()

@property (weak, nonatomic) IBOutlet UILabel *lblJobPostedTime;
@property (weak, nonatomic) IBOutlet UILabel *lblJobTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblJobCompanyName;
@property (weak, nonatomic) IBOutlet UILabel *lblJobLocation;
@property (weak, nonatomic) IBOutlet UIImageView *tileImageView;
@end

@implementation CLCollectionHomeViewCell

-(void)awakeFromNib
{
    self.contentView.frame = self.bounds;
    self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLCollectionHomeViewCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

-(void)updateContentsForIndexPath:(NSIndexPath*)indexPath{
    self.lblJobCompanyName.textColor=self.lblJobPostedTime.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    if(indexPath.row%4==0){
        //self.tileImageView.image=[[UIImage imageNamed:@"TileBackground"] roundedCornerImage:5 borderSize:0];
        self.tileImageView.image=[UIImage imageNamed:@"TileBg1"];
    }
    else if (indexPath.row%4==1){
        self.tileImageView.image=[UIImage imageNamed:@"TileBg2.jpg"];
    }
    else if (indexPath.row%4==2){
        self.tileImageView.image=[UIImage imageNamed:@"TileBg3.jpg"];
    }
    else{
        self.tileImageView.image=[UIImage imageNamed:@"TileBg4.jpg"];
    }
}

@end
