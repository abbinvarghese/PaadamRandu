//
//  CLLocationObject.h
//  CareerLine
//
//  Created by CSG on 7/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLLocationObject : NSObject<NSCopying>

@property(nonatomic,strong)NSString *locationId;
@property(nonatomic,strong)NSString *adminArea;
@property(nonatomic,strong)NSString *countryName;
@property(nonatomic,strong)NSString *locName;
@property(nonatomic,strong)NSString *locationCode;
//@property(nonatomic,strong)NSString *locationApartment;
//@property(nonatomic,strong)NSString *locationfloor;
//@property(nonatomic,strong)NSString *locationHouseNumber;
@property(nonatomic,strong)NSString *locationAddress;
@property(nonatomic,strong)NSString *locationName;
@property(nonatomic,strong)NSString *countryCode;
@property(nonatomic,strong)NSString *locationPincode;
@property(nonatomic,strong)NSString *formattedAddress;
@property(nonatomic,assign)BOOL isCommunicationAddress;

//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//get dictionary for object..
-(NSDictionary*)dictionaryForObject;

-(void)updateFormattedAddress;

+ (void)cancelGetLocationRequest;

//Method for getting locations for home location listing...
+ (void)getLocationsForSearchString:(NSString*)keyword forPage:(int)pageNumber success:(void (^)(NSMutableArray *locationList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;

//Method for getting locations for same country listing...
+ (void)getLocationsForSearchString:(NSString*)keyword withCountryCode:(NSString*)code notIn:(NSString*)blackListString forPage:(int)pageNumber success:(void (^)(NSMutableArray *locationList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;

@end
