//
//  CLSelectJobLevelDetailViewController.h
//  CareerLine
//
//  Created by CSG on 2/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectJobLevelDetailViewController;

//Delegate Methods...
@protocol CLSelectJobLevelDelegate <NSObject>

@optional
- (void)selectJobLevelControllerDidSelectJobLevel:(CLSelectJobLevelDetailViewController*)controller withDictonary:(NSMutableDictionary *)jobLevelDict;
-(void)transferSelectedDictionariesArray:(CLSelectJobLevelDetailViewController*)controller withDictonary:(NSMutableArray*)dictArray;
@end

@interface CLSelectJobLevelDetailViewController : UITableViewController

@property(nonatomic,weak) id <CLSelectJobLevelDelegate> delegate;
@property(nonatomic,strong)NSDictionary *selectedJobLevelGroupDict;
@property(nonatomic) BOOL multipleSelectionOn;
@property(nonatomic,strong)NSMutableArray *selectedCareerLevelGroupArray;
@property(nonatomic,strong)NSMutableArray *SecondselectedCareerLevelGroupArray;
@property(nonatomic,strong) NSMutableDictionary *selectedCareerlevelDict;
@end
