//
//  CLDocsObject.m
//  CareerLine
//
//  Created by Abbin on 12/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLDocsObject.h"
#import "NSDictionary+Additions.h"

@implementation CLDocsObject

-(id)initWithDictionary:(NSDictionary*)dictionary{
    self = [super init];
    if (self == nil) return nil;
    
    self.caption = [dictionary objectForKeyNotNull:kCLDocumentsCaptionKey];
    self.clAreaType = [dictionary objectForKeyNotNull:kCLDocumentsclAreaTypeKey];
    self.dateUploaded = [self formatDateFromString:[dictionary objectForKeyNotNull:kCLDocumentsDateUpload]];
    self.docType = [dictionary objectForKeyNotNull:kCLDocumentsDocTypeKey];
    self.docTypeId = [dictionary objectForKeyNotNull:kCLDocumentsDocTypeIDKey];
    self.file = [dictionary objectForKeyNotNull:kCLDocumentsFileKey];
    self.fileId = [dictionary objectForKeyNotNull:kCLDocumentsFileIDKey];
    self.fileTitle = [dictionary objectForKeyNotNull:kCLDocumentsFileTitleKey];
    self.fileUrl = [dictionary objectForKeyNotNull:kCLDocumentsFileUrlKey];
    self.oldName = [dictionary objectForKeyNotNull:kCLDocumentsOldNameKey];
    self.type = [dictionary objectForKeyNotNull:kCLDocumentsTypeKey];
    self.typeName = [dictionary objectForKeyNotNull:kCLDocumentsTypeName];
    self.imgWidth = [dictionary objectForKeyNotNull:kCLDocumentsWidthKey];
    self.imgHeight = [dictionary objectForKeyNotNull:kCLDocumentsHeightKey];
    
    return self;
}

-(NSString*)formatDateFromString:(NSString*)string{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString = [dateFormatter dateFromString:string];
    NSString *stringDate = [CLCommon getStringForDate:dateFromString andLocalFormat:@"MMMMdy"];
    return stringDate;
}

@end
