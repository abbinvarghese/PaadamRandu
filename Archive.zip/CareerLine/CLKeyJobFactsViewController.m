//
//  CLKeyJobFactsViewController.m
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLKeyJobFactsViewController.h"

#define pickerValName @"name"

#define pickerValPerEmpName    "permanentEmpDirect"
#define pickerValPerEmpInName    "permanentEmpInDirect"
#define pickerValTempEmpName   "temporaryEmpDirect"
#define pickerValTempEmpInName   "temporaryEmpInDirect"
#define pickerValBudgetName   "budgetResponsibility"

#define pickerValId @"id"

#define databaseJobLevelDetailId 50

@interface CLKeyJobFactsViewController ()

typedef enum {
    CLKeyJobFactsTitleIndex = 0,
    CLKeyJobAccountabilitiesIndex= 1,
    CLKeyJobPrformanceIndex = 2,
    CLKeyJobPermanentEmpReportIndex = 3,
    CLKeyJobTempEmpReportIndex = 4,
    CLKeyJobBudgetResposibilityIndex = 5
} CLKeyJobFactsTableSectionIndex;

@property (strong, nonatomic) UIPickerView *pickerView;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (nonatomic,assign) BOOL isReportedTo;
@property (nonatomic,strong) NSNumber *descriptionHeight;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;

@property (nonatomic, retain) NSMutableArray *directArray;
@property (nonatomic, retain) NSMutableArray *inDirectArray;
@property (nonatomic, retain) NSMutableArray *budgetResponsibilityArray;

@property (nonatomic, retain) NSMutableDictionary *selectedPermanentDirect;
@property (nonatomic, retain) NSMutableDictionary *selectedPermanentInDirect;
@property (nonatomic, retain) NSMutableDictionary *selectedTempDirect;
@property (nonatomic, retain) NSMutableDictionary *selectedTempInDirect;
@property (nonatomic, retain) NSMutableDictionary *selectedBudgetResponsibility;

@property (nonatomic, retain) NSString *jobAccountabilityText;
@property (nonatomic, retain) NSString *keyPerformanceText;
@property (nonatomic, retain) NSString *titleText;

@end

@implementation CLKeyJobFactsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.careerLevel !=nil) {
        if ([[self.careerLevel objectForKey:kCLCareerHistoryJobLevelCodekey] intValue] > databaseJobLevelDetailId) {
            self.isReportedTo =YES;
        }else{
            self.isReportedTo =NO;
        }
    }else{
        self.isReportedTo =NO;
    }
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Key Job Facts", @"Key Job Facts page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"titleTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"permanentEmpReportTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"tempReportTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"budgetTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"permanentEmpReportIndirectTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"tempReportIndirectTextCellIdentifier"];
    
    
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"jobAccountablitiesTextCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"keyPerformanceTextCellIdentifier"];
    
    self.descriptionHeight=[[NSNumber alloc] init];
    
    if (self.keyJobFactsObj) {
        self.titleText = self.keyJobFactsObj.jobFacts;
        self.keyPerformanceText = self.keyJobFactsObj.keyPerformance;
        self.jobAccountabilityText = self.keyJobFactsObj.jobAccountabilities;
        self.selectedPermanentDirect = self.keyJobFactsObj.permanentReportDirect;
        self.selectedPermanentInDirect = self.keyJobFactsObj.permanentReportInDirect;
        self.selectedTempDirect = self.keyJobFactsObj.tempReportDirect;
        self.selectedTempInDirect = self.keyJobFactsObj.tempReportInDirect;
        self.selectedBudgetResponsibility = self.keyJobFactsObj.budgetResponsibility;
    }
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=0;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
    
    [self setRightNavigationButton];
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    self.directArray = [NSMutableArray arrayWithObjects:
                        [NSDictionary dictionaryWithObjectsAndKeys:
                         @"1",pickerValId,
                         NSLocalizedString(@"No Direct Reports", @"No Direct Reports text"),pickerValName,
                         nil],
                        [NSDictionary dictionaryWithObjectsAndKeys:
                         @"2",pickerValId,
                         NSLocalizedString(@"1-3 Direct Reports", @"1-3 Direct Reports text"),pickerValName,
                         nil],
                        [NSDictionary dictionaryWithObjectsAndKeys:
                         @"3",pickerValId,
                         NSLocalizedString(@"4-10 Direct Reports", @"4-10 Direct Reports text"),pickerValName,
                         nil],
                        [NSDictionary dictionaryWithObjectsAndKeys:
                         @"4",pickerValId,
                         NSLocalizedString(@"10+ Direct Reports", @"10+ Direct Reports text"),pickerValName,
                         nil],
                        nil];
    self.inDirectArray = [NSMutableArray arrayWithObjects:
                          [NSDictionary dictionaryWithObjectsAndKeys:
                           @"1",pickerValId,
                           NSLocalizedString(@"No Indirect Reports", @"No Indirect Reports text"),pickerValName,
                           nil],
                          [NSDictionary dictionaryWithObjectsAndKeys:
                           @"2",pickerValId,
                           NSLocalizedString(@"1-5 Indirect Reports", @"1-5 Indirect Reports text"),pickerValName,
                           nil],
                          [NSDictionary dictionaryWithObjectsAndKeys:
                           @"3",pickerValId,
                           NSLocalizedString(@"6-20 Indirect Reports", @"6-20 Indirect Reports text"),pickerValName,
                           nil],
                          [NSDictionary dictionaryWithObjectsAndKeys:
                           @"4",pickerValId,
                           NSLocalizedString(@"20+ Indirect Reports", @"20+ Indirect Reports text"),pickerValName,
                           nil],
                          nil];
    
    self.budgetResponsibilityArray = [NSMutableArray arrayWithObjects:
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"1",pickerValId,
                                       NSLocalizedString(@"None", @"None text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"2",pickerValId,
                                       NSLocalizedString(@"< 10K USD", @"< 10K USD text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"3",pickerValId,
                                       NSLocalizedString(@"10K-100K USD", @"10K-100K USD text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"4",pickerValId,
                                       NSLocalizedString(@"100K-500K USD", @"100K-500K USD text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"5",pickerValId,
                                       NSLocalizedString(@"500K-1M USD", @"500K-1M USD text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"6",pickerValId,
                                       NSLocalizedString(@"1M-10M USD", @"1M-10M USD text"),pickerValName,
                                       nil],
                                      [NSDictionary dictionaryWithObjectsAndKeys:
                                       @"7",pickerValId,
                                       NSLocalizedString(@"10M+ USD", @"10M+ USD text"),pickerValName,
                                       nil],
                                      nil];
    
}

#pragma mark UIPickerView Methods

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    if (pickerView.tag == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 0) {
        return [self.directArray count];
    }else if (pickerView.tag == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 1){
        return [self.inDirectArray count];
    }else if (pickerView.tag == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 0){
        return [self.directArray count];
    }else if (pickerView.tag == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 1){
        return [self.inDirectArray count];
    }else if (pickerView.tag == CLKeyJobBudgetResposibilityIndex){
        return [self.budgetResponsibilityArray count];
    }else{
        return 0;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 0) {
        label.text= [[self.directArray objectAtIndex:row] objectForKey:pickerValName];
    }else if (pickerView.tag == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 1){
        label.text= [[self.inDirectArray objectAtIndex:row] objectForKey:pickerValName];
    }else if (pickerView.tag == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 0){
        label.text= [[self.directArray objectAtIndex:row] objectForKey:pickerValName];
    }else if (pickerView.tag == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 1){
        label.text= [[self.inDirectArray objectAtIndex:row] objectForKey:pickerValName];
    }else if (pickerView.tag == CLKeyJobBudgetResposibilityIndex){
        label.text= [[self.budgetResponsibilityArray objectAtIndex:row] objectForKey:pickerValName];
    }
    return label;
}

#pragma mark Utility Methods
-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"dismiss key job facts modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)bttnActionSaveAndDismissModal:(id)sender{
    
    CLCareerKeyJobFactsObject *newKeyJobObj=[[CLCareerKeyJobFactsObject alloc] init];
    
    newKeyJobObj.jobFacts = self.titleText;
    self.jobAccountabilityText = [self.jobAccountabilityText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];;
    newKeyJobObj.jobAccountabilities = self.jobAccountabilityText;
    self.keyPerformanceText = [self.keyPerformanceText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];;
    newKeyJobObj.keyPerformance = self.keyPerformanceText;
    newKeyJobObj.permanentReportDirect = self.selectedPermanentDirect;
    newKeyJobObj.permanentReportInDirect = self.selectedPermanentInDirect;
    newKeyJobObj.tempReportDirect = self.selectedTempDirect;
    newKeyJobObj.tempReportInDirect = self.selectedTempInDirect;
    newKeyJobObj.budgetResponsibility = self.selectedBudgetResponsibility;
    self.keyJobFactsObj = newKeyJobObj;
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.25;
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromBottom;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(keyJobController:didAddKeyJob:)]){
        [self.delegate keyJobController:self didAddKeyJob:self.keyJobFactsObj];
    }
    [self.navigationController popViewControllerAnimated:NO];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    if(cell!=nil){
        
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        
        if (cell.cellIndexPath.section == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 0) {
            
            [cell setCellText:[[self.directArray objectAtIndex:row] objectForKey:pickerValName]];
            self.selectedPermanentDirect =[self.directArray objectAtIndex:row];
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLKeyJobPermanentEmpReportIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }else if (cell.cellIndexPath.section == CLKeyJobPermanentEmpReportIndex && self.txtFirstResponder.tag == 1){
            
            [cell setCellText:[[self.inDirectArray objectAtIndex:row] objectForKey:pickerValName]];
            self.selectedPermanentInDirect =[self.inDirectArray objectAtIndex:row];
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLKeyJobPermanentEmpReportIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }else if (cell.cellIndexPath.section == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 0){
            
            [cell setCellText:[[self.directArray objectAtIndex:row] objectForKey:pickerValName]];
            self.selectedTempDirect =[self.directArray objectAtIndex:row];
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLKeyJobTempEmpReportIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }else if (cell.cellIndexPath.section == CLKeyJobTempEmpReportIndex && self.txtFirstResponder.tag == 1){
            
            [cell setCellText:[[self.inDirectArray objectAtIndex:row] objectForKey:pickerValName]];
            self.selectedTempInDirect =[self.inDirectArray objectAtIndex:row];
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLKeyJobTempEmpReportIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }else if (cell.cellIndexPath.section == CLKeyJobBudgetResposibilityIndex){
            
            [cell setCellText:[[self.budgetResponsibilityArray objectAtIndex:row] objectForKey:pickerValName]];
            self.selectedBudgetResponsibility =[self.budgetResponsibilityArray objectAtIndex:row];
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLKeyJobBudgetResposibilityIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark - tableView methods

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case CLKeyJobFactsTitleIndex:{
            CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Key Job Facts", @"Placeholder for Key Job Facts field")];
            [relatedToCell setCellText:self.titleText];
            [relatedToCell setCellIndexPath:indexPath];
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
        }
        case CLKeyJobAccountabilitiesIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobAccountablitiesTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            
            descCell.text=self.jobAccountabilityText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Key Job Accountabilities/Deliverables", @"Placeholder for Key Job Accountabilities/Deliverables field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLKeyJobPrformanceIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"keyPerformanceTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.keyPerformanceText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Key Performance Indicators", @"Placeholder for Key Performance Indicators field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
            
        }
        case CLKeyJobPermanentEmpReportIndex:{
            if (indexPath.row == 0) {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"permanentEmpReportTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputView:self.pickerView];
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Direct", @"Placeholder for direct field")];
                
                if (self.selectedPermanentDirect != nil) {
                    [relatedToCell setCellText:[self.selectedPermanentDirect objectForKey:pickerValName]];
                }else{
                    [relatedToCell setCellText:@""];
                }
                
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }else{
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"permanentEmpReportIndirectTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputView:self.pickerView];
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Indirect", @"Placeholder for Indirect field")];
                if (self.selectedPermanentInDirect != nil) {
                     [relatedToCell setCellText:[self.selectedPermanentInDirect objectForKey:pickerValName]];
                    
                }else{
                    [relatedToCell setCellText:@""];
                }
                [relatedToCell setCellIndexPath:indexPath];
                
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }
            
        }
        case CLKeyJobTempEmpReportIndex:{
            if (indexPath.row == 0) {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"tempReportTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputView:self.pickerView];
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Direct", @"Placeholder for Direct field")];
                if (self.selectedTempDirect !=nil) {
                    [relatedToCell setCellText:[self.selectedTempDirect objectForKey:pickerValName]];
                }else{
                    [relatedToCell setCellText:@""];
                }
                [relatedToCell setCellIndexPath:indexPath];
                
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }else{
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"tempReportIndirectTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputView:self.pickerView];
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Indirect", @"Placeholder for Indirect field")];
                if (self.selectedTempInDirect !=nil) {
                     [relatedToCell setCellText:[self.selectedTempInDirect objectForKey:pickerValName]];
                }else{
                    [relatedToCell setCellText:@""];
                }
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }
            
        }
        case CLKeyJobBudgetResposibilityIndex:{
            CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"budgetTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setTextInputView:self.pickerView];
            [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [relatedToCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Budget Responsibility", @"Placeholder for Budget Responsibility field")];
            if (self.selectedBudgetResponsibility != nil) {
                [relatedToCell setCellText:[self.selectedBudgetResponsibility objectForKey:pickerValName]];
               
            }else{
                 [relatedToCell setCellText:@""];
            }
            [relatedToCell setCellIndexPath:indexPath];
            
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
        }
        default:
            return nil;
            break;
    }
    
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLKeyJobFactsTitleIndex:
            return NSLocalizedString(@"Key Job Facts", @"Placeholder for Key Job Facts field");
            break;
        case CLKeyJobAccountabilitiesIndex:
            return NSLocalizedString(@"Key Job Accountabilities/Deliverables", @"Placeholder for Key Job Accountabilities/Deliverables field");
            break;
        case CLKeyJobPrformanceIndex:
            return NSLocalizedString(@"Key Performance Indicators", @"Placeholder for Key Performance Indicators field");
            break;
        case CLKeyJobPermanentEmpReportIndex:
            return NSLocalizedString(@"Permanent Employee Reports", @"Placeholder for Permanent Employee Reports field");
            break;
        case CLKeyJobTempEmpReportIndex:
            return NSLocalizedString(@"Temporary/Sub-Contractor Reports", @"Placeholder for Temporary/Sub-Contractor Reports field");
            break;
        case CLKeyJobBudgetResposibilityIndex:
            return NSLocalizedString(@"Budget Responsibility", @"Placeholder for Budget Responsibility field");
            break;
            
        default:
            return nil;
            break;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == CLKeyJobPermanentEmpReportIndex) {
        return 2;
    }else if (section == CLKeyJobTempEmpReportIndex){
        return 2;
    }else{
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLKeyJobAccountabilitiesIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.jobAccountabilityText];
        }
        return MAX(44, ansHeight+1);
    }else if (indexPath.section == CLKeyJobPrformanceIndex){
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.keyPerformanceText];
        }
        return MAX(44, ansHeight+1);
    }
    return 44;
}
-(CGFloat)getTextViewSizeForText:(NSString*)text{
    
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.isReportedTo) {
        return 3;
    }else{
        return 6;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    if (indexPath.section == CLKeyJobAccountabilitiesIndex) {
        self.jobAccountabilityText=heightCell.text;
        
        
    }else if (indexPath.section == CLKeyJobPrformanceIndex){
        self.keyPerformanceText = heightCell.text;
    }
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillClearContent:(CLSimpleTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (cell.cellIndexPath.section) {
        case CLKeyJobFactsTitleIndex:{
           self.titleText = @"";
            break;
        }
        case CLKeyJobPermanentEmpReportIndex:{
            if (cell.cellIndexPath.row == 0) {
                self.selectedPermanentDirect =nil;
            }else{
                self.selectedPermanentInDirect=nil;
            }
            break;
        }
        case CLKeyJobTempEmpReportIndex:{
            if (cell.cellIndexPath.row == 0) {
                self.selectedTempDirect=nil;
            }else{
                self.selectedTempInDirect=nil;
            }
            break;
        }
        case CLKeyJobBudgetResposibilityIndex:{
            self.selectedBudgetResponsibility=nil;
            break;
        }
        default:
            break;
    }
    [self.tableView reloadData];
}

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    if (cell.cellIndexPath.section == CLKeyJobPermanentEmpReportIndex ||cell.cellIndexPath.section == CLKeyJobTempEmpReportIndex || cell.cellIndexPath.section == CLKeyJobBudgetResposibilityIndex) {
        
        self.pickerView.tag = cell.cellIndexPath.section;
        self.txtFirstResponder.tag = cell.cellIndexPath.row;
        [self.pickerView selectRow:0 inComponent:0 animated:YES];
        [self.pickerView reloadAllComponents];
    }
}
 
- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLKeyJobFactsTitleIndex:{
            self.titleText=text;
            break;
        }
        default:
            break;
    }
}

@end
