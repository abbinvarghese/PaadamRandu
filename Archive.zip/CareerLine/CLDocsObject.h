//
//  CLDocsObject.h
//  CareerLine
//
//  Created by Abbin on 12/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLDocsObject : NSObject

@property(nonatomic,strong) NSString *caption;
@property(nonatomic,strong) NSString *clAreaType;
@property(nonatomic,strong) NSString *dateUploaded;
@property(nonatomic,strong) NSString *docType;
@property(nonatomic,strong) NSString *docTypeId;
@property(nonatomic,strong) NSString *file;
@property(nonatomic,strong) NSString *fileId;
@property(nonatomic,strong) NSString *fileTitle;
@property(nonatomic,strong) NSString *fileUrl;
@property(nonatomic,strong) NSString *oldName;
@property(nonatomic,strong) NSString *type;
@property(nonatomic,strong) NSString *typeName;

@property(nonatomic,strong) NSNumber *imgWidth;
@property(nonatomic,strong) NSNumber *imgHeight;

-(id)initWithDictionary:(NSDictionary*)dictionary;


@end
