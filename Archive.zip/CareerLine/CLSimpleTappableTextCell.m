//
//  CLProfileNationalityCell.m
//  CareerLine
//
//  Created by CSG on 2/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSimpleTappableTextCell.h"

@interface CLSimpleTappableTextCell()
@property (weak, nonatomic) IBOutlet UITextField *txtTapField;
@property (weak, nonatomic) IBOutlet UIView *tapView;
@property(strong,nonatomic)IBOutlet UITapGestureRecognizer *singleTap;
@property (weak, nonatomic) IBOutlet UIButton *closeBtn;

- (IBAction)bttnActionSelectNationality:(id)sender;

@end

@implementation CLSimpleTappableTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLSimpleTappableTextCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)bttnActionSelectNationality:(id)sender {
    self.tapView.backgroundColor=ColorCode_CareerLineGreen;
    self.tapView.alpha=0.2;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(changeColorOfTapView) object:nil];
	[self performSelector:@selector(changeColorOfTapView) withObject:nil afterDelay:0.2];
    
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellDidTapCellTextField:forIndexPath:)]){
		[self.delegate cellDidTapCellTextField:self forIndexPath:self.cellIndexPath];
	}
}
- (IBAction)closeBtnAction:(id)sender {
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(tappableCellWillClearContent:forIndexPath:forTextField:)])
    {
        [self.delegate tappableCellWillClearContent:self forIndexPath:self.cellIndexPath forTextField:self.txtTapField];
    }
}

-(void)setCellCloseBtnOption:(BOOL)status{
    self.closeBtn.hidden = status;
}
-(void)changeColorOfTapView{
    self.tapView.backgroundColor=[UIColor clearColor];
}

-(NSString*)getEnteredText{
    return self.txtTapField.text;
}

-(void)setPlaceHoldrText:(NSString *)text{
    self.txtTapField.placeholder=text;
}

-(void)setCellText:(NSString*)text{
    self.txtTapField.text=text;
}

-(void)setCellFont:(UIFont*)font{
    self.txtTapField.font=font;
}

-(void)enableTapStatus{
    self.singleTap.enabled=YES;
}

-(void)updateTapStatus{
    if(self.txtTapField.text.length>0){
        self.singleTap.enabled=NO;
    }
    else{
        self.singleTap.enabled=YES;
    }
}

@end
