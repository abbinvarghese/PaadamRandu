//
//  CLIndustryGroupViewController.m
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLIndustryGroupViewController.h"
#define kIndustryGrpOtherText NSLocalizedString(@"Other",@"Other text title")

@interface CLIndustryGroupViewController ()
@property (nonatomic ,strong)NSMutableArray *industryGroupArray;
@property (nonatomic ,strong)NSMutableDictionary *otherDict;
@property (nonatomic,assign)BOOL isAllSelect;
@end

@implementation CLIndustryGroupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.title= [self.selectedIndustrySectorDict objectForKey:kIndSectDictName];
    
    self.otherDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[self.selectedIndustrySectorDict objectForKey:kIndSectDictCode],kIndSectDictCode,@"0",kIndustryGrpDictCode,[NSString stringWithFormat:@"%@ - %@",kIndustryGrpOtherText,[self.selectedIndustrySectorDict objectForKey:kIndSectDictName]],kIndustryGrpDictName,@"1",kIndGrpOtherFlag, nil];
    self.industryGroupArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getIndustriesGroupedForSector:self.selectedIndustrySectorDict];
    
    if (!self.singleSelection) {
        [self.industryGroupArray addObject:self.otherDict];
    }
    
    if ([self checkArrayAndEnableSelectAll] && self.enableSelectAll) {
        self.isAllSelect = YES;
    }
    else{
        self.isAllSelect = NO;
    }
    if (!self.singleSelection && [self checkArrayAndEnableSelectAll]){
        [self setRightNavigationButton];
    }
}

-(BOOL)checkArrayAndEnableSelectAll{
    BOOL enable = NO;
    if (self.alrdySelectedindustries.count == 0) {
        enable = YES;
    }
    else{
        for (NSMutableDictionary *dict in self.alrdySelectedindustries)
        {
            NSArray *result = [dict valueForKeyPath:@"IndSect"];
            
            NSArray *industry = [dict valueForKeyPath:@"Industry"];
            
            if (result.count>0) {
                for(NSDictionary *dict in result)
                {
                    if ([[dict objectForKey:@"industrySectCode"] integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]) {
                        enable = NO;
                        break;
                    }
                    else if ([[dict objectForKey:@"indsectcode"] integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]){
                        enable = NO;
                        break;
                    }
                    else{
                        enable = YES;
                        
                    }
                    
                }
            }
            
            else if (industry.count>0) {
                for (NSDictionary *dict in industry) {
                    if ([[dict objectForKey:@"indsectcode"]integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]) {
                        enable = NO;
                        break;
                    }
                    else if ([[dict objectForKey:@"industrySectCode"] integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]){
                        enable = NO;
                        break;
                    }
                    else{
                        enable = YES;
                    }
                }
            }
            
            else if ([self doWeNeedSelect]){
                enable = NO;
            }
            
            
            else if ([self doWeNeedSelectAllAgain]){
                enable = YES;
            }
            else if([self doWeNeedSelectAll]){
                enable = YES;
            }
            else {
                YES;
            }
//            if ([[dict objectForKey:@"industrySectCode"] integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]) {
//                enable = NO;
//            }
//            else if ([[dict objectForKey:@"indsectcode"] integerValue] == [[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]integerValue]){
//                enable = NO;
//            }
//            else{
//                enable = YES;
//            }
        }
    }
    return enable;
}

-(BOOL)doWeNeedSelect{
    for (NSMutableDictionary *dict in [[self.alrdySelectedindustries objectAtIndex:0]objectForKey:@"IndGrp"]) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"indsectcode"]] isEqualToString:[NSString stringWithFormat:@"%@",[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]]]) {
            return YES;
        }
    }
    return NO;
}

-(BOOL)doWeNeedSelectAllAgain{
    for (NSMutableDictionary *dict in [[self.alrdySelectedindustries objectAtIndex:0]objectForKey:@"Industry"]) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"indsectcode"]] isEqualToString:[NSString stringWithFormat:@"%@",[self.selectedIndustrySectorDict objectForKey:@"industrySectCode"]]]) {
            return NO;
        }
        
    }
    return YES;
}

-(BOOL)doWeNeedSelectAll{
    if ([[[self.alrdySelectedindustries objectAtIndex:0]objectForKey:@"Industry"] count]>0) {
        return NO;
    }
    return YES;
}

#pragma mark Utility Methods
-(void)setRightNavigationButton
{
    NSString *text=@"";
    if (self.isAllSelect)
    {
        text = @"Select All";
    }
    else{
        text = @"Done";
    }
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(text, @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark - IBActions
-(void)bttnActionCancelModal:(id)sender{
    
    if (self.isAllSelect && [self checkArrayAndEnableSelectAll])
    {
        NSMutableArray *industryMainArray = [self.alrdySelectedindustries mutableCopy];
        NSMutableArray *industryArray = [self.alrdySelectedindustries mutableCopy];
        self.alrdySelectedindustries = [[NSMutableArray alloc]initWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                               @"1",@"industryAll",
                                                                               @"0",@"industryOther",
                                                                               @"0",@"industryGrpOther",
                                                                               [self.selectedIndustrySectorDict objectForKey:@"industrySectCode"],@"industrySectCode",
                                                                               [NSString stringWithFormat:@"All %@",
                                                                               [self.selectedIndustrySectorDict objectForKey:@"industrySectName"]],
                                                                               @"industrySectName",
                                                                               @"",@"industry",
                                                                               @"",@"industryCode",
                                                                               @"",@"industryGroupCode",
                                                                               @"",@"industryGroupName",
                                                                    @"",@"industrySubName",nil], nil];
        
        NSString *selIndSectCode = [self.selectedIndustrySectorDict objectForKey:@"industrySectCode"];
        
       // if([industryArray count])
        {
            for(NSMutableDictionary *dict in self.alrdySelectedindustries)
            {
                if([industryArray count])
                {
                    for(NSMutableDictionary *thedict in industryMainArray)
                    {
                         NSMutableArray *result = [[thedict valueForKeyPath:@"IndSect"]mutableCopy];
                        
                        if([result count])
                        {
//                            NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [dict objectForKey:@"industrySectCode"], @"industrySectCode", [dict objectForKey:@"industrySectName"], @"industrySectName", @"", @"industry",nil];
                            [result addObject:dict];
                            
                            NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            [newDict1 setValue:result forKey:@"IndSect"];

                            
//                            NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
//                            [newDict setValue:result forKey:@"IndSect"];
                            [industryArray removeAllObjects];
                            [industryArray addObject:newDict1];

                        }
                        else
                        {
//                            NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [dict objectForKey:@"industrySectCode"], @"industrySectCode", [dict objectForKey:@"industrySectName"], @"industrySectName", @"", @"industry",nil];
                            
                            NSMutableArray *result = [[NSMutableArray alloc]init];
                            [result addObject:dict];
                            
                            NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            [newDict1 setValue:result forKey:@"IndSect"];
                            
                            [industryArray removeAllObjects];
                            [industryArray addObject:newDict1];
                            
//                            NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
//                            [newDict setValue:result forKey:@"IndSect"];
//                            [industryArray addObject:newDict];
                        }
                    }
                }
                else
                {
                    //NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [dict objectForKey:@"industrySectCode"], @"industrySectCode", [dict objectForKey:@"industrySectName"], @"industrySectName", @"", @"industry",nil];
                    
                    NSMutableArray *result = [[NSMutableArray alloc]init];
                     [result addObject:dict];
                    
                    NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
                    [newDict setValue:result forKey:@"IndSect"];
                    [industryArray addObject:newDict];
                }
            }
        }
        

            if([industryArray count])
            {
                for(NSMutableDictionary *thedict in industryMainArray)
                {
                    NSMutableArray *result = [[thedict valueForKeyPath:@"Industry"]mutableCopy];
                    
                    if([result count])
                    {
                        NSMutableArray *tempArr = [[NSMutableArray alloc]init];
                        for(NSMutableDictionary *dict in result)
                        {
                            NSString *sectCode = [dict objectForKey:@"indsectcode"];
                            
                            if([sectCode isEqualToString:selIndSectCode])
                            {
                            }
                            else
                                [tempArr addObject:dict];
                        }
                        
                        NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                        newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                        [newDict1 setValue:tempArr forKey:@"Industry"];
                        
                        [industryArray removeAllObjects];
                        [industryArray addObject:newDict1];
                            
                    }
                        
                }
            }

        
        [self.tableView setEditing:NO animated:NO];
        [self dismissViewControllerAnimated:YES completion:^{
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(industryGroupViewController:didAddOtherIndustryGroup: andListArray:)]){
                //            [self addSectionNameto:self.otherDict];
                [self.delegate industryGroupViewController:self didAddOtherIndustryGroup:[self.alrdySelectedindustries objectAtIndex:0] andListArray:industryArray];
            }
        }];

    }
    else{
        [self.tableView setEditing:NO animated:NO];
        [self dismissViewControllerAnimated:YES completion:^{
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(industryGroupViewController:didAddOtherIndustryGroup: andListArray:)]){
                [self addSectionNameto:self.otherDict];
                [self.delegate industryGroupViewController:self didAddOtherIndustryGroup:self.otherDict andListArray:nil];
            }
        }];
    }
    
    
}

-(NSMutableDictionary*)addSectionNameto:(NSMutableDictionary*)dictionary{
    NSString *sectionName = [[CLCoreDataHelper sharedCLCoreDataHelper] getIndustrySectionNameFrom:[dictionary objectForKey:kCLTargetJobsindustrySectCode]];
    [dictionary setValue:sectionName forKey:kCLTargetJobsindustrySectName];
    return dictionary;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}   
  
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.industryGroupArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:1];
    }
    
    NSMutableDictionary *industrySectorGroup=[self.industryGroupArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text=[industrySectorGroup objectForKey:kIndustryGrpDictName];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[[self.industryGroupArray objectAtIndex:indexPath.row] objectForKey:kIndGrpOtherFlag] boolValue]) {
        if([CLCommon isOSversionLessThan8])
        {
            UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];
            enterFuncAlert.tag=88;
            enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
            [enterFuncAlert show];
        }else{
            // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
            UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                           message: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option")
                                                                    preferredStyle: UIAlertControllerStyleAlert];
            
            [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                
            }];
            UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * action){
                                                                 //Do Some action here
                                                                 
                                                                 UITextField *textField = alert.textFields[0];
                                                                 [textField resignFirstResponder];
                                                                 
                                                                 NSString *otherFuncText = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                 if (![CLCommon doesItHaveSpace:otherFuncText]) {
                                                                     [self.otherDict removeObjectForKey:kIndustryGrpDictName];
                                                                     [self.otherDict setObject:otherFuncText forKey:kIndustryGrpDictName];
                                                                     self.isAllSelect = NO;
                                                                     [self bttnActionCancelModal:nil];
                                                                 }
                                                                 
                                                                 
                                                                 
                                                             }];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                   style: UIAlertActionStyleDefault
                                                                 handler: nil];
            
            [alert addAction: cancelAction];
            [alert addAction: okAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
       
        
    }else{

    CLIndustryViewController *detailViewController = [[CLIndustryViewController alloc] initWithNibName:@"CLIndustryViewController" bundle:[NSBundle mainBundle]];
        detailViewController.singleSelection=self.singleSelection;
    detailViewController.selectedIndustryDict=[self.industryGroupArray objectAtIndex:indexPath.row];
     detailViewController.selectedindustries=self.alrdySelectedindustries;
        detailViewController.delegate = (id<CLSelectIndustryDelegate>)self.delegate;
    [self.navigationController pushViewController:detailViewController animated:YES];
    }
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //Enter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            
            NSString *otherFuncText = [[[alertView textFieldAtIndex:0] text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (![CLCommon doesItHaveSpace:otherFuncText]) {
                [self.otherDict removeObjectForKey:kIndustryGrpDictName];
                [self.otherDict setObject:otherFuncText forKey:kIndustryGrpDictName];
                [self bttnActionCancelModal:nil];
            }
            
            
            //[self.tableView reloadData];
            
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}



@end
