//
//  CLRegisterTableController.m
//  CareerLine
//
//  Created by CSG on 9/1/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLRegisterTableController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLUserObject.h"
#import "CLWelcomeScreenViewController.h"
#import "CLTermsAndConditionsViewController.h"
#import "CLResetPassworkController.h"

@interface CLRegisterTableController ()

typedef enum {
    CLRegisterFirstNameIndex = 0,
    CLRegisterLastNameIndex= 1,
    CLRegisterEmailIndex = 2,
    CLRegisterConfEmailIndex = 3,
    CLRegisterPassIndex = 4,
    CLRegisterConfPassIndex = 5
} CLRegisterTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIView *tableHeaderView;
@property (strong, nonatomic) IBOutlet UIView *tableFooterView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property (weak, nonatomic) IBOutlet UIButton *bttnRegister;
@property (weak, nonatomic) IBOutlet UIButton *termsLabel;

@property(strong,nonatomic)NSString *firstNameText;
@property(strong,nonatomic)NSString *lastNameText;
@property(strong,nonatomic)NSString *emailText;
@property(strong,nonatomic)NSString *confEmailText;
@property(strong,nonatomic)NSString *passText;
@property(strong,nonatomic)NSString *confPassText;

- (IBAction)bttnActionRegister:(id)sender;

@end

@implementation CLRegisterTableController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.termsLabel.titleLabel.textColor = ColorCode_CareerLineGreen;
    
    self.title=NSLocalizedString(@"Register", @"Registration Page Title");
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"firstNameCellIdentifier"];
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"lastNameCellIdentifier"];
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"emailCellIdentifier"];
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"confirmEmailCellIdentifier"];
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"passwordCellIdentifier"];
    [self.tableView registerClass:[CLBorderedTextCell class] forCellReuseIdentifier:@"confirmPassCellIdentifier"];
    
    self.keyboardResignView.tintColor=ColorCode_CareerLineGreen;
    self.tableView.tableHeaderView=self.tableHeaderView;
    self.tableView.tableFooterView=self.tableFooterView;
    
    self.firstNameText=@"";
    self.lastNameText=@"";
    self.emailText=@"";
    self.confEmailText=@"";
    self.passText=@"";
    self.confPassText=@"";
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UINavigationBar appearance] setBarTintColor:ColorCode_CareerLineGreen];
    self.navigationItem.leftBarButtonItem.title = @"Back";
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.txtFirstResponder resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    if ([self.firstNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter first name.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.firstNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check first name length.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.firstNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"First name should consist of alphanumeric,hypens and period.", @"Error Message for alphabets firstname field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }

    
    if ([self.lastNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter last name.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.lastNameText length]>100) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check last name length.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.lastNameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Last name should consist of alphanumeric,hypens and period.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }

    
    if ([self.emailText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Email Address.", @"Error Message for null email address registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
	}
    else if (![CLCommon validateEmailWithString:self.emailText]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Email address.", @"Error Message for invalid email address for registration") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if ([self.confEmailText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Confirm Email address.", @"Error Message for null email address registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
	}
    else if (![CLCommon validateEmailWithString:self.confEmailText]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Confirm Email address.", @"Error Message for invalid email address for registration") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if (![self.emailText isEqualToString:self.confEmailText]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Confirm Email must be repeated exactly.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if ([self.passText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Password.", @"Error Message for null password registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
	}
//    else if ([self.passText length]<8) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Password must contain minimum 8 characters", @"Error Message for password registration field less than 6") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
//    
//    else if ([self doesitHaveSpaces:self.passText]){
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Password must not contain any spaces", @"Error Message for password spaces") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    else if (![CLCommon isPasswordStrong:self.passText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Your Password Should Be at Least 8 Characters with a Combination of Letters and Numbers Without Any Spaces.", @"Error Message for password") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;

    }
    
    if ([self.confPassText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Confirm Password.", @"Error Message for null password registration field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
	}
    else if ([self.confPassText length]<8) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Confirm Password must contain minimum 8 characters", @"Error Message for password registration field less than 6") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if (![self.passText isEqualToString:self.confPassText]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Passwords do not match.", @"Error Message") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(BOOL)doesitHaveSpaces:(NSString*)string{
    BOOL space = YES;
    NSString *cutString = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([cutString isEqualToString:@""]) {
        space = YES;
    }
    else{
        NSMutableArray *array = (NSMutableArray *)[cutString componentsSeparatedByString:@" "];
        if (array.count == 1) {
            space = NO;
        }
        else{
            space = YES;
        }

    }
        return space;
}

#pragma mark IBActions

- (IBAction)bttnActionRegister:(id)sender {
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Registering User...", @"Text displayed in the loading indicator while logging in");
        [progressHUD showInView:[UIApplication sharedApplication].keyWindow];
        
        [CLUserObject registerUser:self.emailText withFirstName:self.firstNameText lastName:self.lastNameText password:self.passText
                           success:^(NSString *userName, NSString *password){
                               [progressHUD hideWithAnimation:YES];
                               CLWelcomeScreenViewController *welcomeScreen=[[CLWelcomeScreenViewController alloc] initWithNibName:@"CLWelcomeScreenViewController" bundle:[NSBundle mainBundle]];
                               [CLCommon sharedInstance].userName=userName;
                               [CLCommon sharedInstance].firstname =self.firstNameText;
                               [CLCommon sharedInstance].lastname =self.lastNameText;
                               welcomeScreen.fromPageFlag=CLNavigationFromRegisterPage;
                               [self.navigationController pushViewController:welcomeScreen animated:YES];
                           }
                           failure:^(NSString *error){
                               [progressHUD hideWithAnimation:YES];
                               if (![error isEqualToString:@""]) {
                                   [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                               }
                           }];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case CLRegisterFirstNameIndex:{
            CLBorderedTextCell *firstnameCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"firstNameCellIdentifier"];
            firstnameCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [firstnameCell setTextInputAccesoryView:self.keyboardResignView];
            [firstnameCell setPlaceHoldrText:NSLocalizedString(@"First Name", @"Placeholder text")];
            [firstnameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [firstnameCell setCellText:self.firstNameText];
            [firstnameCell setCellIndexPath:indexPath];
            firstnameCell.delegate=self;
            [firstnameCell isSecureType:NO];
            [firstnameCell setKeyboardType:UIKeyboardTypeAlphabet];
            [firstnameCell returnKeyType:UIReturnKeyNext];
            return firstnameCell;
            break;
        }
        case CLRegisterLastNameIndex:{
            CLBorderedTextCell *lastnameCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"lastNameCellIdentifier"];
            lastnameCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [lastnameCell setTextInputAccesoryView:self.keyboardResignView];
            [lastnameCell setPlaceHoldrText:NSLocalizedString(@"Last Name", @"Placeholder text")];
            [lastnameCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [lastnameCell setCellText:self.lastNameText];
            [lastnameCell setCellIndexPath:indexPath];
            lastnameCell.delegate=self;
            [lastnameCell isSecureType:NO];
            [lastnameCell setKeyboardType:UIKeyboardTypeAlphabet];
            [lastnameCell returnKeyType:UIReturnKeyNext];
            return lastnameCell;
            break;
        }
        case CLRegisterEmailIndex:{
            CLBorderedTextCell *emailCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"emailCellIdentifier"];
            emailCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [emailCell setTextInputAccesoryView:self.keyboardResignView];
            [emailCell setPlaceHoldrText:NSLocalizedString(@"Email", @"Placeholder text")];
            [emailCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [emailCell setCellText:self.emailText];
            [emailCell setCellIndexPath:indexPath];
            emailCell.delegate=self;
            [emailCell isSecureType:NO];
            [emailCell setKeyboardType:UIKeyboardTypeEmailAddress];
            [emailCell returnKeyType:UIReturnKeyNext];
            return emailCell;
            break;
        }
        case CLRegisterConfEmailIndex:{
            CLBorderedTextCell *emailCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"confirmEmailCellIdentifier"];
            emailCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [emailCell setTextInputAccesoryView:self.keyboardResignView];
            [emailCell setPlaceHoldrText:NSLocalizedString(@"Confirm Email", @"Placeholder text")];
            [emailCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [emailCell setCellText:self.confEmailText];
            [emailCell setCellIndexPath:indexPath];
            emailCell.delegate=self;
            [emailCell isSecureType:NO];
            [emailCell setKeyboardType:UIKeyboardTypeEmailAddress];
            [emailCell returnKeyType:UIReturnKeyNext];
            return emailCell;
            break;
        }
        case CLRegisterPassIndex:{
            CLBorderedTextCell *passCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"passwordCellIdentifier"];
            passCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [passCell setTextInputAccesoryView:self.keyboardResignView];
            [passCell setPlaceHoldrText:NSLocalizedString(@"Password", @"Placeholder text")];
            [passCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [passCell setCellText:self.passText];
            [passCell setCellIndexPath:indexPath];
            passCell.delegate=self;
            [passCell isSecureType:YES];
            [passCell setKeyboardType:UIKeyboardTypeDefault];
            [passCell returnKeyType:UIReturnKeyNext];
            return passCell;
            break;
        }
        case CLRegisterConfPassIndex:{
            CLBorderedTextCell *passCell = (CLBorderedTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"confirmPassCellIdentifier"];
            passCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [passCell setTextInputAccesoryView:self.keyboardResignView];
            [passCell setPlaceHoldrText:NSLocalizedString(@"Confirm Password", @"Placeholder text")];
            [passCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [passCell setCellText:self.confPassText];
            [passCell setCellIndexPath:indexPath];
            passCell.delegate=self;
            [passCell isSecureType:YES];
            [passCell setKeyboardType:UIKeyboardTypeDefault];
            [passCell returnKeyType:UIReturnKeyGo];
            return passCell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellShouldReturn:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    if (cell.cellIndexPath.row == 0) {
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
        [cell becomeFirstResponder];
    }
    else if (cell.cellIndexPath.row == 1){
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
        [cell becomeFirstResponder];
    }
    else if (cell.cellIndexPath.row == 2){
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:0]];
        [cell becomeFirstResponder];
    }
    else if (cell.cellIndexPath.row == 3){
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0]];
        [cell becomeFirstResponder];
    }
    else if (cell.cellIndexPath.row == 4){
        CLBorderedTextCell *cell = (CLBorderedTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:5 inSection:0]];
        [cell becomeFirstResponder];
    }
    else{
        [self bttnActionRegister:self];
    }

}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.row) {
        case CLRegisterFirstNameIndex:{
            self.firstNameText=text;
            break;
        }
        case CLRegisterLastNameIndex:{
            self.lastNameText=text;
            break;
        }
        case CLRegisterEmailIndex:{
            self.emailText=text;
            break;
        }
        case CLRegisterConfEmailIndex:{
            self.confEmailText=text;
            break;
        }
        case CLRegisterPassIndex:{
            self.passText=text;
            break;
        }
        case CLRegisterConfPassIndex:{
            self.confPassText=text;
            break;
        }
        default:
            break;
    }
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}
- (IBAction)termsConditionsClicked:(UIButton *)sender {
    CLTermsAndConditionsViewController *controller = [[CLTermsAndConditionsViewController alloc]initWithNibName:@"CLTermsAndConditionsViewController" bundle:[NSBundle mainBundle]];
    [controller setTitleString:@"Terms Of Use"];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Terms Of Use"];
     
    [controller setStringURL:@"https://dev.careerlinedevelopment.com/?r=site/termsofusemobilebefore"];

    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
    [self presentViewController:nav animated:YES completion:nil];
    
}

- (IBAction)privacyPolicyClicked:(UIButton *)sender {
    CLTermsAndConditionsViewController *controller = [[CLTermsAndConditionsViewController alloc]initWithNibName:@"CLTermsAndConditionsViewController" bundle:[NSBundle mainBundle]];
    [controller setTitleString:@"Data Protection Policy"];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Data Protection Policy"];
    [controller setStringURL:@"https://dev.careerlinedevelopment.com/index.php?r=site/dataprivacypolicymobilebefore"];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
    [self presentViewController:nav animated:YES completion:nil];
}

@end
