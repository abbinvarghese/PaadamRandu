//
//  CLCareerSummaryViewController.h
//  CareerLine
//
//  Created by RENJITH on 22/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLHeightAdjustTextCell.h"
#import "CLCareerObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLCareerSummaryViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate,CLHeightAdjustTextCellDelegate,HTProgressHUDDelegate>

@property(nonatomic,strong) CLCareerObject *careerSummary;

@end
 