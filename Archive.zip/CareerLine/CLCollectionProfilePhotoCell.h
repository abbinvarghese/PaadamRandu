//
//  CLCollectionProfilePhotoCell.h
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLCollectionProfilePhotoCell : UICollectionViewCell

-(void)setCellImageWithUrl:(NSString*)imageUrl;
-(void)setWhiteBorderWidth:(int)borderWidth;
-(void)updateActivityIndicatorColor;
@property(nonatomic,strong)NSString *placeHolderImageName;

@end
