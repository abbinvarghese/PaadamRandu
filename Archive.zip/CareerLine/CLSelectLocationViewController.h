//
//  CLSelectLocationViewController.h
//  CareerLine
//
//  Created by CSG on 2/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CLSelectLocationDelegate;

@interface CLSelectLocationViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>

typedef enum {
    LocationListingTypeOtherCountries=0,
	LocationListingTypeSameCountry = 1,
    LocationListingTypeHomeLocation= 2,
    LocationListingCountryForCRF = 3,
    LocationListingCountryBasedLocation = 4
} LocationListingType;

@property(nonatomic,weak) id <CLSelectLocationDelegate> delegate;
@property(nonatomic,assign) LocationListingType locationListType;
@property(nonatomic,strong) NSString *countryCodeforListing;
@property(nonatomic,strong) NSMutableArray *selectedLocations;
@property(nonatomic,assign) BOOL forceSingleSelection;

@end


//Delegate Methods...
@protocol CLSelectLocationDelegate <NSObject>
@optional
- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict;
- (void)selectLocationControllerDidSelectLocations:(CLSelectLocationViewController*)controller forType:(LocationListingType)type withArray:(NSMutableArray *)locArray;
@end