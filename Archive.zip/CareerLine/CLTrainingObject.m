//
//  CLTrainingObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTrainingObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLTrainingObject

static NSOperationQueue *saveTrainingRequest;


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.trainingId = [dictionary objectForKeyNotNull:kCLQlfitnTrainingIdkey];
    self.name = [dictionary objectForKeyNotNull:kCLQlfitnTrainingNamekey];
    self.institution = [dictionary objectForKeyNotNull:kCLQlfitnTrainingInstitutionkey];
    self.location = [[CLLocationObject alloc]initWithDictionary:[dictionary objectForKeyNotNull:kCLQlfitnTrainingLocationkey]];
    
    NSString *fromDateStr = [dictionary objectForKeyNotNull:kCLQlfitnTrainingFromDatekey];
    NSMutableString *startDateStr = [[NSMutableString alloc]init];
    NSArray *startDateArray = [fromDateStr componentsSeparatedByString:@"-"];
    if ([[startDateArray objectAtIndex:0] isEqualToString:@""]) {
        [startDateStr appendString:@"01"];
        [startDateStr appendString:@"-"];
        [startDateStr appendString:[startDateArray objectAtIndex:1]];
        [startDateStr appendString:@"-"];
        [startDateStr appendString:[startDateArray objectAtIndex:2]];
        self.fromDate = [CLCommon getDateForString:startDateStr andFormat:@"dd-MM-yyyy"];
    }else{
        self.fromDate = [CLCommon getDateForString:fromDateStr andFormat:@"dd-MM-yyyy"];
    }
    self.numberOfDays = [dictionary objectForKeyNotNull:kCLQlfitnTrainingNumDayskey];
    self.contents = [dictionary objectForKeyNotNull:kCLQlfitnTrainingContentskey];
    self.trainer = [dictionary objectForKeyNotNull:kCLQlfitnTrainingTrainerkey];
    self.vendor = [dictionary objectForKeyNotNull:kCLQlfitnTrainingVendorkey];
    //self.relatedTo = [dictionary objectForKeyNotNull:];
    self.documentsUrl=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLQlfitnTrainingDocumentskey];
    for (int i=0; i<[files count]; i++) {
        [self.documentsUrl addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    
    return self;
}

//Method for saving training of a particular user...
+ (void)saveTraining:(CLTrainingObject*)trainingObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *traningId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *traningId){};
    }
    
    NSDictionary *parameters =nil;
    
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": trainingObj.trainingId, @"fields":[CLTrainingObject jsonStringForObject:trainingObj]};
        
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLTrainingObject jsonStringForObject:trainingObj]};
    }
    
    [saveTrainingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveTrainingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceEducationSaveURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveTrainingRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLQlfitnTrainingIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(NSString*)jsonStringForObject:(CLTrainingObject*)trainingObj{
    
    NSMutableDictionary *trainingDict=[[NSMutableDictionary alloc] init];
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    
    [insideDict setObject:trainingObj.name forKey:kCLQlfitnTrainingNamekey];
    [insideDict setObject:trainingObj.institution forKey:kCLQlfitnTrainingInstitutionkey];
    
    if (trainingObj.location) {
        if (trainingObj.location.locationCode !=nil) {
        NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
        [locationDict setObject:trainingObj.location.locationCode forKey:kCLQlfitnTrainingLocationCodekey];
        [locationDict setObject:trainingObj.location.countryCode forKey:kCLQlfitnTrainingLocationCountrykey];
        [insideDict setObject:locationDict forKey:kCLQlfitnTrainingLocationkey];
        }
        else if (trainingObj.location.countryCode!=nil){
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:trainingObj.location.countryCode forKey:kCLQlfitnTrainingLocationCountrykey];
            [insideDict setObject:locationDict forKey:kCLQlfitnTrainingLocationkey];
        }
    }

    [insideDict setObject:[CLCommon getStringForDate:trainingObj.fromDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLQlfitnTrainingFromDatekey];
    [insideDict setObject:trainingObj.numberOfDays forKey:kCLQlfitnTrainingNumDayskey];
    [insideDict setObject:trainingObj.vendor forKey:kCLQlfitnTrainingVendorkey];
    [insideDict setObject:trainingObj.trainer forKey:kCLQlfitnTrainingTrainerkey];
    [insideDict setObject:trainingObj.contents forKey:kCLQlfitnTrainingContentskey];
    [trainingDict setObject:insideDict forKey:kCLQlfitnTrainingkey];
    NSLog(@"%@",[CLCommon jsonStringWithPrettyPrint:YES foDict:trainingDict]);
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:trainingDict];
}

@end
