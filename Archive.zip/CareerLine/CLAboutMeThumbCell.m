//
//  CLAboutMeThumbCell.m
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAboutMeThumbCell.h"
#import "CLFileObject.h"
#import "CLCollectionProfilePhotoCell.h"

#define kThumbUrlKey @"file_url"
@interface CLAboutMeThumbCell()

@property (weak, nonatomic) IBOutlet UICollectionView *photoThumbCollectionView;
@property (weak, nonatomic) IBOutlet UICollectionViewFlowLayout *flowLayout;

@end
@implementation CLAboutMeThumbCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
     
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLAboutMeThumbCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        [self.photoThumbCollectionView registerClass:[CLCollectionProfilePhotoCell class] forCellWithReuseIdentifier:@"profilePhotoGridCell"];
        self.photoThumbCollectionView.backgroundColor = [UIColor clearColor];
      
        //configure collectionview layout
        [self.flowLayout setItemSize:CGSizeMake(90,90)];
        [self.flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        self.flowLayout.minimumInteritemSpacing = 8.0f;
        [self.photoThumbCollectionView setCollectionViewLayout:self.flowLayout];
        self.photoThumbCollectionView.bounces = YES;
        [self.photoThumbCollectionView setScrollEnabled:YES];
        [self.photoThumbCollectionView setShowsHorizontalScrollIndicator:NO];
        [self.photoThumbCollectionView setShowsVerticalScrollIndicator:NO];
     
    }
    return self;
}

#pragma mark -Update contents in collection view
-(void)updateCollectionViewContents{
    [self.photoThumbCollectionView reloadData];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

#pragma mark UICollectionView Methods
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
  
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return [self.photoUrls count];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView
                        layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
 
    CLCollectionProfilePhotoCell *cell = [self.photoThumbCollectionView dequeueReusableCellWithReuseIdentifier:@"profilePhotoGridCell" forIndexPath:indexPath];
    [cell updateActivityIndicatorColor];
    [cell setWhiteBorderWidth:7];
    [cell setCellImageWithUrl:[[self.photoUrls objectAtIndex:indexPath.row] objectForKey:kThumbUrlKey]];
    return cell;
}
@end
