//
//  CLAddAllowanceViewController.h
//  CareerLine
//
//  Created by RENJITH on 14/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLFrequencyViewController.h"
#import "CLCurrencyViewController.h"
#import "CLAllowanceLoadingsViewController.h"

@class CLAddAllowanceViewController;

@protocol CLAddAllowanceDelegate <NSObject>

@optional
- (void)allowanceController:(CLAddAllowanceViewController *)controller didAddOrChangeAllowance:(NSMutableDictionary*)editedAllowanceDict isEdit:(BOOL)isEdit;

@end
@interface CLAddAllowanceViewController : UITableViewController<CLSimpleTextCellDelegate,CLTappableCellDelegate,CLTextCheckBoxCellDelegate,CLCurrencyDelegate,CLFrequencyDelegate,CLAllowanceAndLoadingDelegate>

@property (nonatomic ,weak) id <CLAddAllowanceDelegate> delegate;
@property (nonatomic ,assign) BOOL isEdit;
@property(nonatomic,strong)NSMutableDictionary *selectedAllowanceForEdit;
@property(nonatomic ,retain) NSMutableDictionary *selectedAllowanceCurrency;
@end
