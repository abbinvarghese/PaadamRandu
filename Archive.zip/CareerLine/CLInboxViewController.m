//
//  CLInboxViewController.m
//  CareerLine
//
//  Created by CSG on 2/26/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxViewController.h"
#import "CLSideMenuViewController.h"
#import "CLInboxDetailTableViewController.h"
#import "CLInboxListingCell.h"
#import "CLInboxObject.h"
#import "CLUserObject.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLInboxViewController ()

@property (weak, nonatomic) IBOutlet UITableView *inboxListingTable;
@property(nonatomic,strong)NSMutableArray *inboxArray;
@property(nonatomic,strong)UIRefreshControl *refreshControl;
@property(nonatomic,strong)HTProgressHUD *progressHUD;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorMsg;
@property(nonatomic,assign)NSInteger unreadCount;
//@property(nonatomic,assign)BOOL shouldUpdateInbox;
@end

@implementation CLInboxViewController
@synthesize inboxArray,refreshControl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"Inbox", @"Inbox page title");
    [self setupLeftMenuButton];
    [self setUpRefreshControl];
    [self setUpProgressHud];
    [self.inboxListingTable registerClass:[CLInboxListingCell class] forCellReuseIdentifier:@"inboxListingCellIdentifier"];
}

-(void)viewWillAppear:(BOOL)animated{
    [self.inboxListingTable deselectRowAtIndexPath:[self.inboxListingTable indexPathForSelectedRow] animated:animated];
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    if([self.inboxArray count]>0){
        [self.inboxListingTable reloadData];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    self.lblErrorMsg.hidden=YES;
    if(([self.inboxArray count]<=0) || (self.unreadCount!=[CLUserObject currentUser].unreadInboxCount)){
        [self retrieveInboxListFromWebService];
    }
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLInboxObject cancelInboxListingPendingRequests];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Functions

-(void)gotoInboxDetailViewFromPushWithInboxId:(NSString*)inboxId{
    NSLog(@"push notif gotoInboxDetail function invoked...");
    CLInboxDetailTableViewController *inboxDetailController=[[CLInboxDetailTableViewController alloc] initWithNibName:@"CLInboxDetailTableViewController" bundle:[NSBundle mainBundle]];
    inboxDetailController.isFromPushNotifications=YES;
    CLInboxObject *inbox=[[CLInboxObject alloc] init];
    inbox.inboxId=inboxId;
    inboxDetailController.inbox=inbox;
    [self.navigationController pushViewController:inboxDetailController animated:NO];
}

-(void)clearArraysAndReloadTable{
    [self.inboxArray removeAllObjects];
    [self.inboxListingTable reloadData];
}

-(void)setUpProgressHud{
    HTProgressHUD *activityIndicator = [[HTProgressHUD alloc] init];
    activityIndicator.animation=[HTProgressHUDFadeZoomAnimation animation];
    activityIndicator.text=NSLocalizedString(@"Loading Inbox...", @"Text displayed in the loading indicator while loading inbox");
    self.progressHUD=activityIndicator;
    [self updateProgressHudColor];
    
}

-(void)updateProgressHudColor{
    self.progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.progressHUD.hudView.alpha=0.9;
}

-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(void)setUpRefreshControl{
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.inboxListingTable;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshInboxList:) forControlEvents:UIControlEventValueChanged];
    tableViewController.refreshControl = self.refreshControl;
}

-(void)refreshInboxList:(id)sender{
    [self retrieveInboxListFromWebService];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}

-(void)retrieveInboxListFromWebService{
    [self updateProgressHudColor];
    [self.progressHUD showInView:self.view];
    [CLInboxObject listInboxForUserId:[CLUserObject currentUser].userID
                              success:^(NSMutableArray *inboxList,NSInteger unreadInboxCount){
                                  [self.progressHUD hideWithAnimation:YES];
                                  self.unreadCount=unreadInboxCount;
                                  self.inboxArray=inboxList;
                                  [self.inboxListingTable reloadData];
                                  if ([self.inboxArray count]==0) {
                                      self.lblErrorMsg.hidden=NO;
                                  }
                                  else{
                                      self.lblErrorMsg.hidden=YES;
                                  }
                                  
                                  //update side menu badge count..
                                  [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateBadge:unreadInboxCount andSaveUserForPageType:CLInboxControllerIndex];
                              }
                              failure:^(NSString *error){
                                  if (![error isEqualToString:@""]) {
                                      [self.progressHUD hideWithAnimation:YES];
                                      [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                      if ([self.inboxArray count]==0) {
                                          self.lblErrorMsg.hidden=NO;
                                      }
                                      else{
                                          self.lblErrorMsg.hidden=YES;
                                      }
                                      
                                  }
                              }];
}

#pragma mark UITableView Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.inboxArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CLInboxListingCell *cell = (CLInboxListingCell *)[self.inboxListingTable dequeueReusableCellWithIdentifier:@"inboxListingCellIdentifier"];
    cell.inbox=[self.inboxArray objectAtIndex:indexPath.row];
    [cell updateCellContent];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CLInboxDetailTableViewController *inboxDetailController=[[CLInboxDetailTableViewController alloc] initWithNibName:@"CLInboxDetailTableViewController" bundle:[NSBundle mainBundle]];
    inboxDetailController.inbox=[self.inboxArray objectAtIndex:indexPath.row];
    inboxDetailController.isFromQuestionnaireSubmission=NO;
    if (inboxDetailController.inbox.inboxThreadReadStatus==0) {
        self.unreadCount--;
    }
    [self.navigationController pushViewController:inboxDetailController animated:YES];
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    if([self.inboxArray count]>0){
        [self.inboxListingTable reloadData];
    }
}

@end
