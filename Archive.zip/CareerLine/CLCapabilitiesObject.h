//
//  CLCapabilitiesObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLCapabilitiesObject : NSObject

@property(nonatomic,strong)NSMutableArray *knowledgeArray;          // [(CLKnowledgeObject),(CLKnowledgeObject),...]
@property(nonatomic,strong)NSMutableArray *skillsArray;             // [(CLSkillObject),(CLSkillObject),...]
@property(nonatomic,strong)NSMutableArray *abilitiesArray;          // [(CLAbilityObject),(CLAbilityObject),...]
@property(nonatomic,strong)NSMutableArray *languagesArray;          // [(CLLanguageAbility),(CLLanguageAbility),...]

@end
