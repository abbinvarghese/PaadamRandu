//
//  CLTargetJobsObject.h
//  CareerLine
//
//  Created by Abbin on 24/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLTargetJobsObject : NSObject

@property (nonatomic,retain) NSMutableArray *preferredJobArray;
@property (nonatomic,retain) NSMutableArray *industryArray;
@property (nonatomic,retain) NSMutableArray *functionArray;
@property (nonatomic,retain) NSMutableDictionary *functionDict;
@property (nonatomic,retain) NSMutableArray *careerLevelArray;
@property (nonatomic,retain) NSMutableArray *jobScopeArray;
@property (nonatomic,retain) NSString *anythingElseString;

+ (void)targetJobsSummaryForUser:(NSString *)userId lang:(NSString*)lang success:(void (^)(CLTargetJobsObject *targetJobsObj))success failure:(void (^)(NSString *error))failure;

+(void)getPreferredJobsListForSearchString:(NSString*)searchText forUser:(NSString *)userId success:(void (^)(NSMutableArray *preferredJobsList))success failure:(void (^)(NSString *error))failure;

+ (void)cancelGetPreferredJobsRequest;

+ (void)saveTargetJobs:(CLTargetJobsObject*)tarObj forUser:(NSString*)userId forlang:(NSString*)lang success:(void (^)(NSString *tarId))success failure:(void (^)(NSString *error))failure;

+(void)cancelTargetjobSummeryRequest;

@end
