//
//  CLQuestionnaireCell.h
//  CareerLine
//
//  Created by CSG on 3/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLQuestionnaireObject.h"
#import "RateView.h"

#define kintialTextViewHeight 32

@interface CLQuestionnaireCell : UITableViewCell<UITextViewDelegate>

@property(nonatomic,strong)CLQuestionnaireObject *quesObj;

-(NSNumber*)getAnsTextViewHeight;
-(void)updateCellContent:(BOOL)isSubmitted;

@end
