//
//  CLSkillObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLSkillObject : NSObject

//Skill Rating..
typedef enum {
    CLSkillStarRatingNone = 0,
    CLSkillStarRatingOne=  1,
    CLSkillStarRatingTwo = 2,
    CLSkillStarRatingThree = 3,
    CLSkillStarRatingFour = 4,
    CLSkillStarRatingFive = 5,
} CLSkillStarRating;

@property(nonatomic,strong)NSString *skillId;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *desc;
@property(nonatomic,strong)NSString *relatedTo;

@end
