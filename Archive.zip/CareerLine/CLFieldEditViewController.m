//
//  CLFieldEditViewController.m
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLFieldEditViewController.h"


#define kSectionFooterBgColor [UIColor whiteColor]


@interface CLFieldEditViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,retain) NSMutableArray *selectedDictArray;

@end

@implementation CLFieldEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedDictArray = [[NSMutableArray alloc]initWithArray:self.selectedFieldsValuePassedOn];
    [self setRightNavigationButton];
    [self setLeftNavigationButton];
    if (self.selectedIndex.section == 0) {
//        switch (self.selectedIndex.row) {
//            case 3:
        NSString *titleString = [NSString stringWithFormat:@"Edit Or Add %@",self.titleString];
                self.title = NSLocalizedString(titleString, @"title");
//                break;
//            case 4:
//                self.title = NSLocalizedString(@"Edit Or Add State", @"title");
//                break;
//            case 5:
//                self.title = NSLocalizedString(@"Edit Or Add Metro", @"title");
//                break;
//            case 6:
//                self.title = NSLocalizedString(@"Edit Or Add Metro Cluster", @"title");
//                break;
//            case 7:
//                self.title = NSLocalizedString(@"Edit Or Add Tier2 Cities", @"title");
//                break;
//            case 8:
//                self.title = NSLocalizedString(@"Edit Or Add Town/Villages", @"title");
//                break;
//            default:
//                break;
//        }
    }
    else if (self.selectedIndex.section == 1){
        switch (self.selectedIndex.row) {
            case 2:
                self.title = NSLocalizedString(@"Edit Or Add Region", @"title");
                break;
            case 3:
                self.title = NSLocalizedString(@"Edit Or Add Sub Region", @"title");
                break;
            case 4:
                self.title = NSLocalizedString(@"Edit Or Add Country", @"title");
                break;
            case 5:
                self.title = NSLocalizedString(@"Edit Or Add Location", @"title");
                break;
            default:
                break;
        }
    }
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated
{
    if ([self.selectedDictArray count]>0)
        [self.tableView setEditing:YES animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.selectedDictArray count];
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
    [sectionFooter addSubview:button];

    return sectionFooter;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 0) {
        return 44;
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        if ([self.selectedDictArray objectAtIndex:indexPath.row]) {
            [self.selectedDictArray removeObjectAtIndex:indexPath.row];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        }
        
    }
}

-(void)addSelectedFields:(NSMutableDictionary *)dictionary{
    [self.selectedDictArray addObject:dictionary];
    [self.tableView reloadData];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"editCells"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"editCells"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:13];
    }
    
    NSString *countryString = [[self.selectedDictArray objectAtIndex:indexPath.row] objectForKey:kCLRelocationLocationKey];
    NSData *data = [countryString dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    cell.textLabel.text = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];

    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}


-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    CLFieldSearchViewController *relocController = [[CLFieldSearchViewController alloc]initWithNibName:@"CLFieldSearchViewController" bundle:[NSBundle mainBundle]];
    relocController.delegate=self;
    [relocController setFromTwentyField:self.fromTwentyField];
    [relocController setCurrentLocationDictionary:self.currentLocationDictionary];
    [relocController setSelectedDictArray:self.selectedDictArray];
    [relocController setSelectedIndex:self.selectedIndex];
    [relocController setTitleString:self.titleString];
    UINavigationController *relocNav = [[UINavigationController alloc]initWithRootViewController:relocController];
    [self presentViewController:relocNav animated:YES completion:nil];
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for save button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)bttnActionSaveModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        if ([_delegate respondsToSelector:@selector(addSelectedFieldsDictArray:to:)]) {
            NSLog(@"%ld",(long)self.selectedIndex.row);
            [_delegate addSelectedFieldsDictArray:self.selectedDictArray to:self.selectedIndex];
        }
    }];
    
}


@end
