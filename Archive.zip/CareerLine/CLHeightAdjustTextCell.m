//
//  CLHeightAdjustTextCell.m
//  CareerLine
//
//  Created by CSG on 7/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLHeightAdjustTextCell.h"

@interface CLHeightAdjustTextCell()

@property(nonatomic, assign) float txtHeight;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaceholder;
@property (weak, nonatomic) IBOutlet UITextView *txtView;

@end

@implementation CLHeightAdjustTextCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLHeightAdjustTextCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        self.txtHeight=[self getTextViewSize].height;
    }
    return self;
}

-(NSNumber*)getTextViewHeight{
    return [NSNumber numberWithFloat:self.txtHeight];
}

-(CGSize)getTextViewSize{
    CGSize maximumLabelSize = CGSizeMake(self.frame.size.width-20, FLT_MAX);
    return [self.txtView sizeThatFits:maximumLabelSize];
}

-(void)updateCellContents{
    self.txtView.text=self.text;
    self.lblPlaceholder.hidden = ([self.txtView.text length] > 0);
}


-(void)setCellFont:(UIFont*)font{
    self.txtView.font=font;
}

-(void)setPlaceHoldrText:(NSString *)text{
    self.lblPlaceholder.text=text;
}

-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode{
    self.txtView.autocapitalizationType=capitalizationMode;
}

-(void)setTextInputView:(id)picker{
    self.txtView.inputView=picker;
}

-(void)setTextInputAccesoryView:(id)view{
    self.txtView.inputAccessoryView=view;
}

-(BOOL)isCellFirstResponder{
    if ([self.txtView isFirstResponder]) {
        return YES;
    }
    else{
        return NO;
    }
}

-(void)resignCellFirstResponder{
    [self.txtView resignFirstResponder];
}

#pragma mark UITextView Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.lblPlaceholder.hidden = YES;
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(heightCellWillBeginEditing:forIndexPath:forTextView:)]){
		[self.delegate heightCellWillBeginEditing:self forIndexPath:self.cellIndexPath forTextView:self.txtView];
	}
}

-(void)textViewDidChange:(UITextView*)textView{
    self.lblPlaceholder.hidden = ([textView.text length] > 0);
    self.text=textView.text;
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(heightCellTextDidChange:forIndexPath:withText:)]){
		[self.delegate heightCellTextDidChange:self forIndexPath:self.cellIndexPath withText:textView.text];
	}
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.lblPlaceholder.hidden = ([textView.text length] > 0);
}



@end
