//
//  CLInfoPreviousNameViewController.m
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInfoPreviousNameViewController.h"
#import "CLUserObject.h"

@interface CLInfoPreviousNameViewController ()

typedef enum {
    CLPreviousNameTitleIndex = 0,
    CLPreviousNameDateIndex= 1,
} CLPreviousNameTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;

@property(strong,nonatomic)NSString *nameText;
@property(strong,nonatomic)NSDate *date;

@end

@implementation CLInfoPreviousNameViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Previous Name", @"Previous Name edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"titleTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"dateTextCellIdentifier"];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        [datePickr setDate:[CLUserObject currentUser].birthDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    if (self.isEditMode) {
        self.nameText=self.previousNameObj.name;
        self.date=self.previousNameObj.nameDate;
        [self.datePicker setDate:self.date];
    }
    else{
        self.nameText=@"";
        self.date=nil;
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self.txtFirstResponder resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLPreviousNameTitleIndex:{
            CLSimpleTextCell *titleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            titleCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [titleCell setTextInputAccesoryView:self.keyboardResignView];
            [titleCell setPlaceHoldrText:NSLocalizedString(@"Previous Name", @"Placeholder text")];
            [titleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [titleCell setCellText:self.nameText];
            [titleCell setCellIndexPath:indexPath];
            titleCell.delegate=self;
            return titleCell;
            break;
        }
        case CLPreviousNameDateIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"dateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.datePicker];
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Date", @"Placeholder for date field")];
            [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
            break;
        }
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLPreviousNameTitleIndex:
            return NSLocalizedString(@"Previous Name", @"Placeholder text");
            break;
        case CLPreviousNameDateIndex:
            return NSLocalizedString(@"Date", @"Placeholder for date field");
            break;
        default:
            return nil;
            break;
    }
}
#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLPreviousNameTitleIndex:{
            self.nameText=text;
            break;
        }
        default:
            break;
    }
}
#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Name modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveNameAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Name modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddNameAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Name modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Full Name validation..
    if ([self.nameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Previous Name.", @"Error Message for null title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.nameText length]>200) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check name length.", @"Error Message for length of title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateAlphabetsAndSpace:self.nameText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Name should consist of alphanumeric,hypens and period..", @"Error Message for alphabets name field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Date validation..
    if (self.date==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Previous Name date.", @"Error Message for null date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(void)savePreviousNameForEdit:(BOOL)isEdit{
    if (isEdit) {
        self.previousNameObj.name=self.nameText;
        self.previousNameObj.nameDate=self.date;
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        self.previousNameObj=[[CLPreviousNameObject alloc] init];
        self.previousNameObj.name=self.nameText;
        self.previousNameObj.nameDate=self.date;
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(previousNameController:didAddName:)]){
                [self.delegate previousNameController:self didAddName:self.previousNameObj];
            }
        }];
    }
}

#pragma mark IBActions

-(IBAction)bttnActionSaveNameAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self savePreviousNameForEdit:YES];
    }
}

-(IBAction)bttnActionAddNameAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self savePreviousNameForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
//   // if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]])
//    {
//        CLSimpleTextCell *cell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLPreviousNameDateIndex]];
//        //CLSimpleTextCell *cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
//        if (cell.cellIndexPath.section==CLPreviousNameDateIndex) {
//            if (self.date==nil || !([self.date compare:self.datePicker.date] == NSOrderedSame)) {
//                self.date=self.datePicker.date;
//                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//            }
//        }
//    }
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if (cell!=nil) {
        if (cell.cellIndexPath.section==1){
            if (self.date==nil || !([self.date compare:self.datePicker.date] == NSOrderedSame)) {
                self.date=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
    [self.txtFirstResponder resignFirstResponder];
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.date=date;
    
    CLSimpleTextCell *dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLPreviousNameDateIndex]];
    [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
}

@end
