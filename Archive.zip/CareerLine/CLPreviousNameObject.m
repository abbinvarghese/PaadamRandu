//
//  CLPreviousNameObject.m
//  CareerLine
//
//  Created by CSG on 8/22/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPreviousNameObject.h"
#import "NSDictionary+Additions.h"

@implementation CLPreviousNameObject


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.nameId=[dictionary objectForKeyNotNull:kCLProfileAboutMePreviousNameIdkey];
    self.name=[dictionary objectForKeyNotNull:kCLProfileAboutMePreviousNamekey];
    self.nameDate=[CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileAboutMePreviousNameDatekey] andFormat:@"dd-MM-yyyy"];
    
    return self;
}

-(NSDictionary*)dictionaryForObject{
    NSMutableDictionary *tempDict=[[NSMutableDictionary alloc] init];
    
    if (self.nameId) {
        [tempDict setObject:self.nameId forKey:kCLProfileAboutMePreviousNameIdkey];
    }
    
    if (self.name) {
        [tempDict setObject:self.name forKey:kCLProfileAboutMePreviousNamekey];
    }
    
    if (self.nameDate) {
        [tempDict setObject:[CLCommon getStringForDate:self.nameDate andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileAboutMePreviousNameDatekey];
    }
    
    return tempDict;
}

@end
