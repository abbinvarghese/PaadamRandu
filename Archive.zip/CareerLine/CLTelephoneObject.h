//
//  CLTelephoneObject.h
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLTelephoneObject : NSObject<NSCopying>

typedef enum {
    ContactTypeNone=0,
    ContactTypeAlternativeHome= 1,
    ContactTypeAlternativeMobile= 2,
    ContactTypeBusiness= 3,
    ContactTypeHome=4,
    ContactTypeMobile=5
} CLTelephoneContactType;

@property(nonatomic,strong)NSString *telephoneId;
@property(nonatomic,strong)NSString *telephoneIsdCode;
@property(nonatomic,strong)NSString *telephoneAreaCode;
@property(nonatomic,strong)NSString *telephoneContactNumber;
@property(nonatomic,strong)NSString *formattedTelephoneNumber;
@property(nonatomic,strong)NSMutableDictionary *contactType;
@property(nonatomic,assign)BOOL isPrimaryContact;


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//get dictionary for object..
-(NSDictionary*)dictionaryForObject;

-(void)updateFormattedTelephoneNumber;

@end
