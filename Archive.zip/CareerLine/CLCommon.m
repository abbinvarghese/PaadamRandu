//
//  CLCommon.m
//  CareerLine
//
//  Created by CSG on 1/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCommon.h"
#import "CLUserObject.h"
#import "UIAlertView+NSCookbook.h"
#import "Reachability.h"
#import <AVFoundation/AVFoundation.h>

//#import <CoreTelephony/CTTelephonyNetworkInfo.h>
//#import <CoreTelephony/CTCarrier.h>

@implementation CLCommon
@synthesize deviceTokenString,dbPath;

static  BOOL  isOnline = NO;

+(NSString*)deviceID{
    NSString *string = [CLCommon sharedInstance].deviceTokenString;
    if (string == nil) {
        return @"";
    }
    else{
        return string;
    }
}

+(void)initialiseHeaderForWeb:(AFHTTPRequestSerializer*)forRequest{
    
    if ([CLUserObject currentUser].userID && ![[CLCommon deviceID] isEqualToString:@""]) {
        [forRequest setValue:[CLCommon deviceID] forHTTPHeaderField:@"deviceId"];
        [forRequest setValue:@"1" forHTTPHeaderField:@"deviceType"];
        [forRequest setValue:[CLUserObject currentUser].userID forHTTPHeaderField:@"user"];
    }
}

+(void)ImageSelectionWithCaptionWithImagePicker:(UIImagePickerController *)controller withSuccess:(void (^)(NSString *captionTxt))success{

    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Do You Like Captions?", @"alert heading") message:NSLocalizedString(@"Add a Caption", @"alert") delegate:self cancelButtonTitle:NSLocalizedString(@"NO", @"title for cancel button") otherButtonTitles:NSLocalizedString(@"YES", @"title for yes button"), nil];

    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    
    [alertView showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex) {
        
        if(buttonIndex == 1){
            success([alertView textFieldAtIndex:0].text);
            [controller dismissViewControllerAnimated:YES completion:nil];
            [[alertView textFieldAtIndex:0] resignFirstResponder];
            
        }else{
            NSString *str =@"";
            success(str);
            [controller dismissViewControllerAnimated:YES completion:nil];
            [[alertView textFieldAtIndex:0] resignFirstResponder];
        }
    }];
    
}


+ (void)sentScreenNameToGoogleAnalytics:(NSString*)aScreenName
{
    id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
    [tracker set:@"&uid"
           value:[CLUserObject currentUser].userID];
    [tracker set:kGAIScreenName value:aScreenName];
    [tracker send:[[GAIDictionaryBuilder createAppView] build]];
    
}


+ (void)sentEventNameToGoogleAnalytics:(NSString*)aEventName screenName:(NSString*)aScreenName
{
    id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
    [tracker set:@"&uid"
           value:[CLUserObject currentUser].userID];
    [tracker set:kGAIScreenName value:aScreenName];
    [tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"UI"
                                                          action:@"touch"
                                                           label:aEventName
                                                           value:nil] build]];
    [tracker set:kGAIScreenName value:nil];
    
}


+ (BOOL) isNetworkConnected
{
    BOOL status = YES;
    
    Reachability *reachability;
    reachability = [Reachability reachabilityForInternetConnection];
    
    NetworkStatus netStatus = [reachability currentReachabilityStatus];
    
    switch (netStatus)
    {
        case NotReachable:
            status = NO;
            break;
            
        case ReachableViaWWAN:
            status = YES;
            break;
            
        case ReachableViaWiFi:
            status = YES;
            break;
    }
    
    [CLCommon setOnLineStatus:status];
    
    return status;
}

+ (void)setOnLineStatus:(BOOL)status
{
    isOnline   = status;
}

+ (BOOL)isOnLine
{
    return isOnline;
}

+ (void)doViewAnimation:(UIView*)theView
{
    CATransition *animation = [CATransition animation];
    [animation setDuration:0.25];
    [animation setType:kCATransitionFade];
    [animation setSubtype:kCATransitionFromLeft];
    [animation setRemovedOnCompletion:YES];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    [[theView layer] addAnimation:animation forKey:nil];
}

+ (void)showAlert:(NSString *)aMessage
{
    UIAlertView *alert  = [[UIAlertView alloc]initWithTitle:@""  message:aMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil,nil];
    
    
    [alert show];

}

+(BOOL)doesItHaveSpace:(NSString*)string{
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    if ([[string stringByTrimmingCharactersInSet: set] length] == 0)
    {
        return YES;
    }
    else{
        return NO;
    }
}


+(BOOL)isOSversionLessThan8{
    NSString *reqSysVer = @"8.0";
    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
    if ([currSysVer compare:reqSysVer options:NSNumericSearch] != NSOrderedAscending){
        return NO;
    }
    else{
        return YES;
    }
}

+ (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

+(BOOL) validateAlphabetsAndSpace: (NSString *)alpha{
    NSString *abnRegex = @"^[a-zA-Z0-9\\s.\\-]+$";// @"[a-zA-Z]+[ a-zA-Z]*";    //alphabets and space
    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
    BOOL isValid = [abnTest evaluateWithObject:alpha];
    return isValid;
}

+(BOOL) validateAlphabetsOnly: (NSString *)alpha{
    NSString *abnRegex = @"[A-Za-z]+";    //alphabets only
    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
    BOOL isValid = [abnTest evaluateWithObject:alpha];
    return isValid;
}

+(BOOL) validateNumbersOnly: (NSString *)number{
    NSString *abnRegex = @"[0-9]+";    //numbers only
    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
    BOOL isValid = [abnTest evaluateWithObject:number];
    return isValid;
}

+(BOOL)isPasswordStrong:(NSString *)password {
    /*
     8-20 chars
     at least one letter
     at least one number OR special character
     no more than 3 repeated characters
     */
    //NSString *strongPass= @"^(?!.*(.)\\1{3})((?=.*[\\d])(?=.*[A-Za-z])|(?=.*[^\\w\\d\\s])(?=.*[A-Za-z])).{8,20}$";
    
    ////Minimum 8 characters at least 1 Alphabet and 1 Number and accept any other character:
    
    NSString *strongPass= @"((?=.*\\d)(?=.*[a-zA-Z]).{8,100})";
    
    //Minimum 8 characters at least 1 Alphabet and 1 Number:
    //NSString *strongPass= @"^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$";
    
   // Minimum 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
   // NSString *strongPass= @"^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,}$";
    
    NSPredicate *regexTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", strongPass];
    
    return [regexTest evaluateWithObject:password];
}

+(void)showAlertwithTitle:(NSString *)title alertString:(NSString*)alertStr cancelbuttonName:(NSString*)cancel{
    if ([self isOSversionLessThan8]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:alertStr delegate:nil cancelButtonTitle:cancel otherButtonTitles:nil];
        [alert show];
    }
    else{
        UIAlertController *alertController=[UIAlertController alertControllerWithTitle:alertStr message:nil preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancel style:UIAlertActionStyleCancel handler:nil];
        
        [alertController addAction:cancelAction];
        
        alertController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        
        UIViewController *topRootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
        while (topRootViewController.presentedViewController)
        {
            topRootViewController = topRootViewController.presentedViewController;
        }
        
        [topRootViewController presentViewController:alertController animated:YES completion:nil];
    }
    
}

-(void)loadCareerLineDB{
    dbPath= [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:careerLineDB];
    
    
	// Create the path to the database in the Documents directory.
//    NSArray *pathsToDocuments = [[NSArray alloc] initWithArray: NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)];
//	dbPath = [[NSString alloc] initWithString:[[pathsToDocuments objectAtIndex:0] stringByAppendingPathComponent:careerLineDB]];
//	if (![[NSFileManager defaultManager] isReadableFileAtPath:dbPath]) {
//		if ([[NSFileManager defaultManager] copyItemAtPath:yourOriginalDatabasePath toPath:dbPath error:NULL] != YES)
//			NSAssert2(0, @"Fail to copy database from %@ to %@", yourOriginalDatabasePath, dbPath);
//	}
    
}

+(NSString*) jsonStringWithPrettyPrint:(BOOL) prettyPrint foDict:(NSMutableDictionary*)dict {
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:(NSJSONWritingOptions)    (prettyPrint ? NSJSONWritingPrettyPrinted : 0)
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"jsonStringWithPrettyPrint: error: %@", error.localizedDescription);
        return @"{}";
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}

+(BOOL)isSizeLessThan5MBForImage:(UIImage*)image{
    BOOL sizeIsLess = YES;
    CGImageRef imageRef = [image CGImage];
    NSInteger sizeOfImage = CGImageGetBytesPerRow(imageRef) * CGImageGetHeight(imageRef);
    if (sizeOfImage > 5000000) {
        sizeIsLess = NO;
    }
    return sizeIsLess;
}

+ (NSString *)trimWhiteSpaces:(NSString *)text
{
    return [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

+(NSString*) getMessageForErrorCode:(long)code{
    NSString *errorString=nil;
    
    switch (code) {
        case -999:
            errorString=@"";
            break;
        case -1001:
            errorString=kWebservice_reqTimedOutErrorMsg;
            break;
        case -1003:
            errorString=kWebservice_serverErrorMsg;//server with specified hostname not found..
            break;
        case -1004:
            errorString=kWebservice_serverConnectErrorMsg;
            break;
        case -1005:
            errorString=kWebservice_networkLostErrorMsg;
            break;
        case -1009:
            errorString=kWebservice_networkErrorMsg;
            break;
        case 3840:
            errorString=kWebservice_serverErrorMsg;
            break;
        default:
            errorString=kWebservice_unknownErrorMsg;
            break;
    }
    
    return errorString;
}

+(NSString*) getStringForDate:(NSDate*)date andExactFormat:(NSString*)format{
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    dateFormatter.dateFormat=format;
    return [dateFormatter stringFromDate:date];
}

+(NSString*) getStringForDate:(NSDate*)date andLocalFormat:(NSString*)format{
    NSString *localFormat = [NSDateFormatter dateFormatFromTemplate:format options:0 locale:[NSLocale currentLocale]];
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setLocale:[NSLocale currentLocale]];
    dateFormatter.dateFormat=localFormat;
    return [dateFormatter stringFromDate:date];
}

+(NSDate*) getDateForString:(NSString*)string andFormat:(NSString*)format{
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setLocale:[NSLocale currentLocale]];
    dateFormatter.dateFormat=format;
    return [dateFormatter dateFromString:string];
}

+ (CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font
{
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
    return [[[NSAttributedString alloc] initWithString:string attributes:attributes] size].width;
}

+ (UIImage *)filledImageFrom:(UIImage *)source withColor:(UIColor *)color
{
    // begin a new image context, to draw our colored image onto with the right scale
    UIGraphicsBeginImageContextWithOptions(source.size, NO, [UIScreen mainScreen].scale);
    
    // get a reference to that context we created
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // set the fill color
    [color setFill];
    
    // translate/flip the graphics context (for transforming from CG* coords to UI* coords
    CGContextTranslateCTM(context, 0, source.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGContextSetBlendMode(context, kCGBlendModeColorBurn);
    CGRect rect = CGRectMake(0, 0, source.size.width, source.size.height);
    CGContextDrawImage(context, rect, source.CGImage);
    
    CGContextSetBlendMode(context, kCGBlendModeSourceIn);
    CGContextAddRect(context, rect);
    CGContextDrawPath(context,kCGPathFill);
    
    // generate a new UIImage from the graphics context we drew onto
    UIImage *coloredImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //return the color-burned image
    return coloredImg;
}

+ (CGFloat)measureHeightOfUILabel:(UILabel *)labelView
{
    if (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1)
    {
        CGRect frame = labelView.bounds;
        NSString *textToMeasure = labelView.text;
        if ([textToMeasure hasSuffix:@"\n"])
        {
            textToMeasure = [NSString stringWithFormat:@"%@-", labelView.text];
        }
        
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineBreakMode:NSLineBreakByWordWrapping];
        //[paragraphStyle setLineSpacing:2];
        
        NSDictionary *attributes = @{ NSFontAttributeName: labelView.font, NSParagraphStyleAttributeName : paragraphStyle};
        
        // [attributedString addAttribute:NSParagraphStyleAttributeName value:paragrahStyle range:NSMakeRange(0, [labelText length])];
        
        CGRect size = [textToMeasure boundingRectWithSize:CGSizeMake(CGRectGetWidth(frame), MAXFLOAT)
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:attributes
                                                  context:nil];
        
        CGFloat measuredHeight = ceilf(CGRectGetHeight(size));
        return measuredHeight;
    }
    else
    {
        return [CLCommon measureString:labelView.text withFont:labelView.font andConstraintWidth:labelView.frame.size.width andConstraintHeight:999.0f].height;
    }
}

+ (CGSize)measureString:(NSString *)stringToMeasure withFont:(UIFont *)font andConstraintWidth:(CGFloat)constraintWidth andConstraintHeight:(CGFloat)constraintHeight
{
    CGSize	sizeRequired	= CGSizeZero;
    CGSize	textSize 		= CGSizeMake( constraintWidth, constraintHeight );
    
    //	sizeRequired = [stringToMeasure sizeWithFont:font
    //							   constrainedToSize:textSize
    //								   lineBreakMode:NSLineBreakByWordWrapping];
    
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    
    NSDictionary * attributes = @{NSFontAttributeName : font,
                                  NSParagraphStyleAttributeName : paragraphStyle};
    
    sizeRequired = [stringToMeasure boundingRectWithSize:textSize
                                                 options:NSStringDrawingUsesFontLeading
                    |NSStringDrawingUsesLineFragmentOrigin
                                              attributes:attributes
                                                 context:nil].size;
    
    return sizeRequired;
}

//+(NSString*)getLocationFromTimeZone{
//    return [[NSTimeZone abbreviationDictionary] objectForKey:[NSTimeZone localTimeZone].abbreviation];
//}
//
//+(NSString*)getLocationFromNetwork{
//    CTTelephonyNetworkInfo *netInfo = [[CTTelephonyNetworkInfo alloc] init];
//    CTCarrier *carrier = [netInfo subscriberCellularProvider];
//    return [carrier mobileCountryCode];
//}

//SINLETON functions..
static CLCommon *sharedInstance = nil;

// Get the shared instance and create it if necessary.
+ (CLCommon *)sharedInstance {
    if (sharedInstance == nil) {
        sharedInstance = [[super allocWithZone:NULL] init];
    }
    
    return sharedInstance;
}

// We can still have a regular init method, that will get called the first time the Singleton is used.
- (id)init
{
    self = [super init];
    
    if (self) {
        // Work your initialising magic here as you normally would
    }
    
    return self;
}

// We don't want to allocate a new instance, so return the current one.
+ (id)allocWithZone:(NSZone*)zone {
    return [self sharedInstance];
}

// Equally, we don't want to generate multiple copies of the singleton.
- (id)copyWithZone:(NSZone *)zone {
    return self;
}

+(NSMutableDictionary*)getcountryFromDevice{
    NSMutableDictionary *countryDict = [[NSMutableDictionary alloc]init];
    NSLocale *locale = [NSLocale currentLocale];
    NSString *countryCode = [locale objectForKey: NSLocaleCountryCode];
    
    NSString *country = [locale displayNameForKey: NSLocaleCountryCode value: countryCode];
    NSString *conCode = [[CLCoreDataHelper sharedCLCoreDataHelper]getCountryCodeForCountry:country];
    
    if (country==nil || conCode == nil) {
        [countryDict setValue:@"India" forKey:@"jobLocationCountryName"];
        [countryDict setValue:@"IND" forKey:@"jobLocationCountryCode"];
        
    }
    else{
        [countryDict setValue:country forKey:@"jobLocationCountryName"];
        [countryDict setValue:conCode forKey:@"jobLocationCountryCode"];
    }

    return countryDict;
}

+(BOOL)HaveCamaraAccess:(UIView*)view{
    __block BOOL access = NO;
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(status == AVAuthorizationStatusAuthorized) {
       access = YES;
    } else if(status == AVAuthorizationStatusDenied){
        access = NO;
    } else if(status == AVAuthorizationStatusRestricted){
        access = NO;
    } else if(status == AVAuthorizationStatusNotDetermined){
        // not determined
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if(granted){
                NSLog(@"Camara Access Granted!!");

            } else {
                NSLog(@"Camara Access Denied!!");
            }
        }];
    }
    return access;
}

+ (BOOL) validateUrl: (NSString *) candidate {
    NSString *urlRegEx =
    @"(@)?(href=')?(HREF=')?(HREF=\")?(href=\")?((http|https)://)?[a-zA-Z_0-9\\-]+(\\.\\w[a-zA-Z_0-9\\-]+)+(/[#&\\n\\-=?\\+\\%/\\.\\w]+)?";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}


@end
