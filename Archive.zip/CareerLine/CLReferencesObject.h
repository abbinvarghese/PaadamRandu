//
//  CLReferencesObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLReferencesObject : NSObject


@property(nonatomic,strong)NSMutableArray *reviewArray;          // [(CLReviewObject),(CLReviewObject),...]
@property(nonatomic,strong)NSMutableArray *perfRevArray;          // [(CLPerformanceReviewObject),(CLPerformanceReviewObject),...]
@property(nonatomic,strong)NSMutableArray *careerListArray;


//cancel request..
+ (void)cancelReferencePendingRequest;

//Method for getting a references for a particular user...
+ (void)referenceDetailsForUser:(NSString *)userId success:(void (^)(CLReferencesObject *referenceObj))success failure:(void (^)(NSString *error))failure;

@end
