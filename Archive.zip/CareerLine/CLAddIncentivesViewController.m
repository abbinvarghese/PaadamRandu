//
//  CLAddIncentivesViewController.m
//  CareerLine
//
//  Created by RENJITH on 14/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAddIncentivesViewController.h"
#define isEditText @"isEdit"

@interface CLAddIncentivesViewController ()
typedef enum {
    CLIncentiveBonusIndex = 0,
    CLIncentiveFrequencyIndex= 1,
    CLGrossSalaryIndex = 2,
    CLActualValueIndex = 3,
} CLIncentiveTableSectionIndex;

@property (nonatomic, assign) BOOL grossSalSwitch;
@property (nonatomic, assign) BOOL actualValSwitch;

@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;

@property(nonatomic ,retain) NSMutableDictionary *incentiveDict;
@property(nonatomic ,retain) NSMutableDictionary *selectedIncentiveBonus;
@property(nonatomic ,retain) NSMutableDictionary *selectedIncentiveFrequency;


@property(nonatomic ,retain) NSString *grossSalValText;
@property(nonatomic ,retain) NSString *actualValText;

@end

@implementation CLAddIncentivesViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Incentives & Bonus", @"Incentive & Bonus page title text");
    //Incentive section
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"incentiveTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"incentiveActualValCurrencyCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"incentiveFrequencyTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"incentiveGrossSalaryTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"incentiveActualValueTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"incentiveGrossSalaryCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"incentiveActualValueCellIdentifier"];
    
    if (self.selectedIncentiveForEdit !=nil) {
        self.incentiveDict = [[NSMutableDictionary alloc]initWithDictionary:self.selectedIncentiveForEdit];
    }
    if (self.incentiveDict!=nil) {
        
        self.grossSalValText = [self.incentiveDict objectForKey:kCLCareerHistoryAllowanceGrossSalkey];
        self.actualValText = [self.incentiveDict objectForKey:kCLCareerHistoryAllowanceActualValkey];
        
        if (![self.grossSalValText isEqualToString:@""]) {
            self.grossSalSwitch = YES;
        }
        if (![self.actualValText isEqualToString:@""]) {
            self.actualValSwitch = YES;
        }
        self.selectedIncentiveBonus = [self.incentiveDict objectForKey:kCLCareerHistoryIncentiveBonuskey];
        self.selectedIncentiveFrequency = [self.incentiveDict objectForKey:kCLCareerHistoryAllowanceFrequencykey];
        if ([self.incentiveDict objectForKey:kCLCareerHistoryAllowanceCurrencykey]!=nil) {
            self.selectedIncentiveCurrency = [[NSMutableDictionary alloc]initWithDictionary:[self.incentiveDict objectForKey:kCLCareerHistoryAllowanceCurrencykey]];
        }
    }else{
        self.selectedIncentiveBonus = nil;
        self.selectedIncentiveFrequency = nil;
        self.grossSalValText = @"";
        self.actualValText = @"";
    }
    [self setRightNavigationButton];
   // [self setLeftNavigationButton];
    if (!self.isEdit) {
        [self setLeftNavigationButton];
    }
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods
-(void)setRightNavigationButton{
    
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"dismiss Incentive modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *lefttNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Dismiss allowance and loading modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionBenefitsDismiss:)];
    self.navigationItem.leftBarButtonItem=lefttNavBttn;
}

-(void)bttnActionBenefitsDismiss:(id)sender{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    
    [self.txtFirstResponder resignFirstResponder];
}

-(BOOL)isFieldsValid{
    
    BOOL isValid=YES;
    //Course validation..
    if (self.selectedIncentiveBonus ==nil) {
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Warning", @"Alert title text") alertString:NSLocalizedString(@"Please Select Incentive.", @"alert msg text") cancelbuttonName:NSLocalizedString(@"OK", @"ok btn text")];
        return isValid=NO;
    }
    else if (self.actualValText.length >9){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum Length Of Actual Value Should Be 9", @"Error Message for actual value field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (self.grossSalValText.length > 3){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Maximum Length Of Gross Salary Should Be 3.", @"Error Message for gross salary field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    return isValid;
}

-(void)bttnActionSaveAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        CATransition *transition = [CATransition animation];
        transition.duration = 0.25;
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromBottom;
        
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        
        if (self.isEdit) {
            [self.incentiveDict setObject:@"1" forKey:isEditText];
            [self.navigationController popViewControllerAnimated:NO];
        }else{
            if (self.incentiveDict ==nil) {
                self.incentiveDict = [[NSMutableDictionary alloc]init];
            }
            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
        
        [self.incentiveDict setObject:self.grossSalValText forKey:kCLCareerHistoryAllowanceGrossSalkey];
        [self.incentiveDict setObject:self.actualValText forKey:kCLCareerHistoryAllowanceActualValkey];
        
        if (self.selectedIncentiveBonus !=nil) {
            [self.incentiveDict setObject:self.selectedIncentiveBonus forKey:kCLCareerHistoryIncentiveBonuskey];
        }
        if (self.selectedIncentiveFrequency !=nil) {
            [self.incentiveDict setObject:self.selectedIncentiveFrequency forKey:kCLCareerHistoryAllowanceFrequencykey];
        }if (self.selectedIncentiveCurrency !=nil) {
            if ([self.selectedIncentiveCurrency objectForKey:@"ccFips"]) {
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                [dict setObject:[self.selectedIncentiveCurrency objectForKey:@"countryCode"] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@/%@",[self.selectedIncentiveCurrency objectForKey:@"countryName"],[self.selectedIncentiveCurrency objectForKey:@"currencyCode"]] forKey:@"currency"];
                [self.incentiveDict setObject:dict forKey:kCLCareerHistoryAllowanceCurrencykey];
            }
            else{
                [self.incentiveDict setObject:self.selectedIncentiveCurrency forKey:kCLCareerHistoryAllowanceCurrencykey];
            }
        }
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(incentiveController:didAddOrChangeIncentive:isEdit:)]){
            [self.delegate incentiveController:self didAddOrChangeIncentive:self.incentiveDict isEdit:self.isEdit];
        }
    }else{
        
    }
}

#pragma mark - tableView methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case CLIncentiveBonusIndex:{
            CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Incentives & Bonus", @"Placeholder for Incentives & Bonus field")];
            if (self.selectedIncentiveBonus ==NULL) {
                
                [relatedToCell setCellText:@""];
            }else{
                [relatedToCell setCellText:[self.selectedIncentiveBonus objectForKey:kCLCareerHistoryIncentiveBonuskey]];
            }
            [relatedToCell setCellIndexPath:indexPath];
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
        }
        case CLIncentiveFrequencyIndex:{
            CLSimpleTappableTextCell *relatedToCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveFrequencyTextCellIdentifier"];
            relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Frequency", @"Placeholder for Frequency field")];
            if (self.selectedIncentiveFrequency ==NULL) {
                
                [relatedToCell setCellText:@""];
            }else{
                [relatedToCell setCellCloseBtnOption:NO];
                [relatedToCell setCellText:[self.selectedIncentiveFrequency objectForKey:kCLCareerHistoryAllowanceFrequencykey]];
            }
            [relatedToCell setCellIndexPath:indexPath];
            relatedToCell.delegate=self;
            return relatedToCell;
            break;
        }
        case CLGrossSalaryIndex:{
            if (indexPath.row == 0) {
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveGrossSalaryCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.grossSalSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
            }
            else {
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveGrossSalaryTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary field")];
                [relatedToCell setCellText:self.grossSalValText];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }
        }
        case CLActualValueIndex:{
            if (indexPath.row == 0) {
                
                CLTextCheckBoxCell *numDaysCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveActualValueCellIdentifier"];
                numDaysCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [numDaysCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [numDaysCell disableCelltxtField];
                [numDaysCell setCellText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value")];
                [numDaysCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [numDaysCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [numDaysCell setCellIndexPath:indexPath];
                [numDaysCell setCellTextColor:[UIColor darkGrayColor]];
                [numDaysCell checkBoxClick:self.actualValSwitch];
                numDaysCell.textCheckBoxdelegate=self;
                return numDaysCell;
                break;
            }
            else if (indexPath.row == 1){
                CLSimpleTextCell *relatedToCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveActualValueTextCellIdentifier"];
                relatedToCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedToCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
                [relatedToCell setKeyboardType:UIKeyboardTypeNumberPad];
                [relatedToCell setPlaceHoldrText:NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value field")];
                [relatedToCell setCellText:self.actualValText];
                [relatedToCell setCellIndexPath:indexPath];
                relatedToCell.delegate=self;
                return relatedToCell;
                break;
            }else{
                CLSimpleTappableTextCell *relatedCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"incentiveActualValCurrencyCellIdentifier"];
                relatedCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [relatedCell setPlaceHoldrText:NSLocalizedString(@"Currency", @"Placeholder for Currency field")];
                if (self.selectedIncentiveCurrency ==nil) {
                    
                    [relatedCell setCellText:@""];
                }else{
                    [relatedCell setCellCloseBtnOption:NO];
                    if ([self.selectedIncentiveCurrency objectForKey:kCLCareerHistoryAllowanceCurrencykey]) {
                        [relatedCell setCellText:[self.selectedIncentiveCurrency objectForKey:kCLCareerHistoryAllowanceCurrencykey]];
                    }
                    else{
                        [relatedCell setCellText:[NSString stringWithFormat:@"%@/%@",[self.selectedIncentiveCurrency objectForKey:@"currencyCode"],[self.selectedIncentiveCurrency objectForKey:@"countryName"]]];
                    }
                }
                [relatedCell setCellIndexPath:indexPath];
                relatedCell.delegate=self;
                return relatedCell;
                break;
            }
        }
        default:
            return nil;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLIncentiveBonusIndex:
            return NSLocalizedString(@"Incentives & Bonus", @"Placeholder for Incentives & Bonus field");
            break;
        case CLIncentiveFrequencyIndex:
            return NSLocalizedString(@"Frequency", @"Placeholder for Frequency field");
            break;
        case CLGrossSalaryIndex:
            return NSLocalizedString(@"% of Gross Salary", @"Placeholder for Gross Salary field");
            break;
        case CLActualValueIndex:
            return NSLocalizedString(@"Actual Value", @"Placeholder for Actual Value field");
            break;
        default:
            return nil;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == CLGrossSalaryIndex) {
        if (self.grossSalSwitch)
            return 2;
        else
            return 1;
    }else if (section == CLActualValueIndex){
        if (self.actualValSwitch)
            return 3;
        else
            return 1;
    }else{
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44;
}

#pragma mark CLSimpleTextCellDelegate Methods
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    self.txtFirstResponder=textField;
    
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLActualValueIndex:{
            self.actualValText=text;
            break;
        }
        case CLGrossSalaryIndex:{
            self.grossSalValText = text;
        }
        default:
            break;
    }
}

#pragma mark CLTappable cell delegate


- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    switch (indexPath.section) {
        case CLIncentiveFrequencyIndex:
            self.selectedIncentiveFrequency = nil;
            break;
        case CLActualValueIndex:{
            if (indexPath.row == 2) {
                self.selectedIncentiveCurrency = nil;
            }
        }
            break;
            
        default:
            break;
    }
    [self.tableView reloadData];
}

- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    
    if (indexPath.section == CLIncentiveBonusIndex) {
        
        CLIncentiveListViewController *controller = [[CLIncentiveListViewController alloc]initWithNibName:@"CLIncentiveListViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedIncentives = self.selectedIncentiveBonus;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
        
    }else if (indexPath.section == CLIncentiveFrequencyIndex){
        
        CLFrequencyViewController *controller = [[CLFrequencyViewController alloc]initWithNibName:@"CLFrequencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedFrequency = self.selectedIncentiveFrequency;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
        
    }else if (indexPath.section == CLActualValueIndex){
        
        CLCurrencyViewController *controller = [[CLCurrencyViewController alloc]initWithNibName:@"CLCurrencyViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedCurrency = self.selectedIncentiveCurrency;
        controller.delegate = self;
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
        [self.navigationController presentViewController:navigation animated:YES completion:nil];
    }
}

#pragma mark CLTextCheckBox delegate
- (void)textCheckBoxBgChange:(CLTextCheckBoxCell *)cell withStatus:(BOOL)status{
    
    [CLCommon doViewAnimation:self.view];
    NSIndexPath *index=cell.cellIndexPath;
    if (index.section == CLGrossSalaryIndex){
        if (status) {
            self.grossSalSwitch = YES;
            
            if(self.actualValSwitch)
            {
                self.actualValSwitch = NO;
                self.actualValText =@"";

            }
            
        }else{
            self.grossSalSwitch = NO;
            self.grossSalValText =@"";
            
        }
        
        [self.tableView reloadData];
       // [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLGrossSalaryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }else if (index.section == CLActualValueIndex){
        if (status) {
            self.actualValSwitch = YES;
            
            if(self.grossSalSwitch)
            {
                self.grossSalSwitch = NO;
                self.grossSalValText =@"";
                
            }
        }else{
            self.actualValSwitch = NO;
            self.actualValText =@"";
        }
        [self.tableView reloadData];
       // [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:CLActualValueIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
    
}

#pragma mark - frequency delegate method
-(void)frequencyController:(CLFrequencyViewController *)controller didSelect:(NSMutableDictionary *)selectedDict{
    
    self.selectedIncentiveFrequency = selectedDict;
    [self.tableView reloadData];
}

#pragma mark - currency delegate method
-(void)loadSelectedCurrencyDictionary:(NSMutableDictionary *)dictionary{
    
    NSString *string = [NSString stringWithFormat:@"%@/%@",[dictionary objectForKey:kjobPreferenceCurrencyCode],[dictionary objectForKey:kjobPreferenceCountryName]];
    if (self.selectedIncentiveCurrency == nil) {
        self.selectedIncentiveCurrency = [[NSMutableDictionary alloc]init];
    }
    [self.selectedIncentiveCurrency setObject:string forKey:kCLCareerHistoryAllowanceCurrencykey];
    [self.selectedIncentiveCurrency setObject:[dictionary objectForKey:kjobPreferenceCountryCode] forKey:kCLCareerHistoryAllowanceCurrencyIdkey];
    [self.tableView reloadData];
}

#pragma mark - Incentive delegate
-(void)incentiveBonusController:(CLIncentiveListViewController *)controller didSelect:(NSMutableDictionary *)selectedDict{
    
    self.selectedIncentiveBonus =selectedDict;
    [self.tableView reloadData];
}
@end
