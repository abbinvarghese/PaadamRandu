//
//  CLPortfolioProjectsViewController.h
//  CareerLine
//
//  Created by Pravin on 10/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLProjectObject.h"
#import "CLHeightAdjustTextCell.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"
#import "CLEduProjectObject.h"

@class CLPortfolioProjectsViewController;

//Delegate Methods...
@protocol CLProjectsControllerDelegate <NSObject>

@optional
- (void)projectsController:(CLPortfolioProjectsViewController *)controller didAddProject:(id)projObj fromEdu:(BOOL)Education;

@end

@interface CLPortfolioProjectsViewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,UIPickerViewDelegate,UIPickerViewDataSource,CLProfilePhotoListingGridCellDelegate
,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLProjectsControllerDelegate> delegate;
@property(nonatomic,strong)CLProjectObject *projectObj;
@property(nonatomic,strong)CLEduProjectObject *eduObj;
@property(nonatomic,strong)NSMutableArray *careerListArray;
@property(nonatomic,strong)NSMutableArray *coursesArray;
@property(nonatomic,assign)BOOL isEditMode;
@property(nonatomic,assign)BOOL forEdu;

@end
