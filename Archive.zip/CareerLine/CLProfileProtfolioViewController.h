//
//  CLProfileProtfolioViewController.h
//  CareerLine
//
//  Created by CSG on 7/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLPortfolioProjectsViewController.h"
#import "CLPortfolioItemViewController.h"
#import "CLProtfolioObject.h"

@interface CLProfileProtfolioViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CLProjectsControllerDelegate,CLItemsControllerDelegate>

@property(nonatomic,strong)CLProtfolioObject *protfolio;
@property (nonatomic, assign)NSInteger selectedRow;

@end
