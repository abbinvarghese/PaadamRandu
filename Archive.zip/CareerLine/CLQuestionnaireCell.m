//
//  CLQuestionnaireCell.m
//  CareerLine
//
//  Created by CSG on 3/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLQuestionnaireCell.h"

#define kBottomIndentWhenSubmitted 30
#define kBottomIndentWhenNotSubmitted 1

@interface CLQuestionnaireCell()

@property(nonatomic, assign) float txtHeight;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaceholder;
@property (weak, nonatomic) IBOutlet UITextView *txtAnsView;
@property (weak, nonatomic) IBOutlet UILabel *lblQuestion;
@property (weak, nonatomic) IBOutlet RateView *rateView;

@property (weak, nonatomic) IBOutlet UIView *ratingView;
//@property (weak, nonatomic) IBOutlet UIButton *bttnRating1;
//@property (weak, nonatomic) IBOutlet UIButton *bttnRating2;
//@property (weak, nonatomic) IBOutlet UIButton *bttnRating3;
//@property (weak, nonatomic) IBOutlet UIButton *bttnRating4;
//@property (weak, nonatomic) IBOutlet UIButton *bttnRating5;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *txtAnsViewBottomConstraint;
@end

@implementation CLQuestionnaireCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLQuestionnaireCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        self.txtHeight=[self getTextViewSize].height;
    }
    return self;
}

#pragma mark Utility Methods

-(NSNumber*)getAnsTextViewHeight{
    return [NSNumber numberWithFloat:self.txtHeight];
}

-(CGSize)getTextViewSize{
    CGSize maximumLabelSize = CGSizeMake(self.frame.size.width-40, FLT_MAX);
    return [self.txtAnsView sizeThatFits:maximumLabelSize];
}

-(void)updateCellContent:(BOOL)isSubmitted{
    self.lblQuestion.text=self.quesObj.question;
    self.txtAnsView.text=self.quesObj.answer;
    self.lblPlaceholder.hidden = ([self.txtAnsView.text length] > 0);
    if (isSubmitted) {
        if (self.quesObj.rating!=CLQuestionnaireSmileyRatingNone) {
            self.txtAnsViewBottomConstraint.constant=kBottomIndentWhenSubmitted;
            self.ratingView.hidden=NO;
            [self selectRatingButtonWithTag:self.quesObj.rating];
        }
        else{
            self.txtAnsViewBottomConstraint.constant=kBottomIndentWhenNotSubmitted;
            self.ratingView.hidden=YES;
        }
        self.lblPlaceholder.hidden=YES;
        self.txtAnsView.userInteractionEnabled=NO;
        self.lblQuestion.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    }
    else{
        self.txtAnsViewBottomConstraint.constant=kBottomIndentWhenNotSubmitted;
        self.ratingView.hidden=YES;
        
        self.txtAnsView.userInteractionEnabled=YES;
        self.lblQuestion.textColor=[UIColor blackColor];
    }
}

- (void)selectRatingButtonWithTag:(CLQuestionnaireSmileyRating)rating{
    
    self.rateView.notSelectedImage = [UIImage imageNamed:@"star_empty@2x.png"];
    self.rateView.fullSelectedImage = [UIImage imageNamed:@"star_full@2x.png"];
     self.rateView.rating = rating;
     self.rateView.editable = NO;
     self.rateView.maxRating = 5;
     self.rateView.delegate = nil;
     self.rateView.userInteractionEnabled=NO;

}

#pragma mark UITextView Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.lblPlaceholder.hidden = YES;
}

-(void)textViewDidChange:(UITextView*)textView{
    self.lblPlaceholder.hidden = ([textView.text length] > 0);
    
    self.quesObj.answer=textView.text;
    self.txtHeight=[self getTextViewSize].height;
    if (self.txtHeight>=kintialTextViewHeight) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterQuestionnaireCellHeightChange object:self];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.lblPlaceholder.hidden = ([textView.text length] > 0);
}

@end
