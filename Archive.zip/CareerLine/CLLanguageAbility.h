//
//  CLLanguageAbility.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLLanguageAbility : NSObject

@property(nonatomic,strong)NSString *languageId;
@property(nonatomic,strong)NSString *languageName;

@property(nonatomic,strong)NSString *meetingLevelId;
@property(nonatomic,strong)NSString *meetingLevelName;

@property(nonatomic,strong)NSString *presentationLevelId;
@property(nonatomic,strong)NSString *presentationLevelName;

@property(nonatomic,strong)NSString *socializingLevelId;
@property(nonatomic,strong)NSString *socializingLevelName;

@property(nonatomic,strong)NSString *telephoningLevelId;
@property(nonatomic,strong)NSString *telephoningLevelName;

@property(nonatomic,strong)NSString *writingLevelId;
@property(nonatomic,strong)NSString *writingLevelName;

@end
