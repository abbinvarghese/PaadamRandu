//
//  CLForgotPassViewController.m
//  CareerLine
//
//  Created by CSG on 1/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLForgotPassViewController.h"
#import "CLWelcomeScreenViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLForgotPassViewController ()

@property (weak, nonatomic) IBOutlet UITextField *txtEmailField;
- (IBAction)bttnActionResetPassword:(id)sender;
@end

@implementation CLForgotPassViewController

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title=NSLocalizedString(@"Forgot Your Password?", @"Forgot password page title");
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.txtEmailField becomeFirstResponder];
    [[UINavigationBar appearance] setBarTintColor:ColorCode_CareerLineGreen];
    self.navigationItem.leftBarButtonItem.title = @"Back";
    self.navigationController.navigationBar.hidden=NO;
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Forgot Password"];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [self.txtEmailField resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark IBActions

- (IBAction)bttnActionResetPassword:(id)sender {
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Resetting...", @"Text displayed in the loading indicator while resettting password in forgot password");
        [progressHUD showInView:self.view];
        [CLUserObject forgotPassword:self.txtEmailField.text
                             success:^(NSString *userName){
                                 [progressHUD hideWithAnimation:YES];
                                 CLWelcomeScreenViewController *welcomeScreen=[[CLWelcomeScreenViewController alloc] initWithNibName:@"CLWelcomeScreenViewController" bundle:[NSBundle mainBundle]];
                                 [CLCommon sharedInstance].userName=userName;
                                 welcomeScreen.fromPageFlag=CLNavigationFromForgotPassPage;
                                 [self.navigationController pushViewController:welcomeScreen animated:YES];
                             }
                             failure:^(NSString *error){
                                 [progressHUD hideWithAnimation:YES];
                                 if (![error isEqualToString:@""]) {
                                     [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"")];
                                 }
                             }];
    }
}

#pragma mark Utility Functions

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    if ([self.txtEmailField.text isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Email Address.", @"Error Message for null email address login field") cancelbuttonName:NSLocalizedString(@"OK", @"")];
        isValid=NO;
	}
    else if (![CLCommon validateEmailWithString:self.txtEmailField.text]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter a valid Email address.", @"Error Message for invalid email address for login") cancelbuttonName:NSLocalizedString(@"OK", @"")];
        isValid=NO;
    }
    return isValid;
}


@end
