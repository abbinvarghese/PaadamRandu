//
//  CLLoaderCell.m
//  CareerLine
//
//  Created by Abbin on 13/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLLoaderCell.h"


@implementation CLLoaderCell

- (void)awakeFromNib {
}

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLLoaderCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        self = [arrayOfViews objectAtIndex:0];
        
    }
    
    return self;
    
}


-(void)updateLoaderForPage:(BOOL)lastPages{
    if (lastPages) {
        [self.activityIndicator stopAnimating];
    }
    else{
        [self.activityIndicator startAnimating];
    }
}


@end
