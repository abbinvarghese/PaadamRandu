//
//  CLCollectionIndustryCell.m
//  CareerLine
//
//  Created by CSG on 2/18/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCollectionIndustryCell.h"

@interface CLCollectionIndustryCell()

@property (weak, nonatomic) IBOutlet UIImageView *cellImage;
@property (weak, nonatomic) IBOutlet UILabel *celltext;
@end

@implementation CLCollectionIndustryCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLCollectionIndustryCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}


-(void)setCellText:(NSString*)text{
    self.celltext.text=text;
}

-(void)setCellImageWithName:(NSString*)imageName{
    self.cellImage.image=[UIImage imageNamed:imageName];
}

@end
