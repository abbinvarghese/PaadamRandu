//
//  CLProfilePhotoListingGridCell.m
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfilePhotoListingGridCell.h"
#import "CLCollectionProfilePhotoCell.h"
#import "CLCollectionProfileAddDetailCell.h"

@interface CLProfilePhotoListingGridCell()

@property (weak, nonatomic) IBOutlet UICollectionView *photoCollectionView;
@property (weak, nonatomic) IBOutlet UICollectionViewFlowLayout *flowLayout;

@end

@implementation CLProfilePhotoListingGridCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLProfilePhotoListingGridCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        self.placeHolderImageName=@"company_placeholder";
        [self.photoCollectionView registerClass:[CLCollectionProfilePhotoCell class] forCellWithReuseIdentifier:@"profilePhotoGridCell"];
        [self.photoCollectionView registerClass:[CLCollectionProfileAddDetailCell class] forCellWithReuseIdentifier:@"profilePhotoAddDetailCell"];
        self.photoCollectionView.backgroundColor = [UIColor clearColor];
        
        // Configure layout
        [self.flowLayout setItemSize:CGSizeMake(([UIScreen mainScreen].bounds.size.width-30)/2, ([UIScreen mainScreen].bounds.size.width-30)/2)];
        [self.flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
        self.flowLayout.minimumInteritemSpacing = 10.0f;
        [self.photoCollectionView setCollectionViewLayout:self.flowLayout];
        self.photoCollectionView.bounces = NO;
        [self.photoCollectionView setScrollEnabled:NO];
        [self.photoCollectionView setShowsHorizontalScrollIndicator:NO];
        [self.photoCollectionView setShowsVerticalScrollIndicator:NO];
        self.photosLimit=4;
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark Utility Methods

-(void)updateCollectionViewContents{
    [self.photoCollectionView reloadData];
}

#pragma mark UICollectionView Delegates

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if ([self.photoUrls count]==self.photosLimit) {
        return [self.photoUrls count];
    }
    else if ([self.photoUrls count] > self.photosLimit){
        return [self.photoUrls count];
    }
    return [self.photoUrls count]+1;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==[self.photoUrls count]) {
        if ([self.photoUrls count]!=self.photosLimit || [self.photoUrls count] >! self.photosLimit ) {
            CLCollectionProfileAddDetailCell *cell=[self.photoCollectionView dequeueReusableCellWithReuseIdentifier:@"profilePhotoAddDetailCell" forIndexPath:indexPath];
            return cell;
        }
    }
    CLCollectionProfilePhotoCell *cell = [self.photoCollectionView dequeueReusableCellWithReuseIdentifier:@"profilePhotoGridCell" forIndexPath:indexPath];
    [cell updateActivityIndicatorColor];
    [cell setWhiteBorderWidth:10];
    [cell setPlaceHolderImageName:self.placeHolderImageName];
    [cell setCellImageWithUrl:((CLFileObject*)[self.photoUrls objectAtIndex:indexPath.row]).filePreviewUrl];
    return cell;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView
                        layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==[self.photoUrls count]) {
        if ([self.photoUrls count]!=self.photosLimit) {
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellDidPressAddDetailButton:forIndexPath:)]){
                [self.delegate cellDidPressAddDetailButton:self forIndexPath:self.indexPath];
            }
        }
        else{
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellDidPressMediaItem:forMedia:sectionIndexPath:andRowIndexPath:)]){
                [self.delegate cellDidPressMediaItem:self forMedia:[self.photoUrls objectAtIndex:indexPath.row] sectionIndexPath:self.indexPath andRowIndexPath:indexPath];
            }
        }
    }
    else{
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellDidPressMediaItem:forMedia:sectionIndexPath:andRowIndexPath:)]){
            [self.delegate cellDidPressMediaItem:self forMedia:[self.photoUrls objectAtIndex:indexPath.row] sectionIndexPath:self.indexPath andRowIndexPath:indexPath];
        }
    }
}

@end
