//
//  CLWelcomeScreenViewController.h
//  CareerLine
//
//  Created by CSG on 1/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLWelcomeScreenViewController : UIViewController<UIAlertViewDelegate,UIActionSheetDelegate>

//To identify the message to be displayed in welcome screen...
typedef enum {
	CLNavigationFromWelcomePage = 0,
	CLNavigationFromRegisterPage= 1,
    CLNavigationFromForgotPassPage = 2
} CLNavigationFromPage;

@property (nonatomic,assign)CLNavigationFromPage fromPageFlag;
@property(nonatomic,assign)BOOL isFirstTime;
@property(nonatomic)BOOL fromPasswordReset;


@end
