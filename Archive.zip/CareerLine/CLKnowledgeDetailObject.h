//
//  CLKnowledgeDetailObject.h
//  CareerLine
//
//  Created by Abbin on 20/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLKnowledgeDetailObject : NSObject

@property(nonatomic,retain) NSString *objID;
@property(nonatomic,retain) NSString *knowledgeID;
@property(nonatomic,retain) NSString *title;
@property(nonatomic) BOOL isLiked;
@property(nonatomic,retain) NSString *likes;
@property(nonatomic) BOOL bookmarks;
@property(nonatomic,retain) NSString *summary;
@property(nonatomic,retain) NSURL *imageURL;
@property(nonatomic,retain) NSString *type;
@property(nonatomic,retain) NSString *subType;
@property(nonatomic,retain) NSString *discription;
@property(nonatomic,retain) NSURL *url;
@property(nonatomic,retain) NSArray *author;
@property(nonatomic,retain) NSString *authorName;
@property(nonatomic,retain) NSString *published;
@property(nonatomic,retain) NSString *edition;
@property(nonatomic,retain) NSString *volume;
@property(nonatomic,retain) NSString *isbnTen;
@property(nonatomic,retain) NSString *isbnThirteen;
@property(nonatomic,retain) NSString *fileUrl;
@property(nonatomic,retain) NSNumber* mainImageHeight;
@property(nonatomic,retain) NSNumber* mainImageWidth;
@property(nonatomic,retain) NSNumber* secondImageHeight;
@property(nonatomic,retain) NSNumber* secondImageWidth;
@property(nonatomic,retain) NSString* newsAgencyName;
@property(nonatomic,retain) NSString* NewsAgencyUrl;
@property(nonatomic,retain) NSString* PublicationDate;
@property(nonatomic,retain) NSString* Publishedon;
@property(nonatomic,retain) NSString* SEO;
@property(nonatomic,retain) NSString* Validity;
@property(nonatomic,retain) NSString* bodyContent;
@property(nonatomic,retain) NSMutableArray* certification;
@property(nonatomic,retain) NSString* company;
@property(nonatomic,retain) NSString* contact;
@property(nonatomic,retain) NSString* country;
@property(nonatomic,retain) NSString* date;
@property(nonatomic,retain) NSMutableArray* education;
@property(nonatomic,retain) NSString* email;
@property(nonatomic,retain) NSString* fax;
@property(nonatomic,retain) NSString* languages;
@property(nonatomic,retain) NSString* location;
@property(nonatomic,retain) NSString* mediaLink;
@property(nonatomic,retain) NSString* metaTags;
@property(nonatomic,retain) NSString* orgUrl;
@property(nonatomic,retain) NSString* studioTitle;
@property(nonatomic,retain) NSString* subject;
@property(nonatomic,retain) NSString* telephone;
@property(nonatomic,retain) NSString* theme;
@property(nonatomic,retain) NSString* venue;
@property(nonatomic,retain) NSString* venueImage;
@property(nonatomic,retain) NSString* video;
@property(nonatomic,retain) NSString* whoAttend;




-(id)initWithDictionary:(NSDictionary*)dictionary;

+(void)getknowledgeDetailForUser:(NSString*)userId andKnowledgeID:(NSString*)knowledgeID type:(NSString*)type success:(void (^)(CLKnowledgeDetailObject*knowledgeDetailObj))success failure:(void (^)(NSString *error))failure;

@end
