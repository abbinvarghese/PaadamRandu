//
//  CLProfileReferenceViewController.m
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileReferenceViewController.h"
#import "CLUserObject.h"
#import "CLReferencesObject.h"
#import "CLPerformanceReviewObject.h"
#import "CLProfileReferenceCell.h"
#import "UIImageView+WebCache.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

#define kSectionFooterBgColor [UIColor whiteColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont 14
#define kCellDetailFont 13
#define kCellvalueBoldFont 15

#define kcellTextDictKey @"cellText"
#define kcellDetailTextDictKey @"cellDetailText"

@interface CLProfileReferenceViewController ()

typedef enum {
    CLReviewIndex = 0,
    CLPerformanceReviewIndex= 1
} CLProfileReferenceTableSectionIndex;

@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (weak, nonatomic) IBOutlet UITableView *referencesTable;

@property(nonatomic,assign)BOOL isDataLoaded;

@end

@implementation CLProfileReferenceViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"Reviews", @"Title for References page");
    [self.referencesTable registerClass:[CLProfileReferenceCell class] forCellReuseIdentifier:@"referenceCellIdentifier"];
    self.isDataLoaded=NO;
    
//    self.isDataLoaded=YES;

    
    [self retrieveReferenceDetails];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Reviews"];
    [self.referencesTable reloadData];
}

-(void)viewDidDisappear:(BOOL)animated{
    [self.referencesTable setEditing:NO animated:NO];
    [CLReferencesObject cancelReferencePendingRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark CLReferenceConroller Delegate Methods

- (void)referenceController:(CLReferenceDetailViewController *)controller didAddReview:(CLReviewObject*)reviewObj{
    [self.referenceObj.reviewArray addObject:reviewObj];
    [self.referencesTable reloadSections:[NSIndexSet indexSetWithIndex:CLReviewIndex] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark CLPerformanceConroller Delegate Methods

- (void)performanceReviewController:(CLPerformanceReviewController *)controller didAddPerformanceReview:(CLPerformanceReviewObject *)perfRevObj{
    [self.referenceObj.perfRevArray addObject:perfRevObj];
    [self.referencesTable reloadSections:[NSIndexSet indexSetWithIndex:CLPerformanceReviewIndex] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark Utility Methods

-(void)retrieveReferenceDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading reference");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    [CLReferencesObject referenceDetailsForUser:[CLUserObject currentUser].userID success:^(CLReferencesObject *referenceObj){
                                       [progressHUD hideWithAnimation:YES];
                                       self.referenceObj=referenceObj;
                                       self.isDataLoaded=YES;
                                       [self.referencesTable reloadData];
                                   }
                                   failure:^(NSString *error){
                                       if (![error isEqualToString:@""]) {
                                           [progressHUD hideWithAnimation:YES];
                                           self.isDataLoaded=NO;
                                           [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                           
                                       }
                                   }];
}

-(void)removeReferenceAtIndexPath:(NSIndexPath *)indexPath{
    CLReviewObject *revObj=(CLReviewObject*)[self.referenceObj.reviewArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting reference");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLReviewObject deleteReference:revObj.referenceId forUser:[CLUserObject currentUser].userID success:^(){
                                               [progressHUD hideWithAnimation:YES];
                                               self.navigationItem.hidesBackButton=NO;
                                               [self.referenceObj.reviewArray removeObjectAtIndex:indexPath.row];
                                               if(indexPath.row==0 && [self.referenceObj.reviewArray count]==0){
                                                   [self.referencesTable reloadData];
                                               }
                                               else{
                                                   [self.referencesTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                               }
                                           }
                                           failure:^(NSString *error){
                                               if (![error isEqualToString:@""]) {
                                                   [progressHUD hideWithAnimation:YES];
                                                   self.navigationItem.hidesBackButton=NO;
                                                   [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                               }
                                           }];
}

-(void)removePerformanceAtIndexPath:(NSIndexPath *)indexPath{
    CLPerformanceReviewObject *revObj=(CLPerformanceReviewObject*)[self.referenceObj.perfRevArray objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting reference");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLPerformanceReviewObject deletePerformanceReview:revObj.performanceId forUser:[CLUserObject currentUser].userID success:^(){
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.hidesBackButton=NO;
        [self.referenceObj.perfRevArray removeObjectAtIndex:indexPath.row];
        if(indexPath.row==0 && [self.referenceObj.perfRevArray count]==0){
            [self.referencesTable reloadData];
        }
        else{
            [self.referencesTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
                                               failure:^(NSString *error){
                                                   if (![error isEqualToString:@""]) {
                                                       [progressHUD hideWithAnimation:YES];
                                                       self.navigationItem.hidesBackButton=NO;
                                                       [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                                   }
                                               }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

#pragma mark UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.isDataLoaded) {
        return 2;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==CLReviewIndex) {
        return [self.referenceObj.reviewArray count];
    }
    else{
        return [self.referenceObj.perfRevArray count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView setAllowsSelectionDuringEditing:YES];
    
    if (indexPath.section==CLReviewIndex) {
        CLProfileReferenceCell *refCell = (CLProfileReferenceCell *)[self.referencesTable dequeueReusableCellWithIdentifier:@"referenceCellIdentifier"];
        refCell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if ([self.referenceObj.reviewArray count])
            [tableView setEditing:YES animated:YES];
        
        refCell.revObj=[self.referenceObj.reviewArray objectAtIndex:indexPath.row];
        [refCell updateCellContents];
        return refCell;
    }
    else{
        static NSString *CellIdentifier = @"performanceCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont systemFontOfSize:kCellvalueBoldFont]];
            [cell.detailTextLabel setFont:[UIFont systemFontOfSize:kCellDetailFont]];
            [cell.textLabel setNumberOfLines:1];
            [cell.detailTextLabel setNumberOfLines:1];
            [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
            [cell.detailTextLabel setTextAlignment:NSTextAlignmentLeft];
        }
        [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        [cell.detailTextLabel setTextColor:[UIColor darkGrayColor]];
        
        if ([self.referenceObj.perfRevArray count])
            [tableView setEditing:YES animated:YES];
        
        CLPerformanceReviewObject *perfObj=[self.referenceObj.perfRevArray objectAtIndex:indexPath.row];
        cell.textLabel.text=[perfObj.careerSelected objectForKey:kCLProfilePerfReviewCareerTitlekey];
        cell.detailTextLabel.text=perfObj.formattedDateString;
        
        return cell;
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.referencesTable.bounds.size.width, 22);
    [sectionFooter addSubview:button];
    
    return sectionFooter;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLReviewIndex) {
        return 85;
    }
    else{
        return 44;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section==CLReviewIndex) {
        return NSLocalizedString(@"Reviews", @"Reviews");
    }
    else{
        return NSLocalizedString(@"Performance Reviews", @"Performance Reviews");
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:[UIFont systemFontOfSize:kSectionHeaderFont]];
}

#pragma mark UITableView Delegates

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLReviewIndex) {
        CLReferenceDetailViewController *referenceController=[[CLReferenceDetailViewController alloc] initWithStyle:UITableViewStyleGrouped];
        referenceController.isEditMode=YES;
        referenceController.revObj=(CLReviewObject*)[self.referenceObj.reviewArray objectAtIndex:indexPath.row];
        //    UINavigationController *referenceNavigation=[[UINavigationController alloc] initWithRootViewController:referenceController];
        //    [self presentViewController:referenceNavigation animated:YES completion:nil];
        [self.navigationController pushViewController:referenceController animated:YES];
    }
    else{
        CLPerformanceReviewController *perfController=[[CLPerformanceReviewController alloc] initWithStyle:UITableViewStylePlain];
        perfController.isEditMode=YES;
        perfController.perfObj=[self.referenceObj.perfRevArray objectAtIndex:indexPath.row];
        perfController.careerListArray=self.referenceObj.careerListArray;
        [self.navigationController pushViewController:perfController animated:YES];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        switch (indexPath.section) {
            case CLReviewIndex:{
                [self removeReferenceAtIndexPath:indexPath];
                break;
            }
            case CLPerformanceReviewIndex:{
                [self removePerformanceAtIndexPath:indexPath];
                break;
            }
            default:
                break;
        }
    }
}

#pragma mark IBActions

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    switch (sender.tag) {
        case CLReviewIndex:{
            CLReferenceDetailViewController *referencecontroller=[[CLReferenceDetailViewController alloc] initWithStyle:UITableViewStyleGrouped];
            referencecontroller.isEditMode = NO;
            referencecontroller.delegate=self;
            UINavigationController *addReferenceNavigation=[[UINavigationController alloc] initWithRootViewController:referencecontroller];
            [self presentViewController:addReferenceNavigation animated:YES completion:nil];
            break;
        }
        case CLPerformanceReviewIndex:{
            CLPerformanceReviewController *projController=[[CLPerformanceReviewController alloc] initWithStyle:UITableViewStylePlain];
            projController.isEditMode=NO;
            projController.perfObj=nil;
            projController.careerListArray=self.referenceObj.careerListArray;
            projController.delegate=self;
            UINavigationController *projNavigation=[[UINavigationController alloc] initWithRootViewController:projController];
            [self presentViewController:projNavigation animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
}

@end
