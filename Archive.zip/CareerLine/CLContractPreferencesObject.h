//
//  CLContractPreferencesObject.h
//  CareerLine
//
//  Created by Abbin on 10/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLContractPreferencesObject : NSObject
@property(nonatomic,retain) NSString *objectId;
@property(nonatomic,retain) NSMutableDictionary *employMentTypeDict;
@property(nonatomic,retain) NSMutableDictionary *contractTypeDict;
@property(nonatomic,retain) NSMutableDictionary *currencyDict;
@property(nonatomic,retain) NSString *minimumSalary;
@property(nonatomic,retain) NSMutableDictionary *salaryBasisDict;
@property(nonatomic,retain) NSString *increaseInSalary;
@property(nonatomic,retain) NSString *negotiable;
@property(nonatomic,retain) NSString *Other;

-(id)initWithDictionary:(NSMutableDictionary*)dictionary;
@end
