//
//  CLBusinessDivViewController.h
//  CareerLine
//
//  Created by RENJITH on 05/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectBusinessDivViewController.h"

@class CLBusinessDivViewController;
@protocol CLBusinessDivDelegate <NSObject>

@optional
- (void)employmentDetailsController:(CLBusinessDivViewController *)controller didAddBusinessDiv:(NSMutableArray*)businessDivArray;

@end
@interface CLBusinessDivViewController : UITableViewController <CLAddBusDivDelegate>


//@property(nonatomic,strong) NSMutableArray *completeBusinessDiv;
@property(nonatomic,strong) NSMutableDictionary *selectedCompany;
@property (nonatomic,weak) id<CLBusinessDivDelegate>delegate;
@property (nonatomic,strong) NSMutableArray *alreadySelectedBusDivision;
@end
