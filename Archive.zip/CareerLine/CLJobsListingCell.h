//
//  CLJobsListingCell.h
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLJobsObject.h"

@interface CLJobsListingCell : UITableViewCell

@property (nonatomic, strong) CLJobsObject *job;

-(void)updateCellContent;

@end
