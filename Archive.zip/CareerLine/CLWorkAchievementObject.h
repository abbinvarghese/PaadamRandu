//
//  CLWorkAchievementObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLWorkAchievementObject : NSObject

@property(nonatomic,strong)NSString *wrkHisId;
@property(nonatomic,strong)NSString *achievementId;
@property(nonatomic,strong)NSString *awards;
@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *workDescription;
@property(nonatomic,strong)NSMutableDictionary *relatedToSelected;
@property(nonatomic,strong)NSMutableArray *documents;       //[(CLFileObject),(CLFileObject),...]


//get dict from object..
- (NSMutableDictionary *)getDictFromObject:(CLWorkAchievementObject *)wrkAchvmntObj;

//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for saving work achievement of a particular user...
+ (void)saveWorkAchievement:(CLWorkAchievementObject*)achObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *workAchId))success failure:(void (^)(NSString *error))failure;

//Method for deleting work achievement for a particular user...
+ (void)deleteWorkAchievement:(NSString*)achievementId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading work achievement document for a particular user...
+ (void)addDocument:(UIImage*)image forWorkAchievement:(NSString*)achId andUser:(NSString *)userId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting work achievement document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
