//
//  CLProtfolioAssessmentViewController.h
//  CareerLine
//
//  Created by CSG on 7/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLAssessmentObject.h"
#import "CLProfilePhotoListingGridCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLProtfolioAssessmentViewController;

//Delegate Methods...
@protocol CLAssessmentControllerDelegate <NSObject>

@optional
- (void)assessmentController:(CLProtfolioAssessmentViewController *)controller didAddAssessment:(CLAssessmentObject*)assessObj;

@end

@interface CLProtfolioAssessmentViewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,CLHeightAdjustTextCellDelegate,CLProfilePhotoListingGridCellDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLAssessmentControllerDelegate> delegate;
@property(nonatomic,strong)CLAssessmentObject *assessObj;
@property(nonatomic,assign)BOOL isEditMode;


@end
