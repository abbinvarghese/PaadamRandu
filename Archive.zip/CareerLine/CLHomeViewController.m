//
//  CLViewController.m
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLHomeViewController.h"
#import "CLCollectionHomeViewCell.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import <QuartzCore/QuartzCore.h>
//#import "MarqueeLabel.h"

@interface CLHomeViewController ()

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
//@property (nonatomic,strong) MarqueeLabel *lbltitle;
@end

@implementation CLHomeViewController

#pragma mark UIViewController Methods

//- (void)setTitle:(NSString *)title
//{
//    [super setTitle:title];
//    
//    UIView *titleView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 40)];
//    [titleView setBackgroundColor:[UIColor clearColor]];
//    self.lbltitle = [[MarqueeLabel alloc] initWithFrame:titleView.frame duration:8.0f andFadeLength:20.0f];
//    //lbltitle.marqueeType=MLContinuous;
//    self.lbltitle.backgroundColor = [UIColor clearColor];
//    self.lbltitle.textAlignment=NSTextAlignmentCenter;
//    self.lbltitle.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:20];
//    self.lbltitle.textColor = [UIColor whiteColor]; // Change to desired color
//    self.lbltitle.text =title;
//    [titleView addSubview:self.lbltitle];
//    self.navigationItem.titleView = titleView;
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.title=NSLocalizedString(@"CareerLine", @"Home page title");
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    [self setupLeftMenuButton];
    [self setupCollectionView];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    //[self.lbltitle restartLabel];
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
}

-(void)viewDidAppear:(BOOL)animated{
    [self.collectionView reloadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UICollectionView Methods

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 14;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CLCollectionHomeViewCell *cell = (CLCollectionHomeViewCell *)[self.collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    [cell updateContentsForIndexPath:indexPath];
    return cell;
    
}

- (CGFloat)collectionView:(UICollectionView *)collectionView
                   layout:(CLCollectionViewMasonryLayout *)collectionViewLayout
 heightForItemAtIndexPath:(NSIndexPath *)indexPath {
    return MAX(252, [self getImageHeightForIndexPath:indexPath]+[self getTextSectionHeightForCell]);
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //Navigate to detail page..
}

#pragma mark Utility Functions

-(void)clearArraysAndReloadTable{
    
}

-(float)getImageHeightForIndexPath:(NSIndexPath*)indexPath{
    UIImage *image=nil;
    if(indexPath.row%4==0){
        image=[UIImage imageNamed:@"TileBg1"];
    }
    else if (indexPath.row%4==1){
        image=[UIImage imageNamed:@"TileBg2.jpg"];
    }
    else if (indexPath.row%4==2){
        image=[UIImage imageNamed:@"TileBg3.jpg"];
    }
    else{
        image=[UIImage imageNamed:@"TileBg4.jpg"];
    }
    float imageViewWidth=((CLCollectionViewMasonryLayout*)self.collectionView.collectionViewLayout).itemWidth;
    float imageWidth=image.size.width;
    float imageHeight=image.size.height;
    float result=(imageViewWidth*imageHeight)/imageWidth;
    return result;
}

-(float)getTextSectionHeightForCell{
    return 105;
}

-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(void)setupCollectionView {
    [self.collectionView registerClass:[CLCollectionHomeViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    self.collectionView.delegate=self;
    self.collectionView.dataSource=self;
    
    CLCollectionViewMasonryLayout *masonryLayout = [[CLCollectionViewMasonryLayout alloc] init];
    masonryLayout.sectionInset = UIEdgeInsetsMake(20,10,10,10);
    masonryLayout.delegate = self;
    masonryLayout.columnCount = 2;
    masonryLayout.itemWidth = ([UIScreen mainScreen].bounds.size.width-30)/2;
    [self.collectionView setCollectionViewLayout:masonryLayout];
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self.collectionView reloadData];
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

@end
