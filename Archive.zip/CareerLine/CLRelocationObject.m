//
//  CLRelocationObject.m
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLRelocationObject.h"
#import "AFHTTPRequestOperationManager+Timeout.h"

#define kDebugMessages 0


@implementation CLRelocationObject

static NSOperationQueue *getSecondRegionForSearchStringrequest;
static NSOperationQueue *getRegionForSearchStringrequest;
static NSOperationQueue *reloactionSummeryRequest;
static NSOperationQueue *saveRelocationRequest;



+(void)cancelRelocationSummeryRequest{
    [reloactionSummeryRequest cancelAllOperations];
    reloactionSummeryRequest = nil;
}

+(void)getRegionListForSearchString:(NSString*)searchText forUserId:(NSString*)userId forLocType:(NSString*)locType countryCode:(NSString*)code fromTwentyField:(BOOL)twentyField forPage:(int)pageNumber  success:(void (^)(NSMutableArray *preferredJobsList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *regionList,BOOL isLastPageReached){};
    }
    
    NSDictionary *parameters = nil;
    if (twentyField) {
        parameters = @{@"str":searchText, @"cyCode": code, @"page":[NSNumber numberWithInt:pageNumber]};
    }
    else{
        parameters = @{@"user":userId, @"loctype":locType, @"str":searchText, @"page":[NSNumber numberWithInt:pageNumber]};
    }
    
    
    [getRegionForSearchStringrequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getRegionForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        NSString *URL;
        if (twentyField) {
            URL = kCLWebServiceGetRegionListURLForTwentyField;
        }
        else{
            URL = kCLWebServiceGetRegionListURL;
        }
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,URL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *regionArray = [[NSMutableArray alloc]init];
                BOOL lastPageReached = NO;
                if ([[NSString stringWithFormat:@"%@",[response objectForKey:@"cur_page"]] isEqualToString:[NSString stringWithFormat:@"%@",[response objectForKey:@"pages"]]]) {
                    lastPageReached = YES;
                }
                for (NSMutableDictionary*dict in [response objectForKey:@"results"]) {
                    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithDictionary:dict];
                    [dic setObject:locType forKey:@"loc_type"];
                    [regionArray addObject:dic];
                }
                success(regionArray,lastPageReached);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"eroorrr=---->%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

-(NSMutableArray*)insertType:(NSString*)type intoArray:(NSMutableArray*)array{
    for (NSMutableDictionary *dict in array) {
        [dict setObject:type forKey:@"loc_type"];
    }
    return array;
}


+(void)getSecondSectionRegionListForSearchString:(NSString*)searchText forUserId:(NSString*)userId forType:(NSString*)Type fromTwentyField:(BOOL)twentyField currentLocationDictionary:(NSMutableDictionary*)dictionary forPage:(int)pageNumber success:(void (^)(NSMutableArray *regionList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *regionList,BOOL isLastPageReached){};
    }
    
    NSDictionary *parameters = nil;
    if (twentyField) {
        parameters = @{@"cyCode":[dictionary objectForKey:kCLRelocationjobLocationCountryCode], @"type":Type, @"str":searchText, @"page":[NSString stringWithFormat:@"%d",pageNumber]};
    }
    else{
        parameters = @{@"user":userId, @"type":Type, @"str":searchText, @"page":[NSString stringWithFormat:@"%d",pageNumber]};
    }
    
    
    [getSecondRegionForSearchStringrequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getRegionForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        NSString *URL;
        if (twentyField) {
            URL = kCLWebServiceGetSecondRegionListURLForTwentyField;
        }
        else{
            URL = kCLWebServiceGetSecondRegionListURL;
        }
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,URL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
//                NSMutableArray *regionArray = [[NSMutableArray alloc]initWithArray:[response objectForKey:@"results"]];
//                success(regionArray);
                
                NSMutableArray *regionArray = [[NSMutableArray alloc]init];
                BOOL lastPageReached = NO;
                if ([[NSString stringWithFormat:@"%@",[response objectForKey:@"cur_page"]] isEqualToString:[NSString stringWithFormat:@"%@",[response objectForKey:@"pages"]]]) {
                    lastPageReached = YES;
                }
                for (NSMutableDictionary*dict in [response objectForKey:@"results"]) {
                    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithDictionary:dict];
                    [dic setObject:Type forKey:@"loc_type"];
                    [regionArray addObject:dic];
                }
                success(regionArray,lastPageReached);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"eroorrr=---->%@",error.description);
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}






+ (void)RelocationSummaryForUser:(NSString *)userId lang:(NSString*)lang fromTwentyField:(BOOL)twentyField currentLocationFromTwentyField:(NSMutableDictionary*)currentLocationDict success:(void (^)(CLRelocationObject *relocObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLRelocationObject *relocObj){};
    }
    NSDictionary *parameters;
    if (twentyField) {
        parameters = @{@"cyCode": [currentLocationDict objectForKey:kCLRelocationjobLocationCountryCode], @"cyName" : [currentLocationDict objectForKey:kCLRelocationjobLocationCountryName], @"loc_name" : [currentLocationDict objectForKey:kCLRelocationjobLocationName] };
    }
    else{
        parameters = @{@"user": userId, @"lang": lang};
    }
    
    
    [reloactionSummeryRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        reloactionSummeryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceGetRelocationSummeryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSMutableDictionary *response=(NSMutableDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLRelocationObject *relocObj=[[CLRelocationObject alloc] initWithDictionary:response];
                success(relocObj);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

+ (void)saveRelocationConsideration:(CLRelocationObject*)relocObj forUser:(NSString*)userId success:(void (^)(NSString *relocId))success failure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *relocId){};
    }
    NSDictionary *parameters =@{@"user": userId, @"fields":[CLRelocationObject jsonStringForObject:relocObj]};
    [saveRelocationRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveRelocationRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServicePostRelocationURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveRelocationRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:@"id"]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(NSMutableDictionary*)jsocDictionaryFor:(CLRelocationObject*)relocObj{
    NSMutableDictionary *workInLocation = [[NSMutableDictionary alloc]initWithDictionary:relocObj.workOnlyInLocation];
    NSMutableDictionary *anywhereInCountry = [[NSMutableDictionary alloc]initWithDictionary:relocObj.anywhereInCountry];
    NSMutableDictionary *nominated = [[NSMutableDictionary alloc]initWithDictionary:relocObj.nominatedLocationsWithinCountry];
    NSMutableArray *withinCountryArray = [[NSMutableArray alloc]initWithObjects:workInLocation,anywhereInCountry,nominated, nil];
    NSMutableDictionary *anywhereOutsideCountry = [[NSMutableDictionary alloc]initWithDictionary:relocObj.anywhereOutsideCountry];
    NSMutableDictionary *specificNominated = [[NSMutableDictionary alloc]initWithDictionary:relocObj.specificNominatedLocations];
    NSMutableArray *OutsideCountryArray = [[NSMutableArray alloc]initWithObjects:anywhereOutsideCountry,specificNominated, nil];
    
    NSMutableDictionary *insideDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:withinCountryArray, kCLRelocationWithinCountry, OutsideCountryArray, kCLRelocationOutSideCountry, nil];
    NSMutableDictionary *maindict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:insideDict, kCLRelocationOptionsKey, nil];
    
    return maindict;
}

+(NSString*)jsonStringForObject:(CLRelocationObject*)relocObj{
    NSMutableDictionary *workInLocation = [[NSMutableDictionary alloc]initWithDictionary:relocObj.workOnlyInLocation];
    NSMutableDictionary *anywhereInCountry = [[NSMutableDictionary alloc]initWithDictionary:relocObj.anywhereInCountry];
    NSMutableDictionary *nominated = [[NSMutableDictionary alloc]initWithDictionary:relocObj.nominatedLocationsWithinCountry];
    NSMutableArray *withinCountryArray = [[NSMutableArray alloc]initWithObjects:workInLocation,anywhereInCountry,nominated, nil];
    NSMutableDictionary *anywhereOutsideCountry = [[NSMutableDictionary alloc]initWithDictionary:relocObj.anywhereOutsideCountry];
    NSMutableDictionary *specificNominated = [[NSMutableDictionary alloc]initWithDictionary:relocObj.specificNominatedLocations];
    NSMutableArray *OutsideCountryArray = [[NSMutableArray alloc]initWithObjects:anywhereOutsideCountry,specificNominated, nil];
    
    NSMutableDictionary *insideDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:withinCountryArray, kCLRelocationWithinCountry, OutsideCountryArray, kCLRelocationOutSideCountry, nil];
    NSMutableDictionary *maindict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:insideDict, kCLRelocationOptionsKey, nil];
    NSLog(@"%@",[CLCommon jsonStringWithPrettyPrint:NO foDict:maindict]);
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:maindict];
}



- (id)initWithDictionary:(NSDictionary*)dictionary{
    self = [super init];
    if (self == nil) return nil;
    self.currentCountry = [[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationCountryCode];
    self.workOnlyInLocation = [[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:0];
    self.anywhereInCountry = [[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:1];
    self.nominatedLocationsWithinCountry = [[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2];
    self.regionWithinCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kClRelocationRegionKey];
    self.stateWithinCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kCLRElocationStateKEy];
    self.metroWithinCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kCLRelocationMetroKEy];
    self.metroClusterWithCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kCLRelocationMetroClusterKey];
    self.tierTwoCitiesWithinCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kCLRelocationTier2CitiesKey];
    self.townsWithinCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry]objectAtIndex:2]objectForKey:kCLRelocationTownVillages];
    self.anywhereOutsideCountry = [[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:0];
    self.specificNominatedLocations = [[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:1];
    
    self.regionOutsideCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:1]objectForKey:kCLRelocationRegionOutside];
    self.subregionOutsideCountry = [[[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:1]objectForKey:kCLRelocationSubregionKey];
    self.countries = [[[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:1]objectForKey:kCLRelocationCountryKey];
    self.locations = [[[[dictionary objectForKey:kCLRelocationOptionsKey]objectForKey:kCLRelocationOutSideCountry]objectAtIndex:1]objectForKey:kCLRelocationLocationKeyOutside];
    
    return self;
}


@end
