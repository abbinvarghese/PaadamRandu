//
//  CLJobPreferencesViewController.m
//  CareerLine
//
//  Created by Abbin on 31/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobPreferencesViewController.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "CLTargetJobsViewController.h"
#import "CLContractConsiderationsViewController.h"
#import "CLWorkConditionViewController.h"
#import "CLJobPreferencesObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLRelocationViewController.h"

#define kProfileCellCotentFont 13
#define kProfileCellHeadingFont 14

@interface CLJobPreferencesViewController ()

typedef enum {
    CLJobPreferencesTargetJobsIndex = 0,
    CLJobPreferencesContractConsiderationIndex= 1,
    CLJobPreferencesWorkConditionIndex = 2,
    CLJobPreferencesRelocationIndex = 3
} CLJobPreferencesTableSectionIndex;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) HTProgressHUD *activityIndicator;

@property (nonatomic,retain) NSArray *sectionHeadingArry;
@property (nonatomic,retain) NSMutableArray *selectedTargetJobsArray;
@property (nonatomic,retain) NSMutableArray *selectedWorkConsiderationArray;
@property (nonatomic,retain) NSMutableArray *selectedRelocationConsiderationArray;
@property (nonatomic,retain) NSMutableArray *selectedContractConsideration;
@property (nonatomic,retain) NSMutableDictionary *jobPreferenceDict;

@end

@implementation CLJobPreferencesViewController

-(void)viewDidAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    [self getjobPreferenceSummaryDetails];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLJobPreferencesObject cancelJobSummeryRequest];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Job Preferences"];
//    [self.tableView reloadData];
}


- (void)viewDidLoad {
    [super viewDidLoad];
   // [self setupLeftMenuButton];
//    [self getjobPreferenceSummaryDetails];
    
     self.title = NSLocalizedString(@"Job Preferences", @"title for job preference");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





#pragma mark UITableView delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.jobPreferenceDict.count != 0) {
        return 4;
    }
    else{
        return 0;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case CLJobPreferencesTargetJobsIndex:
            return [self.selectedTargetJobsArray count];
            break;
        case CLJobPreferencesContractConsiderationIndex:
            return [self.selectedContractConsideration count];
            break;
        case CLJobPreferencesWorkConditionIndex:
            return [self.selectedWorkConsiderationArray count];
            break;
        case CLJobPreferencesRelocationIndex:
            return [self.selectedRelocationConsiderationArray count];
            break;
            
        default:
            break;
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jobPreferencesCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                          reuseIdentifier:@"jobPreferencesCell"];
    }
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:13];
    [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
    cell.detailTextLabel.numberOfLines = 2;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    switch (indexPath.section) {
        case CLJobPreferencesTargetJobsIndex:{
            cell.textLabel.text = [[self.selectedTargetJobsArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryTargetJobsHeadingKey];
            cell.detailTextLabel.text = [[self.selectedTargetJobsArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryTargetJobsValueKey];
            return cell;
        }
            break;
        case CLJobPreferencesContractConsiderationIndex:{
            cell.textLabel.text = [[self.selectedContractConsideration objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryContractConsiderationTitleKey];
            cell.detailTextLabel.text = [[self.selectedContractConsideration objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryContractConsiderationAvailabilityKey];
            return cell;
        }
            break;
        case CLJobPreferencesWorkConditionIndex:{
            cell.textLabel.text = [[self.selectedWorkConsiderationArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryWorkConsiderationHeadingKey];
            cell.detailTextLabel.text = [[self.selectedWorkConsiderationArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryWorkconsiderationValueKey];
            return cell;
        }
            break;
        case CLJobPreferencesRelocationIndex:{
            cell.textLabel.text = [[self.selectedRelocationConsiderationArray objectAtIndex:indexPath.row]objectForKey:@"title"];
            cell.detailTextLabel.text = [[self.selectedRelocationConsiderationArray objectAtIndex:indexPath.row]objectForKey:kClRelocationBoolValueKey];
            return cell;
        }
            break;
        default:
            break;
    }
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    CGFloat indentHeight = 16;
//    NSString *text = nil;
//    NSString *heading = nil;
//    
//    switch (indexPath.section) {
//        case CLJobPreferencesTargetJobsIndex:{
//            text =[[self.selectedTargetJobsArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryTargetJobsHeadingKey];
//            heading =[[self.selectedTargetJobsArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryTargetJobsValueKey];
//        }
//            break;
//        case CLJobPreferencesContractConsiderationIndex:{
//            text =[[self.selectedContractConsideration objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryContractConsiderationTitleKey];
//            heading = [[self.selectedContractConsideration objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryContractConsiderationAvailabilityKey];
//        }
//            break;
//        case CLJobPreferencesWorkConditionIndex:{
//            text = [[self.selectedWorkConsiderationArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryWorkConsiderationHeadingKey];
//            heading = [[self.selectedWorkConsiderationArray objectAtIndex:indexPath.row] objectForKey:kCLJobPreferenceSummaryWorkconsiderationValueKey];
//        }
//            break;
//        case CLJobPreferencesRelocationIndex:{
//            
//        }
//            break;
//        default:
//            break;
//    }
//    CGRect expectedDetailedtextFrame = [text boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX)
//                                                          options:NSStringDrawingUsesLineFragmentOrigin
//                                                       attributes:[NSDictionary dictionaryWithObjectsAndKeys:
//                                                                   [UIFont systemFontOfSize:kProfileCellCotentFont], NSFontAttributeName,
//                                                                   nil]
//                                                          context:nil];
//    
//    CGRect expectedHeaadingtextFrame = [heading boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX)
//                                                             options:NSStringDrawingUsesLineFragmentOrigin
//                                                          attributes:[NSDictionary dictionaryWithObjectsAndKeys:
//                                                                      [UIFont systemFontOfSize:kProfileCellHeadingFont], NSFontAttributeName,
//                                                                      nil]
//                                                             context:nil];
//    
//    CGFloat detailHeight = expectedDetailedtextFrame.size.height;
//    CGFloat headingHeight = expectedHeaadingtextFrame.size.height;
//    CGFloat totalHeight = detailHeight+headingHeight+indentHeight;
    return 60;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case CLJobPreferencesTargetJobsIndex:{
            
            NSLog(@"selected Row = %ld", (long)indexPath.row);
            CLTargetJobsViewController *targetJobController = [[CLTargetJobsViewController alloc]initWithNibName:@"CLTargetJobsViewController" bundle:nil];
            targetJobController.selectedRow = indexPath.row;
            
            [self.navigationController pushViewController:targetJobController animated:YES];
        }
            break;
        case CLJobPreferencesContractConsiderationIndex:{
            CLContractConsiderationsViewController *contractConsiderationsController = [[CLContractConsiderationsViewController alloc]initWithNibName:@"CLContractConsiderationsViewController" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:contractConsiderationsController animated:YES];
            
        }
            break;
        case CLJobPreferencesWorkConditionIndex:{
            CLWorkConditionViewController *condictionController = [[CLWorkConditionViewController alloc]initWithNibName:@"CLWorkConditionViewController" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:condictionController animated:YES];
        }
            break;
        case CLJobPreferencesRelocationIndex:{
            CLRelocationViewController *relocController = [[CLRelocationViewController alloc]initWithNibName:@"CLRelocationViewController" bundle:[NSBundle mainBundle]];
            relocController.selectedRow = indexPath.row;
            [self.navigationController pushViewController:relocController animated:YES];
        }
            break;
        default:
            break;
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionHeadingArry objectAtIndex:section];
}



#pragma mark Utility

-(void)loadListOfSelectedArray{
    self.selectedTargetJobsArray = [self.jobPreferenceDict objectForKey:kCLJobPreferenceTargetJobsKey];
    self.selectedContractConsideration = [self.jobPreferenceDict objectForKey:kCLJobPreferenceContractConsiderationsKey];
    self.selectedRelocationConsiderationArray = [self.jobPreferenceDict objectForKey:kCLJobPreferenceRelocConsiderationKey];
    NSMutableArray *array = [self.jobPreferenceDict objectForKey:kCLJobPreferenceWorkConsiderationKey];
    NSMutableDictionary *dict = [array objectAtIndex:0];
    NSMutableDictionary *dict2 = [dict objectForKey:kCLJobPreferenceSummaryWorkconsiderationValueKey];
    self.selectedWorkConsiderationArray =[dict2 objectForKey:kCLJobPreferenceSummaryWorkconsiderationWorkKey];
    self.sectionHeadingArry = [[NSArray alloc]initWithObjects:@"Target Jobs", @"Contract Considerations", @"Work Condition Considerations", @"Relocation Considerations", nil];
}

//-(void)setupLeftMenuButton{
//    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
//    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
//}
//
//-(void)leftDrawerButtonPress:(id)sender{
//    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
//}

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self.tableView reloadData];
}

-(void)getjobPreferenceSummaryDetails{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];

    [CLJobPreferencesObject jobSummaryForUser:[CLUserObject currentUser].userID success:^(NSMutableDictionary *jobPreDict){
        self.jobPreferenceDict = jobPreDict;
        [self loadListOfSelectedArray];
        [self.tableView reloadData];
        if (self.selectedRow != 0) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:_selectedRow];
            [self.tableView scrollToRowAtIndexPath:indexPath
                                           atScrollPosition:UITableViewScrollPositionTop
                                                   animated:NO];
        }
        _selectedRow = 0;
        [progressHUD hideWithAnimation:YES];
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't load Job Preferrences. Please try again later.", @"Error message when job preference is not loaded") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];

    }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
