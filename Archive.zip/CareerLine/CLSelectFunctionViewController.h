//
//  CLSelectFunctionViewController.h
//  CareerLine
//
//  Created by CSG on 2/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectFunctionViewController;

//Delegate Methods...
@protocol CLAddJobFunctionDelegate <NSObject>

@required
- (void)selectJobFunctionControllerDidSelectJobFunction:(CLSelectFunctionViewController*)controller withArray:(NSMutableArray *)jobFunctionArray;
- (void)selectJobFunctionControllerDidSelectJobFunction:(CLSelectFunctionViewController*)controller withArray:(NSMutableArray *)jobFunctionArray andSelectAllInfo:(NSMutableDictionary*)dict;

@end

@interface CLSelectFunctionViewController : UITableViewController

@property(nonatomic,weak) id <CLAddJobFunctionDelegate> delegate;
@property(nonatomic,strong)NSMutableArray *alreadySelectedFunctions;
@property(nonatomic,strong)NSDictionary *selectedJobFuncCategoryDict;
@property(nonatomic,retain) NSMutableDictionary *selectedFunctionDict;
@property(nonatomic)BOOL enableSelectOption;
@property(nonatomic)BOOL allFunctionSelected;
@end
