//
//  CLMembershipViewController.h
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLMembershipObject.h"
#import "CLSimpleTextCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLProfilePhotoListingGridCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLSimpleTappableTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLSelectLocationViewController.h"

@class CLMembershipViewController;

@protocol CLQualificationMembershipDelegate <NSObject>

@optional
-(void)qualificationMembership:(CLMembershipViewController *)controller didAddMembership:(CLMembershipObject *)memObj;

@end

@interface CLMembershipViewController : UITableViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLProfilePhotoListingGridCellDelegate,CLHeightAdjustTextCellDelegate,CLSimpleTextCellDelegate,CLTextCheckBoxCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate>


@property(nonatomic,weak) id <CLQualificationMembershipDelegate> delegate;
@property (nonatomic, assign) BOOL isEditMode;
@property (nonatomic, retain) CLMembershipObject *membershipObj;
@end
