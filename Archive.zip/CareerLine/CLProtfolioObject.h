//
//  CLProtfolioObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLProtfolioObject : NSObject

//@property(nonatomic,strong)NSMutableArray *workAchievementsArray;          // [(CLWorkAchievementObject),(CLWorkAchievementObject),...]
//@property(nonatomic,strong)NSMutableArray *assessmentsArray;          // [(CLAssessmentObject),(CLAssessmentObject),...]
//@property(nonatomic,strong)NSMutableArray *relatedToListArray;

@property(nonatomic,strong)NSMutableArray *projectsArray;          // [(CLProjectObject),(CLProjectObject),...]
@property(nonatomic,strong)NSMutableArray *itemsArray;          // [(CLItemObject),(CLItemObject),...]
@property(nonatomic,strong)NSMutableArray *educationProjects;
@property(nonatomic,strong)NSMutableArray *careerListArray;
@property(nonatomic,strong)NSMutableArray *courses;


//cancel request..
+ (void)cancelProtfolioPendingRequest;

//Method for getting a protfolio detail for a particular user...
+ (void)getProtfolioDetailsForUser:(NSString *)userId success:(void (^)(CLProtfolioObject *protfolioObj))success failure:(void (^)(NSString *error))failure;

@end
