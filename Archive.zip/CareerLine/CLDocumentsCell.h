//
//  CLDocumentsCell.h
//  CareerLine
//
//  Created by Abbin on 13/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLDocsObject.h"

@interface CLDocumentsCell : UICollectionViewCell

@property(nonatomic,retain) CLDocsObject *docObj;

-(void)updateCellForDocuments:(CLDocsObject*)docObj;

@end
