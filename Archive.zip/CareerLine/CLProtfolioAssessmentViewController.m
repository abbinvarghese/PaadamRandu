//
//  CLProtfolioAssessmentViewController.m
//  CareerLine
//
//  Created by CSG on 7/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProtfolioAssessmentViewController.h"
#import "CLDocumentViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import <MobileCoreServices/MobileCoreServices.h>

@interface CLProtfolioAssessmentViewController ()

typedef enum {
    CLAssessmentTitleIndex = 0,
    CLAssessmentDateIndex= 1,
    CLAssessmentScoreIndex = 2,
    CLAssessmentURLIndex = 3,
    CLAssessmentDescIndex = 4,
    CLAssessmentDocsIndex = 5
} CLAssessmentTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property(strong,nonatomic)NSString *titleText;
@property(strong,nonatomic)NSDate *date;
@property(strong,nonatomic)NSString *scoreText;
@property(strong,nonatomic)NSString *urlText;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;

@end

@implementation CLProtfolioAssessmentViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Assessment", @"Assessment edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"titleTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"dateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"scoreTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"urlTextCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionTextCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        [datePickr setDate:[CLUserObject currentUser].birthDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    if (self.isEditMode) {
        self.titleText=self.assessObj.assessmentTitle;
        self.date=self.assessObj.date;
        [self.datePicker setDate:self.date];
        self.scoreText=self.assessObj.score;
        self.urlText=self.assessObj.url;
        self.descriptionText=self.assessObj.assessDescription;
    }
    else{
        self.titleText=@"";
        self.date=nil;
        self.scoreText=@"";
        self.urlText=@"";
        self.descriptionText=@"";
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Achievements modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Reffered by validation..
    if ([self.titleText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Assessment title.", @"Error Message for null Awards/Titles field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.titleText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Assessment title length.", @"Error Message for length of Awards/Titles field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Date validation..
    if (self.date==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select date.", @"Error Message for null date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}
-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(void)saveAssessmentForEdit:(BOOL)isEditMode{
    CLAssessmentObject *newAssessObj=[[CLAssessmentObject alloc] init];
    if (isEditMode) {
        newAssessObj.assessmentId=self.assessObj.assessmentId;
    }
    else{
        newAssessObj.assessmentId=nil;
    }
    newAssessObj.assessmentTitle=self.titleText;
    [newAssessObj updateDate:self.date];
    newAssessObj.score=self.scoreText;
    newAssessObj.url=self.urlText;
    newAssessObj.assessDescription=self.descriptionText;
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLAssessmentObject saveAssessment:newAssessObj forUser:[CLUserObject currentUser].userID editMode:isEditMode
                               success:^(NSString *assessId){
                                             if (isEditMode) {
                                                 self.assessObj.assessmentTitle=newAssessObj.assessmentTitle;
                                                 [self.assessObj updateDate:newAssessObj.date];
                                                 self.assessObj.score=newAssessObj.score;
                                                 self.assessObj.url=newAssessObj.url;
                                                 self.assessObj.assessDescription=newAssessObj.assessDescription;
                                             }
                                             else{
                                                 newAssessObj.assessmentId=assessId;
                                                 self.assessObj=newAssessObj;
                                             }
                                             
                                             [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                                         }
                                         failure:^(NSString *error){
                                             if (![error isEqualToString:@""]) {
                                                 self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                                 self.navigationItem.rightBarButtonItem.enabled=YES;
                                                 [progressHUD hideWithAnimation:YES];
                                                 [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save reference. Please try again later.", @"Error message when reference cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                             }
                                         }];
}

-(void)addPickedImageToDocuments:(UIImage*)image{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLAssessmentObject addDocument:image forAssessment:self.assessObj.assessmentId andUser:[CLUserObject currentUser].userID
                            success:^(CLFileObject *documentObj){
                                     [progressHUD hideWithAnimation:YES];
                                     self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                     self.navigationItem.rightBarButtonItem.enabled=YES;
                                     if (!self.assessObj.documents) {
                                         self.assessObj.documents=[[NSMutableArray alloc] init];
                                     }
                                     [self.assessObj.documents addObject:documentObj];
                                     [self.tableView reloadData];
                                 }
                                 failure:^(NSString *error) {
                                     if (![error isEqualToString:@""]) {
                                         [progressHUD hideWithAnimation:YES];
                                         self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                         self.navigationItem.rightBarButtonItem.enabled=YES;
                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                     }
                                 }];
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *documentObj=[self.assessObj.documents objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLAssessmentObject deleteDocument:documentObj.fileId
                               success:^(){
                                        [progressHUD hideWithAnimation:YES];
                                        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                        self.navigationItem.rightBarButtonItem.enabled=YES;
                                        [self.assessObj.documents removeObjectAtIndex:indexPath.row];
                                        [self.tableView reloadData];
                                    }
                                    failure:^(NSString *error){
                                        if (![error isEqualToString:@""]) {
                                            [progressHUD hideWithAnimation:YES];
                                            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                            self.navigationItem.rightBarButtonItem.enabled=YES;
                                            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                        }
                                    }];
}

#pragma mark IBActions

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveAssessmentForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveAssessmentForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.date=date;
    
    CLSimpleTextCell *dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLAssessmentDateIndex]];
    [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if(cell!=nil){
        if (cell.cellIndexPath.section==CLAssessmentDateIndex) {
            if (self.date==nil || !([self.date compare:self.datePicker.date] == NSOrderedSame)) {
                self.date=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 6;
    }
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLAssessmentTitleIndex:{
            CLSimpleTextCell *titleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
            titleCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [titleCell setTextInputAccesoryView:self.keyboardResignView];
            [titleCell setPlaceHoldrText:NSLocalizedString(@"Title", @"Placeholder for Titles")];
            [titleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [titleCell setCellText:self.titleText];
            [titleCell setCellIndexPath:indexPath];
            titleCell.delegate=self;
            return titleCell;
            break;
        }
        case CLAssessmentDateIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"dateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.datePicker];
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Date", @"Placeholder for date field")];
            [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
            break;
        }
        case CLAssessmentScoreIndex:{
            CLSimpleTextCell *scoreCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"scoreTextCellIdentifier"];
            scoreCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [scoreCell setTextInputAccesoryView:self.keyboardResignView];
            [scoreCell setPlaceHoldrText:NSLocalizedString(@"Score", @"Placeholder text")];
            [scoreCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [scoreCell setCellText:self.scoreText];
            [scoreCell setCellIndexPath:indexPath];
            scoreCell.delegate=self;
            return scoreCell;
            break;
        }
        case CLAssessmentURLIndex:{
            CLSimpleTextCell *urlCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"urlTextCellIdentifier"];
            urlCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [urlCell setTextInputAccesoryView:self.keyboardResignView];
            [urlCell setPlaceHoldrText:NSLocalizedString(@"URL", @"Placeholder for url")];
            [urlCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [urlCell setCellText:self.urlText];
            [urlCell setCellIndexPath:indexPath];
            urlCell.delegate=self;
            return urlCell;
            break;
        }
        case CLAssessmentDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionTextCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything else you want to say about this", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLAssessmentDocsIndex:{
            CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.indexPath=indexPath;
            cell.delegate=self;
            cell.photosLimit=-1;
            cell.placeHolderImageName=@"documentPlaceHolder";
            cell.photoUrls=self.assessObj.documents;
            [cell updateCollectionViewContents];
            return cell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLAssessmentTitleIndex:
            return NSLocalizedString(@"Assessment title", @"Placeholder for titles");
            break;
        case CLAssessmentDateIndex:
            return NSLocalizedString(@"Assessment Date", @"Placeholder for date field");
            break;
        case CLAssessmentScoreIndex:
            return NSLocalizedString(@"Score/Result", @"Placeholder for score field");
            break;
        case CLAssessmentURLIndex:
            return NSLocalizedString(@"URL", @"Placeholder for url field");
            break;
        case CLAssessmentDescIndex:
            return NSLocalizedString(@"Remarks", @"Placeholder for description field");
            break;
        case CLAssessmentDocsIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLAssessmentDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else if(indexPath.section==CLAssessmentDocsIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.assessObj.documents count]+1)/2));
    }
    else{
        return 44;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLAssessmentTitleIndex:{
            self.titleText=text;
            break;
        }
        case CLAssessmentScoreIndex:{
            self.scoreText=text;
            break;
        }
        case CLAssessmentURLIndex:{
            self.urlText=text;
            break;
        }
        case CLAssessmentDescIndex:
            self.descriptionText=text;
            break;
            
        default:
            break;
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
    UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
    addDocumentActionSheet.tag=1;
    [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
    UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
    editDocumentActionSheet.tag=2;
    self.mediaPressed=mediaObj;
    self.indexPathPressed=rowIndexPath;
    [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [self addPickedImageToDocuments:pickedImage];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark UIActionsheet Delegates

-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(assessmentController:didAddAssessment:)]){
                [self.delegate assessmentController:self didAddAssessment:self.assessObj];
            }
        }];
    }
}


@end
