//
//  CLAboutMeThumbCell.h
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLAboutMeThumbCell : UITableViewCell<UICollectionViewDataSource,UICollectionViewDelegate>

@property(nonatomic,strong)NSMutableArray *photoUrls;
-(void)updateCollectionViewContents;

@end
