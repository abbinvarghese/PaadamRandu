//
//  CLInfoAddressViewController.h
//  CareerLine
//
//  Created by CSG on 8/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLLocationObject.h"
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLSelectLocationViewController.h"

@class CLInfoAddressViewController;

//Delegate Methods...
@protocol CLAddressControllerDelegate <NSObject>

@required
- (void)addressController:(CLInfoAddressViewController *)controller didAddAddress:(CLLocationObject*)locObj;

@optional
- (void)addressController:(CLInfoAddressViewController *)controller didEditAddress:(CLLocationObject*)locObj;

@end

@interface CLInfoAddressViewController : UITableViewController<CLSimpleTextCellDelegate,CLTappableCellDelegate,CLTextCheckBoxCellDelegate,CLSelectLocationDelegate>

@property(nonatomic,weak) id <CLAddressControllerDelegate> delegate;
@property(nonatomic,strong)CLLocationObject *locationObj;
@property(nonatomic,assign)BOOL isEditMode;
@property(nonatomic,assign)BOOL isCurrentAddress;

@end
