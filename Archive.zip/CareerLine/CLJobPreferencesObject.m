//
//  CLJobPreferencesObject.m
//  CareerLine
//
//  Created by Abbin on 13/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobPreferencesObject.h"
#import "AFHTTPRequestOperationManager+Timeout.h"
#import "CLConstants.h"
#define kDebugMessages 0

@implementation CLJobPreferencesObject

static NSOperationQueue *profileSummaryRequest;

+ (void)jobSummaryForUser:(NSString *)userId success:(void (^)(NSMutableDictionary *jobPreDict))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableDictionary *jobPreDict){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [profileSummaryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        profileSummaryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceJobPreferenceSummaryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSMutableDictionary *response=(NSMutableDictionary *)responseObject;
            
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableDictionary  *dict=[[NSMutableDictionary alloc] initWithDictionary:response];
                success(dict);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(void)cancelJobSummeryRequest{
    [profileSummaryRequest cancelAllOperations];
    profileSummaryRequest = nil;
}

@end
