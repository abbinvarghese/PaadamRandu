//
//  CLPreferredJobsEditViewController.m
//  CareerLine
//
//  Created by Abbin on 27/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLPreferredJobsEditViewController.h"


#define kSectionFooterBgColor [UIColor whiteColor]

@interface CLPreferredJobsEditViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *selectedPreferredJobsArray;

@end

@implementation CLPreferredJobsEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedPreferredJobsArray = [[NSMutableArray alloc]initWithArray:self.passedOnPreferredJobsArray];
    self.title = NSLocalizedString(@"Preferred Jobs", @"title for modal");
    [self setLeftNavigationButton];
    [self setRightNavigationButton];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.selectedPreferredJobsArray count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.selectedPreferredJobsArray count];
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
    [sectionFooter addSubview:button];
    if (section == 0) {
        return sectionFooter;
    }
    else return nil;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.selectedPreferredJobsArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"editCells"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"editCells"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:13];
    }
    cell.textLabel.text = [[self.selectedPreferredJobsArray objectAtIndex:indexPath.row] objectForKey:kCLTargetJobsPreferredJobKey];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 0) {
        return 44;
    }
    return 0;
}


-(void)loadSelectedPreferredJobs:(NSMutableDictionary *)dictionary{
    [self.selectedPreferredJobsArray addObject:dictionary];
    [self.tableView reloadData];
}


-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    CLPreferredJobsViewController *jobsController = [[CLPreferredJobsViewController alloc]initWithNibName:@"CLPreferredJobsViewController" bundle:[NSBundle mainBundle]];
    jobsController.delegate = self;
    [jobsController setPassedOnPreferredJobsArray:self.selectedPreferredJobsArray];
    UINavigationController *prefferenceNav = [[UINavigationController alloc]initWithRootViewController:jobsController];
    [self presentViewController:prefferenceNav animated:YES completion:nil];
}


-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for save button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)bttnActionSaveModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
    if ([_delegate respondsToSelector:@selector(loadFinalSelectedJobsPreferenceArray:)]) {
        [_delegate loadFinalSelectedJobsPreferenceArray:self.selectedPreferredJobsArray];
    }
}

@end
