//
//  CLInfoObject.m
//  CareerLine
//
//  Created by CSG on 7/25/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInfoObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLInfoObject

static NSOperationQueue *saveInfoRequest;
static NSOperationQueue *uploadPrimaryImageRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.country=[dictionary objectForKey:kCLProfileAboutMeCountryKey];
    self.infoId=[dictionary objectForKeyNotNull:kCLProfileAboutMeInfoIdkey];
    self.firstName = [dictionary objectForKeyNotNull:kCLProfileAboutMeFirstNamekey];
    self.middleName=[dictionary objectForKeyNotNull:kCLProfileAboutMeMiddleNamekey];
    self.lastName = [dictionary objectForKeyNotNull:kCLProfileAboutMeLastNamekey];
    self.formattedName=[self formattedNameForDisplay];
    self.nickname = [dictionary objectForKeyNotNull:kCLProfileAboutMeNickNamekey];
    //self.previousname = [dictionary objectForKeyNotNull:kCLProfileAboutMePreviousNameArraykey];
    self.skypeName=[dictionary objectForKeyNotNull:kCLProfileAboutMeSkypeNamekey];
    self.profileImage=[[CLFileObject alloc] initWithDictionary:[[dictionary objectForKeyNotNull:kCLProfileAboutMeProfileImagekey] objectAtIndex:0]];
    
    self.homeNumber = [[CLTelephoneObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLProfileAboutMeHomeNumberkey]];
    self.homeNumber.contactType=[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:ContactTypeHome],kCLProfileAboutMeTelephoneContactTypeIdkey,@"Home",kCLProfileAboutMeTelephoneContactTypeTextkey, nil];
    
    self.mobileNumber = [[CLTelephoneObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLProfileAboutMeMobileNumberkey]];
    self.mobileNumber.contactType=[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:ContactTypeMobile],kCLProfileAboutMeTelephoneContactTypeIdkey,@"Mobile",kCLProfileAboutMeTelephoneContactTypeTextkey, nil];
    
    self.email = [dictionary objectForKeyNotNull:kCLProfileAboutMeEmailkey];
    self.alternateEmail = [dictionary objectForKeyNotNull:kCLProfileAboutMeAlternateEmailkey];
    self.dob = [CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileAboutMeAgekey] andFormat:@"dd-MM-yyyy"];
    //self.salutation = [dictionary objectForKeyNotNull:kCLProfileAboutMeSalutationDictkey];
    //self.gender = [dictionary objectForKeyNotNull:kCLProfileAboutMeGenderDictkey];  //change keys in dict
    self.nationalities=[[dictionary objectForKeyNotNull:kCLProfileAboutMeNationalityArraykey] mutableCopy];
    self.currentLocation = [[CLLocationObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLProfileAboutMeCurrentLocationDictkey]];
    
    //changing keys for DBClient compatibility..
    self.salutation=[NSDictionary dictionaryWithObjectsAndKeys:[[dictionary objectForKeyNotNull:kCLProfileAboutMeSalutationDictkey] objectForKey:kCLProfileAboutMeSalutationIdkey],kSalutationOptionId,[[dictionary objectForKeyNotNull:kCLProfileAboutMeSalutationDictkey] objectForKey:kCLProfileAboutMeSalutationTitlekey],kSalutationOptionTitle, nil];
    
    self.gender=[NSDictionary dictionaryWithObjectsAndKeys:[[dictionary objectForKeyNotNull:kCLProfileAboutMeGenderDictkey] objectForKey:kCLProfileAboutMeGenderIdkey],kGenderOptionId,[[dictionary objectForKeyNotNull:kCLProfileAboutMeGenderDictkey] objectForKey:kCLProfileAboutMeGenderTitlekey],kGenderOptionTitle, nil];
    
    NSDictionary *tempNationalityDict;
    for (int i=0; i<[self.nationalities count]; i++) {
        tempNationalityDict=[self.nationalities objectAtIndex:i];
        NSDictionary *tempDict=[NSDictionary dictionaryWithObjectsAndKeys:[tempNationalityDict objectForKey:kCLProfileAboutMeNationalityCodekey],knationalityDictCode,[tempNationalityDict objectForKey:kCLProfileAboutMeNationalityNamekey],knationalityDictName, nil];
        [self.nationalities replaceObjectAtIndex:i withObject:tempDict];
    }
    
    //------ * --------------- * -----
    
    self.previousname=[[NSMutableArray alloc] init];
    NSMutableArray *nameArray=[dictionary objectForKeyNotNull:kCLProfileAboutMePreviousNameArraykey];
    for (int i=0; i<[nameArray count]; i++) {
        [self.previousname addObject:[[CLPreviousNameObject alloc] initWithDictionary:[nameArray objectAtIndex:i]]];
    }
    
//    self.telephoneNumbers=[[NSMutableArray alloc] init];
//    NSMutableArray *telephoneArray=[dictionary objectForKeyNotNull:kCLProfileAboutMeTelephoneNumberArraykey];
//    for (int i=0; i<[telephoneArray count]; i++) {
//        [self.telephoneNumbers addObject:[[CLTelephoneObject alloc] initWithDictionary:[telephoneArray objectAtIndex:i]]];
//    }
    
    self.otherAddresses=[[NSMutableArray alloc] init];
    NSMutableArray *addressArray=[dictionary objectForKeyNotNull:kCLProfileAboutMeOtherAddressArraykey];
    for (int i=0; i<[addressArray count]; i++) {
        [self.otherAddresses addObject:[[CLLocationObject alloc] initWithDictionary:[addressArray objectAtIndex:i]]];
    }
    
    return self;
}


-(NSString *)formattedNameForDisplay{
    NSMutableString *formattedString=[[NSMutableString alloc] init];
    
    if (self.firstName.length!=0) {
        [formattedString appendFormat:@"%@ ",self.firstName];
    }
    if (self.middleName.length!=0) {
        [formattedString appendFormat:@"%@ ",self.middleName];
    }
    if (self.lastName.length!=0) {
        [formattedString appendFormat:@"%@ ",self.lastName];
    }
    if (formattedString.length>0) {
        [formattedString deleteCharactersInRange:NSMakeRange([formattedString length]-1, 1)];
    }
    
    return formattedString;
}

-(void)updateFormattedName{
    self.formattedName=[self formattedNameForDisplay];
}

+(NSString*)jsonStringForObject:(CLInfoObject*)infoObj{
    NSMutableDictionary *infoDict=[[NSMutableDictionary alloc] init];
    
    if (infoObj.infoId!=nil && ![infoObj.infoId isEqualToString:@""]) {
        [infoDict setObject:infoObj.infoId forKey:kCLProfileAboutMeInfoIdkey];
    }
    
    if (infoObj.firstName!=nil && ![infoObj.firstName isEqualToString:@""]) {
        [infoDict setObject:infoObj.firstName forKey:kCLProfileAboutMeFirstNamekey];
    }
    
    if (infoObj.middleName!=nil && ![infoObj.middleName isEqualToString:@""]) {
        [infoDict setObject:infoObj.middleName forKey:kCLProfileAboutMeMiddleNamekey];
    }
    
    if (infoObj.lastName!=nil && ![infoObj.lastName isEqualToString:@""]) {
        [infoDict setObject:infoObj.lastName forKey:kCLProfileAboutMeLastNamekey];
    }
    
    if (infoObj.nickname!=nil && ![infoObj.nickname isEqualToString:@""]) {
        [infoDict setObject:infoObj.nickname forKey:kCLProfileAboutMeNickNamekey];
    }
    
    if (infoObj.skypeName!=nil && ![infoObj.skypeName isEqualToString:@""]) {
        [infoDict setObject:infoObj.skypeName forKey:kCLProfileAboutMeSkypeNamekey];
    }
    
    if (infoObj.email!=nil && ![infoObj.email isEqualToString:@""]) {
        [infoDict setObject:infoObj.email forKey:kCLProfileAboutMeEmailkey];
    }
    
    if (infoObj.alternateEmail!=nil && ![infoObj.alternateEmail isEqualToString:@""]) {
        [infoDict setObject:infoObj.alternateEmail forKey:kCLProfileAboutMeAlternateEmailkey];
    }
    
    if (infoObj.dob!=nil) {
        [infoDict setObject:[CLCommon getStringForDate:infoObj.dob andExactFormat:@"dd-MM-yyyy"] forKey:kCLProfileAboutMeAgekey];
    }
    if (infoObj.country!=nil) {
        [infoDict setObject:[infoObj.country objectForKey:@"countryCode"] forKey:@"CountryCode"];
    }
    
    if (infoObj.salutation!=nil && [infoObj.salutation count]>0) {
        NSDictionary *tempDict=[NSDictionary dictionaryWithObjectsAndKeys:[infoObj.salutation objectForKey:kSalutationOptionId],kCLProfileAboutMeSalutationIdkey, nil];
        [infoDict setObject:tempDict forKey:kCLProfileAboutMeSalutationDictkey];
    }
    
    if (infoObj.gender!=nil && [infoObj.gender count]>0) {
        NSDictionary *tempDict=[NSDictionary dictionaryWithObjectsAndKeys:[infoObj.gender objectForKey:kGenderOptionId],kCLProfileAboutMeGenderIdkey, nil];
        [infoDict setObject:tempDict forKey:kCLProfileAboutMeGenderDictkey];
    }
    
    if (infoObj.homeNumber!=nil && ![infoObj.homeNumber.telephoneContactNumber isEqualToString:@""]) {
        [infoDict setObject:[infoObj.homeNumber dictionaryForObject] forKey:kCLProfileAboutMeHomeNumberkey];
    }
    
    if (infoObj.mobileNumber!=nil && ![infoObj.mobileNumber.telephoneContactNumber isEqualToString:@""]) {
        [infoDict setObject:[infoObj.mobileNumber dictionaryForObject] forKey:kCLProfileAboutMeMobileNumberkey];
    }
    
    if (infoObj.currentLocation!=nil && ![infoObj.currentLocation.locationCode isEqualToString:@""]) {
        [infoDict setObject:[infoObj.currentLocation dictionaryForObject] forKey:kCLProfileAboutMeCurrentLocationDictkey];
    }
    
    NSDictionary *tempNationalityDict;
    NSMutableArray *tempNatArray=[[NSMutableArray alloc] init];
    for (int i=0; i<[infoObj.nationalities count]; i++) {
        tempNationalityDict=[infoObj.nationalities objectAtIndex:i];
        NSDictionary *tempDict=[NSDictionary dictionaryWithObjectsAndKeys:[tempNationalityDict objectForKey:knationalityDictCode],kCLProfileAboutMeNationalityCodekey, nil];
        [tempNatArray addObject:tempDict];
    }
    [infoDict setObject:tempNatArray forKey:kCLProfileAboutMeNationalityArraykey];
    
    NSMutableArray *tempPrevNameArray=[[NSMutableArray alloc] init];
    for (int i=0; i<[infoObj.previousname count]; i++) {
        [tempPrevNameArray addObject:[((CLPreviousNameObject*)[infoObj.previousname objectAtIndex:i]) dictionaryForObject]];
    }
    [infoDict setObject:tempPrevNameArray forKey:kCLProfileAboutMePreviousNameArraykey];
    
//    NSMutableArray *tempTelArray=[[NSMutableArray alloc] init];
//    for (int i=0; i<[infoObj.telephoneNumbers count]; i++) {
//        [tempTelArray addObject:[((CLTelephoneObject*)[infoObj.telephoneNumbers objectAtIndex:i]) dictionaryForObject]];
//    }
//    [infoDict setObject:tempTelArray forKey:kCLProfileAboutMeTelephoneNumberArraykey];
    
    NSMutableArray *tempOtherAddrArray=[[NSMutableArray alloc] init];
    for (int i=0; i<[infoObj.otherAddresses count]; i++) {
        [tempOtherAddrArray addObject:[((CLLocationObject*)[infoObj.otherAddresses objectAtIndex:i]) dictionaryForObject]];
    }
    [infoDict setObject:tempOtherAddrArray forKey:kCLProfileAboutMeOtherAddressArraykey];
    
    
    if (kDebugMessages) {
        NSLog(@"info json fields submitted=%@",[CLCommon jsonStringWithPrettyPrint:YES foDict:infoDict]);
    }
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:infoDict];
}

//Method for saving info of a particular user...
+ (void)saveInfo:(CLInfoObject *)infoObj forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
   
    NSDictionary *parameters = @{@"user": userId, @"id":infoObj.infoId, @"fields":[CLInfoObject jsonStringForObject:infoObj]};
    
    NSLog(@"%@",[CLInfoObject jsonStringForObject:infoObj]);
    
    [saveInfoRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveInfoRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeSaveInfoURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"save info JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading primary image for a particular user...
+ (void)uploadPrimaryImage:(UIImage*)image forUser:(NSString *)userId imageId:(NSString*)imageId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSMutableDictionary *parameters =[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,@"user", nil];// @{@"user": userId, @"id":imageId};
    if (imageId) {
        [parameters setObject:imageId forKey:@"id"];
    }
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadPrimaryImageRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadPrimaryImageRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeUploadPrimaryImageURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"ClImages" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"image upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
