//
//  CLFileObject.m
//  CareerLine
//
//  Created by CSG on 7/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLFileObject.h"
#import "NSDictionary+Additions.h"

@implementation CLFileObject

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.filecaption= [dictionary objectForKey:@"file_caption"];
    self.fileId=[dictionary objectForKeyNotNull:kCLProfileFileIdkey];
    self.fileTitle=[dictionary objectForKeyNotNull:kCLProfileFileTitlekey];
    self.filePreviewUrl=[dictionary objectForKeyNotNull:kCLProfileFilePreviewUrlkey];
    self.file=[dictionary objectForKeyNotNull:kCLProfileFilekey];
    
    return self;
}

- (id)copyWithZone:(NSZone *)zone
{
    id copy = [[[self class] allocWithZone:zone] init];
    
    if (copy) {
        // Copy NSObject subclasses
        [copy setFileId:[self.fileId copyWithZone:zone]];
        [copy setFileTitle:[self.fileTitle copyWithZone:zone]];
        [copy setFilePreviewUrl:[self.filePreviewUrl copyWithZone:zone]];
        [copy setFile:[self.file copyWithZone:zone]];
    }
    
    return copy;
}

@end
