//
//  CLMsgDisplayView.m
//  CareerLine
//
//  Created by Padmam on 07/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLMsgDisplayView.h"
#import "CLCommon.h"

@implementation CLMsgDisplayView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // Initialization code

        //self.backgroundColor = [UIColor darkGrayColor];
        self.backgroundColor = [CLCommon sharedInstance].currentTrafficLightColor;
        self.alpha = 0.8;//colorWithRed:190.0 green:190.0 blue:190.0 alpha:0.7];
        self.msgLbl = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, self.frame.size.width - 20, self.frame.size.height - 10)];

        self.msgLbl.textAlignment = NSTextAlignmentCenter;
        self.msgLbl.font = HELVETICA_NEUE_REGULAR_FONT_WITH_SIZE(13);
        self.msgLbl.textColor = [UIColor whiteColor];
        [self addSubview:self.msgLbl];
        
        self.layer.cornerRadius = 20;
        self.layer.masksToBounds = YES;

    }
    return self;
}

#pragma mark - Public methods -

#pragma mark Showing methods

- (void)showInView:(UIView *)view
{
    [self showInView:view animated:YES];
}

- (void)showInView:(UIView *)view animated:(BOOL)animated {
    [self showInRect:[view bounds] inView:view animated:animated];
}

- (void)showInRect:(CGRect)rect inView:(UIView *)view {
    [self showInRect:rect inView:view animated:YES];
}

- (void)showInRect:(CGRect)rect inView:(UIView *)view animated:(BOOL)animated {
    if (![[NSThread currentThread] isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showInRect:rect inView:view animated:animated];
        });
        return;
    }
    
    self.msgLbl.text = self.displayMsg;
    
    float width = [CLCommon widthOfString:self.displayMsg withFont:HELVETICA_NEUE_REGULAR_FONT_WITH_SIZE(13)];
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    
    if(width >= 300)
    {
        float width = 300;
        self.msgLbl.frame = CGRectMake(0, 0, width, 44);

        float height = [CLCommon measureHeightOfUILabel:self.msgLbl] + 20.0f;
        self.frame = CGRectMake((screenWidth - width)/2, (screenHeight - height)/2, width, height);
        self.msgLbl.frame = CGRectMake(0, 0, width, height);
        
        NSInteger lineCategory = height/25;
        NSInteger numLine =  (int)ceilf(height/21);
        self.msgLbl.numberOfLines = numLine + lineCategory;
    }
    else
    {
        float height = 44;
        self.frame = CGRectMake((screenWidth - (width + 20))/2, (screenHeight - height)/2, width + 20, height);
        self.msgLbl.frame = CGRectMake(0, 0, width + 20, height);
    }
    
    self.msgLbl.backgroundColor = [UIColor clearColor];
    
    [CLCommon doViewAnimation:self];
    [view addSubview:self];
   // [self performSelector:@selector(hide) withObject:nil afterDelay:2.0f];
}

#pragma mark - Hiding methods -


- (void)hide
{
    [self hideWithAnimation:YES];
}

- (void)hideWithAnimation:(BOOL)animated {
    if (![[NSThread currentThread] isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideWithAnimation:animated];
        });
        return;
    }

    self.hidden = YES;

    [CLCommon doViewAnimation:self];
    [self removeFromSuperview];
}

- (void)hideAfterDelay:(NSTimeInterval)delay {
    [self hideAfterDelay:delay animated:YES];
}

- (void)hideAfterDelay:(NSTimeInterval)delay animated:(BOOL)animated
{
    NSMethodSignature *signature = [[self class] instanceMethodSignatureForSelector:@selector(hideWithAnimation:)];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    [invocation setTarget:self];
    [invocation setSelector:@selector(hideWithAnimation:)];
    [invocation setArgument:&animated atIndex:2];
    [invocation retainArguments];
    [NSTimer scheduledTimerWithTimeInterval:delay invocation:invocation repeats:NO];
}

@end
