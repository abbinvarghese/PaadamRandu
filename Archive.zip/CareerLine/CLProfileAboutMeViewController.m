//
//  CLProfileAboutMeViewController.m
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileAboutMeViewController.h"
#import "CLDocumentViewController.h"
#import "CLPhotoBrowserViewController.h"
#import "CLAboutMeInfoViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
//#import "UIImageView+WebCache.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLUserObject.h"
#import "CLAchievementObject.h"
#import "CLMediaPresenceObject.h"
#import "CLInterestObject.h"
#import "CLLoaderImageVIew.h"

#define kSectionFooterBgColor [UIColor whiteColor]
#define kSectionHeaderTextColor [UIColor darkGrayColor]
#define kSectionHeaderBgColor [UIColor clearColor]
#define kSectionHeaderFont 14
#define kCellvalueFont 12
#define kCellDetailFont 14
#define kCellvalueBoldFont 16

#define kCollectionUserPhotosLimit 4

#define kcellTextDictKey @"cellText"
#define kcellDetailTextDictKey @"cellDetailText"


@interface CLProfileAboutMeViewController ()

typedef enum {
    CLAboutMeInfoIndex = 0,
    CLAboutMePhotosIndex= 1,
    CLAboutMeAchievementsIndex = 2,
    CLAboutMeMediaPresenceIndex = 3,
    CLAboutMeInterestsIndex = 4,
    CLAboutMeDocumentsIndex = 5
} CLProfileAboutMeTableSectionIndex;

@property (weak, nonatomic) IBOutlet UITableView *aboutMeTable;
@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
@property (weak, nonatomic) IBOutlet CLLoaderImageVIew *userImageView;
@property (weak, nonatomic) IBOutlet UILabel *lblFullName;
@property (weak, nonatomic) IBOutlet UILabel *lblUserDetails;
@property (weak, nonatomic) IBOutlet UILabel *lblPhoneNumbers;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property(nonatomic,strong)UIRefreshControl *refreshControl;

@property(nonatomic,assign)BOOL isDataLoaded;
@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property(nonatomic,assign)CLProfileAboutMeTableSectionIndex actionsheetPressed;

@end

@implementation CLProfileAboutMeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title=NSLocalizedString(@"About Me", @"Title for about me page");
    [self.aboutMeTable registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"aboutmePhotoListingGridCell"];
    [self setUpRefreshControl];
    
    self.isDataLoaded=NO;
    
//    self.isDataLoaded=YES;
//    [self updateTableHeaderDetails];
//    self.aboutMeTable.tableHeaderView=self.tblHeaderView;
    
//    [self retrieveAboutMeDetails];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [self.aboutMeTable reloadData];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self retrieveAboutMeDetails];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - About Me"];
}

-(void)viewDidDisappear:(BOOL)animated{
    [self.aboutMeTable setEditing:NO animated:NO];
    [CLAboutMeObject cancelAboutMePendingRequest];
}

#pragma mark UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.isDataLoaded) {
        return 5;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self getRowCountForSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==CLAboutMeAchievementsIndex || indexPath.section==CLAboutMeMediaPresenceIndex ||
        indexPath.section==CLAboutMeInterestsIndex)
    {
        [tableView setAllowsSelectionDuringEditing:YES];
        if(([self.aboutMe.achievements count]) ||([self.aboutMe.mediaPresence count]) || ([self.aboutMe.mediaPresence count]))
            [tableView setEditing:YES animated:YES];
    }

    if (indexPath.section==CLAboutMeInfoIndex) {
        static NSString *CellIdentifier = @"infoCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont systemFontOfSize:kCellDetailFont]];
            [cell.detailTextLabel setFont:[UIFont systemFontOfSize:kCellDetailFont]];
            [cell.textLabel setNumberOfLines:1];
            [cell.detailTextLabel setNumberOfLines:1];
            [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
            [cell.detailTextLabel setTextAlignment:NSTextAlignmentLeft];
        }
        if (indexPath.row!=0) {
            [cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
            [cell.detailTextLabel setTextColor:[UIColor blackColor]];
        }
        else{
            [cell.textLabel setTextColor:[UIColor lightGrayColor]];
            [cell.detailTextLabel setTextColor:[UIColor lightGrayColor]];
        }
        //[cell.textLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        cell.textLabel.text=[[self getCellTextForIndexPath:indexPath] objectForKey:kcellTextDictKey];
        cell.detailTextLabel.text=[[self getCellTextForIndexPath:indexPath] objectForKey:kcellDetailTextDictKey];
        return cell;
    }
    else if (indexPath.section==CLAboutMeAchievementsIndex || indexPath.section==CLAboutMeMediaPresenceIndex ||
             indexPath.section==CLAboutMeInterestsIndex){
        static NSString *CellIdentifier = @"otherCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            [cell.textLabel setFont:[UIFont boldSystemFontOfSize:kCellvalueBoldFont]];
            [cell.detailTextLabel setFont:[UIFont systemFontOfSize:kCellDetailFont]];
            [cell.textLabel setNumberOfLines:1];
            [cell.detailTextLabel setNumberOfLines:1];
            [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
            [cell.detailTextLabel setTextAlignment:NSTextAlignmentLeft];
        }
        [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
        cell.textLabel.text=[[self getCellTextForIndexPath:indexPath] objectForKey:kcellTextDictKey];
        cell.detailTextLabel.text=[[self getCellTextForIndexPath:indexPath] objectForKey:kcellDetailTextDictKey];
        return cell;
    }
    else{
        CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.aboutMeTable dequeueReusableCellWithIdentifier:@"aboutmePhotoListingGridCell"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.indexPath=indexPath;
        cell.delegate=self;
        
        if (indexPath.section==CLAboutMePhotosIndex){
            cell.placeHolderImageName=@"company_placeholder";
            cell.photosLimit=kCollectionUserPhotosLimit;
            cell.photoUrls=self.aboutMe.photos;
        }
//        else if(indexPath.section==CLAboutMeDocumentsIndex){
//            cell.photosLimit=-1;
//            cell.placeHolderImageName=@"documentPlaceHolder";
//            cell.photoUrls=self.aboutMe.documents;
//        }
        [cell updateCollectionViewContents];
        return cell;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self getTitleForSection:section];
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==CLAboutMeAchievementsIndex || section==CLAboutMeMediaPresenceIndex ||
        section==CLAboutMeInterestsIndex){
        if (section==CLAboutMeInterestsIndex && [self.aboutMe.interest.interestArray count]!=0) {
            return nil;
        }
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.aboutMeTable.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        
        return sectionFooter;
    }
    else{
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section==CLAboutMeAchievementsIndex || section==CLAboutMeMediaPresenceIndex ||
        section==CLAboutMeInterestsIndex){
        if (section==CLAboutMeInterestsIndex && [self.aboutMe.interest.interestArray count]!=0) {
            return 0;
        }
        return 44;
    }
    else{
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLAboutMeInfoIndex) {
        return 44;
    }
    else if (indexPath.section==CLAboutMeAchievementsIndex || indexPath.section==CLAboutMeMediaPresenceIndex ||
             indexPath.section==CLAboutMeInterestsIndex){
        return 44;
    }
    else if (indexPath.section==CLAboutMePhotosIndex){
        if ([self.aboutMe.photos count]==kCollectionUserPhotosLimit) {
            return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)[self.aboutMe.photos count]/2));
        }
        else{
            
            return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.aboutMe.photos count]+1)/2));
        }
    }
    else{
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.aboutMe.documents count]+1)/2));
    }
}

#pragma mark UITableView Delegates

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLAboutMeInfoIndex:{
            [self bttnActionShowInfoDetail:nil];
            break;
        }
        case CLAboutMeAchievementsIndex:{
            CLAboutMeAchievementsViewController *achievementController=[[CLAboutMeAchievementsViewController alloc] initWithStyle:UITableViewStylePlain];
            achievementController.isEditMode=YES;
            achievementController.achievementObj=(CLAchievementObject*)[self.aboutMe.achievements objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:achievementController animated:YES];
//            UINavigationController *achievementNavigation=[[UINavigationController alloc] initWithRootViewController:achievementController];
//            [self presentViewController:achievementNavigation animated:YES completion:nil];
            break;
        }
        case CLAboutMeMediaPresenceIndex:{
            CLAboutMeMediaViewController *mediaController=[[CLAboutMeMediaViewController alloc] initWithStyle:UITableViewStylePlain];
            mediaController.isEditMode=YES;
            mediaController.mediaObj=(CLMediaPresenceObject*)[self.aboutMe.mediaPresence objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:mediaController animated:YES];
//            UINavigationController *mediaNavigation=[[UINavigationController alloc] initWithRootViewController:mediaController];
//            [self presentViewController:mediaNavigation animated:YES completion:nil];
            break;
        }
        case CLAboutMeInterestsIndex:{
            CLAboutMeInterestViewController *interestController=[[CLAboutMeInterestViewController alloc] initWithStyle:UITableViewStylePlain];
            interestController.isEditMode=YES;
            interestController.interestObj=self.aboutMe.interest;
            [self.navigationController pushViewController:interestController animated:YES];
//            UINavigationController *interestNavigation=[[UINavigationController alloc] initWithRootViewController:interestController];
//            [self presentViewController:interestNavigation animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==CLAboutMeAchievementsIndex || indexPath.section==CLAboutMeMediaPresenceIndex ){//|| indexPath.section==CLAboutMeInterestsIndex) {
        return YES;
    }
    else{
        return NO;
    }
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        switch (indexPath.section) {
            case CLAboutMeAchievementsIndex:{
                [self removeAchievementAtIndexPath:indexPath];
                break;
            }
            case CLAboutMeMediaPresenceIndex:{
                [self removeMediaAtIndexPath:indexPath];
                break;
            }
//            case CLAboutMeInterestsIndex:{
//                [self removeInterestAtIndexPath:indexPath];
//                break;
//            }
                
            default:
                break;
        }
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    // Custom section header...
    view.tintColor = kSectionHeaderBgColor;
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:[UIFont systemFontOfSize:kSectionHeaderFont]];
}

#pragma mark Utility Methods

-(void)retrieveAboutMeDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    [CLAboutMeObject aboutMeDetailsForUser:[CLUserObject currentUser].userID
                                   success:^(CLAboutMeObject *aboutMeObj){
                                       [progressHUD hideWithAnimation:YES];
                                       self.aboutMe=aboutMeObj;
                                       self.isDataLoaded=YES;
                                       [self updateTableHeaderDetails];
                                       self.aboutMeTable.tableHeaderView=self.tblHeaderView;
                                       [self.aboutMeTable reloadData];
                                   }
                                   failure:^(NSString *error){
                                       if (![error isEqualToString:@""]) {
                                           [progressHUD hideWithAnimation:YES];
                                           self.isDataLoaded=NO;
                                           [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                           
                                       }
                                   }];
}

-(void)updateTableHeaderDetails{
    //name..
    self.lblFullName.text=self.aboutMe.info.formattedName;
    
    //email & nickname..
    if (self.aboutMe.info.email==nil && self.aboutMe.info.nickname==nil) {
        self.lblUserDetails.text=@"";
    }
    else if (self.aboutMe.info.email!=nil && self.aboutMe.info.nickname==nil){
        self.lblUserDetails.text=self.aboutMe.info.email;
    }
    else if (self.aboutMe.info.email==nil && self.aboutMe.info.nickname!=nil){
        self.lblUserDetails.text=self.aboutMe.info.nickname;
    }
    else{
        self.lblUserDetails.text=[NSString stringWithFormat:@"%@   |   %@",self.aboutMe.info.email,self.aboutMe.info.nickname];
    }
    
    //mobile number..
    if ((self.aboutMe.info.homeNumber.telephoneContactNumber==nil || [self.aboutMe.info.homeNumber.telephoneContactNumber isEqualToString:@""]) && (self.aboutMe.info.mobileNumber.telephoneContactNumber==nil || [self.aboutMe.info.mobileNumber.telephoneContactNumber isEqualToString:@""])) {
        self.lblPhoneNumbers.text=@"";
    }
    else if ((self.aboutMe.info.homeNumber.telephoneContactNumber!=nil || ![self.aboutMe.info.homeNumber.telephoneContactNumber isEqualToString:@""]) && (self.aboutMe.info.mobileNumber.telephoneContactNumber==nil || [self.aboutMe.info.mobileNumber.telephoneContactNumber isEqualToString:@""])){
        self.lblPhoneNumbers.text=self.aboutMe.info.homeNumber.formattedTelephoneNumber;
    }
    else if ((self.aboutMe.info.homeNumber.telephoneContactNumber==nil || [self.aboutMe.info.homeNumber.telephoneContactNumber isEqualToString:@""]) && (self.aboutMe.info.mobileNumber.telephoneContactNumber!=nil || ![self.aboutMe.info.mobileNumber.telephoneContactNumber isEqualToString:@""])){
        self.lblPhoneNumbers.text=self.aboutMe.info.mobileNumber.formattedTelephoneNumber;
    }
    else{
        self.lblPhoneNumbers.text=[NSString stringWithFormat:@"%@   |   %@",self.aboutMe.info.homeNumber.formattedTelephoneNumber,self.aboutMe.info.mobileNumber.formattedTelephoneNumber];
    }
    
    [self.userImageView setImageWithUrlString:self.aboutMe.info.profileImage.file];
    
//    [self.userImageView setImageWithURL:[NSURL URLWithString:[[CLUserObject currentUser].iconURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:@"user_placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//        if (!error) {
//            if (image && (cacheType == SDImageCacheTypeNone || cacheType == SDImageCacheTypeDisk))
//            {
//                self.userImageView.alpha = 0.0;
//                [UIView animateWithDuration:1.0
//                                 animations:^{
//                                     self.userImageView.alpha = 1.0;
//                                 }];
//            }
//        }
//        else{
//            NSLog(@"dp load error=%@",error.debugDescription);
//        }
//    }];
}

-(void)removeAchievementAtIndexPath:(NSIndexPath *)indexPath{
    CLAchievementObject *achObj=(CLAchievementObject*)[self.aboutMe.achievements objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLAchievementObject deletePersonalAchievement:achObj.achievementId forUser:[CLUserObject currentUser].userID
                                           success:^(NSString *achievementId){
                                               [progressHUD hideWithAnimation:YES];
                                               self.navigationItem.hidesBackButton=NO;
                                               [self.aboutMe.achievements removeObjectAtIndex:indexPath.row];
                                               if(indexPath.row==0 && [self.aboutMe.achievements count]==0){
                                                   [self.aboutMeTable reloadData];
                                               }
                                               else{
                                                   [self.aboutMeTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                               }
                                           }
                                           failure:^(NSString *error){
                                               if (![error isEqualToString:@""]) {
                                                   [progressHUD hideWithAnimation:YES];
                                                   self.navigationItem.hidesBackButton=NO;
                                                   [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                               }
                                           }];
}

-(void)removeMediaAtIndexPath:(NSIndexPath *)indexPath{
    CLMediaPresenceObject *mediaObj=(CLMediaPresenceObject*)[self.aboutMe.mediaPresence objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLMediaPresenceObject deleteWebsite:mediaObj.mediaPresenceId forUser:[CLUserObject currentUser].userID
                                           success:^(NSString *mediaId){
                                               [progressHUD hideWithAnimation:YES];
                                               self.navigationItem.hidesBackButton=NO;
                                               [self.aboutMe.mediaPresence removeObjectAtIndex:indexPath.row];
                                               if(indexPath.row==0 && [self.aboutMe.mediaPresence count]==0){
                                                   [self.aboutMeTable reloadData];
                                               }
                                               else{
                                                   [self.aboutMeTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                               }
                                           }
                                           failure:^(NSString *error){
                                               if (![error isEqualToString:@""]) {
                                                   [progressHUD hideWithAnimation:YES];
                                                   self.navigationItem.hidesBackButton=NO;
                                                   [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                               }
                                           }];
}

//-(void)removeInterestAtIndexPath:(NSIndexPath *)indexPath{
//    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
//    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
//    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
//    self.activityIndicator=progressHUD;
//    [self updateProgressHudColor];
//    [progressHUD showInView:self.view];
//    self.navigationItem.hidesBackButton=YES;
//    
//    [CLInterestObject deleteInterestForUser:[CLUserObject currentUser].userID
//                                 success:^(){
//                                     [progressHUD hideWithAnimation:YES];
//                                     self.navigationItem.hidesBackButton=NO;
//                                     self.aboutMe.interest=nil;
//                                     if(indexPath.row==0 && self.aboutMe.interest==nil){
//                                         [self.aboutMeTable reloadData];
//                                     }
//                                     else{
//                                         [self.aboutMeTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//                                     }
//                                 }
//                                 failure:^(NSString *error){
//                                     if (![error isEqualToString:@""]) {
//                                         [progressHUD hideWithAnimation:YES];
//                                         self.navigationItem.hidesBackButton=NO;
//                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//                                     }
//                                 }];
//}

-(void)removePhotoAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *photoObj=[self.aboutMe.photos objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLAboutMeObject deletePhoto:photoObj.fileId forUser:[CLUserObject currentUser].userID
                         success:^(){
                             [progressHUD hideWithAnimation:YES];
                             self.navigationItem.hidesBackButton=NO;
                             [self.aboutMe.photos removeObjectAtIndex:indexPath.row];
                             [self.aboutMeTable reloadData];
                         }
                         failure:^(NSString *error){
                             if (![error isEqualToString:@""]) {
                                 [progressHUD hideWithAnimation:YES];
                                 self.navigationItem.hidesBackButton=NO;
                                 [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                             }
                         }];
}
-(void)setPrimaryPhotoAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *photoObj=[self.aboutMe.photos objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Set as Primary...", @"Text displayed in the loading indicator while Set image as Primary");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
   // int prime= 1;
    int intVal = 1;
  
    [CLAboutMeObject setPrimayImage:photoObj.fileId forUser:[CLUserObject currentUser].userID isPrime:intVal
                            success:^(CLFileObject *fileObj) {
                             [progressHUD hideWithAnimation:YES];
                             self.navigationItem.hidesBackButton=NO;
                                [self.aboutMe.photos removeObjectAtIndex:indexPath.row];

                                if (self.aboutMe.info.profileImage.fileId !=nil) {
                                    [self.aboutMe.photos addObject:self.aboutMe.info.profileImage];
                                }
                                 self.aboutMe.info.profileImage = photoObj;
                                [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterProfileImageChanged object:fileObj];
                                [self updateTableHeaderDetails];
                                [self.aboutMeTable reloadData];
                         }
                         failure:^(NSString *error){
                             if (![error isEqualToString:@""]) {
                                 [progressHUD hideWithAnimation:YES];
                                 self.navigationItem.hidesBackButton=NO;
                                 [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                             }
                         }];
}

//-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
//    CLFileObject *documentObj=[self.aboutMe.documents objectAtIndex:indexPath.row];
//    
//    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
//    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
//    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
//    self.activityIndicator=progressHUD;
//    [self updateProgressHudColor];
//    [progressHUD showInView:self.view];
//    self.navigationItem.hidesBackButton=YES;
//    
//    [CLAboutMeObject deleteDocument:documentObj.fileId forUser:[CLUserObject currentUser].userID
//                            success:^(){
//                                [progressHUD hideWithAnimation:YES];
//                                self.navigationItem.hidesBackButton=NO;
//                                [self.aboutMe.documents removeObjectAtIndex:indexPath.row];
//                                [self.aboutMeTable reloadData];
//                            }
//                            failure:^(NSString *error){
//                                if (![error isEqualToString:@""]) {
//                                    [progressHUD hideWithAnimation:YES];
//                                    self.navigationItem.hidesBackButton=NO;
//                                    [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//                                }
//                            }];
//}

-(void)addPickedImageToProfileImages:(UIImage*)image caption:(NSString*) caption{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLAboutMeObject addNonPrimaryImage:image forUser:[CLUserObject currentUser].userID withCaption:caption
                                success:^(CLFileObject *imageObj){
                                    [progressHUD hideWithAnimation:YES];
                                    self.navigationItem.hidesBackButton=NO;
                                    [self.aboutMe.photos addObject:imageObj];
                                    [self.aboutMeTable reloadData];
                                }
                                failure:^(NSString *error) {
                                    if (![error isEqualToString:@""]) {
                                        [progressHUD hideWithAnimation:YES];
                                        self.navigationItem.hidesBackButton=NO;
                                        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                    }
                                }];
}

//-(void)addPickedImageToDocuments:(UIImage*)image caption:(NSString*)caption{
//    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
//    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
//    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
//    self.activityIndicator=progressHUD;
//    [self updateProgressHudColor];
//    [progressHUD showInView:self.view];
//    self.navigationItem.hidesBackButton=YES;
//    
//    [CLAboutMeObject addDocument:image forUser:[CLUserObject currentUser].userID withCaption:caption
//                                success:^(CLFileObject *documentObj){
//                                    [progressHUD hideWithAnimation:YES];
//                                    self.navigationItem.hidesBackButton=NO;
//                                    [self.aboutMe.documents addObject:documentObj];
//                                    [self.aboutMeTable reloadData];
//                                }
//                                failure:^(NSString *error) {
//                                    if (![error isEqualToString:@""]) {
//                                        [progressHUD hideWithAnimation:YES];
//                                        self.navigationItem.hidesBackButton=NO;
//                                        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//                                    }
//                                }];
//}


-(NSInteger)getRowCountForSection:(NSInteger)sectionIndex{
    switch (sectionIndex) {
        case CLAboutMeInfoIndex:{
            //current address is mandatory
            //            if ((self.aboutMe.currentAddress!=nil && self.aboutMe.currentAddress.length!=0) || (self.aboutMe.currentLocation!=nil && self.aboutMe.currentLocation.count!=0)) {
            //                count++;
            //            }
            
//            if (self.aboutMe.permanentLocation!=nil && self.aboutMe.permanentLocation.locationCode.length!=0) {
//                count++;
//            }
            NSInteger count=1;
            if ((self.aboutMe.info.nationalities!=nil && self.aboutMe.info.nationalities.count!=0)) {
                count++;
            }
            return count;
            break;
        }
        case CLAboutMePhotosIndex:
            return 1;
            break;
        case CLAboutMeAchievementsIndex:
            return [self.aboutMe.achievements count];
            break;
        case CLAboutMeMediaPresenceIndex:
            return [self.aboutMe.mediaPresence count];
            break;
        case CLAboutMeInterestsIndex:
            if ([self.aboutMe.interest.interestArray count]!=0) {
                return 1;
            }
            else{
                return 0;
            }
            break;
//        case CLAboutMeDocumentsIndex:
//            return 1;
//            break;
            
        default:
            return 0;
            break;
    }
}

-(NSDictionary*)getCellTextForIndexPath:(NSIndexPath*)indexPath{
    NSString *cellText=nil;
    NSString *cellDetailText=nil;
    
    switch (indexPath.section) {
        case CLAboutMeInfoIndex:{
            if (indexPath.row==0) {
                cellText=self.aboutMe.info.currentLocation.locationAddress;//NSLocalizedString(@"Current Address", @"current address title in profile");
                
                NSMutableString *formattedString=[[NSMutableString alloc] init];
                if (self.aboutMe.info.currentLocation.locationName.length!=0) {
                    [formattedString appendFormat:@"%@ ",self.aboutMe.info.currentLocation.locationName];
                }
                if (self.aboutMe.info.currentLocation.locationPincode.length!=0) {
                    [formattedString appendFormat:@"- %@ ",self.aboutMe.info.currentLocation.locationPincode];
                }
                cellDetailText=formattedString;
            }
            else{
                cellText=NSLocalizedString(@"Nationalities", @"Nationalities title in profile");
                
                NSMutableString *nationalityText=[[NSMutableString alloc] init];
                for (int i=0; i<[self.aboutMe.info.nationalities count]; i++) {
                    [nationalityText appendFormat:@"%@ | ",[[self.aboutMe.info.nationalities objectAtIndex:i] objectForKey:knationalityDictName]];
                }
                [nationalityText deleteCharactersInRange:NSMakeRange([nationalityText length]-3, 3)];
                cellDetailText=nationalityText;
            }
            break;
        }
        case CLAboutMePhotosIndex:
            cellText=@"";
            cellDetailText=@"";
            break;
        case CLAboutMeAchievementsIndex:{
            CLAchievementObject *achObj= [self.aboutMe.achievements objectAtIndex:indexPath.row];
            cellText=achObj.achievementTitle;
            cellDetailText=achObj.formattedDateString;
            break;
        }
        case CLAboutMeMediaPresenceIndex:{
            CLMediaPresenceObject *mediaObj= [self.aboutMe.mediaPresence objectAtIndex:indexPath.row];
            cellText=mediaObj.websiteName;
            cellDetailText=mediaObj.websiteUrl;
            break;
        }
        case CLAboutMeInterestsIndex:{
            cellText=self.aboutMe.interest.interestFormattedTitle;
            cellDetailText=self.aboutMe.interest.interestDescription;
            break;
        }
//        case CLAboutMeDocumentsIndex:
//            cellText=@"";
//            cellDetailText=@"";
//            break;
            
        default:
            cellText=@"";
            cellDetailText=@"";
            break;
    }
    
    return [NSDictionary dictionaryWithObjectsAndKeys:cellText,kcellTextDictKey,cellDetailText,kcellDetailTextDictKey, nil];
}

-(NSString*)getTitleForSection:(NSInteger)sectionIndex{
    switch (sectionIndex) {
        case CLAboutMeInfoIndex:
            return nil;
            break;
        case CLAboutMePhotosIndex:
            return NSLocalizedString(@"PHOTOS", @"title for about me PHOTOS section");
            break;
        case CLAboutMeAchievementsIndex:
            return NSLocalizedString(@"PERSONAL ACHIEVEMENTS", @"title for about me PERSONAL ACHIEVEMENTS section");
            break;
        case CLAboutMeMediaPresenceIndex:
            return NSLocalizedString(@"Personal/Professional Websites", @"title for about me SOCIAL MEDIA PRESENCE section");
            break;
        case CLAboutMeInterestsIndex:
            return NSLocalizedString(@"Hobbies/Interests", @"title for about me INTERESTS section");
            break;
//        case CLAboutMeDocumentsIndex:
//            return NSLocalizedString(@"DOCUMENTS", @"title for about me DOCUMENTS section");
//            break;
            
        default:
            return nil;
            break;
    }
}

-(void)setUpRefreshControl{
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.aboutMeTable;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshAboutMeDetails:) forControlEvents:UIControlEventValueChanged];
    tableViewController.refreshControl = self.refreshControl;
}

-(void)refreshAboutMeDetails:(id)sender{
    [self retrieveAboutMeDetails];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==CLAboutMePhotosIndex) {
        //add photo
        if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addPhotoActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3"), nil];
        addPhotoActionSheet.tag=1;
        self.actionsheetPressed=CLAboutMePhotosIndex;
        [addPhotoActionSheet showInView:self.view];
        }
        else{
            self.actionsheetPressed=CLAboutMePhotosIndex;
            UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
            
            UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"photo selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                              {
                                                  [self addPhotoActionSheetDismissedWithIndex:0];
                                              }];
            
            UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                                {
                                                    [self addPhotoActionSheetDismissedWithIndex:1];
                                                }];
            
            [actionSheetController addAction:cancelAction];
            [actionSheetController addAction:takePhotoAction];
            [actionSheetController addAction:choosePhotoAction];
            actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
            [self presentViewController:actionSheetController animated:YES completion:nil];
        }
    }
//    else{
//        //add document..
//        if ([CLCommon isOSversionLessThan8]) {
//        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
//        addDocumentActionSheet.tag=4;
//        self.actionsheetPressed=CLAboutMeDocumentsIndex;
//        [addDocumentActionSheet showInView:self.view];
//        }
//        else{
//            self.actionsheetPressed=CLAboutMeDocumentsIndex;
//            UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
//            
//            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
//            
//            UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                              {
//                                                 // [self addDocumentActionSheetDismissedWithIndex:0];
//                                              }];
//            
//            UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                                {
//                                                   // [self addDocumentActionSheetDismissedWithIndex:1];
//                                                }];
//            
//            [actionSheetController addAction:cancelAction];
//            [actionSheetController addAction:takePhotoAction];
//            [actionSheetController addAction:choosePhotoAction];
//            actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
//            [self presentViewController:actionSheetController animated:YES completion:nil];
//        }
//    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if (secIndexPath.section==CLAboutMePhotosIndex) {
        if ([CLCommon isOSversionLessThan8]) {
            UIActionSheet *editPhotoActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Photos", @"photo edit actionsheet option 1"),NSLocalizedString(@"Delete Photo", @"photo edit actionsheet option 2"),NSLocalizedString(@"Set as Primary", @"photo set primary actionsheet option 3"), nil];
            editPhotoActionSheet.tag=2;
            self.mediaPressed=mediaObj;
            self.indexPathPressed=rowIndexPath;
            [editPhotoActionSheet showInView:self.view];
        }
        else{
            self.mediaPressed=mediaObj;
            self.indexPathPressed=rowIndexPath;
            UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
            
            UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Photos", @"photo edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self editPhotoActionSheetDismissedWithIndex:0];
                                            }];
            UIAlertAction *setPrimaryAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Set as Primary", @"photo set primary actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self editPhotoActionSheetDismissedWithIndex:2];
                                            }];
            
            UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Photo", @"photo edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                              {
                                                  [self editPhotoActionSheetDismissedWithIndex:1];
                                              }];
            
            [actionSheetController addAction:cancelAction];
            [actionSheetController addAction:viewDocAction];
            [actionSheetController addAction:deleteDocAction];
            [actionSheetController addAction:setPrimaryAction];
            actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
            [self presentViewController:actionSheetController animated:YES completion:nil];
        }
    }
//    else{
//        if ([CLCommon isOSversionLessThan8]) {
//            UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
//            editDocumentActionSheet.tag=3;
//            self.mediaPressed=mediaObj;
//            self.indexPathPressed=rowIndexPath;
//            [editDocumentActionSheet showInView:self.view];
//        }
//        else{
//            self.mediaPressed=mediaObj;
//            self.indexPathPressed=rowIndexPath;
//            UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
//            
//            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
//            
//            UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                            {
//                                                [self editDocumentActionSheetDismissedWithIndex:0];
//                                            }];
//            
//            UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
//                                              {
//                                                  [self editDocumentActionSheetDismissedWithIndex:1];
//                                              }];
//            
//            [actionSheetController addAction:cancelAction];
//            [actionSheetController addAction:viewDocAction];
//            [actionSheetController addAction:deleteDocAction];
//            actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
//            [self presentViewController:actionSheetController animated:YES completion:nil];
//        }
//    }
}

#pragma mark IBActions

- (IBAction)bttnActionShowInfoDetail:(UITapGestureRecognizer *)sender {
    CLAboutMeInfoViewController *infoController=[[CLAboutMeInfoViewController alloc] initWithStyle:UITableViewStyleGrouped];
    infoController.info=self.aboutMe.info;
    infoController.delegate=self;
    [self.navigationController pushViewController:infoController animated:YES];
}

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    switch (sender.tag) {
        case CLAboutMeAchievementsIndex:{
            CLAboutMeAchievementsViewController *achievementController=[[CLAboutMeAchievementsViewController alloc] initWithStyle:UITableViewStylePlain];
            achievementController.isEditMode=NO;
            achievementController.achievementObj=nil;
            achievementController.delegate=self;
            UINavigationController *achievementNavigation=[[UINavigationController alloc] initWithRootViewController:achievementController];
            [self presentViewController:achievementNavigation animated:YES completion:nil];
            break;
        }
        case CLAboutMeMediaPresenceIndex:{
            CLAboutMeMediaViewController *mediaController=[[CLAboutMeMediaViewController alloc] initWithStyle:UITableViewStylePlain];
            mediaController.isEditMode=NO;
            mediaController.mediaObj=nil;
            mediaController.delegate=self;
            UINavigationController *mediaNavigation=[[UINavigationController alloc] initWithRootViewController:mediaController];
            [self presentViewController:mediaNavigation animated:YES completion:nil];
            break;
        }
        case CLAboutMeInterestsIndex:{
            CLAboutMeInterestViewController *interestController=[[CLAboutMeInterestViewController alloc] initWithStyle:UITableViewStylePlain];
            interestController.isEditMode=NO;
            interestController.interestObj=nil;
            interestController.delegate=self;
            UINavigationController *interestNavigation=[[UINavigationController alloc] initWithRootViewController:interestController];
            [self presentViewController:interestNavigation animated:YES completion:nil];
            break;
        }
            
        default:
            break;
    }
}

#pragma mark UIActionSheet Delegate

//-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
//    switch (buttonIndex) {
//        case 0:{
//            //camera..
//            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
//            {
//                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
//                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
//                imagePicker.allowsEditing = YES;
//                imagePicker.delegate = self;
//                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
//                [self presentViewController:imagePicker animated:YES completion:nil];
//            }
//            else{
//                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//            }
//            break;
//        }
//        case 1:{
//            //photos..
//            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
//                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
//                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
//                imagePicker.allowsEditing = YES;
//                imagePicker.delegate = self;
//                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//                [self presentViewController:imagePicker animated:YES completion:nil];
//            }
//            else{
//                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//            }
//            break;
//        }
//        case 2:
//            //cancel..
//            break;
//            
//        default:
//            break;
//    }
//}

-(void)addPhotoActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

//-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
//    switch (buttonIndex) {
//        case 0:{
//            //view document code..
//            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
//            documentController.documentObj=self.mediaPressed;
//            [self.navigationController pushViewController:documentController animated:YES];
//            break;
//        }
//        case 1:{
//            //delete document code..
//            [self removeDocumentAtIndexPath:self.indexPathPressed];
//            break;
//        }
//        case 2:
//            //cancel
//            break;
//            
//        default:
//            break;
//    }
//}

-(void)editPhotoActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view photo code..
            CLPhotoBrowserViewController *photoController=[[CLPhotoBrowserViewController alloc] initWithNibName:@"CLPhotoBrowserViewController" bundle:[NSBundle mainBundle]];
            photoController.photos=self.aboutMe.photos;
            photoController.startingIndex=self.indexPathPressed.row;
            UINavigationController *photoNav=[[UINavigationController alloc] initWithRootViewController:photoController];
            [self presentViewController:photoNav animated:YES completion:nil];
            break;
        }
        case 1:
            //delete photo code..
            [self removePhotoAtIndexPath:self.indexPathPressed];
            break;
        case 2:
            //set image as primary..
            [self setPrimaryPhotoAtIndexPath:self.indexPathPressed];
            break;
        case 3:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //adding new image actionsheet..
    if (actionSheet.tag==1) {
        [self addPhotoActionSheetDismissedWithIndex:buttonIndex];
    }
    
    //adding new document actionsheet..
//    else if (actionSheet.tag==4) {
//        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
//    }
    
    //delete existing image actionsheet..
    else if (actionSheet.tag==2){
        [self editPhotoActionSheetDismissedWithIndex:buttonIndex];
    }
    //delete existing document actionsheet..
//    else if (actionSheet.tag==3){
//        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
//    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
//        if (self.actionsheetPressed==CLAboutMePhotosIndex) {
//            [self addPickedImageToProfileImages:pickedImage caption:captionTxt];
//        }
//        else if(self.actionsheetPressed==CLAboutMeDocumentsIndex){
//            [self addPickedImageToDocuments:pickedImage caption:captionTxt];
//        }
//
//    }];
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    if (self.actionsheetPressed==CLAboutMePhotosIndex) {
        [self addPickedImageToProfileImages:pickedImage caption:@""];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
//    else if(self.actionsheetPressed==CLAboutMeDocumentsIndex){
//        [self addPickedImageToDocuments:pickedImage caption:@""];
//    }
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark CLAchievementConroller Delegate Methods

- (void)achievementController:(CLAboutMeAchievementsViewController *)controller didAddAchievement:(CLAchievementObject*)achievementObj{
    [self.aboutMe.achievements addObject:achievementObj];
    [self.aboutMeTable reloadSections:[NSIndexSet indexSetWithIndex:CLAboutMeAchievementsIndex] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark CLMediaConroller Delegate Methods

- (void)mediaController:(CLAboutMeMediaViewController *)controller didAddWebsite:(CLMediaPresenceObject*)mediaObj{
    [self.aboutMe.mediaPresence addObject:mediaObj];
    [self.aboutMeTable reloadSections:[NSIndexSet indexSetWithIndex:CLAboutMeMediaPresenceIndex] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark CLInterestConroller Delegate Methods

- (void)interestController:(CLAboutMeInterestViewController *)controller didAddInterest:(CLInterestObject*)interestObj{
    self.aboutMe.interest=interestObj;
    [self.aboutMeTable reloadSections:[NSIndexSet indexSetWithIndex:CLAboutMeInterestsIndex] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark CLInfoConroller Delegate Methods

- (void)infoController:(CLAboutMeInfoViewController *)controller didEditInfo:(CLInfoObject*)infoObj{
    self.aboutMe.info=infoObj;
    [self.aboutMeTable reloadData];
    [self updateTableHeaderDetails];
}


@end
