//
//  CLJobScopeViewController.m
//  CareerLine
//
//  Created by Abbin on 04/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobScopeViewController.h"
#import "CLJobScopeSelectionViewController.h"

@interface CLJobScopeViewController ()

@property(nonatomic,strong) NSMutableArray *jobScopeArray;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation CLJobScopeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedJobScopeDictArray = [[NSMutableArray alloc]initWithArray:self.selectedJobScopeDictArrayForEdit];
    self.title = NSLocalizedString(@"Job Scope", @"job scope viewcontroller title");
    self.jobScopeArray=[self arrayWithChandedKeys];
    if (self.singleSelectionOn) {
        [self setLeftNavigationButton];
    }else{
        [self setRightNavigationButton];
    }
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self.tableView setAllowsSelectionDuringEditing:YES];
    if ([self.selectedJobScopeDictArray count]>0) {
        [self.tableView setEditing:YES animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSMutableArray*)arrayWithChandedKeys{
    NSMutableArray *array = [self getLocationBasedJobScope];
    for (NSMutableDictionary *dict in array) {
        NSString *scopeId = [dict objectForKey:kCLTargetJobsJobScopeScopeIDKey];
        NSString *scopeName = [dict objectForKey:kCLTargetJobsJobScopeScopeNameKey];
        [dict removeAllObjects];
        [dict setValue:scopeId forKey:kCLTargetJobsJobScopeCodeKey];
        [dict setValue:scopeName forKey:kCLTargetJobsJobScopeKey];
    }
    return array;
}

-(NSMutableArray*)getLocationBasedJobScope{
    NSMutableArray *array = [[NSMutableArray alloc]init];
    if (self.singleSelectionOn) {
        array = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpJobScopeFromDB:[self.selectedCountry objectForKey:kCLTargetJobsJobScopeCountryCodeKey]];
        if (array.count == 0) {
            array = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpJobScopeFromDB:@"XXX"];
        }
    }
    else{
        array = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpJobScopeFromDB:@"XXX"];
    }
    return array;
}

#pragma mark UITableView

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.selectedJobScopeDictArray.count == 0) {
        return 1;
    }
    else{
        return 2;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0 && self.selectedJobScopeDictArray.count != 0) {
        return self.selectedJobScopeDictArray.count;
    }
    else if (section == 0 && self.selectedJobScopeDictArray.count == 0){
        return self.jobScopeArray.count;
    }
    else{
        return [self.jobScopeArray count];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    static NSString *cellIdentifier = @"jobScopeCell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
//        cell.textLabel.font = [UIFont systemFontOfSize:14];
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
//        cell.textLabel.font = [UIFont systemFontOfSize:13];
//    }
//    
//    if (indexPath.section == 1 && self.selectedJobScopeDictArray.count != 0) {
//        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//        cell.textLabel.text = [self getscopeNameFromDict:indexPath];
//        return cell;
//    }
//    else if (indexPath.section == 0 && self.selectedJobScopeDictArray.count == 0){
//        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//        [cell.textLabel setTextColor:[UIColor blackColor]];
//        cell.textLabel.text = [self getscopeNameFromDict:indexPath];
//        return cell;
//    }
//    else{
//        cell.accessoryType = UITableViewCellAccessoryNone;
//        [cell.textLabel setTextColor:ColorCode_CareerLineGreen];
//        cell.textLabel.text = [self getscopeNameFromDict:indexPath];
//        return cell;
//    }

    if (indexPath.section == 1 && self.selectedJobScopeDictArray.count != 0) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jobScopeCell"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"jobScopeCell"];
            cell.textLabel.font = [UIFont systemFontOfSize:13];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.textLabel.text = [self getscopeNameFromDict:indexPath];
            [cell.textLabel setTextColor:[UIColor blackColor]];
            

        }
        return cell;
        
    }
    else if (indexPath.section == 0 && self.selectedJobScopeDictArray.count == 0){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jobScopeCellTwo"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"jobScopeCellTwo"];
            cell.textLabel.font = [UIFont systemFontOfSize:13];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.textLabel.text = [self getscopeNameFromDict:indexPath];
            [cell.textLabel setTextColor:[UIColor blackColor]];
            
        }
        return cell;
    }
    else{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jobScopeCellThree"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"jobScopeCellThree"];
            cell.textLabel.font = [UIFont systemFontOfSize:13];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.textLabel.text = [self getscopeNameFromDict:indexPath];
            [cell.textLabel setTextColor:ColorCode_CareerLineGreen];
        }
        return cell;
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    if ([self selectedJobScopeDictArrayContain:[self getJobScopeDictFromArray:indexPath]]) {
//        NSLog(@"%@",self.selectedJobScopeDictArray);
//        [self removeObjectWithkeyValue:[self getJobScopeDictFromArray:indexPath]];
//    }
//    else{
//        [self.selectedJobScopeDictArray addObject:[self getJobScopeDictFromArray:indexPath]];
//    }
    if (indexPath.section == 1 && self.selectedJobScopeDictArray.count != 0) {
        CLJobScopeSelectionViewController *controller = [[CLJobScopeSelectionViewController alloc]initWithNibName:@"CLJobScopeSelectionViewController" bundle:[NSBundle mainBundle]];
        [controller setPassedOnJobScopeDict:[self.jobScopeArray objectAtIndex:indexPath.row]];
        [controller setPassedOnJobScopeArray:self.selectedJobScopeDictArray];
        controller.delegate = self.delegateTwo;
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (indexPath.section == 0 && self.selectedJobScopeDictArray.count == 0){
        CLJobScopeSelectionViewController *controller = [[CLJobScopeSelectionViewController alloc]initWithNibName:@"CLJobScopeSelectionViewController" bundle:[NSBundle mainBundle]];
        if (self.singleSelectionOn) {
            [controller setPassedOnDict:self.selectedJobScopeDictDictForEdit];
            controller.singleSelectionOn = self.singleSelectionOn;
        }
        else{
            
            [controller setPassedOnJobScopeArray:self.selectedJobScopeDictArray];
            
        }
        [controller setPassedOnJobScopeDict:[self.jobScopeArray objectAtIndex:indexPath.row]];
        controller.delegate = self.delegateTwo;
        [self.navigationController pushViewController:controller animated:YES];
        
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0 && self.selectedJobScopeDictArray.count != 0) {
        return NSLocalizedString(@"Edit Job Scope", @"section title");
    }
    else{
        return NSLocalizedString(@"Add Job Scope", @"section title");
    }
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if([self.selectedJobScopeDictArray count]>0){
        if(indexPath.section==0){
            return YES;
        }
        else{
            return NO;
        }
    }
    else{
        return NO;
    }
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
        [self.selectedJobScopeDictArray removeObjectAtIndex:indexPath.row];
        if(indexPath.row==0 && [self.selectedJobScopeDictArray count]==0){
            [self.tableView setEditing:NO animated:NO];
            [self.tableView reloadData];
        }
        else{
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
          //  [self viewDidLoad];
          //  [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationAutomatic];
        }

    }
}


//-(void)removeObjectWithkeyValue:(NSMutableDictionary*)dictionary{
//    NSString *string = [dictionary objectForKey:@"code"];
//    for (int i = 0; i < [self.selectedJobScopeDictArray count]; i++) {
//        NSString *stringTwo = [[self.selectedJobScopeDictArray objectAtIndex:i] objectForKey:@"code"];
//        if ([stringTwo isEqualToString:string]) {
//            [self.selectedJobScopeDictArray removeObjectAtIndex:i];
//        }
//    }
//}


#pragma mark IBActions

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)bttnActionSaveJobscopesAndDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^(){
        if([_delegate respondsToSelector:@selector(loadSelectedJobScope:)])
        {
            [_delegate loadSelectedJobScope:_selectedJobScopeDictArray];
        }
    }];
}




#pragma mark Utility methods

//-(BOOL)selectedJobScopeDictArrayContain:(NSMutableDictionary*)dictionary{
//    BOOL doesIt = NO;
//    for (NSMutableDictionary *dict in _selectedJobScopeDictArray) {
//        NSString *string=[dict objectForKey:kJobPreferenceJobScopeIdKey];
//        if ([string isEqualToString:[dictionary objectForKey:kJobPreferenceJobScopeIdKey]]) {
//            doesIt = YES;
//        }
//    }
//    return doesIt;
//}

-(NSMutableDictionary*)getJobScopeDictFromArray:(NSIndexPath *)indexPath{
    NSMutableDictionary *jobDict = [[NSMutableDictionary alloc]initWithDictionary:[self.jobScopeArray objectAtIndex:indexPath.row]];
    return jobDict;
}

-(NSString*)getscopeNameFromDict:(NSIndexPath*)indexPath{
    if (indexPath.section == 0 && self.selectedJobScopeDictArray.count != 0) {
        NSMutableDictionary *jobDict = [[NSMutableDictionary alloc]initWithDictionary:[self.selectedJobScopeDictArray objectAtIndex:indexPath.row]];
        NSString *string = nil;
        if ([jobDict objectForKey:kCLTargetJobsJobScopeGroupNameKey]) {
            string = [NSString stringWithFormat:@"%@ (%@)",[jobDict objectForKey:kCLTargetJobsJobScopeGroupNameKey],[jobDict objectForKey:kCLTargetJobsJobScopeKey]];
        }
        else{
            string = [jobDict objectForKey:kJobPreferenceJobScopeNameKey];
        }
        
        return string;
    }
    else if (indexPath.section == 0 && self.selectedJobScopeDictArray.count == 0){
        NSMutableDictionary *jobDict = [[NSMutableDictionary alloc]initWithDictionary:[self.jobScopeArray objectAtIndex:indexPath.row]];
        NSString *string = [jobDict objectForKey:kJobPreferenceJobScopeNameKey];
        return string;
    }
    else{
        NSMutableDictionary *jobDict = [[NSMutableDictionary alloc]initWithDictionary:[self.jobScopeArray objectAtIndex:indexPath.row]];
        NSString *string = [jobDict objectForKey:kJobPreferenceJobScopeNameKey];
        return string;
    }
    
}


-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Job Scope modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(void)setRightNavigationButton{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Job Scope modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveJobscopesAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
}


@end
