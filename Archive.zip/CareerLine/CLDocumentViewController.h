//
//  CLDocumentViewController.h
//  CareerLine
//
//  Created by CSG on 7/22/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLFileObject.h"
#import "CLDocsObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"


@interface CLDocumentViewController : UIViewController<UIWebViewDelegate,NSURLConnectionDelegate,UITextFieldDelegate,HTProgressHUDDelegate>

@property(nonatomic,strong)CLFileObject *documentObj;
@property(nonatomic,retain) CLDocsObject *docObj;
@property(nonatomic,assign) BOOL disableCaption;

@property(nonatomic,strong) NSURL *documentURL;
@property(nonatomic) BOOL fromDocument;

@end
