//
//  CLInfoObject.h
//  CareerLine
//
//  Created by CSG on 7/25/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLLocationObject.h"
#import "CLTelephoneObject.h"
#import "CLPreviousNameObject.h"
#import "CLFileObject.h"

@interface CLInfoObject : NSObject

@property(nonatomic,retain)NSMutableDictionary *country;
@property(nonatomic,strong)NSString *infoId;
@property(nonatomic,strong)NSString *firstName;
@property(nonatomic,strong)NSString *middleName;
@property(nonatomic,strong)NSString *lastName;
@property(nonatomic,strong)NSString *formattedName;
@property(nonatomic,strong)NSString *nickname;
@property(nonatomic,strong)NSMutableArray *previousname;    //[(Dict(id,name)),(Dict(id,name)),..]
@property(nonatomic,strong)NSString *skypeName;
@property(nonatomic,strong)CLTelephoneObject *homeNumber;
@property(nonatomic,strong)CLTelephoneObject *mobileNumber;
//@property(nonatomic,strong)NSMutableArray *telephoneNumbers;    //[(CLTelephoneObject),(CLTelephoneObject),..]
@property(nonatomic,strong)NSString *email;
@property(nonatomic,strong)NSString *alternateEmail;
@property(nonatomic,strong)NSDate *dob;
@property(nonatomic,strong)CLFileObject *profileImage;

@property(nonatomic,strong)NSDictionary *salutation;

@property(nonatomic,strong)NSDictionary *gender;

@property(nonatomic,strong)NSMutableArray *nationalities;   //[(Dict),(Dict),..]

@property(nonatomic,strong)CLLocationObject *currentLocation;

@property(nonatomic,strong)NSMutableArray *otherAddresses;  //[(CLLocationObject),(CLLocationObject),..]


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

-(void)updateFormattedName;

//Method for saving info of a particular user...
+ (void)saveInfo:(CLInfoObject *)infoObj forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading primary image for a particular user...
+ (void)uploadPrimaryImage:(UIImage*)image forUser:(NSString *)userId imageId:(NSString*)imageId success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

@end
