//
//  CLInboxQuestionnaireViewController.m
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxQuestionnaireViewController.h"
#import "CLInboxDetailTableViewController.h"
#import "CLQuestionnaireObject.h"
#import "CLQuestionnaireCell.h"
#import "CLInboxObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLInboxQuestionnaireViewController ()

@property (weak, nonatomic) IBOutlet UIButton *bttnSaveDraft;
@property(nonatomic,strong)NSMutableDictionary *ansFieldHeightDict;
@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
- (IBAction)bttnActionSaveDraft:(id)sender;
@end

@implementation CLInboxQuestionnaireViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=NSLocalizedString(@"Questionnaire", @"Questionnaire page title");
    [self setUpTableViewController];
    [self setRightNavigationButton];
    
    //Save draft button is placed as headerview if questionnaire not submitted..
    if (!self.isSubmitted) {
        self.tableView.tableHeaderView=self.tblHeaderView;
    }
}

-(void)viewDidAppear:(BOOL)animated{
    //answer cell height change notifier..
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(answerFieldHeightChangeNotifReceived:) name:kCLNotifCenterQuestionnaireCellHeightChange object:nil];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterQuestionnaireCellHeightChange object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark NSNotification Methods

-(void)answerFieldHeightChangeNotifReceived:(NSNotification*) notification{
    CLQuestionnaireCell *cell=notification.object;
    NSIndexPath *indexPath=[self.tableView indexPathForCell:cell];
    [self.ansFieldHeightDict setObject:[cell getAnsTextViewHeight] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark Utility Methods

-(void)setUpTableViewController{
    self.clearsSelectionOnViewWillAppear = YES;
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    [self.tableView registerClass:[CLQuestionnaireCell class] forCellReuseIdentifier:@"questionnnaireCellIdentifier"];
    self.ansFieldHeightDict=[[NSMutableDictionary alloc] init];
}

-(void)setRightNavigationButton{
    if (self.isSubmitted) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Submitted", @"Text for questionnaire submit button after submission") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSubmitQuestionnaire:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
        self.navigationItem.rightBarButtonItem.enabled=NO;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Submit", @"Text for questionnaire submit button before submission") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSubmitQuestionnaire:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:13];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(280, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(NSString*)createJsonStringForWebService{
    NSMutableArray *quesArray=[[NSMutableArray alloc] init];
    for (int i=0; i<[self.questionnaire count]; i++) {
        CLQuestionnaireObject *quesObj=[self.questionnaire objectAtIndex:i];
        if (quesObj.answer==nil) {
            quesObj.answer=@"";
        }
        NSDictionary *dict=[[NSDictionary alloc] initWithObjectsAndKeys:quesObj.questionionnaireId,kCLInboxDetailQuestionnaireIdkey,quesObj.answer,kCLInboxDetailQuestionnaireAnskey, nil];
        [quesArray addObject:dict];
    }
    
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:[NSMutableDictionary dictionaryWithObject:quesArray forKey:@"Quest"]];
}

-(void)submitQuestionnaireViaWebService:(NSString*)toggleStatus{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    if ([toggleStatus isEqualToString:@"0"]) {
        progressHUD.text=NSLocalizedString(@"Submitting...", @"Text displayed in the loading indicator while submitting questionnaire");
        [progressHUD showInView:self.navigationController.view animated:YES];
    }
    else{
        self.bttnSaveDraft.enabled=NO;
    }
    
    [CLQuestionnaireObject submitQuestionnaireforInboxId:self.inboxId withQuestionnaire:[self createJsonStringForWebService] submitStatus:toggleStatus
                                                 success:^(){
                                                     if([[self.navigationController visibleViewController] isKindOfClass:[self class]]){
                                                         if ([toggleStatus isEqualToString:@"0"]) {
                                                             [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Submitted", @"loading indicator questiionnaire submitted success text") AFterDelay:1 andStatus:toggleStatus];
                                                         }
                                                         else{
                                                             self.bttnSaveDraft.enabled=YES;
                                                         }
                                                     }
                                                 }
                                                 failure:^(NSString *error){
                                                     if (![error isEqualToString:@""]) {
                                                         if([[self.navigationController visibleViewController] isKindOfClass:[self class]]){
                                                             [progressHUD hideWithAnimation:YES];
                                                             self.bttnSaveDraft.enabled=YES;
                                                         }
                                                         if ([toggleStatus isEqualToString:@"0"]) {
                                                         [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"alert title") alertString:NSLocalizedString(@"Couldn't submit questionnaire. Please try again later.", @"Error message when questionnaire cannot be submitted") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                                         }
                                                         else{
                                                             [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"alert title") alertString:NSLocalizedString(@"Couldn't save questionnaire. Please try again later.", @"Error message when questionnaire cannot be submitted") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                                         }
                                                     }
                                                 }
     ];
}

-(BOOL)isFieldsValid{
    for (int i=0; i<[self.questionnaire count]; i++) {
        CLQuestionnaireObject *quesObj=[self.questionnaire objectAtIndex:i];
        if (quesObj.answer==nil || [quesObj.answer isEqualToString:@""]) {
            return NO;
        }
    }
    return YES;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds andStatus:(NSString*)status{
    if ([status isEqualToString:@"0"]) {
        hud.delegate=self;
    }
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

#pragma mark IBAction

-(void)bttnActionSubmitQuestionnaire:(id)sender{
    if ([self isFieldsValid]) {			
        [self submitQuestionnaireViaWebService:@"0"];
    }
    else{
        if([CLCommon isOSversionLessThan8])
        {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Warning", @"alert title warning") message:NSLocalizedString(@"Certain questions are not answered. Do you want to continue?", @"unanswered questions alert message") delegate:self cancelButtonTitle:NSLocalizedString(@"Yes", @"Yes") otherButtonTitles:NSLocalizedString(@"No", @"No"), nil];
        [alert show];
        }else{
            // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
            UIAlertController *alert = [UIAlertController alertControllerWithTitle: NSLocalizedString(@"Warning", @"alert title warning")
                                                                           message: NSLocalizedString(@"Certain questions are not answered. Do you want to continue?", @"unanswered questions alert message")
                                                                    preferredStyle: UIAlertControllerStyleAlert];
            
            UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Yes", @"Yes") style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * action){
                                                                 //Do Some action here
                                                             [self submitQuestionnaireViaWebService:@"0"];
                                                             }];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"No", @"No")
                                                                   style: UIAlertActionStyleDefault
                                                                 handler: nil];
            
            [alert addAction: cancelAction];
            [alert addAction: okAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
}

- (IBAction)bttnActionSaveDraft:(id)sender {
    [self submitQuestionnaireViaWebService:@"1"];
}

#pragma mark UIAlertView Delegate Method

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==0) {
        //Yes clicked submit questionnaire
        [self submitQuestionnaireViaWebService:@"0"];
    }
    else if(buttonIndex==1){
        //No clicked do nothing
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.questionnaire count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CLQuestionnaireCell *cell = (CLQuestionnaireCell *)[self.tableView dequeueReusableCellWithIdentifier:@"questionnnaireCellIdentifier"];
    cell.quesObj=[self.questionnaire objectAtIndex:indexPath.row];
    if([self.ansFieldHeightDict objectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]]==nil){
        [self.ansFieldHeightDict setObject:[NSNumber numberWithFloat:kintialTextViewHeight] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
    }
    [cell updateCellContent:self.isSubmitted];
    return cell;
}


#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat quesHeight;
    CGFloat ansHeight;
    CGFloat indentHeight;
    
    CLQuestionnaireObject *quesObj=(CLQuestionnaireObject*)[self.questionnaire objectAtIndex:indexPath.row];
    
    if (self.isSubmitted) {
        if (quesObj.rating!=CLQuestionnaireSmileyRatingNone) {
            indentHeight=51;
        }
        else{
            indentHeight=21;
        }
    }
    else{
        indentHeight=21;
    }
    
    CLQuestionnaireObject *questObj=((CLQuestionnaireObject*)[self.questionnaire objectAtIndex:indexPath.row]);
    
    NSString *quesText=questObj.question;
    CGRect expectedQuestextFrame = [quesText boundingRectWithSize:CGSizeMake(270, FLT_MAX)
                                                          options:NSStringDrawingUsesLineFragmentOrigin
                                                       attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                   [UIFont systemFontOfSize:13], NSFontAttributeName,
                                                                   nil]
                                                          context:nil];
    quesHeight=expectedQuestextFrame.size.height;
    
    NSNumber *height=[self.ansFieldHeightDict objectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
    if((height!=nil) && ([height floatValue]>kintialTextViewHeight)){
        ansHeight= [height floatValue];
    }
    else{
        ansHeight= [self getTextViewSizeForText:questObj.answer];
    }
    CGFloat totalHeight=quesHeight+ansHeight+indentHeight;
    
    return MAX(76, totalHeight);
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if([[[self.navigationController viewControllers] objectAtIndex:[[self.navigationController viewControllers] count]-2] isKindOfClass:[CLInboxDetailTableViewController class]]){
        CLInboxDetailTableViewController *inboxDetail=(CLInboxDetailTableViewController*) [[self.navigationController viewControllers] objectAtIndex:[[self.navigationController viewControllers] count]-2];
        inboxDetail.inbox.isQuestionnaireSubmitted=YES;
        inboxDetail.inbox.questionnaireDueDate=NSLocalizedString(@"Just Now", @"questionnaire posted just now text");
        inboxDetail.isFromQuestionnaireSubmission=YES;
        [self.navigationController popViewControllerAnimated:YES];
    }
}

@end
