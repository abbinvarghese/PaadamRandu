//
//  CLItemObject.h
//  CareerLine
//
//  Created by Pravin on 10/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLItemObject : NSObject

@property(nonatomic,strong)NSString *itemId;
@property(nonatomic,strong)NSString *itemTitle;
@property(nonatomic,strong)NSMutableArray *documents;       //[(CLFileObject),(CLFileObject),...]
@property(nonatomic,strong)NSString *itemRemarks;


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//Method for saving item of a particular user...
+ (void)saveItem:(CLItemObject*)itemObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *itemId))success failure:(void (^)(NSString *error))failure;

//Method for deleting item for a particular user...
+ (void)deleteItem:(NSString*)itemId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading item document for a particular user...
+ (void)addDocument:(UIImage*)image forItem:(NSString*)itemId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting item document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
