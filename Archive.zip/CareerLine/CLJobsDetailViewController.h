//
//  CLJobsDetailViewController.h
//  CareerLine
//
//  Created by CSG on 1/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "CLJobsObject.h"

@interface CLJobsDetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MFMailComposeViewControllerDelegate,UIActionSheetDelegate>

//Job details status from webservice..
typedef enum {
    CLJobStatusNone = 0,
    CLJobStatusApplied= 1,
    CLJobStatusRejected = 2
} CLJobDetailsStatus;

//Job details object...
@property(nonatomic,strong)CLJobsObject *job;

//To determine whether from push notifs..
@property(nonatomic,assign)BOOL isFromPushNotifications;

@end
