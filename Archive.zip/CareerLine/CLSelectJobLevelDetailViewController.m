//
//  CLSelectJobLevelDetailViewController.m
//  CareerLine
//
//  Created by CSG on 2/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectJobLevelDetailViewController.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLSelectJobLevelDetailViewController ()

@property(nonatomic,strong)NSMutableArray *jobLevelArray;
@property(nonatomic,strong)NSMutableDictionary *selectedJobLevel;


@end

@implementation CLSelectJobLevelDetailViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.selectedCareerLevelGroupArray = [[NSMutableArray alloc]initWithArray:self.SecondselectedCareerLevelGroupArray];
    
//    if ([self.SecondselectedCareerLevelGroupArray count] != 0) {
//        self.selectedCareerLevelGroupArray = self.SecondselectedCareerLevelGroupArray;
//    }
    self.title=[self.selectedJobLevelGroupDict objectForKey:kjobLevelGroupDictName];
    if (self.multipleSelectionOn) {
        [self setRightNavigationButton];
    }
    //self.navigationItem.rightBarButtonItem.enabled=NO;
    self.jobLevelArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobLevelDetailForJobGroup:self.selectedJobLevelGroupDict];
    if (self.selectedCareerlevelDict) {
        self.selectedJobLevel = self.selectedCareerlevelDict;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark IBaction

-(void)bttnActionSelectionDone:(id)sender{
    if (self.multipleSelectionOn) {
        [self dismissViewControllerAnimated:YES completion:^(){
            if([_delegate respondsToSelector:@selector(transferSelectedDictionariesArray:withDictonary:)])
            {
                [_delegate transferSelectedDictionariesArray:self withDictonary:_selectedCareerLevelGroupArray];
                
            }
        }];
        
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(void){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectJobLevelControllerDidSelectJobLevel:withDictonary:)]){
                [self.selectedJobLevel setObject:[self.selectedJobLevelGroupDict objectForKey:kjobLevelGroupDictCode] forKey:kjobLevelGroupDictCode];
                [self.selectedJobLevel setObject:[self.selectedJobLevelGroupDict objectForKey:kjobLevelGroupDictName] forKey:kjobLevelGroupDictName];
                [self.delegate selectJobLevelControllerDidSelectJobLevel:self withDictonary:self.selectedJobLevel];
            }
        }];
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.jobLevelArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    
    if (self.multipleSelectionOn) {
        if ([self selectedCareerLevelGroupArrayContain:[self.jobLevelArray objectAtIndex:indexPath.row]]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            cell.accessoryView = nil;
        }
        else{
            UIView *paintView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 10)];
            cell.accessoryView = paintView;
            cell.accessoryType=UITableViewCellAccessoryNone;
        }

    }
    else{
        if ([self isSelectedJobLevelEqualTo:[self.jobLevelArray objectAtIndex:indexPath.row]]) {
            cell.accessoryType=UITableViewCellAccessoryCheckmark;
        }
        else{
            cell.accessoryType=UITableViewCellAccessoryNone;
        }
    }
    
    NSMutableDictionary *jobLevel=[self.jobLevelArray objectAtIndex:indexPath.row];
    cell.textLabel.text=[jobLevel objectForKey:jobLevelDetailDictName];
    
    return cell;
}

-(BOOL)isSelectedJobLevelEqualTo:(NSMutableDictionary*)dictionary{
    BOOL isIt = NO;
    if ([[dictionary objectForKey:kCLCareerHistoryJobLevelCodekey] isEqualToString:[self.selectedJobLevel objectForKey:kCLCareerHistoryJobLevelCodekey]]) {
        isIt = YES;
    }
    return isIt;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.multipleSelectionOn) {
        
        if ([self selectedCareerLevelGroupArrayContain:[self.jobLevelArray objectAtIndex:indexPath.row]]) {
            [self removeGroupCodeFromDictionary:[self.jobLevelArray objectAtIndex:indexPath.row]];
        }
        
        else{
            [self addGroupCodeToDictionary:[self.jobLevelArray objectAtIndex:indexPath.row]];
        }
        
        [tableView reloadData];
        
    }
    else{
        self.navigationItem.rightBarButtonItem.enabled=YES;
        self.selectedJobLevel=[self.jobLevelArray objectAtIndex:indexPath.row];
        [self.tableView reloadData];
        [self bttnActionSelectionDone:nil];
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return NSLocalizedString(@"Which one best describes your job?", @"Title for job level");
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setFont:kSectionHeaderFont];
}

-(void)addGroupCodeToDictionary:(NSMutableDictionary*)dictionary{
 //   [dictionary setObject:[self.selectedJobLevelGroupDict objectForKey:kjobLevelGroupDictCode] forKey:kjobLevelGroupDictCode];
    [self.selectedCareerLevelGroupArray addObject:dictionary];
}

-(void)removeGroupCodeFromDictionary:(NSMutableDictionary*)dictionary{
//    [dictionary removeObjectForKey:kjobLevelGroupDictCode];
    [self removeDictionaryFromArray:dictionary];
}

-(void)removeDictionaryFromArray:(NSMutableDictionary*)dictionary{
    for (int i = 0; i<[_selectedCareerLevelGroupArray count]; i++) {
        NSMutableDictionary *dict = [_selectedCareerLevelGroupArray objectAtIndex:i];
        NSString *string = [dictionary objectForKey:jobLevelDetailDictCode];
        if ([string isEqualToString:[dict objectForKey:jobLevelDetailDictCode]]) {
            [_selectedCareerLevelGroupArray removeObjectAtIndex:i];
        }
    }
}

-(BOOL)selectedCareerLevelGroupArrayContain:(NSMutableDictionary*)dictionary{
    BOOL doesIt = NO;
    for (NSMutableDictionary *dict in _selectedCareerLevelGroupArray) {
        NSString *string = [dict objectForKey:jobLevelDetailDictCode];
        if ([string isEqualToString:[dictionary objectForKey:jobLevelDetailDictCode]]) {
            doesIt = YES;
        }
    }
    return doesIt;
}






@end
