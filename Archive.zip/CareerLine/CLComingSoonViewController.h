//
//  CLComingSoonViewController.h
//  CareerLine
//
//  Created by CSG on 6/24/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLComingSoonViewController : UIViewController

@end
