//
//  CLReviewObject.h
//  CareerLine
//
//  Created by Pravin on 10/13/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLReviewObject : NSObject

@property(nonatomic,strong)NSString *referenceId;
@property(nonatomic,strong)NSString *refferedBy;
@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSString *jobTitle;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *Company;
@property(nonatomic,strong)NSString *testimonials;
@property(nonatomic,strong)NSMutableArray *documents;    //[(CLFileObject),(CLFileObject),...]

//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for deleting reference for a particular user...
+ (void)deleteReference:(NSString*)referenceId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for saving reference of a particular user...
+ (void)saveReference:(NSString*)referenceId forUser:(NSString*)userId refferedBy:(NSString*)name date:(NSDate *)date jobTitle:(NSString *)job company:(NSString *)companyName testimonials:(NSString*)testimonials editMode:(BOOL)isEditMode success:(void (^)(NSString *referenceId))success failure:(void (^)(NSString *error))failure;

//Method for uploading reference document for a particular user...
+ (void)addDocument:(UIImage*)image forReference:(NSString*)referenceId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting reference document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
