//
//  CLEmployeementDetailsViewController.h
//  CareerLine
//
//  Created by RENJITH on 05/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLEmployeementTypeDetailsViewController;

//Delegate Methods...
@protocol CLSelectEmpTypeDelegate <NSObject>

@required
- (void)selectEmployeementType:(CLEmployeementTypeDetailsViewController*)controller withDictonary:(NSMutableDictionary *)selectedEmpTypeDict;

@end

@interface CLEmployeementTypeDetailsViewController : UITableViewController

@property(nonatomic,weak) id <CLSelectEmpTypeDelegate> delegate;
@property(nonatomic,strong)NSDictionary *selectedEmpTypeGroupDict;
@end
