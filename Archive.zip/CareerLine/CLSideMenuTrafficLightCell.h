//
//  CLSideMenuTrafficLightCell.h
//  CareerLine
//
//  Created by CSG on 3/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSideMenuTrafficLightCell : UITableViewCell

//To setup the cell according to the current status and selected menu..
-(void)setupCell:(NSIndexPath*)indexPath forLightStatus:(CLTrafficLightStatus)status selectedIndex:(int)selectedIndexPathRow;

@end
