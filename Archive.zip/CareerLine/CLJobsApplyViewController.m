//
//  CLJobsApplyViewController.m
//  CareerLine
//
//  Created by CSG on 1/28/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsApplyViewController.h"
#import "UIImageView+WebCache.h"
#import "CLJobsApplyTextCell.h"
#import "CLJobsApplyRatingCell.h"
#import "CLUserObject.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLJobsDetailViewController.h"

#define kintialTextViewHeight 44
#define kSectionHeaderFont [UIFont systemFontOfSize:14]
#define kSectionHeaderBgColor [UIColor whiteColor]

@interface CLJobsApplyViewController ()

@property (strong, nonatomic) IBOutlet UIView *tblHeaderView;
//@property (weak, nonatomic) IBOutlet UIImageView *jobImageView;
@property (weak, nonatomic) IBOutlet UILabel *jobPostedTime;
@property (weak, nonatomic) IBOutlet UILabel *lblJobTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblJobCompany;
@property (weak, nonatomic) IBOutlet UILabel *lblJobLocation;

@property (nonatomic,strong) NSMutableDictionary *commentBoxHeightDict;

@end

@implementation CLJobsApplyViewController
@synthesize commentBoxHeightDict;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=self.job.jobTitle;
    self.tableView.tableHeaderView=self.tblHeaderView;
    [self setRightNavigationButton];
    [self updateTableHeaderDetails];
    
    [self.tableView registerClass:[CLJobsApplyTextCell class] forCellReuseIdentifier:@"jobsApplyTextCellIdentifier"];
    [self.tableView registerClass:[CLJobsApplyRatingCell class] forCellReuseIdentifier:@"jobsApplyRatingCellIdentifier"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(commentFieldHeightChangeNotifReceived:) name:kCLNotifCenterJobsApplyCellHeightChange object:nil];
    
    commentBoxHeightDict=[[NSMutableDictionary alloc] init];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
}

-(void)viewDidAppear:(BOOL)animated{
    self.navigationController.toolbarHidden=YES;
}

-(void)viewDidUnload{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterJobsApplyCellHeightChange object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark NSNotification Methods

-(void)commentFieldHeightChangeNotifReceived:(NSNotification*) notification{
    CLJobsApplyTextCell *cell=notification.object;
    NSIndexPath *indexPath=[self.tableView indexPathForCell:cell];
    [self.commentBoxHeightDict setObject:[cell getEstimatedTextViewHeight] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
    
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Apply", @"Text for job apply button before applied") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionApplyJob:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)updateTableHeaderDetails{
    self.jobPostedTime.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.lblJobCompany.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.jobPostedTime.text=self.job.jobReceivedDate;
    self.lblJobTitle.text=self.job.jobTitle;
    self.lblJobCompany.text=self.job.companyDetails.companyName;
    self.lblJobLocation.text=[NSString stringWithFormat:@"%@, %@",self.job.jobLoc,self.job.jobCountry];
//    [self.jobImageView setImageWithURL:[NSURL URLWithString:[self.job.jobIconUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:@"company_placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//        if (image && cacheType == SDImageCacheTypeNone)
//        {
//            self.jobImageView.alpha = 0.0;
//            [UIView animateWithDuration:1.0
//                             animations:^{
//                                 self.jobImageView.alpha = 1.0;
//                             }];
//        }
//    }];
}

-(NSString*)getTitleForSection:(NSInteger)section{
    if (section==0) {
        return NSLocalizedString(@"How close does this job match my career goals?", @"The text for 1st option when applying for a job");
    }
    else if(section==1){
        return NSLocalizedString(@"How interested am I in working for this company?", @"The text for 2nd option when applying for a job");
    }
    else{
        return nil;
    }
}

-(CGSize)getLabelSizeforText:(NSString *)text withFont:(UIFont*)font {
    CGSize maximumLabelSize = CGSizeMake(self.tableView.frame.size.width-20, FLT_MAX);
    CGRect textRect = [text boundingRectWithSize:maximumLabelSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil];
    return textRect.size;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

#pragma mark IBActions

-(void)bttnActionApplyJob:(id)sender{
    //Creating a dictionary for webservice json..
    NSMutableDictionary *qaDict=[[NSMutableDictionary alloc] init];
    BOOL isValid=YES;
    for (int section=0; section<2; section++) {
        for (int row=0; row<2; row++) {
            if (row==0) {
                CLJobsApplyRatingCell *ratingCell=(CLJobsApplyRatingCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:section]];
                CLJobSmileyRating rating=[ratingCell getSelectedRating];
                [qaDict setObject:[NSNumber numberWithInt:rating] forKey:[NSString stringWithFormat:@"rating%d",section]];
                if (rating==CLJobSmileyRatingNone) {
                    isValid=NO;
                }
            }
            else if (row==1){
                CLJobsApplyTextCell *commentCell=(CLJobsApplyTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:section]];
                NSString *comment=[commentCell getCommentText];
                [qaDict setObject:comment forKey:[NSString stringWithFormat:@"comment%d",section]];
            }
        }
    }
    
    //Validating and webservice called..
    if(isValid){
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
         progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
         progressHUD.text=NSLocalizedString(@"Applying...", @"Text displayed in the loading indicator while loading jobs");
        progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
        progressHUD.hudView.alpha=0.9;
        [progressHUD showInView:self.view animated:YES];
        
        self.navigationItem.hidesBackButton=YES;
        self.navigationItem.rightBarButtonItem.enabled=NO;
        [CLJobsObject acceptJobForJobId:self.job.jobID withUserId:[CLUserObject currentUser].userID toggleStatus:@"1" surveyDetails:qaDict
                                success:^(NSString *jobID){
                                    self.navigationItem.hidesBackButton=NO;
                                    if([[self.navigationController visibleViewController] isKindOfClass:[self class]] && [self.job.jobID isEqualToString:jobID]){
                                        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Applied", @"loading indicator job applied success text") AFterDelay:1];
                                    }
                                }
                                failure:^(NSString *jobID,NSString *error){
                                    self.navigationItem.hidesBackButton=NO;
                                    if (![error isEqualToString:@""]) {
                                        if([[self.navigationController visibleViewController] isKindOfClass:[self class]] && [self.job.jobID isEqualToString:jobID]){
                                            self.navigationItem.rightBarButtonItem.enabled=YES;
                                            [progressHUD hideWithAnimation:YES];
                                        }
                                        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't apply job. Please try again later.", @"Error message when job cannot be applied") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                    }
                                }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please rate the job suggestion to apply.", @"Error message shown when job applied without rating") cancelbuttonName:NSLocalizedString(@"OK", @"Alert ok button text")];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row==0){
        CLJobsApplyRatingCell *ratingCell = (CLJobsApplyRatingCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobsApplyRatingCellIdentifier"];
        //[ratingCell setUpCell];
        return ratingCell;
    }
    else{
        CLJobsApplyTextCell *textCell = (CLJobsApplyTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobsApplyTextCellIdentifier"];
        [textCell setUpCell];
        if([self.commentBoxHeightDict objectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]]==nil){
            [self.commentBoxHeightDict setObject:[NSNumber numberWithFloat:kintialTextViewHeight] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
        }
        return textCell;
    }
}

#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row==0){
        return 62;
    }
    else if(indexPath.row==1){
        NSNumber *height=[self.commentBoxHeightDict objectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
        if((height!=nil)||([height floatValue]>kintialTextViewHeight)){
            return [height floatValue];
        }
        else{
            return kintialTextViewHeight;
        }
    }
    else{
        return kintialTextViewHeight;
    }
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    NSString *title=[self getTitleForSection:section];
    CGSize labelSize=[self getLabelSizeforText:title withFont:kSectionHeaderFont];
    
    UIImageView *sectionHeader=[[UIImageView alloc] initWithFrame:CGRectZero];
    sectionHeader.backgroundColor=kSectionHeaderBgColor;
    sectionHeader.alpha=0.95;
    
    UILabel *label=[[UILabel alloc] initWithFrame:CGRectMake(10, 2, labelSize.width, labelSize.height)];
    label.numberOfLines=0;
    label.translatesAutoresizingMaskIntoConstraints=NO;
    label.font=kSectionHeaderFont;
    label.lineBreakMode=NSLineBreakByWordWrapping;
    label.text=title;
    
    [sectionHeader addSubview:label];
    
    NSDictionary *viewsDictionary = NSDictionaryOfVariableBindings (label);
    NSString *visualFormat = @"H:|-10-[label]-10-|";
    NSArray *horizontalConstraints = [NSLayoutConstraint
                                      constraintsWithVisualFormat: visualFormat
                                      options: 0
                                      metrics: nil
                                      views: viewsDictionary];
    visualFormat = @"V:|-2-[label]-2-|";
    NSArray *verticalConstraints = [NSLayoutConstraint
                                    constraintsWithVisualFormat: visualFormat
                                    options: 0
                                    metrics: nil
                                    views: viewsDictionary];
    [sectionHeader addConstraints:horizontalConstraints];
    [sectionHeader addConstraints:verticalConstraints];
    
    return sectionHeader;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    CGSize labelSize=[self getLabelSizeforText:[self getTitleForSection:section] withFont:kSectionHeaderFont];
    return labelSize.height+20;
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if([[[self.navigationController viewControllers] objectAtIndex:[[self.navigationController viewControllers] count]-2] isKindOfClass:[CLJobsDetailViewController class]]){
        CLJobsDetailViewController *jobsDetail=(CLJobsDetailViewController*) [[self.navigationController viewControllers] objectAtIndex:[[self.navigationController viewControllers] count]-2];
        jobsDetail.job.jobAppliedStatus=CLJobStatusApplied;
        [self.navigationController popViewControllerAnimated:YES];
    }
}


@end
