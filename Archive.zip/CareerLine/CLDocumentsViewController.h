//
//  CLDocumentsViewController.h
//  CareerLine
//
//  Created by RENJITH on 11/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCollectionViewMasonryLayout.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLDocumentsViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout, CLCollectionViewDelegateMasonryLayout,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,HTProgressHUDDelegate>


-(void)clearArraysAndReloadTable;
@end
