//
//  CLLoaderImageVIew.m
//  CareerLine
//
//  Created by CSG on 8/28/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLoaderImageVIew.h"
#import "UIImageView+WebCache.h"
#import "SDWebImageDownloader.h"

@interface CLLoaderImageVIew ()

@property(nonatomic,strong)UIActivityIndicatorView *activityView;
@property(nonatomic,strong)NSString *placeHolderImageName;
@end

@implementation CLLoaderImageVIew

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //code..
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)inCoder{
    self = [super initWithCoder:inCoder];
    if (self) {
        // Initialization code
        
        if (self.activityView==nil) {
            self.placeHolderImageName=@"user_placeholder";
            self.activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];

            //[self.activityView setCenter:CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2)];
            [self.activityView setHidesWhenStopped:YES];
            [self addSubview:self.activityView];
        }
        self.image=[UIImage imageNamed:self.placeHolderImageName];
    }
    return self;
}

-(void)setImageWithUrlString:(NSString *)url andPlaceHolderName:(NSString*)placeHolderName{
    self.placeHolderImageName=placeHolderName;
    [self setImageWithUrlString:url];
    
}

-(void)setImageWithUrlString:(NSString *)url{
    self.image=[UIImage imageNamed:self.placeHolderImageName];
    
    float xPos = (self.frame.size.width/2) - (self.activityView.frame.size.width/2);
    float yPos = (self.frame.size.height/2) - (self.activityView.frame.size.height/2);
    self.activityView.frame = CGRectMake(xPos, yPos, self.activityView.frame.size.width, self.activityView.frame.size.height);

    [self.activityView setColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.activityView startAnimating];
    
//    [[SDWebImageManager sharedManager] downloadWithURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] options:SDWebImageRetryFailed progress:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished) {
//        [self.activityView stopAnimating];
//        if (!error) {
//            if (image) {
//                self.image=image;
//                if (cacheType == SDImageCacheTypeNone) {
//                    self.alpha=0.0;
//                    [UIView animateWithDuration:1.0
//                                     animations:^{
//                                         self.alpha = 1.0;
//                                     }];
//                }
//                
//            }
//        }
//        else{
//            self.image=[UIImage imageNamed:self.placeHolderImageName];
//            NSLog(@"dp load error=%@\nurl=%@",error.localizedDescription,[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]);
//        }
//    }];
    
//    [[SDWebImageDownloader sharedDownloader] setDownloadTimeout:40];
//    [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] options:SDWebImageDownloaderUseNSURLCache progress:nil completed:^(UIImage *image,NSData *data, NSError *error,BOOL finished){
//        [weakSelf.activityView stopAnimating];
//        if (!error) {
//            if (image)
//            {
//                weakSelf.alpha=0.0;
//                [UIView animateWithDuration:1.0
//                                 animations:^{
//                                     weakSelf.image=image;
//                                     weakSelf.alpha = 1.0;
//                                 }];
//            }
//        }
//        else{
//            weakSelf.image=[UIImage imageNamed:@"user_placeholder"];
//            NSLog(@"dp load error=%@\nurl=%@",error.localizedDescription,[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]);
//        }
//    }];
    
    __weak typeof(self) weakSelf=self;
    
    [self sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:self.placeHolderImageName] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [weakSelf.activityView stopAnimating];
        if (!error) {
            if (image && (cacheType == SDImageCacheTypeNone))
            {
                weakSelf.alpha=0.0;
                [UIView animateWithDuration:1.0
                                 animations:^{
                                     weakSelf.alpha = 1.0;
                                 }];
            }
        }
        else{
            NSLog(@"dp load error=%@\nurl=%@",error.localizedDescription,[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]);
        }
    }];
    
//    [self setImageWithURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]] placeholderImage:[UIImage imageNamed:@"user_placeholder"] options:SDWebImageRetryFailed completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType){
//        [weakSelf.activityView stopAnimating];
//        if (!error) {
//            if (image && (cacheType == SDImageCacheTypeNone))
//            {
//                weakSelf.alpha=0.0;
//                [UIView animateWithDuration:1.0
//                                 animations:^{
//                                     weakSelf.alpha = 1.0;
//                                 }];
//            }
//        }
//        else{
//            NSLog(@"dp load error=%@\nurl=%@",error.localizedDescription,[url stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]);
//        }
//    }];
}

@end
