//
//  CLAbilityObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLAbilityObject : NSObject

//Ability Rating..
typedef enum {
    CLAbilityStarRatingNone = 0,
    CLAbilityStarRatingOne=  1,
    CLAbilityStarRatingTwo = 2,
    CLAbilityStarRatingThree = 3,
    CLAbilityStarRatingFour = 4,
    CLAbilityStarRatingFive = 5,
} CLAbilityStarRating;

@property(nonatomic,strong)NSString *abilityId;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *desc;

@end
