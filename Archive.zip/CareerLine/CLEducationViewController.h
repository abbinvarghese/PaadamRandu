//
//  CLQualificationDetailViewController.h
//  CareerLine
//
//  Created by RENJITH on 30/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLProfilePhotoListingGridCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectLocationViewController.h"
#import "CLEducationObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLSelectEducationViewController.h"
#import "CLTextCheckBoxCell.h"

@class CLEducationViewController;
//Delegate Methods...
@protocol CLQualificationControllerDelegate <NSObject>

@optional
- (void)qualificationController:(CLEducationViewController *)controller didAddEducation:(CLEducationObject*)eduObj;

@end

@interface CLEducationViewController : UITableViewController <UITableViewDataSource,UITableViewDelegate,CLSimpleTextCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate,CLProfilePhotoListingGridCellDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,HTProgressHUDDelegate,CLSelectEducationDelegate,CLHeightAdjustTextCellDelegate,CLTextCheckBoxCellDelegate>

@property(nonatomic,weak) id <CLQualificationControllerDelegate> delegate;
@property (nonatomic, assign) BOOL isEditMode;
@property (nonatomic, retain) CLEducationObject *educationObj;
@end
