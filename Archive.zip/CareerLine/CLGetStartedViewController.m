//
//  CLGetStartedViewController.m
//  CareerLine
//
//  Created by CSG on 1/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLGetStartedViewController.h"
#import "CLStatusViewController.h"
#import "CLPersonalProfileDetailsViewController.h"

@interface CLGetStartedViewController ()

@property (weak, nonatomic) IBOutlet UILabel *lblMainText;
@property (weak, nonatomic) IBOutlet UILabel *lblNumOfJobs;
@property (weak, nonatomic) IBOutlet UILabel *lblJobsHeading;
@end

@implementation CLGetStartedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.lblNumOfJobs.font=[UIFont fontWithName:@"Variable" size:26];
    self.lblJobsHeading.font=[UIFont fontWithName:@"Variable" size:17];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    self.title=NSLocalizedString(@"Get Started", @"Get started page title");
    [self setNavigationButtons];
    if(self.isFirstTime){
        self.lblMainText.text=NSLocalizedString(@"Welcome to CareerLine, a revolutionary, online solution designed to help you manage and progress your career journey, anytime and anywhere with as much, or as little help as you require!", @"Getting started page main text at first time shown before status setting page");
    }
    else{
        self.lblMainText.text=NSLocalizedString(@"Welcome to CareerLine, a revolutionary, online solution designed to help you manage and progress your career journey, anytime and anywhere with as much, or as little help as you require!", @"Getting started page main text at second time shown before profile details entering page");
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark Utility Methods

-(void)setNavigationButtons{
    if (self.isFirstTime) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for getting started page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGoToStatusChangePage:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Next", @"Text for getting started page go to next page button") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionGoToProfileDetailsPage:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    
}

#pragma mark IBActions

-(void)bttnActionGoToStatusChangePage:(id)sender{
    CLStatusViewController *statusScreen=[[CLStatusViewController alloc] initWithNibName:@"CLStatusViewController" bundle:[NSBundle mainBundle]];
    statusScreen.isFromWelcomeScreen=YES;
    [self.navigationController pushViewController:statusScreen animated:YES];
}

-(void)bttnActionGoToProfileDetailsPage:(id)sender{
    CLPersonalProfileDetailsViewController *profileScreen=[[CLPersonalProfileDetailsViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:profileScreen animated:YES];
}


@end
