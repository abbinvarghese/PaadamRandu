//
//  CLMsgDisplayView.h
//  CareerLine
//
//  Created by Padmam on 07/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLMsgDisplayView : UIView

@property (strong, nonatomic) UILabel *msgLbl;
@property (strong, nonatomic) NSString *displayMsg; // message to be shown

/* showing methods */
- (void)showInView:(UIView *)view; // Animated
- (void)showInView:(UIView *)view animated:(BOOL)animated;
- (void)showInRect:(CGRect)rect inView:(UIView *)view; // Animated
- (void)showInRect:(CGRect)rect inView:(UIView *)view animated:(BOOL)animated;

/* hiding methods */
- (void)hide; // Animated
- (void)hideWithAnimation:(BOOL)animated;
- (void)hideAfterDelay:(NSTimeInterval)delay; // Animated
- (void)hideAfterDelay:(NSTimeInterval)delay animated:(BOOL)animated;

@end
