//
//  CLKeyJobFactsViewController.h
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCareerKeyJobFactsObject.h"
#import "CLSimpleTextCell.h"
#import "CLHeightAdjustTextCell.h"
@class CLKeyJobFactsViewController;

//Delegate Methods...
@protocol CLKeyJobFactsControllerDelegate <NSObject>

@optional
- (void)keyJobController:(CLKeyJobFactsViewController *)controller didAddKeyJob:(CLCareerKeyJobFactsObject*)keyJobObj;

@end

@interface CLKeyJobFactsViewController : UITableViewController<CLSimpleTextCellDelegate,CLHeightAdjustTextCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate>

@property(nonatomic,weak) id <CLKeyJobFactsControllerDelegate> delegate;
@property (nonatomic,strong) CLCareerKeyJobFactsObject *keyJobFactsObj;
@property (nonatomic,strong) NSMutableDictionary *careerLevel;
@end
 