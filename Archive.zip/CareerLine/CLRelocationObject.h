//
//  CLRelocationObject.h
//  CareerLine
//
//  Created by Abbin on 03/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLRelocationObject : NSObject

@property(nonatomic,retain) NSString *currentCountry;
@property(nonatomic,retain) NSMutableDictionary *workOnlyInLocation;
@property(nonatomic,retain) NSMutableDictionary *anywhereInCountry;
@property(nonatomic,retain) NSMutableDictionary *nominatedLocationsWithinCountry;
@property(nonatomic,retain) NSMutableArray *regionWithinCountry;
@property(nonatomic,retain) NSMutableArray *stateWithinCountry;
@property(nonatomic,retain) NSMutableArray *metroWithinCountry;
@property(nonatomic,retain) NSMutableArray *metroClusterWithCountry;
@property(nonatomic,retain) NSMutableArray *tierTwoCitiesWithinCountry;
@property(nonatomic,retain) NSMutableArray *townsWithinCountry;
@property(nonatomic,retain) NSMutableDictionary *anywhereOutsideCountry;
@property(nonatomic,retain) NSMutableDictionary *specificNominatedLocations;
@property(nonatomic,retain) NSMutableArray *regionOutsideCountry;
@property(nonatomic,retain) NSMutableArray *subregionOutsideCountry;
@property(nonatomic,retain) NSMutableArray *countries;
@property(nonatomic,retain) NSMutableArray *locations;

+(void)cancelRelocationSummeryRequest;

+(void)getRegionListForSearchString:(NSString*)searchText forUserId:(NSString*)userId forLocType:(NSString*)locType countryCode:(NSString*)code fromTwentyField:(BOOL)twentyField forPage:(int)pageNumber  success:(void (^)(NSMutableArray *preferredJobsList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;

+ (void)RelocationSummaryForUser:(NSString *)userId lang:(NSString*)lang fromTwentyField:(BOOL)twentyField currentLocationFromTwentyField:(NSMutableDictionary*)currentLocationDict success:(void (^)(CLRelocationObject *relocObj))success failure:(void (^)(NSString *error))failure;

+(void)getSecondSectionRegionListForSearchString:(NSString*)searchText forUserId:(NSString*)userId forType:(NSString*)Type fromTwentyField:(BOOL)twentyField currentLocationDictionary:(NSMutableDictionary*)dictionary forPage:(int)pageNumber success:(void (^)(NSMutableArray *regionList,BOOL isLastPageReached))success failure:(void (^)(NSString *error))failure;

+ (void)saveRelocationConsideration:(CLRelocationObject*)relocObj forUser:(NSString*)userId success:(void (^)(NSString *relocId))success failure:(void (^)(NSString *error))failure;

+(NSMutableDictionary*)jsocDictionaryFor:(CLRelocationObject*)relocObj;

- (id)initWithDictionary:(NSDictionary*)dictionary;

@end