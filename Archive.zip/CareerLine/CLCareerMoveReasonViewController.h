//
//  CLCareerMoveReasonViewController.h
//  CareerLine
//
//  Created by RENJITH on 23/09/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLCareerMoveReasonViewController;

@protocol CLCareerMoveReasonDelegate <NSObject>

@required

- (void)selectCareerMoveReason:(CLCareerMoveReasonViewController*)controller withSelectedReasons:(NSMutableArray *)careerMoveReasonArray;

@end

@interface CLCareerMoveReasonViewController : UITableViewController

@property(nonatomic,weak) id <CLCareerMoveReasonDelegate> delegate;
@property(nonatomic, retain) NSMutableArray *alreadySelectedReasons;

@end
 