//
//  CLSelectNationalityViewController.m
//  CareerLine
//
//  Created by CSG on 2/10/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectNationalityViewController.h"
#import "CLCommon.h"

@interface CLSelectNationalityViewController ()

@property(nonatomic,strong)NSMutableArray *nationalityList;
@property(nonatomic,strong)NSMutableArray *filteredList;
@property(nonatomic,strong)NSMutableArray *selectedNationalities;
@property(nonatomic,strong)NSString *blackListString;

@property (strong, nonatomic) IBOutlet UISearchDisplayController *searchController;

@end

@implementation CLSelectNationalityViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=NSLocalizedString(@"Select Nationalites", @"Select Nationality page title");
    [self setLeftNavigationButton];
    [self setRightNavigationButton];
    
    self.filteredList=[[NSMutableArray alloc] init];
    self.selectedNationalities=[[NSMutableArray alloc] init];
    
        
    if ([self.alreadyListedNationalities count]>0) {
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[self.alreadyListedNationalities count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[self.alreadyListedNationalities objectAtIndex:i] objectForKey:knationalityDictCode]]];
            //[string appendString:[NSString stringWithFormat:@"\"%@\",",[[self.alreadyListedNationalities objectAtIndex:i] objectForKey:knationalityDictCode]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.blackListString=string;
    }
    
    self.nationalityList=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllNationalityListFromDBnotIn:self.blackListString];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

- (void)filterContentForSearchText:(NSString*)searchText
{
	// Update the filtered array based on the search text.
	[self.filteredList removeAllObjects];
    self.filteredList = [NSMutableArray arrayWithArray:[[CLCoreDataHelper sharedCLCoreDataHelper] getNationalityListForSearchString:searchText notIn:self.blackListString]];
}

-(BOOL)selectedNationalitiesContainsDict:(NSDictionary*)cellDict{
    BOOL isContains=NO;
    NSDictionary *selectedDict=nil;
    for (int i=0; i<[self.selectedNationalities count]; i++) {
        selectedDict=[self.selectedNationalities objectAtIndex:i];
        if([[cellDict objectForKey:knationalityDictCode] isEqualToString:[selectedDict objectForKey:knationalityDictCode]]){
            isContains=YES;
            break;
        }
    }
    return isContains;
}

#pragma mark IBaction

-(void)bttnActionSelectionDone:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^(void){
        if([self.selectedNationalities count]>0){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectNationalityControllerDidSelectNationality:withArray:)]){
                [self.delegate selectNationalityControllerDidSelectNationality:self withArray:self.selectedNationalities];
            }
        }
    }];
}

-(void)bttnActionCancelModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (tableView == self.searchController.searchResultsTableView){
        return [self.filteredList count];
    }
	else{
        return [self.nationalityList count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    
    NSDictionary *cellDict=nil;
    if (tableView == self.searchController.searchResultsTableView){
        cellDict=[self.filteredList objectAtIndex:indexPath.row];
    }
    else{
        cellDict=[self.nationalityList objectAtIndex:indexPath.row];
    }
    cell.textLabel.font = [UIFont systemFontOfSize:13];
    cell.textLabel.text=[cellDict objectForKey:knationalityDictName];
    
    if([self selectedNationalitiesContainsDict:cellDict]){
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == self.searchController.searchResultsTableView){
        if([self selectedNationalitiesContainsDict:[self.filteredList objectAtIndex:indexPath.row]]){
            [self.selectedNationalities removeObject:[self.filteredList objectAtIndex:indexPath.row]];
            [self.searchController.searchResultsTableView reloadData];
        }
        else{
            [self.selectedNationalities addObject:[self.filteredList objectAtIndex:indexPath.row]];
            [self.searchController.searchResultsTableView reloadData];
        }
    }
    else{
        if([self selectedNationalitiesContainsDict:[self.nationalityList objectAtIndex:indexPath.row]]){
            [self.selectedNationalities removeObjectIdenticalTo:[self.nationalityList objectAtIndex:indexPath.row]];
            [self.tableView reloadData];
        }
        else{
            [self.selectedNationalities addObject:[self.nationalityList objectAtIndex:indexPath.row]];
            [self.tableView reloadData];
        }
    }
}

#pragma mark - UISearchDisplayController Delegate Methods

-(void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller{
    [self.tableView reloadData];
    
    //To scroll to the last selected value..
    if([self.selectedNationalities count]>0){
        NSIndexPath *indexpath=nil;
        NSDictionary *dict=nil;
        NSDictionary *selectedDict=[self.selectedNationalities objectAtIndex:[self.selectedNationalities count]-1];
        for (int i=0; i<[self.nationalityList count]; i++) {
            dict=[self.nationalityList objectAtIndex:i];
            if([[dict objectForKey:knationalityDictCode] isEqualToString:[selectedDict objectForKey:knationalityDictCode]]){
                indexpath=[NSIndexPath indexPathForRow:i inSection:0];
                break;
            }
        }
        [self.tableView scrollToRowAtIndexPath:indexpath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    //clear selection..
    //self.selectedDict=nil;
    
    // Tells the table data source to reload when text changes
    [self filterContentForSearchText:searchString];
    
    // Return YES to cause the search result table view to be reloaded.
    return YES;
}

-(void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller {
    [controller.searchBar setShowsCancelButton:YES animated:YES];
    UIButton *cancelButton;
    UIView *topView = controller.searchBar.subviews[0];
    for (UIView *subView in topView.subviews) {
        if ([subView isKindOfClass:NSClassFromString(@"UINavigationButton")]) {
            cancelButton = (UIButton*)subView;
        }
    }
    if (cancelButton) {
        [cancelButton setTitle:@"Done" forState:UIControlStateNormal];
    }
}


@end
