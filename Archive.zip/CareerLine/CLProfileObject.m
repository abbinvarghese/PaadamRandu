//
//  CLProfileObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLProfileObject.h"
#import "CLFileObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"
#import "CLConstants.h"

#define kDebugMessages 0

@implementation CLProfileObject

static NSOperationQueue *profileSummaryRequest;

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.profileImageId = [dictionary objectForKey:@"file_id"];
    self.firstName = [dictionary objectForKeyNotNull:kCLProfileSummaryFirstNamekey];
    self.lastName = [dictionary objectForKeyNotNull:kCLProfileSummaryLastNamekey];
    self.nickName = [dictionary objectForKeyNotNull:kCLProfileSummaryNickNamekey];
    self.dateOfBirth = [dictionary objectForKeyNotNull:kCLProfileSummaryAgekey];
    self.profImageUrl = [dictionary objectForKeyNotNull:kCLProfileSummaryImageUrlkey];
        self.userAge=[dictionary objectForKeyNotNull:kCLLoginUserAgekey];
    
    self.aboutMeArray=[[NSMutableArray alloc] init];
    NSMutableArray *aboutMeSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryAboutMekey];
    for (int i=0; i<[aboutMeSummary count]; i++) {
        [self.aboutMeArray addObject:[aboutMeSummary objectAtIndex:i]];
    }
    self.careerArray=[[NSMutableArray alloc] init];
    NSMutableArray *careerSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryCareerkey];
    for (int i=0; i<[careerSummary count]; i++) {
        [self.careerArray addObject:[careerSummary objectAtIndex:i]];
    }
    self.qualificationArray=[[NSMutableArray alloc] init];
    NSMutableArray *qualificationSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryEducationkey];
    for (int i=0; i<[qualificationSummary count]; i++) {
        [self.qualificationArray addObject:[qualificationSummary objectAtIndex:i]];
    }
    self.capabilityArray=[[NSMutableArray alloc] init];
    NSMutableArray *capabilitySummary=[dictionary objectForKeyNotNull:kCLProfileSummaryCapabilitieskey];
    for (int i=0; i<[capabilitySummary count]; i++) {
        [self.capabilityArray addObject:[capabilitySummary objectAtIndex:i]];
    }
    self.protfolioArray=[[NSMutableArray alloc] init];
    NSMutableArray *protfolioSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryPortfoliokey];
    for (int i=0; i<[protfolioSummary count]; i++) {
        
        
        [self.protfolioArray addObject:[protfolioSummary objectAtIndex:i]];
    }
    self.referenceArray=[[NSMutableArray alloc] init];
     NSMutableArray *referenceSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryReferenceskey];
    //self.referenceDict=[dictionary objectForKeyNotNull:kCLProfileSummaryReferenceskey];
    for (int i=0; i<[referenceSummary count]; i++) {
        [self.referenceArray addObject:[referenceSummary objectAtIndex:i]];
    }
    self.jobPreferenceArray=[[NSMutableArray alloc] init];
    NSMutableArray *jobPreferenceSummary=[dictionary objectForKeyNotNull:kCLProfileSummaryJobPreferencekey];
    for (int i=0; i<[jobPreferenceSummary count]; i++) {
        [self.jobPreferenceArray addObject:[jobPreferenceSummary objectAtIndex:i]];
    }
    
    //goals array converting html to text..
    NSMutableArray *arr=[[dictionary objectForKeyNotNull:kCLProfileSummaryGoalskey] mutableCopy];
    NSMutableDictionary *dict=nil;
    for (int i=0; i<[arr count]; i++) {
        dict=[[arr objectAtIndex:i] mutableCopy];
     
        
        NSMutableString *htmlString=[[[NSAttributedString alloc] initWithData:[[dict objectForKey:kCLProfileSummaryValuekey] dataUsingEncoding:NSUTF8StringEncoding]
                                                                      options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                NSCharacterEncodingDocumentAttribute: [NSNumber numberWithInt:NSUTF8StringEncoding]}
                                                           documentAttributes:nil error:nil].string mutableCopy];
        [htmlString replaceOccurrencesOfString:@"\n" withString:@" " options:NSCaseInsensitiveSearch range:NSMakeRange(0, htmlString.length)];
        [dict setObject:htmlString forKey:kCLProfileSummaryValuekey];
        [arr replaceObjectAtIndex:i withObject:dict];
    }
    self.goalsArray=arr;
    
    self.thumbImages=[[NSMutableArray alloc] init];
    NSMutableArray *thumbImages=[dictionary objectForKeyNotNull:kCLProfileSummaryImagekey];
    for (int i=0; i<[thumbImages count]; i++) {
        [self.thumbImages addObject:[thumbImages objectAtIndex:i]];
    }
    
    return self;
}

+ (void)cancelProfileSummaryPendingRequest {
    [profileSummaryRequest cancelAllOperations];
    profileSummaryRequest = nil;
}

//Method for getting a profile summary for a particular user...
+ (void)profileSummaryForUser:(NSString *)userId success:(void (^)(CLProfileObject *profObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLProfileObject *profObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [profileSummaryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        profileSummaryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileSummaryURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"Success");
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"job detail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLProfileObject  *prof=[[CLProfileObject alloc] initWithDictionary:response];
                success(prof);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"FAiled");
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        
        failure([CLCommon getMessageForErrorCode:-1004]);
    }
}

@end
