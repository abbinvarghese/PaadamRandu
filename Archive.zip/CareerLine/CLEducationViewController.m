//
//  CLQualificationDetailViewController.m
//  CareerLine
//
//  Created by RENJITH on 30/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLEducationViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLUserObject.h"
#import "CLDocumentViewController.h"
#import "CLQualificationObject.h"

#define kAddEducationDocType @"ED"

@interface CLEducationViewController ()

typedef enum {
    CLCourseTextIndex = 0,
    CLMajorTextIndex= 1,
    CLCountryIndex = 2,
    CLLocationTextIndex= 3,
    CLInstitutionTextIndex= 4,
    CLStartDateTextIndex= 5,
    CLEndDateTextIndex = 6,
    CLEducationalLevelTextIndex = 7,
    CLRatingTextIndex = 8,
    CLdescriptionTextIndex = 9,
    CLDocumentThumbIndex = 10
} CLEducationTableSectionIndex;

typedef enum {
    CLdescriptionTextOngoingndex = 8,
    CLDocumentThumbOngoingIndex = 9
} CLEducationTableSectionOngoingIndex;

@property (strong, nonatomic) IBOutlet UIDatePicker *startDatePicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *endDatePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbarWithoutCancel;

@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property (nonatomic, strong) NSMutableDictionary *selectedCurrentLocation;
@property (nonatomic, strong) NSMutableArray *gradeArray;
@property (nonatomic, strong) NSMutableArray *gradeCodeArray;

@property(assign,nonatomic)BOOL onGoing;
@property(nonatomic,assign) BOOL forCountry;
@property(strong,nonatomic)NSString *courseText;
@property(strong,nonatomic)NSString *locationText;
@property(strong,nonatomic)NSString *majorText;
@property(strong,nonatomic)NSString *institutionText;
@property(strong,nonatomic)NSDate *startDateText;
@property(strong,nonatomic)NSDate *endDateText;
@property(strong,nonatomic)NSString *educationalLevelText;
@property(strong,nonatomic)NSString *educationalLevelId;
@property(strong,nonatomic)NSString *ratingText;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@property(strong,nonatomic)NSMutableDictionary *selectedEducation;
@property(strong,nonatomic)NSMutableDictionary *selectedCountry;
@end

@implementation CLEducationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setRightNavigationButton];
    
    self.title = NSLocalizedString(@"Education", @"qualification detail heading");
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentLocationCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"currentCountryCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"educationLevelCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"onGoingTextCellIdentifier"];
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"courseTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"majorTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"institutionTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"startDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"endDateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"ratingTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"ratingGradeTextCellIdentifier"];
    
    UIDatePicker *startDatePickr=[[UIDatePicker alloc] init];
    startDatePickr.backgroundColor=[UIColor whiteColor];
    [startDatePickr setLocale:[NSLocale currentLocale]];
    [startDatePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [startDatePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        
        NSDate *currDate = [NSDate date];
        
        switch ([newDate compare:currDate]){
            case NSOrderedAscending:
                [startDatePickr setDate:newDate];
                
                break;
            case NSOrderedSame:
            case NSOrderedDescending:
                [startDatePickr setDate:currDate];
                break;
        }
        
        //[datePickr setDate:newDate];
    }
    else{
        [startDatePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [startDatePickr setDatePickerMode:UIDatePickerModeDate];
    
    UIDatePicker *endDatePickr=[[UIDatePicker alloc] init];
    endDatePickr.backgroundColor=[UIColor whiteColor];
    [endDatePickr setLocale:[NSLocale currentLocale]];
    [endDatePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [endDatePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        
        NSDate *currDate = [NSDate date];
        
        switch ([newDate compare:currDate]){
            case NSOrderedAscending:
                [startDatePickr setDate:newDate];
                
                break;
            case NSOrderedSame:
            case NSOrderedDescending:
                [startDatePickr setDate:currDate];
                break;
        }

    }
    else{
        [endDatePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [endDatePickr setDatePickerMode:UIDatePickerModeDate];
    
    self.startDatePicker=startDatePickr;
    self.endDatePicker=endDatePickr;
    self.descriptionHeight=[[NSNumber alloc] init];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.toolbarWithoutCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.selectedEducation=[[NSMutableDictionary alloc] init];
    if (self.isEditMode) {
        self.selectedCountry = [[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:self.educationObj.location.countryCode forKey:@"countryCode"];
        [self.selectedCountry setObject:self.educationObj.location.countryName forKey:@"country"];
        self.selectedCurrentLocation = [[NSMutableDictionary alloc]init];
        [self.selectedCurrentLocation setObject:self.educationObj.location.locationCode forKey:@"jobLocationCode"];
        [self.selectedCurrentLocation setObject:self.educationObj.location.countryName forKey:@"jobLocationCountryName"];
        [self.selectedCurrentLocation setObject:self.educationObj.location.adminArea forKey:@"jobLocationAdminArea"];
        [self.selectedCurrentLocation setObject:self.educationObj.location.countryCode  forKey:@"jobLocationCountryCode"];
        [self.selectedCurrentLocation setObject:self.educationObj.location.locName forKey:@"jobLocationName"];
        self.courseText = self.educationObj.course;
        self.majorText = self.educationObj.specialization;
        self.institutionText = self.educationObj.institution;
        self.locationText = self.educationObj.location.locationName;
        self.startDateText = self.educationObj.fromDate;
        self.endDateText = self.educationObj.completionDate;
        self.educationalLevelText = self.educationObj.educationLevel;
        self.educationalLevelId = self.educationObj.educationLevelId;
        
        //[self.selectedEducation setObject:self.educationObj.educationLevelId forKey:kCLQlfitnEducationLevelIdkey];
        //[self.selectedEducation setObject:selfeducationObj.educationLevel forKey:kCLQlfitnEducationLevelDesckey];
        self.onGoing = self.educationObj.isOngoing;
        if (self.educationObj.isOngoing) {
            self.ratingText = @"";
        }else{
            self.ratingText = self.educationObj.ratingType;
        }
        self.descriptionText = self.educationObj.descption;
        if (self.startDateText!=nil) {
            [self.startDatePicker setDate:self.startDateText];
        }
        if (self.endDateText!=nil) {
            [self.endDatePicker setDate:self.endDateText];
        }
    }
    else{
        self.selectedCountry = [[NSMutableDictionary alloc]initWithDictionary:[CLUserObject currentUser].country];
        self.courseText = @"";
        self.majorText = @"";
        self.institutionText = @"";
        self.locationText = @"";
        self.startDateText = nil;
        self.endDateText = nil;
        self.onGoing = NO;
        self.educationalLevelText = @"";
        self.educationalLevelId = @"";
        self.ratingText = @"";
        self.descriptionText = @"";
    }
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Education"];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    if([self.txtFirstResponder isFirstResponder])
        [self.txtFirstResponder resignFirstResponder];
    if([self.txtViewFirstResponder isFirstResponder])
        [self.txtViewFirstResponder resignFirstResponder];
    
}

-(void)datePickerStartDateChanged:(UIDatePicker*)datePicker{
    
    NSDate *date=datePicker.date;
    self.startDateText=date;
    CLSimpleTextCell *dateCell;
    if(self.onGoing){
        dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLStartDateTextIndex]];
        [dateCell setCellText:[CLCommon getStringForDate:self.startDateText andLocalFormat:@"MMMMdy"]];
    }else{
        dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLStartDateTextIndex]];
        [dateCell setCellText:[CLCommon getStringForDate:self.startDateText andLocalFormat:@"MMMMdy"]];
    }
}

-(void)datePickerEndDateChanged:(UIDatePicker*)datePicker{
    
    NSDate *date=datePicker.date;
    self.endDateText=date;
    CLSimpleTextCell *dateCell;
    dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLEndDateTextIndex]];
    [dateCell setCellText:[CLCommon getStringForDate:self.endDateText andLocalFormat:@"MMMMdy"]];
}

#pragma mark Utility Methods
- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    if (self.startDateText == nil && index.section == CLStartDateTextIndex) {
        self.startDateText = self.startDatePicker.date;
        cell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLStartDateTextIndex]];
        [cell setCellText:[CLCommon getStringForDate:self.startDateText andLocalFormat:@"MMMMdy"]];
    }
    
    if (self.endDateText == nil && index.section == CLEndDateTextIndex) {
        self.endDateText = self.endDatePicker.date;
        cell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLEndDateTextIndex]];
        [cell setCellText:[CLCommon getStringForDate:self.endDateText andLocalFormat:@"MMMMdy"]];
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)bttnActionCancel:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}
- (IBAction)toolbarWithOutCancelaction:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Qualification modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveQualificationAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Qualification modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddQualificationAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Qualification modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Course validation..
    if ([self.courseText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Course/Program.", @"Error Message for null Course/Program. field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.courseText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Course/Program Length.", @"Error Message for length of Course/Program. field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Specialisation validation
    if ([self.majorText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Specialisation.", @"Error Message for null Specialisation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.majorText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Specialisation Length.", @"Error Message for length of Specialisation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    // Location validation
//    if ([self.selectedCurrentLocation count] ==0 && [self.locationText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    //institution validation
    if ([self.institutionText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Institution.", @"Error Message for null Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.institutionText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Institution Length.", @"Error Message for length of Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Date validation..
    if (self.startDateText==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Start Date.", @"Error Message for null satart date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Not ongoing condition validation
    if (!self.onGoing) {
        //Date validation..
        if (self.endDateText ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select A Completion Date.", @"Error Message for null Expected Completion Date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
            
        }else{
            if (self.startDateText!=nil && self.endDateText !=nil) {
                if( [self.startDateText timeIntervalSinceDate:self.endDateText] >= 0 ){
                    [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"End date Should Be Greater Than Start Date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                    
                    return isValid=NO;
                }
            }
        }
        
//        if ([self.ratingText isEqualToString:@""]) {
//            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Rate The Course/Program", @"Error Message for rating field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//            
//            return isValid=NO;
//        }
        
        

    }
    
    if ([self.educationalLevelText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Education Level.", @"Error Message for null Education Level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.educationalLevelText length] > 300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Education Level Length.", @"Error Message for length of Education Level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    
    //Education level validation
    //    if ([self.educationalLevelText isEqualToString:@""]) {
    //        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Education Level.", @"Error Message for null Education Level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    //        return isValid=NO;
    //    }else if ([self.educationalLevelText length] > 300){
    //        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Education Level length.", @"Error Message for length of Education Level field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    //        return isValid=NO;
    //    }
    // Location validation
    //    else if ([self.selectedCurrentLocation count] ==0 && [self.locationText isEqualToString:@""]) {
    //        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    //        return isValid=NO;
    //    }
    
    //Company validation..
    //    if ([self.institutionText isEqualToString:@""]) {
    //        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Institution.", @"Error Message for null Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    //        return isValid=NO;
    //    }
    //    else if ([self.institutionText length]>300) {
    //        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Institution length.", @"Error Message for length of Institution field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    //        return isValid=NO;
    //    }
    
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)saveEducationForEdit:(BOOL)isEditMode{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    CLEducationObject *newEduObj=[[CLEducationObject alloc] init];
    if (isEditMode) {
        
        newEduObj.educationId = self.educationObj.educationId;
        
    }else{
        newEduObj.educationId = nil;
    }
    newEduObj.course = self.courseText;
    newEduObj.specialization = self.majorText;
    newEduObj.institution = self.institutionText;
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]init];
    
//    if (self.selectedCurrentLocation == nil) {
//        if (self.educationObj.location.locationName !=nil) {
//            [locDict setObject:self.educationObj.location.locationName forKey:kCLProfileAboutMeLocNamekey];
//            [locDict setObject:self.educationObj.location.locationCode forKey:kCLProfileAboutMeLocCodekey];
//            [locDict setObject:self.educationObj.location.countryCode forKey:kCLQlfitnEducationLocationCountrykey];
//        }
//        else{
//            if (self.selectedCountry) {
//                [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnEducationLocationCountrykey];
//            }
//        }
//    }else{
    if (self.selectedCurrentLocation != nil) {
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCountryCode] forKey:kCLQlfitnEducationLocationCountrykey];
        [locDict setObject:[self.selectedCurrentLocation objectForKey:kLocationCode] forKey:kCLProfileAboutMeLocCodekey];
        [locDict setObject:[NSString stringWithFormat:@"%@/%@,%@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]] forKey:kCLProfileAboutMeLocNamekey];
    }
    else{
        [locDict setObject:[self.selectedCountry objectForKey:@"countryCode"] forKey:kCLQlfitnTrainingLocationCountrykey];
    }
    newEduObj.location = [[CLLocationObject alloc]initWithDictionary:locDict];
    newEduObj.fromDate = self.startDateText;
    newEduObj.completionDate = self.endDateText;
    newEduObj.isOngoing = self.onGoing;
    newEduObj.educationLevel = self.educationalLevelText;
    newEduObj.educationLevelId = self.educationalLevelId;
    newEduObj.ratingType = self.ratingText;
    newEduObj.descption = self.descriptionText;
    
    [CLEducationObject saveEducation:newEduObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *educationId) {
        
//        if (isEditMode) {
//            self.educationObj.course=newEduObj.course;
//            self.educationObj.specialization=newEduObj.specialization;
//            self.educationObj.institution=newEduObj.institution;
//            self.educationObj.fromDate=newEduObj.fromDate;
//            self.educationObj.completionDate=newEduObj.completionDate;
//            self.educationObj.isOngoing = newEduObj.isOngoing;
//            self.educationObj.location = newEduObj.location;
//            self.educationObj.educationLevel=newEduObj.educationLevel;
//            self.educationObj.educationLevelId=newEduObj.educationLevelId;
//            self.educationObj.ratingType=newEduObj.ratingType;
//            self.educationObj.descption=newEduObj.descption;
//            
//            
//        }else{
//            newEduObj.educationId=educationId;
//            self.educationObj=newEduObj;
//        }
        
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [progressHUD hideWithAnimation:YES];
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save education. Please try again later.", @"Error message when education cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    }];
    
}
#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(qualificationController:didAddEducation:)]){
                [self.delegate qualificationController:self didAddEducation:self.educationObj];
            }
            
        }];
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

#pragma mark IBActions
-(IBAction)bttnActionSaveQualificationAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveEducationForEdit:YES];
    }
}

-(IBAction)bttnActionAddQualificationAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveEducationForEdit:NO];
    }
}

#pragma mark CLTappableCellDelegate Methods
- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLLocationTextIndex) {
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryBasedLocation;
        selectLocation.countryCodeforListing = [self.selectedCountry objectForKey:@"countryCode"];
        selectLocation.delegate=self;
        self.forCountry = NO;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    
    else if (indexPath.section == CLCountryIndex){
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingCountryForCRF;
        selectLocation.delegate=self;
        self.forCountry = YES;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
    }
    
    else if (indexPath.section == CLEducationalLevelTextIndex){
        
        CLSelectEducationViewController *selectEducationView=[[CLSelectEducationViewController alloc] initWithStyle:UITableViewStylePlain];
        selectEducationView.delegate=self;
        selectEducationView.cyCode = [self.selectedCountry objectForKey:@"countryCode"];
        if ([self.selectedEducation count]==0 && self.isEditMode) {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
           
            [dict setObject:self.educationObj.educationLevel forKey:keducationDictName];
            [dict setObject:self.educationObj.educationLevelId forKey:keducationDictCode];
            
            selectEducationView.alreadySelectedEduLevel =dict;
        }else{
             selectEducationView.alreadySelectedEduLevel = self.selectedEducation;
        }
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectEducationView];
        [self presentViewController:nav animated:YES completion:nil];
    }
}

#pragma mark CLSelectLocationDelegate
- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    if (self.forCountry) {
        [self.selectedCountry removeAllObjects];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        [self.selectedCountry setObject:[locDict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        self.selectedCurrentLocation =nil;
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCountryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLLocationTextIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{
        self.selectedCurrentLocation=locDict;
        [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLLocationTextIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
}

- (void)selectEducationControllerDidSelectEducation:(CLSelectEducationViewController*)controller withDict:(NSMutableDictionary *)eduDict{
    
    self.selectedEducation=eduDict;
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLEducationalLevelTextIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        if (self.onGoing) {
            return 10;
            
        }else{
            return 11;
        }
    }else{
        if (self.onGoing) {
            return 9;
        }else{
            return 10;
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == CLEndDateTextIndex) {
        return 2;
    }else{
        return 1;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.onGoing) {
        if(indexPath.section == CLDocumentThumbOngoingIndex){
            return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.educationObj.documentsUrl count]+1)/2));
        }else if (indexPath.section==CLdescriptionTextOngoingndex) {
            CGFloat ansHeight;
            if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
                ansHeight= [self.descriptionHeight floatValue];
            }
            else{
                ansHeight= [self getTextViewSizeForText:self.descriptionText];
            }
            return MAX(44, ansHeight+1);
        }
        else{
            return 44;
        }
        
    }else{
        if(indexPath.section == CLDocumentThumbIndex){
            return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.educationObj.documentsUrl count]+1)/2));
        }else if (indexPath.section==CLdescriptionTextIndex) {
            CGFloat ansHeight;
            if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
                ansHeight= [self.descriptionHeight floatValue];
            }
            else{
                ansHeight= [self getTextViewSizeForText:self.descriptionText];
            }
            return MAX(44, ansHeight+1);
        }
        else{
            return 44;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLCourseTextIndex:{
            CLSimpleTextCell *courseCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"courseTextCellIdentifier"];
            courseCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [courseCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [courseCell setPlaceHoldrText:NSLocalizedString(@"Course/Program", @"Placeholder for Course/Program")];
            [courseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [courseCell setCellText:self.courseText];
            [courseCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [courseCell setCellIndexPath:indexPath];
            courseCell.delegate=self;
            return courseCell;
        }
        case CLMajorTextIndex:{
            CLSimpleTextCell *majorCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"majorTextCellIdentifier"];
            majorCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [majorCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [majorCell setPlaceHoldrText:NSLocalizedString(@"Major/Specialisation", @"Placeholder for Major/Specialisation")];
            [majorCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [majorCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [majorCell setCellText:self.majorText];
            [majorCell setCellIndexPath:indexPath];
            majorCell.delegate=self;
            return majorCell;
        }
        case CLCountryIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentCountryCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Country Where Your Education Was Completed", @"Placeholder for country")];
            currLoccell.delegate=self;
            if (self.selectedCountry && [self.selectedCountry objectForKey:@"country"] != [NSNull null]) {
                [currLoccell setCellText:[self.selectedCountry objectForKey:@"country"]];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
        }
            break;
        case CLLocationTextIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"currentLocationCellIdentifier"];
            [currLoccell setPlaceHoldrText: NSLocalizedString(@"Location (City/Town/Village)", @"Placeholder for Location(City/Town/Village,country)")];
            currLoccell.delegate=self;
            if (self.selectedCurrentLocation) {
                
                if (![[self.selectedCurrentLocation objectForKey:kLocationName] isEqualToString:@""] || ![[self.selectedCurrentLocation objectForKey:kLocationAdminArea] isEqualToString:@""]) {
                    [currLoccell setCellCloseBtnOption:NO];
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.selectedCurrentLocation objectForKey:kLocationName],[self.selectedCurrentLocation objectForKey:kLocationAdminArea],[self.selectedCurrentLocation objectForKey:kLocationCountryName]]];
                } else{
                    [currLoccell setCellText:@""];
                }
            }
            else{
                [currLoccell setCellText:@""];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
        }
        case CLInstitutionTextIndex:{
            CLSimpleTextCell *institutionCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"institutionTextCellIdentifier"];
            institutionCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [institutionCell setTextInputAccesoryView:self.toolbarWithoutCancel];
            [institutionCell setPlaceHoldrText:NSLocalizedString(@"Institution", @"Placeholder for Institution")];
            [institutionCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [institutionCell setCellText:self.institutionText];
            [institutionCell setCellIndexPath:indexPath];
            [institutionCell setCellClearButtonMode:UITextFieldViewModeAlways];
            institutionCell.delegate=self;
            return institutionCell;
        }
        case CLStartDateTextIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"startDateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.startDatePicker];
            [self.startDatePicker addTarget:self action:@selector(datePickerStartDateChanged:) forControlEvents:UIControlEventValueChanged];
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Start Date", @"Placeholder for Start Date")];
            [dateCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
            [dateCell setCellText:[CLCommon getStringForDate:self.startDateText andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
        }
        case CLEndDateTextIndex:{
            if (indexPath.row == 0){
                
                CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"endDateTextCellIdentifier"];
                dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [dateCell setTextInputView:self.endDatePicker];
                [self.endDatePicker addTarget:self action:@selector(datePickerEndDateChanged:) forControlEvents:UIControlEventValueChanged];
                [dateCell setTextInputAccesoryView:self.keyboardResignView];
                if (self.onGoing) {
                    [dateCell setPlaceHoldrText: NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date")];
                }else{
                    [dateCell setPlaceHoldrText: NSLocalizedString(@"Completion Date", @"Placeholder for Completion Date")];
                }
                [dateCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                //                if (self.onGoing) {
                //                    [dateCell disableCellField];
                //                    [dateCell setCellText:@""];
                //                }else{
                [dateCell enableCellField];
                [dateCell setCellText:[CLCommon getStringForDate:self.endDateText andLocalFormat:@"MMMMdy"]];
                //   }
                [dateCell setCellIndexPath:indexPath];
                [dateCell setCellClearButtonMode:UITextFieldViewModeAlways];
                dateCell.delegate=self;
                return dateCell;
                
            }
            else{
                
                CLTextCheckBoxCell *onGoingCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"onGoingTextCellIdentifier"];
                onGoingCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [onGoingCell setTextInputAccesoryView:self.keyboardResignView];
                [onGoingCell setPlaceHoldrText:NSLocalizedString(@"", @"Placeholder")];
                [onGoingCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [onGoingCell setCellText:NSLocalizedString(@"Ongoing", @"Placeholder for on going")];
                [onGoingCell setCellTextColor:[UIColor darkGrayColor]];
                [onGoingCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [onGoingCell setCellIndexPath:indexPath];
                [onGoingCell disableCelltxtField];
                [onGoingCell checkBoxClick:self.onGoing];
                onGoingCell.textCheckBoxdelegate=self;
                
                return onGoingCell;
            }
            
        }
        case CLEducationalLevelTextIndex:{
            CLSimpleTappableTextCell *educationCell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"educationLevelCellIdentifier"];
            educationCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [educationCell setPlaceHoldrText:NSLocalizedString(@"Education Level", @"Placeholder for Education Level")];
            if([self.selectedEducation count]==0){
                [educationCell setCellText:self.educationalLevelText];
            }
            else{
                [educationCell setCellCloseBtnOption:NO];
                self.educationalLevelId = [self.selectedEducation objectForKey:keducationDictCode];
                self.educationalLevelText = [self.selectedEducation objectForKey:keducationDictName];
                [educationCell setCellText:[self.selectedEducation objectForKey:keducationDictName]];
            }
            [educationCell setCellIndexPath:indexPath];
            educationCell.delegate=self;
            return educationCell;
        }
        case CLRatingTextIndex:{
            if (self.onGoing) {
                CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
                descCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [descCell setTextInputAccesoryView:self.toolbarWithoutCancel];
                [descCell setPlaceHoldrText:NSLocalizedString(@"Anything else you want to say about this", @"Placeholder for Anything else you want to say about this")];
                [descCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                descCell.text = self.descriptionText;
                [descCell updateCellContents];
                if(self.descriptionHeight==nil){
                    self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
                }
                [descCell setCellIndexPath:indexPath];
                descCell.delegate=self;
                return descCell;
            }else{
                CLSimpleTextCell *ratingCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"ratingTextCellIdentifier"];
                ratingCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [ratingCell setTextInputAccesoryView:self.toolbarWithoutCancel];
                [ratingCell setPlaceHoldrText:NSLocalizedString(@"Rating", @"Placeholder for Rating")];
                [ratingCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [ratingCell setCellText:self.ratingText];
                [ratingCell setCellClearButtonMode:UITextFieldViewModeAlways];
                [ratingCell setCellIndexPath:indexPath];
                ratingCell.delegate=self;
                return ratingCell;
            }
        }
        case CLdescriptionTextIndex:{
            if (!self.onGoing) {
                CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
                descCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [descCell setTextInputAccesoryView:self.toolbarWithoutCancel];
                [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for Anything else you want to say about this")];
                [descCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                descCell.text=self.descriptionText;
                [descCell updateCellContents];
                if(self.descriptionHeight==nil){
                    self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
                }
                [descCell setCellIndexPath:indexPath];
                descCell.delegate=self;
                return descCell;
            }
            else{
                CLProfilePhotoListingGridCell *docCell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
                docCell.selectionStyle=UITableViewCellSelectionStyleNone;
                docCell.indexPath=indexPath;
                docCell.delegate=self;
                docCell.photosLimit=-1;
                docCell.placeHolderImageName=@"documentPlaceHolder";
                docCell.photoUrls=self.educationObj.documentsUrl;
                [docCell updateCollectionViewContents];
                return docCell;
            }
        }
        case CLDocumentThumbIndex:{
            if (!self.onGoing) {
                CLProfilePhotoListingGridCell *docCell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
                docCell.selectionStyle=UITableViewCellSelectionStyleNone;
                docCell.indexPath=indexPath;
                docCell.delegate=self;
                docCell.photosLimit=-1;
                docCell.placeHolderImageName=@"documentPlaceHolder";
                docCell.photoUrls=self.educationObj.documentsUrl;
                [docCell updateCollectionViewContents];
                return docCell;
            }
        }
        default:
            return nil;
            break;
    }
    return nil;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLCourseTextIndex:
            return NSLocalizedString(@"Course/Program", @"Placeholder for Course/Program");
            break;
        case CLMajorTextIndex:
            return NSLocalizedString(@"Major/Specialisation", @"Placeholder for Major/Specialisation");
            break;
        case CLInstitutionTextIndex:
            return NSLocalizedString(@"Institution", @"Placeholder for Institution");
            break;
        case CLLocationTextIndex:
            return NSLocalizedString(@"Location(City/Town/Village,country)", @"Placeholder for Location(City/Town/Village,country)");
            break;
        case CLCountryIndex:
            return NSLocalizedString(@"Country Where Your Education Was Completed", @"title for coutry");
        case CLStartDateTextIndex:
            return NSLocalizedString(@"Start Date", @"Placeholder for Start Date");
            break;
        case CLEndDateTextIndex:
            if (self.onGoing) {
                return NSLocalizedString(@"Expected Completion Date", @"Placeholder for Expected Completion Date");
                break;
            }else{
                 return NSLocalizedString(@"Completion Date", @"Placeholder for Completion Date");
                break;
            }
        case CLEducationalLevelTextIndex:
            return NSLocalizedString(@"Education Level", @"Placeholder for Education Level");
            break;
        case CLRatingTextIndex:
            if (self.onGoing) {
                return NSLocalizedString(@"Anything else you want to say about this", @"Placeholder for Anything else you want to say about this");
                break;
            }else{
                return NSLocalizedString(@"Rating", @"Placeholder for Rating");
                break;
            }
        case CLdescriptionTextIndex:
            if (!self.onGoing) {
                return NSLocalizedString(@"Anything else you want to say about this", @"Placeholder for Anything else you want to say about this");
                break;
            }else{
                return NSLocalizedString(@"Documents", @"Placeholder for Documents");
                break;
            }
        case CLDocumentThumbIndex:
            if (!self.onGoing) {
                return NSLocalizedString(@"Documents", @"Placeholder for Documents");
                break;
            }
        default:
            return nil;
            break;
    }
    
}


- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    switch (indexPath.section) {
        case CLLocationTextIndex:
            self.selectedCurrentLocation=nil;
            self.educationObj.location=nil;
            break;
        case CLEducationalLevelTextIndex:
            self.selectedEducation = nil;
            self.educationalLevelId = @"";
            self.educationalLevelText = @"";
            break;
            
        default:
            break;
    }
    [self.tableView reloadData];
}

#pragma mark CLHeightAdjustTextCellDelegate Methods
- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark CLSimpleTextCellDelegate Methods

-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    switch (indexPath.section) {
        case CLCourseTextIndex:
            self.courseText = @"";
            break;
        
        case CLMajorTextIndex:
            self.majorText = @"";
            break;
        case CLInstitutionTextIndex:
            self.institutionText = @"";
            break;
        case CLStartDateTextIndex:
            self.startDateText = nil;
            break;
        case CLEndDateTextIndex:{
            if (indexPath.row == 0) {
                self.endDateText = nil;
            }
        }
            break;
        case CLRatingTextIndex:
            self.ratingText = @"";
            break;
            
        default:
            break;
    }
}

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    NSIndexPath *indexPath = cell.cellIndexPath;
    if (indexPath.section == CLEndDateTextIndex && self.onGoing) {
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate *currentDate = [NSDate date];
        NSDateComponents *comps = [[NSDateComponents alloc] init];
        [comps setYear:30];
        NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
        [self.endDatePicker setMaximumDate:maxDate];
        [self.endDatePicker setMinimumDate:[NSDate date]];
    }else{
        [self.endDatePicker setMaximumDate:[NSDate date]];
        [self.endDatePicker setMinimumDate:[CLUserObject currentUser].birthDate];
        
    }
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
            
        case CLCourseTextIndex:
            self.courseText=text;
            break;
            
        case CLMajorTextIndex:
            self.majorText=text;
            break;
        case CLLocationTextIndex:
            self.locationText=text;
            break;
        case CLInstitutionTextIndex:
            self.institutionText=text;
            break;
        case CLEducationalLevelTextIndex:
            self.educationalLevelText=text;
            break;
        case CLRatingTextIndex:
            self.ratingText=text;
            break;
        case CLdescriptionTextIndex:
            self.descriptionText=text;
            break;
        default:
            break;
    }
}

#pragma mark CLTextCheckBoxCellDelegate Methods
-(void)textCheckBoxCellWillBeginEditing:(CLTextCheckBoxCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    
    [CLCommon doViewAnimation:self.view];
    if (status) {
        self.onGoing = YES;
        self.endDateText = nil;
    }else{
        self.onGoing = NO;
        self.endDateText = nil;
    }
    [self reloadTableWithAnimation:YES];
}

-(void)reloadTableWithAnimation:(BOOL)boolVal{
    if (boolVal) {
        [UIView transitionWithView:self.tableView
                          duration:0.4f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^(void) {
                            [self.tableView reloadData];
                        } completion:NULL];
    }else{
        [self.tableView reloadData];
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods
- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate
-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject addDocument:image forQualification:self.educationObj.educationId andUser:[CLUserObject currentUser].userID withDocType:kAddEducationDocType andCaption:caption success:^(CLFileObject *fileObj) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.educationObj.documentsUrl) {
            self.educationObj.documentsUrl=[[NSMutableArray alloc] init];
        }
        [self.educationObj.documentsUrl addObject:fileObj];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

#pragma mark UIActionsheet Delegates
-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLFileObject *documentObj=[self.educationObj.documentsUrl objectAtIndex:indexPath.row];
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting education doc");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLQualificationObject deleteQDocument:documentObj.fileId success:^{
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.educationObj.documentsUrl removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            [progressHUD hideWithAnimation:YES];
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

@end
