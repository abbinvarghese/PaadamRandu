//
//  CLRelocationViewController.m
//  CareerLine
//
//  Created by RENJITH on 10/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLRelocationViewController.h"


@interface CLRelocationViewController ()
typedef enum {
    CLRelocationWithinCountryIndex = 0,
    CLRelocationOutSideCountryIndex= 1
} CLRelocationTableSectionIndex;

typedef enum {
    CLWorkOnlyInIndex = 0,
    CLWorkAnyWhereWithinCountryIndex = 1,
    CLNominatedLocationWithinCountry = 2,
    CLRegionIndexWithInCountryIndex = 3,
    ClStateWithInCountryIndex = 4,
    CLMetroWithInCountryIndex = 5,
    ClMetroClusterWithInCountryIndex = 6,
    ClTierTwoCWithInCountryIndex = 7,
    ClTownsOrVillagesWithInCountryIndex = 8
    
}CLRelocationTableIndexForFirstSection;

typedef enum {
    CLAnywhereOutsideCountry = 0,
    CLSpecificNominatedLocationIndex = 1,
    CLRegionOutsideCountryIndex = 2,
    CLSubregionIndex = 3,
    ClCountriesIndex = 4,
    CLLocationsIndex = 5
    
}CLRelocationTableIndexForSecondSection;



@property (strong, nonatomic) IBOutlet TITokenField *tokenTextField;

@property (strong, nonatomic) HTProgressHUD *activityIndicator;
//@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,retain) NSArray *sectionHeadings;

@property (nonatomic,retain) NSMutableDictionary *workInLocationDict;
@property (nonatomic,retain) NSMutableDictionary *anywhereWithinCountryDict;
@property (nonatomic,retain) NSMutableDictionary *nominatedLocationWithinCountryDict;

@property (nonatomic,retain) NSArray *ausArray;
@property (nonatomic,retain) NSArray *indArray;
@property (nonatomic,retain) NSMutableArray *selectedRegionDictArray;
@property (nonatomic,retain) NSMutableArray *selectedStateDictArray;
@property (nonatomic,retain) NSMutableArray *selectedMetroDictArray;
@property (nonatomic,retain) NSMutableArray *selectedMetroClusterDictArray;
@property (nonatomic,retain) NSMutableArray *selectedTierTwoCitiesDictArray;
@property (nonatomic,retain) NSMutableArray *selectedTownOrVillagesDictArray;

@property(nonatomic,retain) NSMutableDictionary *anywhereOutsideCountry;
@property(nonatomic,retain) NSMutableDictionary *specificNominatedLocations;
@property(nonatomic,retain) NSMutableArray *regionOutsideCountry;
@property(nonatomic,retain) NSMutableArray *subregionOutsideCountry;
@property(nonatomic,retain) NSMutableArray *countries;
@property(nonatomic,retain) NSMutableArray *locations;

@property (nonatomic,retain) NSString *currentCountry;
@property(nonatomic)BOOL nominatedLocationSelected;
@property(nonatomic) BOOL indiaOrAus;
@end

@implementation CLRelocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self saveAllTheArrays];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"locationCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"countryCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"subRegionCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"regionCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"townsCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"tierTwoCityCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"metroClurterCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"metroCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"stateCell"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"regionCellOut"];
    [self setRightNavigationButton];
    self.title = NSLocalizedString(@"I Am Willing To Work", @"title");
    if (self.relocObj) {
        [self setAllTheFields];
    }
    else{
        [self reloactionSummeryDetails];
    }
    
    if (self.fromTwentyField) {
        [self setleftNavigationButton];
        self.currentCountry = [self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryCode];
    }
    
    
    TITokenField *textField = [[TITokenField alloc]initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, 30)];
    self.tokenTextField = textField;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Relocation Considerations"];

}

-(void)viewDidDisappear:(BOOL)animated{
    [CLRelocationObject cancelRelocationSummeryRequest];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.relocObj) {
        return 2;
    }
    else{
        return 0;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == CLRelocationWithinCountryIndex) {
        if ([[self.nominatedLocationWithinCountryDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
            if (self.fromTwentyField || !self.indiaOrAus) {
                return 4;
            }
            else{
                return 9;
            }
        }
        else{
            return 3;
        }
    }
    else if (section == CLRelocationOutSideCountryIndex){
        if ([[self.specificNominatedLocations objectForKey:kCLRelocationCheckedKey]boolValue]) {
            if (self.fromTwentyField || !self.indiaOrAus) {
                return 4;
            }
            else{
                return 4;
            }
        }
        else{
            return 2;
        }
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case CLRelocationWithinCountryIndex:{
            switch (indexPath.row) {
                case CLWorkOnlyInIndex:{
                    UITableViewCell *firstCell = [tableView dequeueReusableCellWithIdentifier:@"firstCell"];
                    if (firstCell == nil) {
                        firstCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"firstCell"];
                        firstCell.textLabel.font = [UIFont systemFontOfSize:13];
                        firstCell.textLabel.numberOfLines = 0;
                        firstCell.selectionStyle = UITableViewCellSelectionStyleNone;
                    }
                    //                    if (self.fromTwentyField) {
                    //                        firstCell.textLabel.text = [NSString stringWithFormat:@"I only want to work in %@", [self.currentLocationDictionary objectForKey:@"jobLocationName"]];
                    //                    } else{
                    firstCell.textLabel.text = [self.workInLocationDict objectForKey:kClRelocationBoolValueKey];
                    //                    }
                    
                    if ([[self.workInLocationDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        firstCell.accessoryType = UITableViewCellAccessoryCheckmark;
                    }
                    else{
                        firstCell.accessoryType = UITableViewCellAccessoryNone;
                    }
                    return firstCell;
                }
                    break;
                case CLWorkAnyWhereWithinCountryIndex:{
                    UITableViewCell *secondCell = [tableView dequeueReusableCellWithIdentifier:@"secondCell"];
                    if (secondCell == nil) {
                        secondCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"secondCell"];
                        secondCell.textLabel.font = [UIFont systemFontOfSize:13];
                        secondCell.textLabel.numberOfLines = 0;
                        secondCell.selectionStyle = UITableViewCellSelectionStyleNone;
                    }
                    //                    if (self.fromTwentyField) {
                    //                        secondCell.textLabel.text = [NSString stringWithFormat:@"I would consider working anywhere within %@", [self.currentLocationDictionary objectForKey:@"jobLocationCountryName"]];
                    //                    } else{
                    secondCell.textLabel.text = [self.anywhereWithinCountryDict objectForKey:kClRelocationBoolValueKey];
                    //                    }
                    
                    if ([[self.anywhereWithinCountryDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        secondCell.accessoryType = UITableViewCellAccessoryCheckmark;
                        
                    }
                    else{
                        secondCell.accessoryType = UITableViewCellAccessoryNone;
                        
                    }
                    return secondCell;
                }
                    break;
                case CLNominatedLocationWithinCountry:{
                    UITableViewCell *thirdCell = [tableView dequeueReusableCellWithIdentifier:@"thirdCell"];
                    if (thirdCell == nil) {
                        thirdCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"thirdCell"];
                        thirdCell.textLabel.font = [UIFont systemFontOfSize:13];
                        thirdCell.textLabel.numberOfLines = 0;
                        thirdCell.selectionStyle = UITableViewCellSelectionStyleNone;
                    }
                    //                    if (self.fromTwentyField) {
                    //                        thirdCell.textLabel.text = [NSString stringWithFormat:@"I would consider working in a nominated location(s) within %@", [self.currentLocationDictionary objectForKey:@"jobLocationCountryName"]];
                    //                    } else{
                    thirdCell.textLabel.text = [self.nominatedLocationWithinCountryDict objectForKey:kClRelocationBoolValueKey];
                    if (self.nominatedLocationSelected) {
                        thirdCell.detailTextLabel.numberOfLines = 0;
                        thirdCell.detailTextLabel.font = [UIFont systemFontOfSize:12];
                        thirdCell.detailTextLabel.text = @"\nSelect one or multiple locations depending on where you want to work";
                    }
                    else{
                        thirdCell.detailTextLabel.text = @"";
                    }
                    //                    }
                    
                    if ([[self.nominatedLocationWithinCountryDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        thirdCell.accessoryType = UITableViewCellAccessoryCheckmark;
                        
                    }
                    else{
                        thirdCell.accessoryType = UITableViewCellAccessoryNone;
                    }
                    return thirdCell;                }
                    break;
                case CLRegionIndexWithInCountryIndex:{
                    if (self.fromTwentyField || !self.indiaOrAus) {
                        CLTappableTextViewCell *townsCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"townsCell"];
                        townsCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        if (!self.indiaOrAus) {
                            if ([self.relocObj.currentCountry isEqualToString:@"AUS"]) {
                                [townsCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for townsCell")];
                            }
                            else{
                                [townsCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for townsCell")];
                            }
                        }
                        else{
                            if ([self.currentCountry isEqualToString:@"AUS"]) {
                                [townsCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for townsCell")];
                            }
                            else{
                                [townsCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for townsCell")];
                            }
                        }
                        
                        [townsCell setCellText:[self getStringForCellAtindex:indexPath]];
                        [townsCell setCellFont:[UIFont systemFontOfSize:13]];
                        [townsCell setCellIndexPath:indexPath];
                        townsCell.delegate = self;
                        return townsCell;
                    }
                    else{
                        CLTappableTextViewCell *regionCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"regionCell"];
                        regionCell.selectionStyle=UITableViewCellSelectionStyleNone;
                        [regionCell setCellPlaceHolderText:NSLocalizedString(@"Region(s)", @"placeholder for region cell")];
                        
                        [regionCell setCellFont:[UIFont systemFontOfSize:13]];
                        [regionCell setCellIndexPath:indexPath];
                        regionCell.delegate = self;
                        if ([self.currentCountry isKindOfClass:[NSNull class]]) {
                            self.currentCountry = @"";
                        }
                        if ([self.currentCountry isEqualToString:@"AUS"] && indexPath.section == 0) {
                            regionCell.userInteractionEnabled = NO;
                            self.selectedRegionDictArray = nil;
                            [regionCell disableCellField];
                        }
                        [regionCell setCellText:[self getStringForCellAtindex:indexPath]];
                        return regionCell;
                    }
                    
                }
                    break;
                case ClStateWithInCountryIndex:{
                    CLTappableTextViewCell *stateCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"stateCell"];
                    stateCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [stateCell setCellPlaceHolderText:NSLocalizedString(@"State(s)", @"placeholder for state cell")];
                    [stateCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [stateCell setCellFont:[UIFont systemFontOfSize:13]];
                    [stateCell setCellIndexPath:indexPath];
                    stateCell.delegate = self;
                    return stateCell;
                }
                    break;
                case CLMetroWithInCountryIndex:{
                    CLTappableTextViewCell *metroCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"metroCell"];
                    metroCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        [metroCell setCellPlaceHolderText:NSLocalizedString([self.ausArray objectAtIndex:[indexPath row]-3], @"placeholder for metroCell")];
                    }
                    else{
                        [metroCell setCellPlaceHolderText:NSLocalizedString([self.indArray objectAtIndex:[indexPath row]-3], @"placeholder for metroCell")];
                    }
                    [metroCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [metroCell setCellFont:[UIFont systemFontOfSize:13]];
                    [metroCell setCellIndexPath:indexPath];
                    metroCell.delegate = self;
                    return metroCell;
                }
                    break;
                case ClMetroClusterWithInCountryIndex:{
                    CLTappableTextViewCell *metroClurterCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"metroClurterCell"];
                    metroClurterCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        [metroClurterCell setCellPlaceHolderText:NSLocalizedString([self.ausArray objectAtIndex:[indexPath row]-3], @"placeholder for metroClurterCell")];
                    }
                    else{
                        [metroClurterCell setCellPlaceHolderText:NSLocalizedString([self.indArray objectAtIndex:[indexPath row]-3], @"placeholder for metroClurterCell")];
                    }
                    
                    [metroClurterCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [metroClurterCell setCellFont:[UIFont systemFontOfSize:13]];
                    [metroClurterCell setCellIndexPath:indexPath];
                    metroClurterCell.delegate = self;
                    return metroClurterCell;
                }
                    break;
                case ClTierTwoCWithInCountryIndex:{
                    CLTappableTextViewCell *tierTwoCityCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"tierTwoCityCell"];
                    tierTwoCityCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        [tierTwoCityCell setCellPlaceHolderText:NSLocalizedString([self.ausArray objectAtIndex:[indexPath row]-3], @"placeholder for tierTwoCityCell")];
                    }
                    else{
                        [tierTwoCityCell setCellPlaceHolderText:NSLocalizedString([self.indArray objectAtIndex:[indexPath row]-3], @"placeholder for tierTwoCityCell")];
                    }
                    
                    [tierTwoCityCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [tierTwoCityCell setCellFont:[UIFont systemFontOfSize:13]];
                    [tierTwoCityCell setCellIndexPath:indexPath];
                    tierTwoCityCell.delegate = self;
                    return tierTwoCityCell;
                }
                    break;
                case ClTownsOrVillagesWithInCountryIndex:{
                    CLTappableTextViewCell *townsCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"townsCell"];
                    townsCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        [townsCell setCellPlaceHolderText:NSLocalizedString([self.ausArray objectAtIndex:[indexPath row]-3], @"placeholder for townsCell")];
                    }
                    else{
                        [townsCell setCellPlaceHolderText:NSLocalizedString([self.indArray objectAtIndex:[indexPath row]-3], @"placeholder for townsCell")];
                    }
                    
                    [townsCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [townsCell setCellFont:[UIFont systemFontOfSize:13]];
                    [townsCell setCellIndexPath:indexPath];
                    townsCell.delegate = self;
                    return townsCell;
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
        case CLRelocationOutSideCountryIndex:{
            switch (indexPath.row) {
                case CLAnywhereOutsideCountry:{
                    UITableViewCell *secondCell = [tableView dequeueReusableCellWithIdentifier:@"relocationCell"];
                    if (secondCell == nil) {
                        secondCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"relocationCell"];
                        secondCell.textLabel.font = [UIFont systemFontOfSize:13];
                        secondCell.textLabel.numberOfLines = 0;
                        secondCell.selectionStyle = UITableViewCellSelectionStyleNone;
                    }
                    if (self.fromTwentyField) {
                        secondCell.textLabel.text = [NSString stringWithFormat:@"Anywhere Outside %@", [self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryName]];
                    } else{
                        secondCell.textLabel.text = [self.anywhereOutsideCountry objectForKey:kClRelocationBoolValueKey];
                    }
                    
                    if ([[self.anywhereOutsideCountry objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        secondCell.accessoryType = UITableViewCellAccessoryCheckmark;
                    }
                    else{
                        secondCell.accessoryType = UITableViewCellAccessoryNone;                    }
                    return secondCell;
                }
                    break;
                case CLSpecificNominatedLocationIndex:{
                    UITableViewCell *secondCell = [tableView dequeueReusableCellWithIdentifier:@"relocationCell"];
                    if (secondCell == nil) {
                        secondCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"relocationCell"];
                        secondCell.textLabel.font = [UIFont systemFontOfSize:13];
                        secondCell.textLabel.numberOfLines = 0;
                        secondCell.selectionStyle = UITableViewCellSelectionStyleNone;
                    }
                    secondCell.textLabel.text = [self.specificNominatedLocations objectForKey:kClRelocationBoolValueKey];
                    if ([[self.specificNominatedLocations objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        secondCell.accessoryType = UITableViewCellAccessoryCheckmark;
                    }
                    else{
                        secondCell.accessoryType = UITableViewCellAccessoryNone;
                    }
                    return secondCell;                }
                    break;
                    
                case CLRegionOutsideCountryIndex:{
                    //                    if (self.fromTwentyField||!self.indiaOrAus) {
                    CLTappableTextViewCell *countryCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"countryCell"];
                    countryCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [countryCell setCellPlaceHolderText:NSLocalizedString(@"Country(s)", @"placeholder for countryCell")];
                    [countryCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [countryCell setCellFont:[UIFont systemFontOfSize:13]];
                    [countryCell setCellIndexPath:indexPath];
                    countryCell.delegate = self;
                    return countryCell;
                    //                    }
                    //                    else{
                    //                        CLTappableTextViewCell *regionCellout = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"regionCellOut"];
                    //                        regionCellout.selectionStyle=UITableViewCellSelectionStyleNone;
                    //                        [regionCellout setCellPlaceHolderText:NSLocalizedString(@"Region(s)", @"placeholder for regionCell")];
                    //                        [regionCellout setCellText:[self getStringForCellAtindex:indexPath]];
                    //                        [regionCellout setCellFont:[UIFont systemFontOfSize:13]];
                    //                        [regionCellout setCellIndexPath:indexPath];
                    //                        regionCellout.delegate = self;
                    //                        return regionCellout;
                    //                    }
                }
                    break;
                case CLSubregionIndex:{
                    //                    CLTappableTextViewCell *subRegionCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"subRegionCell"];
                    //                    subRegionCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    //                    [subRegionCell setCellPlaceHolderText:NSLocalizedString(@"Sub Region(s)", @"placeholder for subRegionCell")];
                    //                    [subRegionCell setCellText:[self getStringForCellAtindex:indexPath]];
                    //                    [subRegionCell setCellFont:[UIFont systemFontOfSize:13]];
                    //                    [subRegionCell setCellIndexPath:indexPath];
                    //                    subRegionCell.delegate = self;
                    //                    return subRegionCell;
                    CLTappableTextViewCell *locationCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"locationCell"];
                    locationCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [locationCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for locationCell")];
                    [locationCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [locationCell setCellFont:[UIFont systemFontOfSize:13]];
                    [locationCell setCellIndexPath:indexPath];
                    locationCell.delegate = self;
                    return locationCell;
                    
                }
                    break;
                case ClCountriesIndex:{
                    CLTappableTextViewCell *countryCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"countryCell"];
                    countryCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [countryCell setCellPlaceHolderText:NSLocalizedString(@"Country(s)", @"placeholder for countryCell")];
                    [countryCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [countryCell setCellFont:[UIFont systemFontOfSize:13]];
                    [countryCell setCellIndexPath:indexPath];
                    countryCell.delegate = self;
                    return countryCell;
                    
                }
                    break;
                case CLLocationsIndex:{
                    CLTappableTextViewCell *locationCell = (CLTappableTextViewCell*)[self.tableView dequeueReusableCellWithIdentifier:@"locationCell"];
                    locationCell.selectionStyle=UITableViewCellSelectionStyleNone;
                    [locationCell setCellPlaceHolderText:NSLocalizedString(@"Location(s)", @"placeholder for locationCell")];
                    [locationCell setCellText:[self getStringForCellAtindex:indexPath]];
                    [locationCell setCellFont:[UIFont systemFontOfSize:13]];
                    [locationCell setCellIndexPath:indexPath];
                    locationCell.delegate = self;
                    return locationCell;
                    
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        default:
            break;
    }
    return nil;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    //    return [self.sectionHeadings objectAtIndex:section];
    NSString *title;
    if (self.fromTwentyField) {
        if (section == 0) {
            title = [NSString stringWithFormat:@"Within %@",[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryName]];
        }
        else if (section == 1) {
            title = [NSString stringWithFormat:@"Outside %@",[self.currentLocationDictionary objectForKey:kCLRelocationjobLocationCountryName]];
        }
    }
    else{
        if (section == 0) {
            title = [self.workInLocationDict objectForKey:@"heading"];
        }
        else if (section == 1){
            title = [self.anywhereOutsideCountry objectForKey:@"heading"];
        }
    }
    return title;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == CLRelocationWithinCountryIndex) {
        switch (indexPath.row) {
            case CLNominatedLocationWithinCountry:{
                if (self.nominatedLocationSelected) {
                    return 100;
                }
                else{
                    return 55;
                }
            }
                break;
            case CLRegionIndexWithInCountryIndex:
            case ClStateWithInCountryIndex:
            case CLMetroWithInCountryIndex:
            case ClMetroClusterWithInCountryIndex:
            case ClTierTwoCWithInCountryIndex:
            case ClTownsOrVillagesWithInCountryIndex:
                return MAX(44, [self getHeightForTokenFieldWithText:[self getStringForCellAtindex:indexPath]]+10);
                break;
                
            default:
                break;
        }
    }
    else if (indexPath.section == CLRelocationOutSideCountryIndex){
        switch (indexPath.row) {
            case CLRegionOutsideCountryIndex:
            case CLSubregionIndex:
            case ClCountriesIndex:
            case CLLocationsIndex:
                return MAX(44, [self getHeightForTokenFieldWithText:[self getStringForCellAtindex:indexPath]]+10);
                break;
                
            default:
                break;
        }
    }
    
    return 44;
}

-(CGFloat)getHeightForTokenFieldWithText:(NSString*)text{
    [self.tokenTextField setFont:[UIFont systemFontOfSize:13]];
    [self.tokenTextField setPromptText:nil];
    [self.tokenTextField removeAllTokens];
    [self.tokenTextField addTokensWithTitleList:text];
    [self.tokenTextField layoutTokensAnimated:NO];
    return self.tokenTextField.bounds.size.height;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case CLRelocationWithinCountryIndex:{
            switch (indexPath.row) {
                case CLWorkOnlyInIndex:
                    if (![[self.workInLocationDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        self.nominatedLocationSelected = NO;
                        [self.workInLocationDict setValue:[NSString stringWithFormat:@"%d",1] forKey:kCLRelocationCheckedKey];
                        [self.anywhereWithinCountryDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                        [self.nominatedLocationWithinCountryDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                    }
                    break;
                case CLWorkAnyWhereWithinCountryIndex:{
                    if (![[self.anywhereWithinCountryDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        self.nominatedLocationSelected = NO;
                        [self.anywhereWithinCountryDict setValue:[NSString stringWithFormat:@"%d",1] forKey:kCLRelocationCheckedKey];
                        [self.workInLocationDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                        [self.nominatedLocationWithinCountryDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                    }
                }
                    break;
                case CLNominatedLocationWithinCountry:{
                    if (![[self.nominatedLocationWithinCountryDict objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        self.nominatedLocationSelected = YES;
                        [self.nominatedLocationWithinCountryDict setValue:[NSString stringWithFormat:@"%d",1] forKey:kCLRelocationCheckedKey];
                        [self.workInLocationDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                        [self.anywhereWithinCountryDict setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
        case CLRelocationOutSideCountryIndex:{
            switch (indexPath.row) {
                case CLAnywhereOutsideCountry:{
                    if (![[self.anywhereOutsideCountry objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        [self.anywhereOutsideCountry setValue:[NSString stringWithFormat:@"%d",1] forKey:kCLRelocationCheckedKey];
                        [self.specificNominatedLocations setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                    }
                }
                    break;
                case CLSpecificNominatedLocationIndex:{
                    if (![[self.specificNominatedLocations  objectForKey:kCLRelocationCheckedKey]boolValue]) {
                        [self.specificNominatedLocations setValue:[NSString stringWithFormat:@"%d",1] forKey:kCLRelocationCheckedKey];
                        [self.anywhereOutsideCountry setValue:[NSString stringWithFormat:@"%d",0] forKey:kCLRelocationCheckedKey];
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        default:
            break;
    }
    
    [self reloadTableWithAnimation:YES];
}


-(void) cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLRelocationWithinCountryIndex) {
        switch (indexPath.row) {
            case CLRegionIndexWithInCountryIndex:{
                
                
                if (self.fromTwentyField||!self.indiaOrAus) {
                    CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                    regionController.delegate = self;
                    [regionController setFromTwentyField:self.fromTwentyField];
                    if (self.fromTwentyField) {
                        [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                    }
                    else{
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                        [regionController setCurrentLocationDictionary:dict];
                    }
                    NSIndexPath *indexPaths = [NSIndexPath indexPathForRow:8 inSection:0];
                    [regionController setSelectedIndex:indexPaths];
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        regionController.titleString = NSLocalizedString(@"Suburb(s)/Town(s)", @"title");
                    }
                    else{
                        regionController.titleString = NSLocalizedString(@"Cities/Towns/Villages", @"title");
                    }
                    [regionController setSelectedFieldsValuePassedOn:self.selectedTownOrVillagesDictArray];
                    UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                    [self presentViewController:regionNav animated:YES completion:nil];
                }
                else{
                    CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                    regionController.delegate = self;
                    [regionController setFromTwentyField:self.fromTwentyField];
                    if (self.fromTwentyField) {
                        [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                    }
                    else{
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                        [regionController setCurrentLocationDictionary:dict];
                    }
                    
                    regionController.selectedIndex = indexPath;
                    if ([self.currentCountry isEqualToString:@"AUS"]) {
                        regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                    }
                    else{
                        regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                    }
                    [regionController setSelectedFieldsValuePassedOn:self.selectedRegionDictArray];
                    UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                    [self presentViewController:regionNav animated:YES completion:nil];
                }
                
            }
                break;
            case ClStateWithInCountryIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                if ([self.currentCountry isEqualToString:@"AUS"]) {
                    regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                }
                else{
                    regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                }
                [regionController setSelectedFieldsValuePassedOn:self.selectedStateDictArray];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case CLMetroWithInCountryIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                if ([self.currentCountry isEqualToString:@"AUS"]) {
                    regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                }
                else{
                    regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                }
                [regionController setSelectedFieldsValuePassedOn:self.selectedMetroDictArray];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case ClMetroClusterWithInCountryIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                if ([self.currentCountry isEqualToString:@"AUS"]) {
                    regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                }
                else{
                    regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                }
                [regionController setSelectedFieldsValuePassedOn:self.selectedMetroClusterDictArray];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case ClTierTwoCWithInCountryIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                if ([self.currentCountry isEqualToString:@"AUS"]) {
                    regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                }
                else{
                    regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                }
                [regionController setSelectedFieldsValuePassedOn:self.selectedTierTwoCitiesDictArray];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case ClTownsOrVillagesWithInCountryIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                if ([self.currentCountry isEqualToString:@"AUS"]) {
                    regionController.titleString = NSLocalizedString([self.ausArray objectAtIndex:indexPath.row-3], @"title");
                }
                else{
                    regionController.titleString = NSLocalizedString([self.indArray objectAtIndex:indexPath.row-3], @"title");
                }
                [regionController setSelectedFieldsValuePassedOn:self.selectedTownOrVillagesDictArray];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
                
                
            default:
                break;
        }
        
    }
    else if (indexPath.section == CLRelocationOutSideCountryIndex){
        switch (indexPath.row) {
            case CLRegionOutsideCountryIndex:{
                //                if (self.fromTwentyField||!self.indiaOrAus) {
                if (YES) {
                    
                    CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                    regionController.delegate = self;
                    [regionController setFromTwentyField:self.fromTwentyField];
                    if (self.fromTwentyField) {
                        [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                    }
                    else{
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                        [regionController setCurrentLocationDictionary:dict];
                    }
                    
                    NSIndexPath *indePaths = [NSIndexPath indexPathForRow:4 inSection:1];
                    [regionController setSelectedIndex:indePaths];
                    [regionController setSelectedFieldsValuePassedOn:self.countries];
                    UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                    [self presentViewController:regionNav animated:YES completion:nil];
                    
                    //                    CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                    //                    regionController.delegate = self;
                    //                    [regionController setFromTwentyField:self.fromTwentyField];
                    //                    if (self.fromTwentyField) {
                    //                        [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                    //                    }
                    //                    else{
                    //                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    //                        [regionController setCurrentLocationDictionary:dict];
                    //                    }
                    //
                    //                    NSIndexPath *indePaths = [NSIndexPath indexPathForRow:5 inSection:1];
                    //                    [regionController setSelectedIndex:indePaths];
                    //                    [regionController setSelectedFieldsValuePassedOn:self.locations];
                    //                    UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                    //                    [self presentViewController:regionNav animated:YES completion:nil];
                }
                else{
                    CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                    regionController.delegate = self;
                    [regionController setFromTwentyField:self.fromTwentyField];
                    if (self.fromTwentyField) {
                        [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                    }
                    else{
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                        [regionController setCurrentLocationDictionary:dict];
                    }
                    
                    [regionController setSelectedIndex:indexPath];
                    [regionController setSelectedFieldsValuePassedOn:self.regionOutsideCountry];
                    UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                    [self presentViewController:regionNav animated:YES completion:nil];
                }
                
            }
                break;
            case CLSubregionIndex:{
                //                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                //                regionController.delegate = self;
                //                [regionController setFromTwentyField:self.fromTwentyField];
                //                if (self.fromTwentyField) {
                //                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                //                }
                //                else{
                //                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                //                    [regionController setCurrentLocationDictionary:dict];
                //                }
                //
                //                [regionController setSelectedIndex:indexPath];
                //                [regionController setSelectedFieldsValuePassedOn:self.subregionOutsideCountry];
                //                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                //                [self presentViewController:regionNav animated:YES completion:nil];
                
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                NSIndexPath *indePaths = [NSIndexPath indexPathForRow:5 inSection:1];
                [regionController setSelectedIndex:indePaths];
                [regionController setSelectedFieldsValuePassedOn:self.locations];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case ClCountriesIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                [regionController setSelectedFieldsValuePassedOn:self.countries];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
            case CLLocationsIndex:{
                CLFieldEditViewController *regionController = [[CLFieldEditViewController alloc]initWithNibName:@"CLFieldEditViewController" bundle:[NSBundle mainBundle]];
                regionController.delegate = self;
                [regionController setFromTwentyField:self.fromTwentyField];
                if (self.fromTwentyField) {
                    [regionController setCurrentLocationDictionary:self.currentLocationDictionary];
                }
                else{
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:self.relocObj.currentCountry,kCLRelocationjobLocationCountryCode, @"",kCLRelocationjobLocationCountryName, nil];
                    [regionController setCurrentLocationDictionary:dict];
                }
                
                [regionController setSelectedIndex:indexPath];
                [regionController setSelectedFieldsValuePassedOn:self.locations];
                UINavigationController *regionNav = [[UINavigationController alloc]initWithRootViewController:regionController];
                [self presentViewController:regionNav animated:YES completion:nil];
                
            }
                break;
                
            default:
                break;
        }
    }
    
}

-(void)addSelectedFieldsDictArray:(NSMutableArray *)array to:(NSIndexPath*)index{
    if (index.section ==  0) {
        switch (index.row) {
            case CLRegionIndexWithInCountryIndex:
                self.selectedRegionDictArray = array;
                break;
            case ClStateWithInCountryIndex:
                self.selectedStateDictArray = array;
                break;
            case CLMetroWithInCountryIndex:
                self.selectedMetroDictArray = array;
                break;
            case ClMetroClusterWithInCountryIndex:
                self.selectedMetroClusterDictArray = array;
                break;
            case ClTierTwoCWithInCountryIndex:
                self.selectedTierTwoCitiesDictArray = array;
                break;
            case ClTownsOrVillagesWithInCountryIndex:
                self.selectedTownOrVillagesDictArray = array;
                break;
                
            default:
                break;
        }
    }
    else if (index.section == 1){
        switch (index.row) {
            case 2:
                self.regionOutsideCountry = array;
                break;
            case 3:
                self.subregionOutsideCountry = array;
                break;
            case 4:
                self.countries = array;
                break;
            case 5:
                self.locations = array;
                break;
                
            default:
                break;
        }
    }
    
    
    [self.tableView reloadData];
}


-(NSString*)getStringForCellAtindex:(NSIndexPath*)indexPath{
    NSString *string =[[NSString alloc]init];
    if (indexPath.section == CLRelocationWithinCountryIndex) {
        switch (indexPath.row) {
            case CLRegionIndexWithInCountryIndex:{
                if (self.fromTwentyField||!self.indiaOrAus) {
                    for (NSMutableDictionary *dict in self.selectedTownOrVillagesDictArray) {
                        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                    }
                }
                else{
                    for (NSMutableDictionary *dict in self.selectedRegionDictArray) {
                        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                    }
                }
            }
                break;
            case ClStateWithInCountryIndex:{
                for (NSMutableDictionary *dict in self.selectedStateDictArray) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case CLMetroWithInCountryIndex:{
                for (NSMutableDictionary *dict in self.selectedMetroDictArray) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case ClMetroClusterWithInCountryIndex:{
                for (NSMutableDictionary *dict in self.selectedMetroClusterDictArray) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case ClTierTwoCWithInCountryIndex:{
                for (NSMutableDictionary *dict in self.selectedTierTwoCitiesDictArray) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case ClTownsOrVillagesWithInCountryIndex:{
                for (NSMutableDictionary *dict in self.selectedTownOrVillagesDictArray) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
                
            default:
                break;
        }
    }
    else if (indexPath.section == CLRelocationOutSideCountryIndex){
        switch (indexPath.row) {
            case CLRegionOutsideCountryIndex:{
                //                if (self.fromTwentyField||!self.indiaOrAus) {
                if (YES) {
                    for (NSMutableDictionary *dict in self.countries) {
                        //                        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                    }
                }
                else{
                    for (NSMutableDictionary *dict in self.regionOutsideCountry) {
                        string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                    }
                }
            }
                break;
            case CLSubregionIndex:{
                for (NSMutableDictionary *dict in self.locations) {
                    //                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case ClCountriesIndex:{
                for (NSMutableDictionary *dict in self.countries) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
            case CLLocationsIndex:{
                for (NSMutableDictionary *dict in self.locations) {
                    string = [string stringByAppendingString:[NSString stringWithFormat:@"%@|",[dict objectForKey:kCLRelocationLocationKey]]];
                }
            }
                break;
                
            default:
                break;
        }
    }
    return string;
}



-(void)reloadTableWithAnimation:(BOOL)boolVal{
    if (boolVal) {
        [UIView transitionWithView:self.tableView
                          duration:0.3f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^(void) {
                            [self.tableView reloadData];
                        } completion:NULL];
    }else{
        [self.tableView reloadData];
    }
}

-(void)saveAllTheArrays{
    
    self.sectionHeadings = [[NSArray alloc]initWithObjects:[NSString stringWithFormat:NSLocalizedString(@"Within %@", @"section title"),self.currentCountry],[NSString stringWithFormat:NSLocalizedString(@"Outside %@", @"section title"),self.currentCountry], nil];
    
    self.ausArray = [[NSArray alloc]initWithObjects:@"Region(s)",@"State(s)",@"Region(s)",@"City(s)",@"City Cluster(s)",@"Suburb Towns(s)", nil];
    self.indArray = [[NSArray alloc]initWithObjects:@"Region(s)",@"State(s)",@"Metro(s)",@"Metro Cluster(s)",@"Tier2 Cities",@"Town(s)/Village(s)", nil];
    
    //    self.firstSectionFields = [[NSArray alloc]initWithObjects:[NSString stringWithFormat:NSLocalizedString(@"I only want to work in %@", @"section fields"), self.currentCity],[NSString stringWithFormat:NSLocalizedString(@"I would consider working anywhere within %@", @"section fields"), self.currentCountry],[NSString stringWithFormat:NSLocalizedString(@"I would consider working in a nominated location(s) within %@", @"section fields"), self.currentCountry], nil];
    
    //    self.secondSectionFields = [[NSArray alloc]initWithObjects:[NSString stringWithFormat:NSLocalizedString(@"I would consider jobs outside %@", @"section fields"), self.currentCountry],[NSString stringWithFormat:NSLocalizedString(@"Where are you willing to move outside %@", @"section fields"), self.currentCountry], nil];
    
}

-(void)reloactionSummeryDetails{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading jobs");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.navigationController.view animated:YES];
    [CLRelocationObject RelocationSummaryForUser:[CLUserObject currentUser].userID lang:@"en" fromTwentyField:self.fromTwentyField currentLocationFromTwentyField:self.currentLocationDictionary success:^(CLRelocationObject *relocObj){
        self.relocObj=relocObj;
        if ([relocObj.currentCountry isEqualToString:@"IND"]||[relocObj.currentCountry isEqualToString:@"AUS"]) {
            self.indiaOrAus = YES;
        }
        else{
            self.indiaOrAus=NO;
        }
        self.nominatedLocationSelected = [[self.relocObj.nominatedLocationsWithinCountry objectForKey:@"checked"]boolValue];
        [self setAllTheFields];
        [self.tableView reloadData];
        if (self.selectedRow != 0) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:_selectedRow];
            [self.tableView scrollToRowAtIndexPath:indexPath
                                           atScrollPosition:UITableViewScrollPositionTop
                                                   animated:NO];
        }
        _selectedRow = 0;
        [progressHUD hideWithAnimation:YES];
    }failure:^(NSString *error){
        [progressHUD hideWithAnimation:YES];
        [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't Load Relocation Considerations. Please try again later.", @"Error message when relocation cannot be loaded") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        
    }];
    
}

-(void)setAllTheFields{
    self.currentCountry = self.relocObj.currentCountry;
    self.workInLocationDict = [[NSMutableDictionary alloc]initWithDictionary:self.relocObj.workOnlyInLocation];
    self.anywhereWithinCountryDict = [[NSMutableDictionary alloc]initWithDictionary:self.relocObj.anywhereInCountry];
    self.nominatedLocationWithinCountryDict = [[NSMutableDictionary alloc]initWithDictionary:self.relocObj.nominatedLocationsWithinCountry];
    self.selectedRegionDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.regionWithinCountry];
    self.selectedStateDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.stateWithinCountry];
    self.selectedMetroDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.metroWithinCountry];
    self.selectedMetroClusterDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.metroClusterWithCountry];
    self.selectedTierTwoCitiesDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.tierTwoCitiesWithinCountry];
    self.selectedTownOrVillagesDictArray = [[NSMutableArray alloc]initWithArray:self.relocObj.townsWithinCountry];
    self.anywhereOutsideCountry = [[NSMutableDictionary alloc]initWithDictionary:self.relocObj.anywhereOutsideCountry];
    self.specificNominatedLocations = [[NSMutableDictionary alloc]initWithDictionary:self.relocObj.specificNominatedLocations];
    self.regionOutsideCountry = [[NSMutableArray alloc]initWithArray:self.relocObj.regionOutsideCountry];
    self.subregionOutsideCountry = [[NSMutableArray alloc]initWithArray:self.relocObj.subregionOutsideCountry];
    self.countries = [[NSMutableArray alloc]initWithArray:self.relocObj.countries];
    self.locations = [[NSMutableArray alloc]initWithArray:self.relocObj.locations];
    
}

-(void)setRightNavigationButton{
    NSString *buttonTitle;
    if (self.fromTwentyField) {
        buttonTitle = @"Done";
    }
    else{
        buttonTitle = @"Save";
    }
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(buttonTitle, @"save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveAndDismissModal:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(void)setleftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(cancelbutton:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(IBAction)bttnActionSaveAndDismissModal:(id)sender{
    [self saveWorkConsiderations];
}

-(IBAction)cancelbutton:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)saveWorkConsiderations{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    
    if (self.fromTwentyField) {
        
    } else{
        
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
        progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
        progressHUD.hudView.alpha=0.9;
        [progressHUD showInView:self.view animated:YES];
        self.navigationItem.hidesBackButton=YES;
        self.navigationItem.rightBarButtonItem.enabled=NO;
    }
    
    CLRelocationObject *newRelocObj = [[CLRelocationObject alloc]init];
    newRelocObj.workOnlyInLocation = self.workInLocationDict;
    newRelocObj.anywhereInCountry = self.anywhereWithinCountryDict;
    
    NSMutableDictionary *nominatedDict = [[NSMutableDictionary alloc]initWithDictionary:self.nominatedLocationWithinCountryDict];
    [nominatedDict setValue:self.selectedRegionDictArray forKey:kClRelocationRegionKey];
    [nominatedDict setValue:self.selectedStateDictArray forKey:kCLRElocationStateKEy];
    [nominatedDict setValue:self.selectedMetroDictArray forKey:kCLRelocationMetroKEy];
    [nominatedDict setValue:self.selectedMetroClusterDictArray forKey:kCLRelocationMetroClusterKey];
    [nominatedDict setValue:self.selectedTierTwoCitiesDictArray forKey:kCLRelocationTier2CitiesKey];
    [nominatedDict setValue:self.selectedTownOrVillagesDictArray forKey:kCLRelocationTownVillages];
    
    newRelocObj.nominatedLocationsWithinCountry = nominatedDict;
    
    //    newRelocObj.regionWithinCountry = self.selectedRegionDictArray;
    //    newRelocObj.stateWithinCountry = self.selectedStateDictArray;
    //    newRelocObj.metroWithinCountry = self.selectedMetroDictArray;
    //    newRelocObj.metroClusterWithCountry = self.selectedMetroClusterDictArray;
    //    newRelocObj.tierTwoCitiesWithinCountry = self.selectedTierTwoCitiesDictArray;
    //    newRelocObj.townsWithinCountry = self.selectedTownOrVillagesDictArray;
    
    newRelocObj.anywhereOutsideCountry = self.anywhereOutsideCountry;
    NSMutableDictionary *specifictNominated = [[NSMutableDictionary alloc]initWithDictionary:self.specificNominatedLocations];
    [specifictNominated setValue:self.regionOutsideCountry forKey:kCLRelocationRegionOutside];
    [specifictNominated setValue:self.subregionOutsideCountry forKey:kCLRelocationSubregionKey];
    [specifictNominated setValue:self.countries forKey:kCLRelocationCountryKey];
    [specifictNominated setValue:self.locations forKey:kCLRelocationLocationKeyOutside];
    newRelocObj.specificNominatedLocations = specifictNominated;
    
    //    newRelocObj.regionOutsideCountry = self.regionOutsideCountry;
    //    newRelocObj.subregionOutsideCountry = self.subregionOutsideCountry;
    //    newRelocObj.countries = self.countries;
    //    newRelocObj.locations = self.locations;
    
    if (self.fromTwentyField) {
        NSMutableDictionary *relocDict = [[NSMutableDictionary alloc]initWithDictionary:[CLRelocationObject jsocDictionaryFor:newRelocObj]];
        if ([self CheckRelocationOptionsAreSelected:relocDict]) {
            [self dismissViewControllerAnimated:YES completion:^{
                
                if ([_delegate respondsToSelector:@selector(relocationCompletedSelectionWith:)]) {
                    [_delegate relocationCompletedSelectionWith:relocDict];
                }
            }];
        }
        else{
            [CLCommon showAlertwithTitle:@"Warning" alertString:NSLocalizedString(@"Please Select Your Relocation Expectation", @"Error message when relocation is not selected") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    } else{
        [CLRelocationObject saveRelocationConsideration:newRelocObj forUser:[CLUserObject currentUser].userID success:^(NSString *relocID){
            [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
        }failure:^(NSString *error){
            self.navigationItem.hidesBackButton=NO;
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [progressHUD hideWithAnimation:YES];
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Relocation Consideration. Please try again later.", @"Error message when relocation Consideration cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
            
        }];
    }
    
}

-(BOOL)CheckRelocationOptionsAreSelected:(NSMutableDictionary*)dict{
    BOOL outSide = NO;
    BOOL inside = NO;
    BOOL valid = NO;
    NSMutableArray *outsideCountry = [[dict objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationOutSideCountry];
    NSMutableArray *insideCountry = [[dict objectForKey:kCLRelocationOptionsKey] objectForKey:kCLRelocationWithinCountry];
    
    for (NSMutableDictionary *dictionary in outsideCountry) {
        if ([[dictionary objectForKey:kCLRelocationCheckedKey]boolValue]) {
            outSide = YES;
            break;
        }
        
    }
    
    for (NSMutableDictionary *dictionary in insideCountry) {
        if ([[dictionary objectForKey:kCLRelocationCheckedKey]boolValue]) {
            inside = YES;
            break;
        }
        
    }
    
    if (outSide || inside) {
        valid = YES;
    }
    return valid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}



@end
