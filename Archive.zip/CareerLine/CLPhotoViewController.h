//
//  CLPhotoViewController.h
//  CareerLine
//
//  Created by CSG on 7/23/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

//@class CLPhotoViewController;
//
////Delegate Methods...
//@protocol CLPhotoViewDelegate <NSObject>
//
//@optional
//- (void)photoViewDidSingleTap:(CLPhotoViewController *)photoController forFullScreen:(BOOL)fullScreen;
//
//@end


@interface CLPhotoViewController : UIViewController<UIScrollViewDelegate>

//@property(nonatomic,weak) id <CLPhotoViewDelegate> delegate;
@property(nonatomic,assign) NSUInteger pageIndex;

+ (CLPhotoViewController *)photoViewControllerForPageIndex:(NSUInteger)pageIndex andPhotos:(NSArray*)photos;

@end
