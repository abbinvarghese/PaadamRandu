//
//  CLSalaryBenefitsViewController.h
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLCareerSalaryBenefitsObject.h"
#import "CLTappableTextViewCell.h"
#import "CLBnefitsViewController.h"
#import "CLFrequencyViewController.h"
#import "CLCurrencyViewController.h"
#import "CLAddAllowanceViewController.h"
#import "CLAddIncentivesViewController.h"

@class CLSalaryBenefitsViewController;

@protocol CLSalaryBeneftsDelegate <NSObject>

@optional
- (void)salaryBenefitsController:(CLSalaryBenefitsViewController *)controller didAddSalaryBenefits:(CLCareerSalaryBenefitsObject*)salBenefitssObj;
@end

@interface CLSalaryBenefitsViewController : UITableViewController<CLSimpleTextCellDelegate,CLTappableCellDelegate,CLTextCheckBoxCellDelegate,CLBenefitDlegate,CLFrequencyDelegate,CLCurrencyDelegate,UIPickerViewDataSource,UIPickerViewDelegate,CLAddAllowanceDelegate,CLAddIncentiveDelegate>

@property (nonatomic,weak) id <CLSalaryBeneftsDelegate> delegate;
@property (nonatomic,strong) CLCareerSalaryBenefitsObject *salBenefitssObj;
@property (nonatomic, strong) NSMutableDictionary *selectedCountry;
@end
 