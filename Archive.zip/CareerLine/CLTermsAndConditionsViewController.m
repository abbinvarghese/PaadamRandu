//
//  CLTermsAndConditionsViewController.m
//  CareerLine
//
//  Created by Abbin on 06/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLTermsAndConditionsViewController.h"

@interface CLTermsAndConditionsViewController ()

@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property(nonatomic,assign) BOOL firstLoad;

@end

@implementation CLTermsAndConditionsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.firstLoad = YES;
    self.title = NSLocalizedString(self.titleString, @"Terms & Conditions title");
    self.activityIndicator.hidden = YES;
    [self setRightNavigationButton];
    // Do any additional setup after loading the view from its nib.
    NSURL *URL = [NSURL URLWithString:[self.stringURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:URL];
    [self.webView loadRequest:urlRequest];
    
    NSString *googleAnaText = [NSString stringWithFormat:@"CareerLine IOS - %@",self.titleString];
    [CLCommon sentScreenNameToGoogleAnalytics:googleAnaText];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setRightNavigationButton{
    UIBarButtonItem *RightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @" modal done button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnDoneActionDismissModal:)];
    self.navigationItem.rightBarButtonItem=RightNavBttn;
}

-(IBAction)bttnDoneActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    self.activityIndicator.hidden = YES;
    [self.activityIndicator stopAnimating];
}

-(void)webViewDidStartLoad:(UIWebView *)webView{
    self.activityIndicator.hidden = NO;
    [self.activityIndicator startAnimating];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self.activityIndicator stopAnimating];
    self.activityIndicator.hidden = YES;
    if ([CLCommon isOSversionLessThan8]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Failed to load Terms & Conditions", @"alert title") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"cancel button title") otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Failed to load Terms & Conditions", @"alert title") message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @" modal done button title") style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if (!self.firstLoad)
        return FALSE;
    
    _firstLoad = FALSE;
    return TRUE;
}


@end
