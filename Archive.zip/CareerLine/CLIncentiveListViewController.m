//
//  CLIncentiveListViewController.m
//  CareerLine
//
//  Created by RENJITH on 20/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLIncentiveListViewController.h"

#define kCLIncentiveOtherText NSLocalizedString(@"Other", @"Other text localization")

@interface CLIncentiveListViewController ()

@property (nonatomic, retain) NSMutableArray *incentiveArray;
@property (nonatomic, retain) NSMutableDictionary *selectedIncentiveDict;
@end

@implementation CLIncentiveListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Incentive And Bonus", @"Incentive And Bonus page title text");
    self.selectedIncentiveDict = [[NSMutableDictionary alloc]initWithDictionary:self.alreadySelectedIncentives];
    self.incentiveArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getIncentiveBonusListFromDB];
     [self setLeftNavigationButton];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"5",kIncentiveBonusId,kCLIncentiveOtherText,kIncentiveBonusName,@"1",kIncentiveBonusOtherFlag, nil];
    [self.incentiveArray insertObject:dict atIndex:[self.incentiveArray count]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark Utility Methods
-(void)setLeftNavigationButton{
    UIBarButtonItem *lefttNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Dismiss allowance and loading modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionBenefitsDismiss:)];
    self.navigationItem.leftBarButtonItem=lefttNavBttn;
}

-(void)bttnActionBenefitsDismiss:(id)sender{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

-(void)bttnActionBenefitsSaveAndDismissModal:(id)sender{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:^(void){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(incentiveBonusController:didSelect:)]){
                [self.delegate incentiveBonusController:self didSelect:self.selectedIncentiveDict];
            }
            
        }];
    });
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.incentiveArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    if (self.selectedIncentiveDict !=nil) {
        if ([[self.selectedIncentiveDict objectForKey:kIncentiveBonusName] isEqualToString:[[self.incentiveArray objectAtIndex:indexPath.row] objectForKey:kIncentiveBonusName]]) {
            cell.accessoryType=UITableViewCellAccessoryCheckmark;
        }else if (indexPath.row == [self.incentiveArray count]-1){
            
            if ([[self.selectedIncentiveDict objectForKey:kIncentiveBonusOtherFlag] boolValue]) {
                
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"5",kIncentiveBonusId,kCLIncentiveOtherText,kIncentiveBonusName,@"1",kIncentiveBonusOtherFlag, nil];
                
                [self.incentiveArray insertObject:dict atIndex:[self.incentiveArray count]];
                cell.accessoryType=UITableViewCellAccessoryCheckmark;
            }
        }
        else{
            cell.accessoryType=UITableViewCellAccessoryNone;
        }
    }
    NSMutableDictionary *benefitDict = [self.incentiveArray objectAtIndex:indexPath.row];
    cell.textLabel.text=[benefitDict objectForKey:kIncentiveBonusName];
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == [self.incentiveArray count]-1) {
        if([CLCommon isOSversionLessThan8])
        {
            UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];
            enterFuncAlert.tag=88;
            enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
            [enterFuncAlert show];
        }else{
            // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
            UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                           message: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option")
                                                                    preferredStyle: UIAlertControllerStyleAlert];
            
            [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                
            }];
            UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * action){
                                                                 //Do Some action here
                                                                 UITextField *textField = alert.textFields[0];
                                                                 NSString *otherFuncText = textField.text;
                                                                 
                                                                 [self.incentiveArray removeObjectAtIndex:[self.incentiveArray count]-1];
                                                                 NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"5",kIncentiveBonusId,otherFuncText,kIncentiveBonusName,@"1",kIncentiveBonusOtherFlag, nil];
                                                                 
                                                                 self.selectedIncentiveDict = dict;
                                                                 [self.incentiveArray insertObject:dict atIndex:[self.incentiveArray count]];
                                                                 [self bttnActionBenefitsSaveAndDismissModal:nil];
                                                                 
                                                             }];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                   style: UIAlertActionStyleDefault
                                                                 handler: nil];
            
            [alert addAction: cancelAction];
            [alert addAction: okAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }else{
        self.selectedIncentiveDict = [self.incentiveArray objectAtIndex:indexPath.row];
        [self bttnActionBenefitsSaveAndDismissModal:nil];
    }
}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //ENter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            NSString *otherFuncText = [[alertView textFieldAtIndex:0] text];
            [self.incentiveArray removeObjectAtIndex:[self.incentiveArray count]-1];
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"5",kIncentiveBonusId,otherFuncText,kIncentiveBonusName,@"1",kIncentiveBonusOtherFlag, nil];
            self.selectedIncentiveDict = dict;
            [self.incentiveArray insertObject:dict atIndex:[self.incentiveArray count]];
            [self bttnActionBenefitsSaveAndDismissModal:nil];
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}
@end
