//
//  CLLicenseViewController.h
//  CareerLine
//
//  Created by RENJITH on 11/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLLicenseObject.h"
#import "CLSimpleTextCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLProfilePhotoListingGridCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectLocationViewController.h"
#import "CLTextCheckBoxCell.h"
#import "CLSelectLocationViewController.h"

@class CLLicenseViewController;

@protocol ClQualificationLicenseDeleagte<NSObject>

@optional

-(void)qualificationLicense:(CLLicenseViewController *)controller didAddLicense:(CLLicenseObject *)licensObj;

@end

@interface CLLicenseViewController : UITableViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLSimpleTextCellDelegate,HTProgressHUDDelegate,CLProfilePhotoListingGridCellDelegate,CLHeightAdjustTextCellDelegate,CLSelectLocationDelegate,CLTappableCellDelegate,CLTextCheckBoxCellDelegate>

@property (nonatomic, weak) id <ClQualificationLicenseDeleagte> delegate;
@property (nonatomic, assign) BOOL isEditMode;
@property (nonatomic, retain) CLLicenseObject *licenseObj;
@end
