//
//  CLQualificationCell.h
//  CareerLine
//
//  Created by RENJITH on 29/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLEducationObject.h"
#import "CLTrainingObject.h"
#import "CLLicenseObject.h"
#import "CLMembershipObject.h"
#import "CLCertificationObject.h"

@interface CLQualificationCell : UITableViewCell

@property (nonatomic, retain) CLEducationObject *educationObj;
@property (nonatomic, retain) CLTrainingObject *trainingObj;
@property (nonatomic, retain) CLLicenseObject *licenseObj;
@property (nonatomic, retain) CLCertificationObject *certificationObj;
@property (nonatomic, retain) CLMembershipObject *membershipObj;
@property (weak, nonatomic) IBOutlet UILabel *headingLbl;

@property (nonatomic, assign) int section;

@end
