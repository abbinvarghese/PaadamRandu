//
//  CLEducation.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLLocationObject.h"
#import "CLFileObject.h"

@interface CLEducationObject : NSObject

@property(nonatomic,strong)NSString *educationId;
@property(nonatomic,strong)NSString *course;
@property(nonatomic,strong)NSString *specialization;
@property(nonatomic,strong)NSString *institution;
@property(nonatomic,strong)CLLocationObject *location;
@property(nonatomic,strong)NSDate *fromDate;
@property(nonatomic,strong)NSDate *completionDate;
@property(nonatomic,assign) BOOL isOngoing;
@property(nonatomic,strong)NSString *educationLevel;
@property(nonatomic,strong)NSString *educationLevelId;

@property(nonatomic,strong)NSString *ratingType;
@property(nonatomic,strong)NSString *ratingTypeCode;
@property(nonatomic,strong)NSString *rating;
@property(nonatomic,strong)NSString *descption;
@property(nonatomic,strong)NSMutableArray *documentsUrl;//[(CLFileObject),(CLFileObject),...]

- (id)initWithDictionary:(NSDictionary*)dictionary;
+ (void)saveEducation:(CLEducationObject*)educationObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *eduId))success failure:(void (^)(NSString *error))failure;
@end
