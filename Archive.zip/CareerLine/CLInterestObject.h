//
//  CLInterest.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLInterestObject : NSObject

@property(nonatomic,strong)NSString *interestId;
@property(nonatomic,strong)NSMutableArray *interestArray;
@property(nonatomic,strong)NSString *interestDescription;
@property(nonatomic,strong)NSString *interestFormattedTitle;



//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

-(void)updateFormattedHobbyTitle;

//Method for saving interest of a particular user...
+ (void)saveInterest:(CLInterestObject *)interestObj ForUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *interestId))success failure:(void (^)(NSString *error))failure;

//Method for deleting interest for a particular user...
//+ (void)deleteInterestForUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for getting hobbies list..
+(void)getHobbiesListForSearchString:(NSString*)searchText andBlackListString:(NSString*)blackListString success:(void (^)(NSMutableArray *hobbiesList))success failure:(void (^)(NSString *error))failure;

//To cancel GetHobbies web service requests...
+ (void)cancelGetHobbiesRequest;

@end
