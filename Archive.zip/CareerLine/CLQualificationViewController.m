//
//  CLQualificationViewController.m
//  CareerLine
//
//  Created by RENJITH on 29/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLQualificationViewController.h"
#import "CLQualificationCell.h"
#import "CLQualificationObject.h"
#import "CLUserObject.h"
#import "CLEducationObject.h"


#define kSectionFooterBgColor [UIColor whiteColor]

typedef enum {
    CLEducationIndex = 0,
    CLTrainingIndex= 1,
    CLCertificationsIndex= 2,
    CLLicensesIndex= 3,
    CLMembershipIndex= 4
    
} CLQualificationSectionIndex;

@interface CLQualificationViewController ()

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property (nonatomic, strong) NSArray *sectionHeadings;
@property (weak, nonatomic) IBOutlet UITableView *qualificationTable;
@property (nonatomic, strong) CLQualificationObject *qualifiaction;

@property (nonatomic, strong) CLEducationObject *education;
@end

@implementation CLQualificationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    [self loadQualification];
    [self.qualificationTable reloadData];
}

-(void)viewDidAppear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Qualifications"];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [self.qualificationTable setEditing:NO animated:NO];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLQualificationObject cancelQualificationPendingRequest];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = NSLocalizedString(@"Qualifications", @"Qualification listing page heading");
    self.sectionHeadings = [[NSArray alloc]initWithObjects: NSLocalizedString(@"Education",@"education heading text"),NSLocalizedString(@"Training",@"training heading text"),NSLocalizedString(@"Certifications",@"certifications heading text"),NSLocalizedString(@"Licences",@"licences heading text"),NSLocalizedString(@"Memberships",@"memberships heading text"), nil];
    self.qualificationTable.hidden = YES;
    
}

-(void)loadQualification{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Loading...", @"Text displayed in the loading indicator while loading qualification");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    [CLQualificationObject qualificationDetailsForUser:[CLUserObject currentUser].userID success:^(CLQualificationObject *qualificationObj) {
        [progressHUD hideWithAnimation:YES];
        self.qualificationTable.hidden = NO;
        self.qualifiaction = qualificationObj;
        [self.qualificationTable reloadData];
        if (self.selectedRow != 0) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:_selectedRow];
            [self.qualificationTable scrollToRowAtIndexPath:indexPath
                                           atScrollPosition:UITableViewScrollPositionTop
                                                   animated:NO];
        }
        _selectedRow = 0;

    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

#pragma mark UiTableView Methods
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 57;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [self.sectionHeadings count];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == CLEducationIndex) {
        return [self.qualifiaction.educationArray count];
    }else if (section == CLTrainingIndex){
        return [self.qualifiaction.trainingArray count];
    }else if (section == CLCertificationsIndex){
        return [self.qualifiaction.certificationArray count];
    }else if (section == CLLicensesIndex){
        return [self.qualifiaction.licenseArray count];
    }else if (section == CLMembershipIndex){
        return [self.qualifiaction.membershipArray count];
    }else{
        return 0;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLEducationIndex) {
        CLEducationViewController *controller=[[CLEducationViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.educationObj = [self.qualifiaction.educationArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
    }else if (indexPath.section == CLTrainingIndex){
        CLTrainingViewController *controller=[[CLTrainingViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.trainingObj = [self.qualifiaction.trainingArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
    }else if (indexPath.section == CLCertificationsIndex){
        CLCertificationViewController *controller=[[CLCertificationViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.certificationObj = [self.qualifiaction.certificationArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
    }else if (indexPath.section == CLLicensesIndex){
        CLLicenseViewController *controller=[[CLLicenseViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.licenseObj = [self.qualifiaction.licenseArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
    }else if (indexPath.section == CLMembershipIndex){
        CLMembershipViewController *controller=[[CLMembershipViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = YES;
        controller.membershipObj = [self.qualifiaction.membershipArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (indexPath.section == CLEducationIndex || indexPath.section == CLTrainingIndex) {
            UIAlertView *alertViewMessage = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Warning", @"alert heading") message:NSLocalizedString(@"Deleting this Education/Training record will lead to deletion of associated data (which you've created) in your CareerLine such as Education/Training Projects/Experiences. Proceed to delete?", @"alert messgae") delegate:self cancelButtonTitle:NSLocalizedString(@"YES", @"title for cancel button") otherButtonTitles:NSLocalizedString(@"NO", @"title for cancel button"), nil];
            [alertViewMessage showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex){
                
                if (buttonIndex == 0) {
                    [self removeQualificationAtIndexPath:indexPath];
                } else{
                    
                }
                
            }];
        }
        
        else
        {
            [self removeQualificationAtIndexPath:indexPath];
        }
        
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CLQualificationCell *cell = (CLQualificationCell *)[tableView dequeueReusableCellWithIdentifier:@"qualificationCellIdentifier"];
    if (cell == nil) {
        cell = [[CLQualificationCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:@"qualificationCellIdentifier"];
    }
    cell.section = (int)indexPath.section;
    
    [tableView setAllowsSelectionDuringEditing:YES];
    
    if (indexPath.section == CLEducationIndex) {
        if ([self.qualifiaction.educationArray count])
            [tableView setEditing:YES animated:YES];

        cell.educationObj = [self.qualifiaction.educationArray objectAtIndex:indexPath.row];
    }else if (indexPath.section == CLTrainingIndex){
        
        if ([self.qualifiaction.trainingArray count])
            [tableView setEditing:YES animated:YES];

        cell.trainingObj = [self.qualifiaction.trainingArray objectAtIndex:indexPath.row];
    }else if (indexPath.section == CLCertificationsIndex){
        
        if ([self.qualifiaction.certificationArray count])
            [tableView setEditing:YES animated:YES];
        
        cell.certificationObj = [self.qualifiaction.certificationArray objectAtIndex:indexPath.row];
    }else if (indexPath.section == CLLicensesIndex){
        
        if ([self.qualifiaction.licenseArray count])
            [tableView setEditing:YES animated:YES];
        
        cell.licenseObj = [self.qualifiaction.licenseArray objectAtIndex:indexPath.row];
    }else if (indexPath.section == CLMembershipIndex){
        
        if ([self.qualifiaction.membershipArray count])
            [tableView setEditing:YES animated:YES];
        
        cell.membershipObj = [self.qualifiaction.membershipArray objectAtIndex:indexPath.row];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.headingLbl setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
    return cell;
    
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [self.sectionHeadings objectAtIndex:section];
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 35.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    return 37.0;
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
    sectionFooter.backgroundColor=kSectionFooterBgColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    button.tag=section;
    button.translatesAutoresizingMaskIntoConstraints=YES;
    [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 11, self.qualificationTable.bounds.size.width, 22);
    [sectionFooter addSubview:button];
    return sectionFooter;
    
}

#pragma mark IBActions
-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    
    if (sender.tag == CLEducationIndex) {
        CLEducationViewController *controller=[[CLEducationViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = NO;
        controller.delegate=self;
        UINavigationController *addQualificationNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:addQualificationNavigation animated:YES completion:nil];
    }else if (sender.tag == CLTrainingIndex){
        CLTrainingViewController *controller=[[CLTrainingViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = NO;
        controller.delegate=self;
        UINavigationController *addTrainingNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:addTrainingNavigation animated:YES completion:nil];
    }else if (sender.tag == CLCertificationsIndex){
        CLCertificationViewController *controller=[[CLCertificationViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = NO;
        controller.delegate=self;
        UINavigationController *addCertificationNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:addCertificationNavigation animated:YES completion:nil];
    }else if (sender.tag == CLLicensesIndex){
        CLLicenseViewController *controller=[[CLLicenseViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = NO;
        controller.delegate=self;
        UINavigationController *addLicenseNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:addLicenseNavigation animated:YES completion:nil];
    }else if (sender.tag == CLMembershipIndex){
        CLMembershipViewController *controller=[[CLMembershipViewController alloc] initWithStyle:UITableViewStylePlain];
        controller.isEditMode = NO;
        controller.delegate=self;
        UINavigationController *addMembershipNavigation=[[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:addMembershipNavigation animated:YES completion:nil];
    }
    
}

#pragma mark NSNotification Methods
-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    [self.qualificationTable reloadData];
}

#pragma mark CLQualifiactionConroller Delegate Methods
- (void)qualificationController:(CLEducationViewController *)controller didAddEducation:(CLEducationObject*)eduObj{
//    [self.qualifiaction.educationArray addObject:eduObj];
    [self.qualificationTable reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark ClQualificationTrainingDeleagte Delegate Methods
- (void)qualificationTraining:(CLTrainingViewController *)controller didAddTraining:(CLTrainingObject *)trainingObj{
//    [self.qualifiaction.trainingArray addObject:trainingObj];
    [self.qualificationTable reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark CLCertificationDelegate Delegate Methods
- (void)qualificationCertification:(CLCertificationViewController *)controller didAddCertification:(CLCertificationObject *)certftnObj{
//    [self.qualifiaction.certificationArray addObject:certftnObj];
    [self.qualificationTable reloadSections:[NSIndexSet indexSetWithIndex:2] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark ClQualificationLicenseDeleagte Delegate Methods
- (void)qualificationLicense:(CLLicenseViewController *)controller didAddLicense:(CLLicenseObject *)licensObj{
//    [self.qualifiaction.licenseArray addObject:licensObj];
    [self.qualificationTable reloadSections:[NSIndexSet indexSetWithIndex:3] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark CLQualificationMembershipDelegate Delegate Methods
- (void)qualificationMembership:(CLMembershipViewController *)controller didAddMembership:(CLMembershipObject *)memObj{
//    [self.qualifiaction.membershipArray addObject:memObj];
    [self.qualificationTable reloadSections:[NSIndexSet indexSetWithIndex:4] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark Delete Qualification
-(void)removeQualificationAtIndexPath:(NSIndexPath *)indexPath{
    
    CLEducationObject *eduObj;
    CLTrainingObject *trainingObj;
    CLCertificationObject *certiftnObj;
    CLMembershipObject *memebrshpObj;
    CLLicenseObject *licenseObj;
    
    NSString *deleteQulftnId = nil;
    if (indexPath.section == CLEducationIndex) {
        eduObj = [self.qualifiaction.educationArray objectAtIndex:indexPath.row];
        deleteQulftnId = eduObj.educationId;
    }else if (indexPath.section == CLTrainingIndex){
        trainingObj = [self.qualifiaction.trainingArray objectAtIndex:indexPath.row];
        deleteQulftnId = trainingObj.trainingId;
    }else if (indexPath.section == CLCertificationsIndex){
        certiftnObj = [self.qualifiaction.certificationArray objectAtIndex:indexPath.row];
        deleteQulftnId = certiftnObj.certificationId;
    }else if (indexPath.section == CLLicensesIndex){
        licenseObj = [self.qualifiaction.licenseArray objectAtIndex:indexPath.row];
        deleteQulftnId = licenseObj.licenseId;
    }else if (indexPath.section == CLMembershipIndex){
        memebrshpObj = [self.qualifiaction.membershipArray objectAtIndex:indexPath.row];
        deleteQulftnId = memebrshpObj.membershipId;
    }
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting qualification");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLQualificationObject deleteQualification:deleteQulftnId forUser:[CLUserObject currentUser].userID success:^{
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.hidesBackButton=NO;
        
        if (indexPath.section == CLEducationIndex) {
            [self.qualifiaction.educationArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.qualifiaction.educationArray count]==0){
                [self.qualificationTable reloadData];
            }
            else{
                [self.qualificationTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else if (indexPath.section == CLTrainingIndex){
            [self.qualifiaction.trainingArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.qualifiaction.trainingArray count]==0){
                [self.qualificationTable reloadData];
            }
            else{
                [self.qualificationTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else if (indexPath.section == CLCertificationsIndex){
            [self.qualifiaction.certificationArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.qualifiaction.certificationArray count]==0){
                [self.qualificationTable reloadData];
            }
            else{
                [self.qualificationTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else if (indexPath.section == CLLicensesIndex){
            [self.qualifiaction.licenseArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.qualifiaction.licenseArray count]==0){
                [self.qualificationTable reloadData];
            }
            else{
                [self.qualificationTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }else if (indexPath.section == CLMembershipIndex){
            [self.qualifiaction.membershipArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.qualifiaction.membershipArray count]==0){
                [self.qualificationTable reloadData];
            }
            else{
                [self.qualificationTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
        
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.hidesBackButton=NO;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}

@end
