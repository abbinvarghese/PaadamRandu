//
//  CLAddCareerHistoryViewController.m
//  CareerLine
//
//  Created by RENJITH on 22/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAddCareerHistoryViewController.h"
#import "TITokenField.h"
#import "CLCareerObject.h"
#import "NSDictionary+Additions.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "CLDocumentViewController.h"
#import "CLEmployeementTypeViewController.h"
#import "CLWorkAchievementViewController.h"
#import "CLKeyJobFactsViewController.h"
#import "CLCareerKeyJobFactsObject.h"
#import "CLSalaryBenefitsViewController.h"


#define kSectionFooterBgColor [UIColor whiteColor]
#define kCLCompanyDivisionOther NSLocalizedString(@"Other","Other text title")
#define kCLNewEntryId @"0"

#define kCLCompanyDivPickerTag 1
#define kCLJobScopePickerTag 2
#define kCLEmpContractTypePickerTag 3
#define kCLPrimarySecondaryPickerTag 4

@interface CLAddCareerHistoryViewController ()

typedef enum {
    CLCareerHistoryIndex = 0,
    CLCareerMoveReasonIndex= 1,
    CLCareerReportedToIndex= 2,
    CLCareerSelfEmployed = 3,
    CLCareerJobFactsIndex= 4,
    CLCareerSalaryBenefitsIndex= 5,
    //CLCareerProjectsExpIndex = 5,
    CLCareerMajorAchvmentsIndex = 6,
    CLCareerExpGainedIndex = 7,
    CLCareerRemarksIndex = 8,
    CLCareerDocIndex = 9
} CLCareerHistoryTableSectionIndex;

typedef enum {
    CLCareerJobTitleIndex = 0,
    CLCareerCountryIndex= 1,
    CLCareerCompanyNameIndex= 2,
    CLCareerIndustryIndex = 3,
    CLCareerBusinessDivisionIndex= 4,
    CLCareerCompanyLocationIndex= 5,
    CLCareerCompanyDescIndex = 6,
    CLCareerFromDateIndex = 7,
    CLCareerToDateIndex = 8,
    CLCareerOngoingIndex = 9
} CLCareerHistoryRowIndex;

typedef enum {
    CLCareerReasonForMoveIndex = 0,
    CLCareerFunctionIndex= 1,
    CLCareerLevelIndex= 2,
    CLCareerJobScopeIndex= 3
} CLCareerMoveReasonRowIndex;

typedef enum {
    CLCareerLineManager = 0,
    CLCareerEmployeementTypeIndex= 1,
    CLCareerEmployeementContractTypeIndex= 2,
    CLCareerPrimarySecondaryIndex= 3
} CLCareerReportedToRowIndex;

@property (strong, nonatomic)HTProgressHUD *activityIndicator;
//fields for career history
@property (strong, nonatomic) IBOutlet UIPickerView *pickerView;
@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardToolBarWithCancel;
@property (strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (nonatomic, strong) NSMutableDictionary *selectedCountry;
@property (nonatomic, strong) NSMutableArray *companyDivisionArray;
@property (nonatomic, strong) NSMutableArray *alreadySelectedReasonArray;
@property (nonatomic, strong) NSMutableArray *jobScopeArray;
@property (nonatomic, strong) NSMutableArray *workAchievmentsArray;
@property (nonatomic, strong) NSMutableArray *primarySecondaryArray;
@property (nonatomic, strong) NSMutableArray *empContractType;
@property (nonatomic, strong) NSMutableDictionary *selectedEmpContractType;
@property (nonatomic, strong) NSMutableDictionary *selectedEmpType;
@property (nonatomic, strong) NSMutableDictionary *selectedJobScope;
@property (nonatomic, strong) NSMutableDictionary *selectedcompanyDivision;
@property (nonatomic, strong) NSMutableDictionary *selectedBusinessDivision;
@property (nonatomic, strong) NSMutableDictionary *selectedIndustry;
@property (nonatomic, strong) NSMutableArray *selectedMultipleBusDiv;
@property (nonatomic, strong) NSMutableDictionary *selectedCompanyName;
@property (nonatomic, strong) NSMutableDictionary *selectedOtherCompany;
@property (nonatomic, strong) NSMutableDictionary *selectedCareerLevel;
@property (nonatomic, strong) NSMutableArray *selectedFunctionArray;
@property (nonatomic,strong) NSNumber *descriptionHeight;
@property (nonatomic,strong) CLCareerKeyJobFactsObject *keyJobFactsObj;
@property (nonatomic,strong) CLCareerSalaryBenefitsObject *salBenefitsObj;

@property (nonatomic, strong) NSDate *fromDate;
@property (nonatomic, strong) NSDate *toDate;
@property (nonatomic, strong) NSString *jobTitleText;
@property (nonatomic, strong) NSString *countryText;
@property (nonatomic, strong) NSString *companyNameText;
@property (nonatomic, strong) NSString *businessDivisionText;
@property (strong, nonatomic) NSString *multipleBusinessDivText;
@property (nonatomic, strong) NSString *companyLocationText;
@property (nonatomic, strong) NSString *companyDescText;
@property (nonatomic, strong) NSString *fromDateText;
@property (nonatomic, strong) NSString *toDateText;
@property (nonatomic, assign) BOOL onGoing;
@property (nonatomic, assign) BOOL selfEmployed;
@property (nonatomic, assign) BOOL isNewCompny;

//fields for Reported To
@property (nonatomic, assign) BOOL isPrimary;
@property (nonatomic, strong) NSString *primarySecondaryText;
@property (nonatomic, strong) NSString *empContratTypeText;
@property (nonatomic, strong) NSString *reportedToText;
@property (nonatomic, strong) NSString *empTypeText;
@property (nonatomic, strong) NSString *timeSpendText;


//fields for exp gained and remarks
@property (nonatomic, strong) NSString *expGainedText;
@property (nonatomic, strong) NSString *remarkText;

//fields for reason for career move
@property (nonatomic, strong) NSString *reasonForText;
@property (nonatomic, strong) NSString *functionText;
@property (nonatomic, strong) NSString *careerLevelText;
@property (nonatomic, strong) NSString *jobScopeText;
@property (strong, nonatomic) IBOutlet TITokenField *tokenTxtField;
@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;
@end

@implementation CLAddCareerHistoryViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [self.pickerView reloadAllComponents];
//    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    
    [CLCommon sentScreenNameToGoogleAnalytics:@"CareerLine IOS - Career History"];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:YES];
    [self.txtFirstResponder resignFirstResponder];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"Career History", @"Career history listing page");
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    self.isNewCompny = self.carrerHisObj.isDesc;
    CGRect tokenFieldFrame=self.tokenTxtField.frame;
    tokenFieldFrame.size.width=self.tableView.bounds.size.width-10;
    self.tokenTxtField.frame=tokenFieldFrame;
    
    UIPickerView *businessDivPickerView=[[UIPickerView alloc] init];
    businessDivPickerView.backgroundColor=[UIColor whiteColor];
    businessDivPickerView.tag =1;
    businessDivPickerView.delegate=self;
    businessDivPickerView.dataSource=self;
    businessDivPickerView.showsSelectionIndicator = YES;
    self.pickerView =businessDivPickerView;
    
    [self setRightNavigationButton];
    
    self.keyboardToolBarWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    //Table cells for career history index
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"locationCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"IndustryCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"countryCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"companyNameCellIdentifier"];
    
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"onGoingTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"selfEmployedTextCellIdentifier"];
    
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"companyNameTxtCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"jobTitleTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"businessDivCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"companyDescCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"fromDateCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"toDateCellIdentifier"];
    
    //Reported to cells
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"jobTitleLineManagerCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"employmentTypeCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"employmentContractTypeCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"primarySecondaryCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"percentageTimeSpendCellIdentifier"];
    
    //Document cell
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    
    //table cells for experience gained and remarks section
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"experienceGainedCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"remarksCellIdentifier"];
    
    //Table cells for reason for career move index
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"careerMoveReasonCellIdentifier"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"functionCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"careerLevelCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"jobScopeCellIdentifier"];
    [self.tableView registerClass:[CLTappableTextViewCell class] forCellReuseIdentifier:@"empBusinessDivMultipleTextCellIdentifier"];
    
    
    self.primarySecondaryArray = [[NSMutableArray alloc]initWithObjects:NSLocalizedString(@"Primary", @"Primary text"),NSLocalizedString(@"Secondary", @"Secondary text"), nil];
    
    
    self.empContractType = [NSMutableArray arrayWithObjects:
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"1",kempContractId,
                             NSLocalizedString(@"Local", @"Local text"),kempContractName,
                             nil],
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"2",kempContractId,
                             NSLocalizedString(@"Local Plus", @"Local Plus text"),kempContractName,
                             nil],
                            [NSDictionary dictionaryWithObjectsAndKeys:
                             @"3",kempContractId,
                             NSLocalizedString(@"Expat", @"Expat text"),kempContractName,
                             nil],
                            nil]; 
    self.workAchievmentsArray = [[NSMutableArray alloc]init];
    self.selectedFunctionArray = [[NSMutableArray alloc]init];
    self.alreadySelectedReasonArray = [[NSMutableArray alloc]init];
    self.selectedMultipleBusDiv = [[NSMutableArray alloc]init];
    self.descriptionHeight=[[NSNumber alloc] init];
    
    if (self.isEditMode) {
        
        //edit mode for section career history
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:self.carrerHisObj.careerCountry.countryCode forKey:kLocationCountryCode];
        [dict setObject:self.carrerHisObj.careerCountry.locationName forKey:kLocationCountryName];
        
        if (![self.carrerHisObj.careerLocation.locationCode isEqualToString:@""]) {
            [dict setObject:self.carrerHisObj.careerLocation.locationCode forKey:kLocationCode];
            [dict setObject:self.carrerHisObj.careerLocation.locationName forKey:kLocationName];
        }else if(![[self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyLockey] isEqualToString:@""]){
            [dict setObject:[self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryOtherCompanyLockey] forKey:kLocationCode];
            [dict setObject:[self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyLockey] forKey:kLocationName];
        }
        if (self.selectedCountry ==nil) {
            self.selectedCountry = [[NSMutableDictionary alloc]init];
            self.selectedCountry = dict;
        }else{
            self.selectedCountry = dict;
        }

        self.companyDivisionArray = [[NSMutableArray alloc]initWithArray:self.carrerHisObj.companyDivisions];
        [self.companyDivisionArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:kCLNewEntryId,kCLSearchCompanyDivisionIdkey,kCLCompanyDivisionOther,kCLSearchCompanyDivisionNamekey, nil] atIndex:[self.companyDivisionArray count]];
        self.jobTitleText = self.carrerHisObj.jobTitle;
        self.countryText = self.carrerHisObj.careerCountry.locationName;
        self.companyNameText = [self.carrerHisObj.companyName objectForKey:kCLCareerHistoryCompanyNamekey];
        self.selectedCompanyName = self.carrerHisObj.companyName;
        
        if (self.carrerHisObj.industry) {
            self.selectedIndustry=self.carrerHisObj.industry;
        }
        
        if (self.carrerHisObj.isOtherCompany) {
            self.companyNameText = [self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyNamekey];
            self.businessDivisionText = [self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryBusinessDivisionkey];
        }
        
        
//        if (![[self.carrerHisObj.companyDivision objectForKey:kCLCareerHistoryDivisionkey] isEqualToString:@""] ) {
//            if ([self.carrerHisObj.companyDivision objectForKey:kCLCareerHistoryDivisionkey]!=nil) {
//                
//                self.businessDivisionText = [self.carrerHisObj.companyDivision objectForKey:kCLCareerHistoryDivisionkey];
//            }else{
//                self.businessDivisionText = [self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryBusinessDivisionkey];
//            }
//            
//        }else if (![[self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyNamekey] isEqualToString:@""]){
//            
//            self.companyNameText = [self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyNamekey];
//            self.businessDivisionText = [self.carrerHisObj.otherCompanyName objectForKey:kCLCareerHistoryBusinessDivisionkey];
//        }else{
//            
//            self.businessDivisionText = [self.carrerHisObj.companyBusinessDivision objectForKey:kCLCareerHistoryCompanyDivisionkey];
//        }
        
        if ([self.carrerHisObj.multBusinessDiv count]>0) {
            self.selectedMultipleBusDiv = self.carrerHisObj.multBusinessDiv;
            [self businessDivTextForArray:self.selectedMultipleBusDiv];
        }

        self.selectedBusinessDivision = self.carrerHisObj.companyBusinessDivision;
        self.companyLocationText = self.carrerHisObj.careerLocation.locationName;
        self.companyDescText = self.carrerHisObj.companyDesc;
        self.fromDateText = [CLCommon getStringForDate:self.carrerHisObj.durationFrom andLocalFormat:@"MMMMdy"];
        self.toDateText = [CLCommon getStringForDate:self.carrerHisObj.durationTo andLocalFormat:@"MMMMdy"];
        self.fromDate = self.carrerHisObj.durationFrom;
        self.toDate = self.carrerHisObj.durationTo;
        self.onGoing = self.carrerHisObj.durationCurrent;
        self.selfEmployed = self.carrerHisObj.selfEmployed;
        if (self.carrerHisObj.companyDesc == Nil) {
            self.isNewCompny = NO;
        }else{
            self.isNewCompny = YES;
        }
        //edit mode for reason for career move
        if ([self.carrerHisObj.reasonForMove count] > 0) {
            
            [self updateReasonTextForArray:self.carrerHisObj.reasonForMove];
        }
        if ([self.carrerHisObj.careerHisFunction count] > 0) {
            if ([[self.carrerHisObj.careerHisFunction objectAtIndex:0] objectForKeyNotNull:kjobFunctionOtherFlag]) {
                
                [self updateFuctionTextForArray:self.carrerHisObj.careerHisFunction];
            }else{
                
                [self updateFuctionTextForArrayFromObj:self.carrerHisObj.careerHisFunction];
            }
        }
        self.careerLevelText = [self.carrerHisObj.jobLevel objectForKey:kCLCareerHistoryJobLevelNamekey];
        self.jobScopeText = [self.carrerHisObj.jobImpact objectForKey:kCLCareerHistoryJobImpactNamekey];
        self.selectedcompanyDivision = self.carrerHisObj.companyDivision;
        self.selectedJobScope = self.carrerHisObj.jobImpact;
        self.selectedCareerLevel = self.carrerHisObj.jobLevel;
        
        
        //Reported to section
        
        self.isPrimary = self.carrerHisObj.isJobTypePrimary;
        self.reportedToText = self.carrerHisObj.reportedTo;
        self.primarySecondaryText = self.carrerHisObj.jobType;
        if (self.carrerHisObj.employmentType !=nil) {
            self.selectedEmpType = [[NSMutableDictionary alloc]initWithDictionary:self.carrerHisObj.employmentType];
        }
        self.selectedEmpContractType = self.carrerHisObj.employmentContractType;
        self.empContratTypeText = [self.carrerHisObj.employmentContractType objectForKey:kCLCareerHistoryEmploymentContractTypekey];
        self.empTypeText = [self.carrerHisObj.employmentType objectForKeyNotNull:kCLCareerHistoryEmploymentTypekey];
        self.timeSpendText = self.carrerHisObj.timeSpend;
        
        //keyJobFacts section
        self.keyJobFactsObj = self.carrerHisObj.keyJobFacts;
        //Sal benefits section
        self.salBenefitsObj = self.carrerHisObj.salBenefitObj;
        
        //Work Achievement section
        self.workAchievmentsArray = self.carrerHisObj.majorAchievements;
        
        self.expGainedText = self.carrerHisObj.experiencesGained;
        self.remarkText = self.carrerHisObj.remarksAbtJob;
        
    }else{
        self.selectedCountry = [[NSMutableDictionary alloc]init];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"countryCode"] forKey:kLocationCountryCode];
        [self.selectedCountry setObject:[[CLUserObject currentUser].country objectForKey:@"country"] forKey:kLocationCountryName];
        //add for career history section
        self.jobTitleText = @"";
        self.countryText = @"";
        self.companyLocationText = @"";
        self.companyDivisionArray =nil;
        self.companyNameText = @"";
        self.businessDivisionText = @"";
        self.companyDescText = @"";
        self.fromDateText = @"";
        self.toDateText = @"";
        self.onGoing = NO;
        self.selfEmployed = NO;
        //add for reason for section
        self.reasonForText = @"";
        self.functionText = @"";
        self.careerLevelText = @"";
        self.jobScopeText = @"";
        //add reported to
        self.isPrimary = YES;
        self.reportedToText = @"";
        self.primarySecondaryText = @"";
        self.empContratTypeText = @"";
        self.empTypeText = @"";
        self.timeSpendText = @"";
        //keyJobFacts section
        self.keyJobFactsObj = nil;
        //sal beneifits
        self.salBenefitsObj = nil;
        //Work Achievement section
      //  self.workAchievmentsArray = nil;
        
        self.expGainedText = @"";
        self.remarkText = @"";
    }
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        NSCalendar*       calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents* components = [[NSDateComponents alloc] init];
        components.year = 20;
        NSDate *da =[[NSDate alloc]init];
        da =[CLUserObject currentUser].birthDate;
        NSDate* newDate = [calendar dateByAddingComponents: components toDate: da options: 0];
        
        NSDate *currDate = [NSDate date];
        
        switch ([newDate compare:currDate]){
            case NSOrderedAscending:
                [datePickr setDate:newDate];
                
                break;
            case NSOrderedSame:
            case NSOrderedDescending:
                [datePickr setDate:currDate];
                break;
        }
        
        //[datePickr setDate:newDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    self.jobScopeArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllEmpJobScopeFromDB:@"XXX"];
    
}
#pragma mark - row count adjusment method -
-(int)rowCountUpdateMethod{
    
    int rowAdjsment;
    if(self.isNewCompny){
        rowAdjsment = 0;
        
    }else {
        rowAdjsment = 1;
    }
    return rowAdjsment;
}
-(int)reasonForMoveRowUpdate{
    
    int increment;
    if (self.onGoing) {
        increment =1;
    }else{
        increment =0;
    }
    return increment;
}
- (IBAction)bttnActionKeyboardCancel:(id)sender {
    
    [self.txtViewFirstResponder resignFirstResponder];
    [self.txtFirstResponder resignFirstResponder];
}
-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    
    NSDate *date=datePicker.date;
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    
    int adjstestedRowCount = [self rowCountUpdateMethod];
    
    if (datePicker.tag+adjstestedRowCount == CLCareerFromDateIndex && index.section == CLCareerHistoryIndex) {
        self.fromDate=date;
        
        CLSimpleTextCell *startDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerFromDateIndex-adjstestedRowCount  inSection:CLCareerHistoryIndex]];
        [startDateCell setCellText:[CLCommon getStringForDate:self.fromDate andLocalFormat:@"MMMMdy"]];
        self.fromDateText = [CLCommon getStringForDate:self.fromDate andLocalFormat:@"MMMMdy"];
        
    }
    if (datePicker.tag+adjstestedRowCount == CLCareerToDateIndex && index.section == CLCareerHistoryIndex) {
        self.toDate=date;
        
        
        CLSimpleTextCell *startDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerToDateIndex-adjstestedRowCount  inSection:CLCareerHistoryIndex]];
        [startDateCell setCellText:[CLCommon getStringForDate:self.toDate andLocalFormat:@"MMMMdy"]];
        self.toDateText = [CLCommon getStringForDate:self.toDate andLocalFormat:@"MMMMdy"];
    }
    
}
#pragma mark - PickerView DataSource -

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == kCLCompanyDivPickerTag) {
        return [self.companyDivisionArray count];
    }else if (pickerView.tag == kCLJobScopePickerTag){
        return [self.jobScopeArray count];
    }else if(pickerView.tag == kCLPrimarySecondaryPickerTag){
        return [self.primarySecondaryArray count];
    }else if(pickerView.tag == kCLEmpContractTypePickerTag){
        return [self.empContractType count];
    }else{
        return 0;
    }
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag == kCLCompanyDivPickerTag) {
        label.text = [[self.companyDivisionArray objectAtIndex:row] objectForKey:kCLCareerHistoryDivisionkey];
    }
    else if (pickerView.tag == kCLJobScopePickerTag){
        label.text = [[self.jobScopeArray objectAtIndex:row] objectForKey:kemploymentJobScopeNameKey];
    }else if (pickerView.tag == kCLPrimarySecondaryPickerTag){
        label.text = [self.primarySecondaryArray objectAtIndex:row];
    }else if (pickerView.tag == kCLEmpContractTypePickerTag){
        label.text = [[self.empContractType objectAtIndex:row] objectForKey:kempContractName];
    }
    return label;
}

#pragma mark - Utility Methods -

-(void)setRightNavigationButton{
    
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Career History modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveCareerHistoryAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Career History modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddCareerHistoryAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    
}

-(void)setLeftNavigationButton{
    
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Career History modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
    
}
#pragma mark - Utility Methods -
- (IBAction)keyboardDoneClicked:(id)sender {
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    
    //important to adjust row count with conditions
    int rowAdjsment = [self reasonForMoveRowUpdate];
    
    if (index.section == CLCareerMoveReasonIndex && index.row+rowAdjsment == CLCareerJobScopeIndex){
        
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        CLSimpleTextCell *jobScopeCell;
        jobScopeCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerJobScopeIndex-rowAdjsment inSection:CLCareerMoveReasonIndex]];
        self.selectedJobScope = [self.jobScopeArray objectAtIndex:row];
        [jobScopeCell setCellText:[[self.jobScopeArray objectAtIndex:row] objectForKey:kemploymentJobScopeNameKey]];
        self.jobScopeText = [[self.jobScopeArray objectAtIndex:row] objectForKey:kemploymentJobScopeNameKey];
        
    }else if (index.section == CLCareerReportedToIndex && index.row == CLCareerPrimarySecondaryIndex){
        
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        CLSimpleTextCell *primarySecondaryCell;
        primarySecondaryCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerPrimarySecondaryIndex inSection:CLCareerReportedToIndex]];
        [primarySecondaryCell setCellText:[self.primarySecondaryArray objectAtIndex:row]];
        if(row == 1){
            self.isPrimary =NO;
        }else{
            self.isPrimary =YES;
        }
        self.primarySecondaryText = [self.primarySecondaryArray objectAtIndex:row];
        [self.tableView reloadData];
        
    }else if (index.section == CLCareerReportedToIndex && index.row == CLCareerEmployeementContractTypeIndex){
        
        NSInteger row = [self.pickerView selectedRowInComponent:0];
        CLSimpleTextCell *empContractTypeCell;
        empContractTypeCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerEmployeementContractTypeIndex inSection:CLCareerReportedToIndex]];
        [empContractTypeCell setCellText:[[self.empContractType objectAtIndex:row] objectForKey:kempContractName]];
        self.selectedEmpContractType = [self.empContractType objectAtIndex:row];
        self.empContratTypeText = [[self.empContractType objectAtIndex:row] objectForKey:kempContractName];
        
    }
    
    else if (index.section == CLCareerHistoryIndex && (index.row == CLCareerBusinessDivisionIndex && [self.companyDivisionArray count]>0)) {
        
        if (![[self.selectedcompanyDivision objectForKey:kCLCareerHistoryDivisionIdkey] isEqualToString:kCLNewEntryId]) {
            
            NSInteger row = [self.pickerView selectedRowInComponent:0];
            if (![[[self.companyDivisionArray objectAtIndex:row] objectForKey:kCLCareerHistoryDivisionIdkey] isEqualToString:kCLNewEntryId]) {
                
                self.selectedcompanyDivision = [self.companyDivisionArray objectAtIndex:row];
                
                CLSimpleTextCell *companyDivCell;
                companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerBusinessDivisionIndex inSection:CLCareerHistoryIndex]];
                [companyDivCell setCellText:[self.selectedcompanyDivision  objectForKey:kCLCareerHistoryDivisionkey]];
                self.businessDivisionText = [self.selectedcompanyDivision  objectForKey:kCLCareerHistoryDivisionkey];
                
            }else{
                
                if([CLCommon isOSversionLessThan8])
                {
                    
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"Enter other business division",@"other business division message") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",@"cancel btn title") otherButtonTitles:NSLocalizedString(@"OK",@"ok btn title"), nil] ;
                    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
                    [alertView show];
                    
                }
                else
                {
                    // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                                   message: NSLocalizedString(@"Enter other business division",@"other business division message")
                                                                            preferredStyle: UIAlertControllerStyleAlert];
                    
                    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                        
                    }];
                    UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"ok btn title") style:UIAlertActionStyleDefault
                                                                     handler:^(UIAlertAction * action){
                                                                         //Do Some action here
                                                                         UITextField *textField = alert.textFields[0];
                                                                         NSString *cutString = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                         if (![textField.text isEqualToString:@""] && ![CLCommon doesItHaveSpace:cutString]) {
                                                                             [self.txtFirstResponder resignFirstResponder];
                                                                             CLSimpleTextCell *companyDivCell;
                                                                             companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerBusinessDivisionIndex inSection:CLCareerHistoryIndex]];
                                                                             [companyDivCell setCellText:cutString];
                                                                             self.businessDivisionText = cutString;
                                                                             self.selectedBusinessDivision = [[NSMutableDictionary alloc]init];
                                                                             [self.selectedBusinessDivision setObject:[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNameIdkey] forKey:kCLCareerHistoryOtherBusDivCompanyIdkey];
                                                                             [self.selectedBusinessDivision setObject:cutString forKey:kCLCareerHistoryCompanyDivisionkey];
                                                                         }
                                                                         else{
                                                                             [self.txtFirstResponder resignFirstResponder];
                                                                         }
                                                                         
                                                                     }];
                    
                    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel",@"cancel btn title")
                                                                           style: UIAlertActionStyleDefault
                                                                         handler: nil];
                    
                    [alert addAction: cancelAction];
                    [alert addAction: okAction];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        }else{
            
            if ([[self.selectedcompanyDivision  objectForKey:kCLSearchCompanyDivisionIdkey] intValue] == 0) {
                
                if([CLCommon isOSversionLessThan8]){
                    
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message: NSLocalizedString(@"Enter other business division",@"other business division message") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",@"cancel btn title") otherButtonTitles:NSLocalizedString(@"OK",@"ok btn title"), nil] ;
                    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
                    [alertView show];
                    
                }
                else
                {
                    // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                                   message: NSLocalizedString(@"Enter other business division",@"other business division message")
                                                                            preferredStyle: UIAlertControllerStyleAlert];
                    
                    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                        
                    }];
                    UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"ok btn title") style:UIAlertActionStyleDefault
                                                                     handler:^(UIAlertAction * action){
                                                                         //Do Some action here
                                                                         UITextField *textField = alert.textFields[0];
                                                                         NSString *cutString = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                         if (![textField.text isEqualToString:@""] && ![CLCommon doesItHaveSpace:cutString]) {
                                                                             [self.txtFirstResponder resignFirstResponder];
                                                                             CLSimpleTextCell *companyDivCell;
                                                                             companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerBusinessDivisionIndex inSection:CLCareerHistoryIndex]];
                                                                             [companyDivCell setCellText:cutString];
                                                                             self.businessDivisionText = cutString;
                                                                             self.selectedBusinessDivision = [[NSMutableDictionary alloc]init];
                                                                             [self.selectedBusinessDivision setObject:[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNameIdkey] forKey:kCLCareerHistoryOtherBusDivCompanyIdkey];
                                                                             [self.selectedBusinessDivision setObject:cutString forKey:kCLCareerHistoryCompanyDivisionkey];
                                                                         }
                                                                         else{
                                                                             [self.txtFirstResponder resignFirstResponder];
                                                                         }
                                                                         
                                                                     }];
                    
                    
                    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel",@"cancel btn title")
                                                                           style: UIAlertActionStyleDefault
                                                                         handler: nil];
                    
                    [alert addAction: cancelAction];
                    [alert addAction: okAction];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }else{
                
                CLSimpleTextCell *companyDivCell;
                companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerBusinessDivisionIndex inSection:CLCareerHistoryIndex]];
                [companyDivCell setCellText:[self.selectedcompanyDivision  objectForKey:kCLCareerHistoryDivisionkey]];
                self.businessDivisionText = [self.selectedcompanyDivision  objectForKey:kCLCareerHistoryDivisionkey];
                
            }
        }
    }
    
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
    
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    
    int adjustedIndex = 0;
    if (self.isNewCompny) {
        adjustedIndex = 2;
    }
    
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    NSIndexPath *index = [self.tableView indexPathForCell:cell];
    
    //important to adjust row count with conditions
    int rowAdj = [self rowCountUpdateMethod];
    if (index.section == CLCareerHistoryIndex && index.row+rowAdj == CLCareerFromDateIndex-adjustedIndex){
        
        CLSimpleTextCell *fromDateCell;
        fromDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerFromDateIndex-rowAdj-adjustedIndex inSection:CLCareerHistoryIndex]];
        self.fromDate=self.datePicker.date;
        [fromDateCell setCellText:[CLCommon getStringForDate:self.fromDate andLocalFormat:@"MMMMdy"]];
        self.fromDateText =[CLCommon getStringForDate:self.fromDate andLocalFormat:@"MMMMdy"];
        
    }
    else if (index.section == CLCareerHistoryIndex && index.row+rowAdj == CLCareerToDateIndex-adjustedIndex){
        
        CLSimpleTextCell *toDateCell;
        toDateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerToDateIndex-rowAdj-adjustedIndex inSection:CLCareerHistoryIndex]];
        self.toDate=self.datePicker.date;
        [toDateCell setCellText:[CLCommon getStringForDate:self.toDate andLocalFormat:@"MMMMdy"]];
        self.toDateText =[CLCommon getStringForDate:self.toDate andLocalFormat:@"MMMMdy"];
        
    }
    
    [self.txtFirstResponder resignFirstResponder];
    
}
#pragma mark - alertview delegate method -
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    UITextField * alertTextField = [alertView textFieldAtIndex:0];
    NSString *cutString = [alertTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (buttonIndex ==1 && ![alertTextField.text isEqualToString:@""] && ![CLCommon doesItHaveSpace:cutString]) {
        CLSimpleTextCell *companyDivCell;
        companyDivCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:CLCareerBusinessDivisionIndex inSection:CLCareerHistoryIndex]];
        [companyDivCell setCellText:cutString];
        self.businessDivisionText = cutString;
        self.selectedBusinessDivision = [[NSMutableDictionary alloc]init];
        [self.selectedBusinessDivision setObject:[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNameIdkey] forKey:kCLCareerHistoryOtherBusDivCompanyIdkey];
        [self.selectedBusinessDivision setObject:cutString forKey:kCLCareerHistoryCompanyDivisionkey];
    }
    
}

//Work history validation
-(BOOL)isFieldsValid{
    
    BOOL isValid=YES;
    //Job Title validation..
    if ([self.jobTitleText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Job Title.", @"Error Message for null Job Title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.jobTitleText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Job Title Length.", @"Error Message for length of Job Title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //country validation
    if ([self.selectedCountry count] ==0 && [self.countryText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Country.", @"Error Message for null Country") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //company name validation
    if ([self.selectedCompanyName count] ==0 && [self.companyNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Company Name.", @"Error Message for null Company Name") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Location validation
//    if ([self.companyLocationText isEqualToString:@""] || [self.selectedCountry objectForKey:kLocationCode]==nil) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose company location.", @"Error Message for null locationfield") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    if (self.fromDate ==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select From Date.", @"Error Message for null From date Date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    if (!self.onGoing) {
        if (self.toDate ==nil) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select To Date.", @"Error Message for null To Date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        if (self.fromDate !=nil && self.toDate !=nil) {
            
            if( [self.fromDate timeIntervalSinceDate:self.toDate] >= 0 ){
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"To Date Should Be Greater Than From Date.", @"Error Message for date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                
                return isValid=NO;
            }
        }
    }
    //career Function validation
    
    if (self.isNewCompny) {
        if (self.companyDescText == nil || [self.companyDescText isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter A Company Discription.", @"Error Message for null Job function") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
            
        }
    }

    if ([self.selectedFunctionArray count] ==0 && [self.functionText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Job Function.", @"Error Message for null Job function") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //career level validation
    if ([self.selectedCareerLevel count] ==0 && [self.careerLevelText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Choose Career Level.", @"Error Message for null Career level") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    //Job scope validation
    if ([self.jobScopeText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter Job Scope.", @"Error Message for null Job Scope field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.jobScopeText length]>300){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Job Scope Length.", @"Error Message for length of Job Scope field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if (self.timeSpendText.length >= 4) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"% Of Time Spend Must Be No More Than 3 Digits", @"Error Message for length of time spend") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.expGainedText = [self.expGainedText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    self.remarkText = [self.remarkText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
    
}
-(void)saveWorkHistoryForEdit:(BOOL)isEditMode{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    CLCareerHistoryObject *newCareerHisObj=[[CLCareerHistoryObject alloc] init];
    if (isEditMode) {
        newCareerHisObj.wrkHisId = self.carrerHisObj.wrkHisId;
    }else{
        newCareerHisObj.wrkHisId = nil;
    }
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    
    if (![self.companyNameText isEqualToString:@""] && self.companyNameText!=nil) {
        [dict setObject:self.companyNameText forKey:kCLCareerHistoryCompanyNamekey];
    }
    if (![self.businessDivisionText isEqualToString:@""] && self.businessDivisionText!=nil) {
        
        [dict setObject:self.businessDivisionText forKey:kCLCareerHistoryBusinessDivisionkey];
    }
    if (self.companyDescText!=nil) {
        [dict setObject:self.companyDescText forKey:kCLCareerHistoryCompanyDesckey];
    }
    self.selectedOtherCompany = dict;
    newCareerHisObj.otherCompanyName = self.selectedOtherCompany;
    newCareerHisObj.jobTitle = self.jobTitleText;
    newCareerHisObj.jobImpact = self.selectedJobScope;
    newCareerHisObj.companyName = self.selectedCompanyName;
    
    if ([self.businessDivisionText isEqualToString:@""]) {
        self.selectedcompanyDivision = nil;
    }
    if ([self.selectedIndustry objectForKey:@"industryCode"]) {
        [self.selectedIndustry setObject:[self.selectedIndustry objectForKey:@"industryCode"] forKey:@"id"];
        [self.selectedIndustry removeObjectForKey:@"industryCode"];
    }
    newCareerHisObj.industry=self.selectedIndustry;
    newCareerHisObj.companyDivision = self.selectedcompanyDivision;
    newCareerHisObj.companyBusinessDivision = self.selectedBusinessDivision;
    newCareerHisObj.companyDesc = self.companyDescText;
    newCareerHisObj.durationFrom = self.fromDate;
    newCareerHisObj.durationTo = self.toDate;
    newCareerHisObj.durationCurrent = self.onGoing;
    newCareerHisObj.selfEmployed = self.selfEmployed;
    newCareerHisObj.reasonForMove = self.alreadySelectedReasonArray;
    newCareerHisObj.careerHisFunction = self.selectedFunctionArray;
    newCareerHisObj.jobLevel = self.selectedCareerLevel;
    if ([self.companyDivisionArray count]>0) {
        [self.companyDivisionArray removeObjectAtIndex:[self.companyDivisionArray count]-1];
    }
    newCareerHisObj.companyDivisions = self.companyDivisionArray;
    
    NSMutableDictionary *locDict = [[NSMutableDictionary alloc]init];
    NSMutableDictionary *countryDict = [[NSMutableDictionary alloc]init];
    
    if (self.carrerHisObj.careerLocation != nil || self.carrerHisObj.careerCountry !=nil) {
        if (self.selectedCountry!=nil) {
            if ([self.selectedCountry objectForKey:kLocationCode]) {
                [locDict setObject:[self.selectedCountry objectForKey:kLocationCode] forKey:kCLQlfitnEducationLocationCodekey];
                [locDict setObject:[self.selectedCountry objectForKey:kLocationName] forKey:kCLProfileAboutMeLocNamekey];
            }
            else{
//                [locDict setObject:[self.selectedCountry objectForKey:@"jobLocationCountryCode"] forKey:kCLQlfitnEducationLocationCodekey];
//                [locDict setObject:[self.selectedCountry objectForKey:@"jobLocationCountryName"] forKey:kCLProfileAboutMeLocNamekey];
            }
            
//            [countryDict setObject:[self.selectedCountry objectForKey:kLocationCountryName] forKey:kCLProfileAboutMeLocNamekey];
            [countryDict setObject:[self.selectedCountry objectForKey:kLocationCountryCode] forKey:kCLQlfitnEducationLocationCountrykey];
        }else{
            
            NSString* locName = [self.carrerHisObj.careerLocation.locationName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString* locCode = [self.carrerHisObj.careerLocation.locationCode stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if(locName.length)
                [locDict setObject:self.carrerHisObj.careerLocation.locationName forKey:kCLProfileAboutMeLocNamekey];
            if(locCode.length)
                [locDict setObject:self.carrerHisObj.careerLocation.locationCode forKey:kCLProfileAboutMeLocCodekey];
            [countryDict setObject:self.carrerHisObj.careerCountry.locationName forKey:kCLProfileAboutMeLocNamekey];
            [countryDict setObject:self.carrerHisObj.careerCountry.countryCode forKey:kCLQlfitnEducationLocationCountrykey];
        }
    }else{
        if ([self.selectedCountry objectForKey:kLocationCode]) {
//            [locDict setObject:[self.selectedCountry objectForKey:@"jobLocationCountryCode"] forKey:kCLQlfitnEducationLocationCodekey];
//            [locDict setObject:[self.selectedCountry objectForKey:@"jobLocationCountryName"] forKey:kCLProfileAboutMeLocNamekey];
            
            [locDict setObject:[self.selectedCountry objectForKey:kLocationCode] forKey:kCLQlfitnEducationLocationCodekey];
            [locDict setObject:[self.selectedCountry objectForKey:kLocationName] forKey:kCLProfileAboutMeLocNamekey];
            
        }
        else{
//            [locDict setObject:[self.selectedCountry objectForKey:kLocationCode] forKey:kCLQlfitnEducationLocationCodekey];
//            [locDict setObject:[self.selectedCountry objectForKey:kLocationName] forKey:kCLProfileAboutMeLocNamekey];
        }
        
        [countryDict setObject:[self.selectedCountry objectForKey:kLocationCountryName] forKey:kCLProfileAboutMeLocNamekey];
        [countryDict setObject:[self.selectedCountry objectForKey:kLocationCountryCode] forKey:kCLQlfitnEducationLocationCountrykey];
    }
    
    if([locDict count] != 0)
        newCareerHisObj.careerLocation = [[CLLocationObject alloc]initWithDictionary:locDict];
    else
        newCareerHisObj.careerLocation.locationCode = @"";
    
    newCareerHisObj.careerCountry = [[CLLocationObject alloc]initWithDictionary:countryDict];
    
    newCareerHisObj.isJobTypePrimary = self.isPrimary;
    newCareerHisObj.reportedTo = self.reportedToText;
    newCareerHisObj.jobType = self.primarySecondaryText;
    newCareerHisObj.timeSpend = self.timeSpendText;
    newCareerHisObj.employmentType = self.selectedEmpType;
    newCareerHisObj.employmentContractType =self.selectedEmpContractType;
    
    newCareerHisObj.keyJobFacts = self.keyJobFactsObj;
    newCareerHisObj.majorAchievements = self.workAchievmentsArray;
    newCareerHisObj.salBenefitObj = self.salBenefitsObj;
    
    newCareerHisObj.remarksAbtJob = self.remarkText;
    newCareerHisObj.experiencesGained = self.expGainedText;
    
    newCareerHisObj.multBusinessDiv = self.selectedMultipleBusDiv;
    
    [CLCareerHistoryObject saveWorkHistory:newCareerHisObj forUser:[CLUserObject currentUser].userID editMode:isEditMode success:^(NSString *wrkHisId) {
        
        if (isEditMode) {
            self.carrerHisObj.otherCompanyName = newCareerHisObj.otherCompanyName;
            self.carrerHisObj.jobTitle = newCareerHisObj.jobTitle;
            self.carrerHisObj.jobImpact = newCareerHisObj.jobImpact;
            self.carrerHisObj.companyName = newCareerHisObj.companyName;
            self.carrerHisObj.companyDivision = newCareerHisObj.companyDivision;
            self.carrerHisObj.companyDivisions = newCareerHisObj.companyDivisions;
            self.carrerHisObj.companyDesc = newCareerHisObj.companyDesc;
            self.carrerHisObj.durationFrom = newCareerHisObj.durationFrom;
            self.carrerHisObj.durationTo = newCareerHisObj.durationTo;
            self.carrerHisObj.durationCurrent = newCareerHisObj.durationCurrent;
            self.carrerHisObj.reasonForMove = newCareerHisObj.reasonForMove;
            self.carrerHisObj.careerHisFunction = newCareerHisObj.careerHisFunction;
            self.carrerHisObj.jobLevel = newCareerHisObj.jobLevel;
            self.carrerHisObj.careerCountry = newCareerHisObj.careerCountry;
            self.carrerHisObj.careerLocation = newCareerHisObj.careerLocation;
            self.carrerHisObj.companyBusinessDivision = newCareerHisObj.companyBusinessDivision;
            
            self.carrerHisObj.isJobTypePrimary =newCareerHisObj.isJobTypePrimary;
            self.carrerHisObj.reportedTo =newCareerHisObj.reportedTo;
            self.carrerHisObj.jobType =newCareerHisObj.jobType;
            self.carrerHisObj.timeSpend =newCareerHisObj.timeSpend;
            self.carrerHisObj.employmentType =newCareerHisObj.employmentType;
            self.carrerHisObj.employmentContractType =newCareerHisObj.employmentContractType;
            
            self.carrerHisObj.keyJobFacts = newCareerHisObj.keyJobFacts;
            self.carrerHisObj.majorAchievements = newCareerHisObj.majorAchievements;
            self.carrerHisObj.salBenefitObj = newCareerHisObj.salBenefitObj;
            
            self.carrerHisObj.remarksAbtJob = newCareerHisObj.remarksAbtJob;
            self.carrerHisObj.experiencesGained = newCareerHisObj.experiencesGained;
            
            self.carrerHisObj.multBusinessDiv = newCareerHisObj.multBusinessDiv;
            
        }else{
            newCareerHisObj.wrkHisId=wrkHisId;
            self.carrerHisObj=newCareerHisObj;
        }
        [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
        
    } failure:^(NSString *error) {
        
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [progressHUD hideWithAnimation:YES];
            [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Work history. Please try again later.", @"Error message when Work history cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
        }
    }];
    
}
#pragma mark - HTProgressHUD delegates -

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    
    if (self.isEditMode) {
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(addWorkHistory:didAddWorkHistory:)]){
                [self.delegate addWorkHistory:self didAddWorkHistory:self.carrerHisObj];
            }
            
        }];
    }
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

#pragma mark - IBAction -
-(IBAction)bttnActionDismissModal:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(IBAction)bttnActionAddCareerHistoryAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveWorkHistoryForEdit:NO];
    }
    
}
-(IBAction)bttnActionSaveCareerHistoryAndDismissModal:(id)sender{
    
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveWorkHistoryForEdit:YES];
    }
}



#pragma mark - Table view data source -

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    if (self.isEditMode) {
        return 10;
    }else{
        return 9;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == CLCareerHistoryIndex) {
        if(self.isNewCompny){
            return 8;
        }
        else{
            return 9;
        }
    }else if(section == CLCareerMoveReasonIndex){
        if (self.onGoing) {
            return 3;
        }else{
            return 4;
        }
    }else if(section == CLCareerReportedToIndex){
        if (!self.isPrimary) {
            return 5;
        }else{
            return 4;
        }
    }else if (section == CLCareerMajorAchvmentsIndex){
        return [self.workAchievmentsArray count];
    }
    else{
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int adjustedIndex = 0;
    if (self.isNewCompny) {
        adjustedIndex = 2;
    }
    
    NSIndexPath *indexNew;
    int rowChangedVal = [self rowCountUpdateMethod];
    indexNew = [NSIndexPath indexPathForRow:indexPath.row+rowChangedVal inSection:CLCareerHistoryIndex];
    
    switch (indexPath.section) {
        case CLCareerHistoryIndex:{
            
            if (indexPath.row == CLCareerJobTitleIndex) {
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobTitleTextCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setPlaceHoldrText:NSLocalizedString(@"Job Title", @"placeholder text for job title.")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setCellText:self.jobTitleText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
                
            }else if(indexPath.row == CLCareerCountryIndex){
                CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"countryCellIdentifier"];
                [currLoccell setPlaceHoldrText: NSLocalizedString(@"Country", @"Placeholder for country")];
                currLoccell.delegate=self;
                [currLoccell setCellFont:[UIFont systemFontOfSize:13]];
            
                if (self.selectedCountry) {
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@",[self.selectedCountry objectForKey:kLocationCountryName]]];
                    self.countryText = [self.selectedCountry objectForKey:kLocationCountryName];
                }
                else{
                    [currLoccell setCellText:self.countryText];
                }
                [currLoccell setCellIndexPath:indexPath];
                return currLoccell;
            }else if (indexPath.row == CLCareerCompanyNameIndex){
                
                CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"companyNameCellIdentifier"];
                [currLoccell setPlaceHoldrText: NSLocalizedString(@"Company Name", @"Placeholder for Company Name")];
                currLoccell.delegate=self;
                [currLoccell setCellFont:[UIFont systemFontOfSize:13]];
                if (![[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNamekey] isEqualToString:@""] && self.selectedCompanyName !=nil) {
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@",[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNamekey]]];
                    [currLoccell setCellCloseBtnOption:NO];
                }
                else{
                    [currLoccell setCellCloseBtnOption:YES];
                    [currLoccell setCellText:self.companyNameText];
                }
                [currLoccell setCellIndexPath:indexPath];
                return currLoccell;
                
            }
            
            else if (indexPath.row == CLCareerIndustryIndex && !self.isNewCompny){
                CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"IndustryCellIdentifier"];
                [currLoccell setPlaceHoldrText: NSLocalizedString(@"Industry", @"Placeholder for Company Location")];
                currLoccell.delegate=self;
                if (self.selectedIndustry) {
                    if ([self.selectedIndustry objectForKey:@"industrySectName"] != nil) {
                        [currLoccell setCellText:[NSString stringWithFormat:@"%@ %@",[self.selectedIndustry objectForKey:@"industrySectName"],[self.selectedIndustry objectForKey:@"industryGroupName"]]];
                    }
                    else{
                        [currLoccell setCellText:[NSString stringWithFormat:@"%@ %@",[self.selectedIndustry objectForKey:@"industryGroupName"],[self.selectedIndustry objectForKey:@"industry"]]];
                    }
                }else{
                    [currLoccell setCellText:@""];
                }
                [currLoccell setCellFont:[UIFont systemFontOfSize:13]];
                [currLoccell setCellIndexPath:indexPath];
                return currLoccell;
            }
            
            else if (indexPath.row == CLCareerBusinessDivisionIndex && !self.isNewCompny){
                if (self.selectedCompanyName  !=nil && ([[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNameIdkey] isEqualToString:@"0"]||[[self.selectedCompanyName objectForKey:kCLCareerHistoryCompanyNameIdkey] isEqualToString:@""])) {
                    
                    
                    CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"businessDivCellIdentifier"];
                    if ([self.companyDivisionArray count]>0) {
                        [cell setTextInputView:self.pickerView];
                    }
                    [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                    [cell setCellFont:[UIFont systemFontOfSize:13]];
                    [cell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
                    [cell setPlaceHoldrText:NSLocalizedString(@"Business Division", @"placeholder for business division.")];
                    [cell setCellText:self.businessDivisionText];
                    [cell setCellIndexPath:indexPath];
                    cell.delegate=self;
                    return cell;
                    
                }else{
                    
                    
                    
                    
                    
                    CLTappableTextViewCell *functionCell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"empBusinessDivMultipleTextCellIdentifier"];
                    [functionCell setCellPlaceHolderText:NSLocalizedString(@"Business Division", @"Placeholder text")];
                    functionCell.delegate=self;
                    [functionCell setCellFont:[UIFont systemFontOfSize:13]];
                    [functionCell setCellText:self.multipleBusinessDivText];
                    [functionCell setCellIndexPath:indexPath];
                    return functionCell;
                }
                
                

               
            }else if (indexPath.row == CLCareerCompanyLocationIndex - adjustedIndex){
                CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"locationCellIdentifier"];
                [currLoccell setPlaceHoldrText: NSLocalizedString(@"Work Location", @"Placeholder for Company Location")];
                currLoccell.delegate=self;
                [currLoccell setCellFont:[UIFont systemFontOfSize:13]];
                
                if ([self.selectedCountry  objectForKey:kLocationName] !=NULL) {
                    if ([self.selectedCountry objectForKey:kLocationAdminArea]) {
                        [currLoccell setCellText:[NSString stringWithFormat:@"%@,%@,%@",[self.selectedCountry objectForKey:kLocationName],[self.selectedCountry objectForKey:kLocationAdminArea],[self.selectedCountry objectForKey:kLocationCountryName]]];
                        
                        [currLoccell setCellCloseBtnOption:NO];
                    } else{
                        [currLoccell setCellText:[NSString stringWithFormat:@"%@",[self.selectedCountry objectForKey:kLocationName]]];
                        [currLoccell setCellCloseBtnOption:NO];
                    }
                    [currLoccell setCellCloseBtnOption:NO];
                    self.companyLocationText = [NSString stringWithFormat:@"%@,%@,%@",[self.selectedCountry objectForKey:kLocationName],[self.selectedCountry objectForKey:kLocationAdminArea],[self.selectedCountry objectForKey:kLocationCountryName]];
                }
                else{
                    [currLoccell setCellText:self.companyLocationText];
                }
                [currLoccell setCellIndexPath:indexPath];
                return currLoccell;
            }else if (indexNew.row == CLCareerCompanyDescIndex-adjustedIndex){
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"companyDescCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setPlaceHoldrText:NSLocalizedString(@"Company Description", @"Placeholder for Company Description")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setCellText:self.companyDescText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }else if (indexNew.row == CLCareerFromDateIndex-adjustedIndex){
                
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"fromDateCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputView:self.datePicker];
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"From", @"Placeholder for from date")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellText:self.fromDateText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }else if (indexNew.row == CLCareerToDateIndex-adjustedIndex){
                
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"toDateCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputView:self.datePicker];
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"To", @"Placeholder for to date")];
                
                if (self.onGoing) {
                    [cell disableCellField];
                    [cell setCellText:@""];
                }else{
                    [cell enableCellField];
                    [cell setCellText:self.toDateText];
                }
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
                
            }
            else if (indexNew.row == CLCareerOngoingIndex-adjustedIndex){
                
                CLTextCheckBoxCell *onGoingCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"onGoingTextCellIdentifier"];
                onGoingCell.selectionStyle=UITableViewCellSelectionStyleNone;
                [onGoingCell setTextInputAccesoryView:self.keyboardResignView];
                [onGoingCell setPlaceHoldrText:NSLocalizedString(@"", @"Placeholder")];
                [onGoingCell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [onGoingCell setCellText:NSLocalizedString(@"Current", @"Placeholder for on going")];
                [onGoingCell setCellTextColor:[UIColor darkGrayColor]];
                [onGoingCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
                [onGoingCell setCellIndexPath:indexPath];
                [onGoingCell disableCelltxtField];
                [onGoingCell checkBoxClick:self.onGoing];
                onGoingCell.textCheckBoxdelegate=self;
                return onGoingCell;
                
            }
        }
        case CLCareerMoveReasonIndex:{
            NSIndexPath *reasonFormoveIndex;
            int rowAdjst = [self reasonForMoveRowUpdate];
            reasonFormoveIndex = [NSIndexPath indexPathForRow:indexPath.row+rowAdjst inSection:CLCareerMoveReasonIndex];
            if (reasonFormoveIndex.row == CLCareerReasonForMoveIndex) {
                
                CLTappableTextViewCell *cell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"careerMoveReasonCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setCellPlaceHolderText:NSLocalizedString(@"Reason For Career Move", @"Placeholder for Reason for Career move field")];
                [cell setCellText:self.reasonForText];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
                
            }else if(reasonFormoveIndex.row == CLCareerFunctionIndex){
                CLTappableTextViewCell *cell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"functionCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setCellPlaceHolderText:NSLocalizedString(@"Function", @"placeholder text for function")];
                [cell setCellText:self.functionText];
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
                
            }else if(reasonFormoveIndex.row == CLCareerLevelIndex){
//                CLTappableTextViewCell *cell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"careerLevelCellIdentifier"];
//                cell.selectionStyle=UITableViewCellSelectionStyleNone;
//                [cell setCellPlaceHolderText:NSLocalizedString(@"Career Level", @"placeholder text for career level")];
//                [cell setCellText:self.careerLevelText];
//                [cell setCellFont:[UIFont systemFontOfSize:13]];
//                [cell setCellIndexPath:indexPath];
//                cell.delegate=self;
//                return cell;
                
                CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"careerLevelCellIdentifier"];
                [cell setPlaceHoldrText: NSLocalizedString(@"Career Level", @"placeholder text for career level")];
                cell.delegate=self;
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                
                if(self.careerLevelText.length)
                    [cell setCellCloseBtnOption:NO];
                else
                    [cell setCellCloseBtnOption:YES];
                
                [cell setCellText:self.careerLevelText];
                [cell setCellIndexPath:indexPath];
                return cell;
                
            }else if(reasonFormoveIndex.row == CLCareerJobScopeIndex){
//                CLTappableTextViewCell *ecell = (CLTappableTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobScopeCellIdentifier"];
//                cell.selectionStyle=UITableViewCellSelectionStyleNone;
//                [cell setCellPlaceHolderText:NSLocalizedString(@"JobScope", @"placeholder text for jobScope")];
//                [cell setCellText:[self.selectedJobScope objectForKey:kCLCareerHistoryJobImpactNamekey]];
//                [cell setCellFont:[UIFont systemFontOfSize:13]];
//                [cell setCellIndexPath:indexPath];
//                cell.delegate=self;
//                return cell;
                
                CLSimpleTappableTextCell *cell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobScopeCellIdentifier"];
                [cell setPlaceHoldrText: NSLocalizedString(@"Job Scope", @"placeholder text for jobScope")];
                cell.delegate=self;
                [cell setCellFont:[UIFont systemFontOfSize:13]];
                
                if([[self.selectedJobScope objectForKey:kCLCareerHistoryJobImpactNamekey] length])
                    [cell setCellCloseBtnOption:NO];
                else
                    [cell setCellCloseBtnOption:YES];
                
                [cell setCellText:[self.selectedJobScope objectForKey:kCLCareerHistoryJobImpactNamekey]];
                [cell setCellIndexPath:indexPath];
                return cell;
                
            }
        }
        case CLCareerReportedToIndex:{
            
            if (indexPath.row == CLCareerLineManager) {
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobTitleLineManagerCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"Job Title of Line Manager", @"placeholder text for Job Title of Line Manager")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellText:self.reportedToText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }else if (indexPath.row == CLCareerEmployeementTypeIndex){
                CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"employmentTypeCellIdentifier"];
                [currLoccell setPlaceHoldrText: NSLocalizedString(@"Employment Type", @"Placeholder for Employment Type")];
                currLoccell.delegate=self;
                [currLoccell setCellFont:[UIFont systemFontOfSize:13]];
                if (self.selectedEmpType ==NULL) {
                    [currLoccell setCellText:self.empTypeText];
                    //[currLoccell setCellCloseBtnOption:NO];
                }
                else{
                    [currLoccell setCellCloseBtnOption:NO];
                    [currLoccell setCellText:[self.selectedEmpType objectForKey:kCLCareerHistoryEmploymentTypekey]];
                }
                [currLoccell setCellIndexPath:indexPath];
                return currLoccell;
                
            }else if (indexPath.row == CLCareerEmployeementContractTypeIndex){
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"employmentContractTypeCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
                [cell setTextInputView:self.pickerView];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"Employment Contract Type", @"Placeholder for Employment Contract Type")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellText:self.empContratTypeText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }else if (indexPath.row == CLCareerPrimarySecondaryIndex){
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"primarySecondaryCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputView:self.pickerView];
                [cell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"Primary/Secondary", @"Placeholder for Primary/Secondary")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellText:self.primarySecondaryText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }else{
                CLSimpleTextCell *cell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"percentageTimeSpendCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell setTextInputAccesoryView:self.keyboardResignView];
                [cell setKeyboardType:UIKeyboardTypeNumberPad];
                [cell setCellClearButtonMode:UITextFieldViewModeAlways];
                [cell setPlaceHoldrText:NSLocalizedString(@"% of Time Spent", @"Placeholder for % Time Spend")];
                [cell setCellCapitalization:UITextAutocapitalizationTypeWords];
                [cell setCellText:self.timeSpendText];
                [cell setCellIndexPath:indexPath];
                cell.delegate=self;
                return cell;
            }
        }
            
        case CLCareerSelfEmployed:{
            CLTextCheckBoxCell *selfEmployedCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"selfEmployedTextCellIdentifier"];
            selfEmployedCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [selfEmployedCell setTextInputAccesoryView:self.keyboardResignView];
            [selfEmployedCell setPlaceHoldrText:NSLocalizedString(@"", @"Placeholder")];
            [selfEmployedCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [selfEmployedCell setCellText:NSLocalizedString(@"Self Employed", @"Placeholder for on going")];
            [selfEmployedCell setCellTextColor:[UIColor darkGrayColor]];
            [selfEmployedCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
            [selfEmployedCell setCellIndexPath:indexPath];
            [selfEmployedCell disableCelltxtField];
            [selfEmployedCell checkBoxClick:self.selfEmployed];
            selfEmployedCell.textCheckBoxdelegate=self;
            return selfEmployedCell;
        }
            break;
        case CLCareerJobFactsIndex:{
            static NSString *CellIdentifier = @"jobfactsCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
                [cell.textLabel setNumberOfLines:0];
            }
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.text=NSLocalizedString(@"Key Job Facts", @"Key Job Facts text");
            
            return cell;
        }
        case CLCareerSalaryBenefitsIndex:{
            static NSString *CellIdentifier = @"salaryBenefitsCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
                [cell.textLabel setNumberOfLines:0];
            }
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.text=NSLocalizedString(@"Salary and Benefits", @"Salary and Benefits text");
            
            return cell;
        }
        case CLCareerMajorAchvmentsIndex:{
            
            [self.tableView setAllowsSelectionDuringEditing:YES];
            if ([self.workAchievmentsArray count]) {
                [self.tableView setEditing:YES animated:YES];
            }
            
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"achvmentsCellIdentifier"];
            if (cell==nil) {
                cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"achvmentsCellIdentifier"];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                [cell.textLabel setFont:[UIFont boldSystemFontOfSize:14]];
                [cell.detailTextLabel setTextColor:[CLCommon sharedInstance].currentTrafficLightColor];
            }
            
            cell.textLabel.text=((CLWorkAchievementObject*)[self.workAchievmentsArray objectAtIndex:indexPath.row]).awards;
            return cell;
            
        }
        case CLCareerExpGainedIndex:{
            
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"experienceGainedCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            //[descCell setContentToHTMLString:self.expGainedText];
            if (self.expGainedText) {
                NSMutableString *htmlString=[[[NSAttributedString alloc] initWithData:[self.expGainedText dataUsingEncoding:NSUTF8StringEncoding]
                                                                              options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                        NSCharacterEncodingDocumentAttribute: [NSNumber numberWithInt:NSUTF8StringEncoding]}
                                                                   documentAttributes:nil error:nil].string mutableCopy];
                [htmlString replaceOccurrencesOfString:@"\n" withString:@" " options:NSCaseInsensitiveSearch range:NSMakeRange(0, htmlString.length)];
                descCell.text=htmlString;
            }else{
                 descCell.text=@"";
            }
           
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Experience Gained", @"Placeholder for Experience Gained field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
        }
        case CLCareerRemarksIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"remarksCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.remarkText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardToolBarWithCancel];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else about This Job You Want Us to Know", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
        }
        case CLCareerDocIndex:{
            CLProfilePhotoListingGridCell *docCell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            docCell.selectionStyle=UITableViewCellSelectionStyleNone;
            docCell.indexPath=indexPath;
            docCell.delegate=self;
            docCell.photosLimit=-1;
            docCell.placeHolderImageName=NSLocalizedString(@"documentPlaceHolder", @"Placeholder for documentPlaceHolder");
            docCell.photoUrls=self.carrerHisObj.documents;
            [docCell updateCollectionViewContents];
            return docCell;
        }
        default :
            return nil;
            break;
    }
    return nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int rowAdjst = [self reasonForMoveRowUpdate];
    if (indexPath.section == CLCareerMoveReasonIndex) {
        
        if ( indexPath.row+rowAdjst == CLCareerReasonForMoveIndex) {
            
            return MAX(44, [self getHeightForTokenFieldWithText:self.reasonForText]+10);
        }else if (indexPath.row+rowAdjst == CLCareerFunctionIndex){
            
            return MAX(44, [self getHeightForTokenFieldWithText:self.functionText]+10);
        }else if (indexPath.row+rowAdjst == CLCareerLevelIndex){
            
//            return MAX(44, [self getHeightForTokenFieldWithText:self.careerLevelText]+10);
            return 44;
        }else{
            return 44;
        }
        
    }else if(indexPath.section == CLCareerDocIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.carrerHisObj.documents count]+1)/2));
    }else if (indexPath.section == CLCareerSalaryBenefitsIndex || indexPath.section == CLCareerJobFactsIndex){
        return 64;
    }else if (indexPath.section == CLCareerMajorAchvmentsIndex){
        return 50;
    }else if (indexPath.section ==CLCareerExpGainedIndex){
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.expGainedText];
        }
        return MAX(44, ansHeight+1);
    }else if (indexPath.section == CLCareerRemarksIndex){
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.remarkText];
        }
        return MAX(44, ansHeight+1);
    }
    else{
        return 44;
    }
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLCareerMajorAchvmentsIndex) {
        CLWorkAchievementViewController *controller = [[CLWorkAchievementViewController alloc]initWithNibName:@"CLWorkAchievementViewController" bundle:[NSBundle mainBundle]];
        controller.delegate =self;
        controller.wrkHisId = self.carrerHisObj.wrkHisId;
        controller.workAchObj = [self.workAchievmentsArray objectAtIndex:indexPath.row];
        controller.isEditMode = YES;
        [self.navigationController pushViewController:controller animated:YES];
    }else if (indexPath.section == CLCareerJobFactsIndex){
        CLKeyJobFactsViewController *jobFactController = [[CLKeyJobFactsViewController alloc]initWithNibName:@"CLKeyJobFactsViewController" bundle:[NSBundle mainBundle]];
        jobFactController.careerLevel = self.selectedCareerLevel;
        
        if (jobFactController.keyJobFactsObj == NULL) {
            jobFactController.keyJobFactsObj = self.keyJobFactsObj;
        }
        jobFactController.delegate = self;
        [self.navigationController pushViewController:jobFactController animated:YES];
    }else if (indexPath.section == CLCareerSalaryBenefitsIndex){
        CLSalaryBenefitsViewController *salaryBenefitsController = [[CLSalaryBenefitsViewController alloc]initWithNibName:@"CLSalaryBenefitsViewController" bundle:[NSBundle mainBundle]];
        salaryBenefitsController.selectedCountry = self.selectedCountry;
        salaryBenefitsController.delegate = self;
        salaryBenefitsController.salBenefitssObj = self.salBenefitsObj;
        [self.navigationController pushViewController:salaryBenefitsController animated:YES];
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == CLCareerMajorAchvmentsIndex) {
        return YES;
    }
    else{
        return NO;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == CLCareerMajorAchvmentsIndex) {
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            [self removeWorkAchievmentAtIndexPath:indexPath];
        }
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    switch (section) {
        case CLCareerHistoryIndex:
            return NSLocalizedString(@"My Career History", @"My Career History section heading text");
            break;
        case CLCareerMoveReasonIndex:
            if (!self.onGoing) {
                return NSLocalizedString(@"Reason for Career move", @"Reason for Career move section heading text");
            }
            else{
                return @"";
            }
            break;
        case CLCareerReportedToIndex:
            if (self.onGoing) {
                return NSLocalizedString(@"Reporting To", @"Reporting To section heading text");
            }
            else{
                return NSLocalizedString(@"Reported To", @"Reported To section heading text");
            }
            break;
        case CLCareerMajorAchvmentsIndex:
            return NSLocalizedString(@"Work Achievements", @"Work Achievements section heading text");
            break;
        case CLCareerRemarksIndex:
            return NSLocalizedString(@"Anything else about this job you want us to know", @"Anything else about this job you want us to know section heading text");
            break;
        case CLCareerExpGainedIndex:
            return NSLocalizedString(@"Experiences Gained", @"Experiences Gained section heading text");
            break;
        case CLCareerDocIndex:
            return NSLocalizedString(@"Documents", @"Documents section heading text");
            break;
            
        default:
            return nil;
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == CLCareerRemarksIndex)
        return 50;
    else
        return -1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    if (section == CLCareerMajorAchvmentsIndex) {
        return 37.0;
    }else{
        return 1.0;
    }
}
- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    if (section==CLCareerMajorAchvmentsIndex){
        
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        
        return sectionFooter;
    }
    else{
        return nil;
    }
}
#pragma mark - Delete Work Achievement -
-(void)removeWorkAchievmentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLWorkAchievementObject *wrkAchievmentObj = [self.workAchievmentsArray objectAtIndex:indexPath.row];
    NSString *deleteAchievmentId = wrkAchievmentObj.achievementId;
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting work achievment");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.navigationItem.hidesBackButton=YES;
    
    [CLWorkAchievementObject deleteWorkAchievement:deleteAchievmentId forUser:[CLUserObject currentUser].userID success:^{
        [progressHUD hideWithAnimation:YES];
        self.navigationItem.hidesBackButton=NO;
        [self.workAchievmentsArray removeObjectAtIndex:indexPath.row];
        
        if(indexPath.row==0 && [self.workAchievmentsArray count]==0){
            [self.tableView reloadData];
        }
        else{
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    } failure:^(NSString *error) {
        if (![error isEqualToString:@""]) {
            [progressHUD hideWithAnimation:YES];
            self.navigationItem.hidesBackButton=NO;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
    
}
-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}
#pragma mark - IBActions -

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    
    CLWorkAchievementViewController *controller = [[CLWorkAchievementViewController alloc]initWithNibName:@"CLWorkAchievementViewController" bundle:[NSBundle mainBundle]];
    controller.delegate =self;
    controller.wrkHisId = self.carrerHisObj.wrkHisId;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
    [self presentViewController:nav animated:YES completion:nil];
    
}
#pragma mark  - CLTappableCellDelegate Methods -
-(void) cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    
    int adjustedIndex = 0;
    if (self.isNewCompny) {
        adjustedIndex = 2;
    }
    
    int rowAdjst = [self reasonForMoveRowUpdate];
    if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerCountryIndex) {
        
        CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
        selectLocation.locationListType=LocationListingTypeOtherCountries;
        selectLocation.forceSingleSelection = YES;
        selectLocation.delegate=self;
        UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
        [self presentViewController:nav animated:YES completion:nil];
        
    }else if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerCompanyNameIndex) {
        
        if ([self.selectedCountry count] > 0) {
            CLSelectCompanyNameViewController *selectCompanyName=[[CLSelectCompanyNameViewController alloc] initWithNibName:@"CLSelectCompanyNameViewController" bundle:[NSBundle mainBundle]];
            selectCompanyName.countryCode = [self.selectedCountry objectForKey:kLocationCountryCode];
            
            selectCompanyName.delegate=self;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectCompanyName];
            [self presentViewController:nav animated:YES completion:nil];
            
        }else{
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select Country.", @"Error Message for before choose Country") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
        
    }
    
    else if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerIndustryIndex && !self.isNewCompny){
        CLIndustrySectorViewController *controller = [[CLIndustrySectorViewController alloc]initWithNibName:@"CLIndustrySectorViewController" bundle:[NSBundle mainBundle]];
        controller.singleSelection=YES;
        //controller.alreadySelectedIndustries=[NSMutableArray arrayWithObject:self.selectedIndustry];
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }
    
    else if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerCompanyLocationIndex-adjustedIndex) {
        
        if (self.selectedCountry !=nil) {
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            selectLocation.locationListType=LocationListingCountryBasedLocation;
            
            selectLocation.forceSingleSelection = YES;
            
            selectLocation.selectedLocations = [[NSMutableArray alloc]initWithObjects:self.selectedCountry, nil];
            selectLocation.countryCodeforListing=[self.selectedCountry objectForKey:kLocationCountryCode];
            selectLocation.delegate=self;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];
        }else{
            [CLCommon showAlertwithTitle:@"" alertString:NSLocalizedString(@"Please select country",@"error msg") cancelbuttonName:NSLocalizedString(@"OK",@"ok title")];
        }
    }else if (indexPath.section == CLCareerMoveReasonIndex && indexPath.row+rowAdjst == CLCareerReasonForMoveIndex){
        
        CLCareerMoveReasonViewController *controller = [[CLCareerMoveReasonViewController alloc]initWithNibName:@"CLCareerMoveReasonViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedReasons = self.alreadySelectedReasonArray;
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
        
    }else if (indexPath.section == CLCareerMoveReasonIndex && indexPath.row+rowAdjst == CLCareerFunctionIndex){
        
        CLSelectFunctionCategoryViewController *controller = [[CLSelectFunctionCategoryViewController alloc]initWithNibName:@"CLSelectFunctionCategoryViewController" bundle:[NSBundle mainBundle]];
        controller.alreadySelectedFunctions=self.selectedFunctionArray;
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }else if (indexPath.section == CLCareerMoveReasonIndex && indexPath.row+rowAdjst == CLCareerLevelIndex){
        
        CLSelectJobLevelGroupViewController *controller = [[CLSelectJobLevelGroupViewController alloc]initWithNibName:@"CLSelectJobLevelGroupViewController" bundle:[NSBundle mainBundle]];
        controller.selectedCareerlevelDict = self.selectedCareerLevel;
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }else if (indexPath.section == CLCareerReportedToIndex && indexPath.row == CLCareerEmployeementTypeIndex){
        
        CLEmployeementTypeViewController *controller = [[CLEmployeementTypeViewController alloc]initWithNibName:@"CLEmployeementTypeViewController" bundle:[NSBundle mainBundle]];
        controller.delegate =self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
        [self presentViewController:nav animated:YES completion:nil];
    }
    else if (indexPath.section == CLCareerMoveReasonIndex && indexPath.row+rowAdjst == CLCareerJobScopeIndex){
        if (self.selectedCountry == nil) {
            [CLCommon showAlertwithTitle:@"" alertString:NSLocalizedString(@"Please select country",@"error msg") cancelbuttonName:NSLocalizedString(@"OK",@"ok title")];
        }
        else{
            CLJobScopeViewController *jobScopeViewController = [[CLJobScopeViewController alloc]initWithNibName:@"CLJobScopeViewController" bundle:[NSBundle mainBundle]];
            [jobScopeViewController setSelectedJobScopeDictDictForEdit:self.selectedJobScope];
            jobScopeViewController.delegate=self;
            jobScopeViewController.delegateTwo=self;
            jobScopeViewController.singleSelectionOn = YES;
            [jobScopeViewController setSelectedCountry:self.selectedCountry];
            UINavigationController *jobNav = [[UINavigationController alloc]initWithRootViewController:jobScopeViewController];
            [self.navigationController presentViewController:jobNav animated:YES completion:nil];
        }
        
    }else if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerBusinessDivisionIndex && !self.isNewCompny){
        
        if (self.selectedCompanyName !=nil) {
            CLBusinessDivViewController *selectBusinessDivController=[[CLBusinessDivViewController alloc] initWithStyle:UITableViewStylePlain];
            selectBusinessDivController.delegate=self;
            
            //selectBusinessDivController.completeBusinessDiv = self.employmentBusDivArray;
            selectBusinessDivController.selectedCompany = self.selectedCompanyName;
            selectBusinessDivController.alreadySelectedBusDivision=self.selectedMultipleBusDiv;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectBusinessDivController];
            [self presentViewController:nav animated:YES completion:nil];
        }else{
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please specify the company name", @"Please specify the company name") cancelbuttonName:NSLocalizedString(@"OK", @"Ok")];
        }
        
    }
}


#pragma mark - CLIndustry delegate -

-(void)selectIndustryControllerDidSelectIndustry:(CLIndustryViewController *)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
    self.selectedIndustry = [industryArray objectAtIndex:0];
    [self.tableView reloadData];
}

-(void)selectIndustryControllerDidDeleteIndustry:(CLIndustrySectorViewController *)controller withArray:(NSMutableArray *)industryArray andListArray:(NSMutableArray *)listArray{
    self.selectedIndustry = [industryArray objectAtIndex:0];
    [self.tableView reloadData];
}

-(void)industryGroupViewController:(CLIndustryGroupViewController *)controller didAddOtherIndustryGroup:(NSMutableDictionary *)selectedOtherGroup andListArray:(NSMutableArray *)listArray{
    
    self.selectedIndustry = selectedOtherGroup;
    [self.tableView reloadData];
}



#pragma mark - CLHeightAdjustTextCellDelegate Methods -

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    self.txtFirstResponder = nil;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    if (indexPath.section == CLCareerRemarksIndex) {
        self.remarkText = heightCell.text;
    }else if (indexPath.section == CLCareerExpGainedIndex){
        self.expGainedText=heightCell.text;
    }
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
    
}
- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark - CLTextCheckBoxCellDelegate Methods -
-(void)textCheckBoxBgChange:(CLTextCheckBoxCell *)cell withStatus:(BOOL)status{
    
    [CLCommon doViewAnimation:self.view];
    NSIndexPath *indexPath = cell.cellIndexPath;
    if (indexPath.section == CLCareerHistoryIndex) {
        if (status) {
            self.onGoing = YES;
        }else{
            self.onGoing = NO;
        }
    }
    else if (indexPath.section == CLCareerSelfEmployed){
        if (status) {
            self.selfEmployed = YES;
        }else{
            self.selfEmployed = NO;
        }
    }
    [self.tableView reloadData];
}

-(void)loadSelectedJobScopeDict:(NSMutableDictionary *)jobScopeDict{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[jobScopeDict objectForKey:kCLCareerHistoryJobImpactCodeKey],kCLCareerHistoryJobImpactIdkey,[NSString stringWithFormat:@"%@ (%@)", [jobScopeDict objectForKey:kCLCareerHistoryJobImpactjobScopeGroupName], [jobScopeDict objectForKey:kCLCareerHistoryJobImpactjobScope]], kCLCareerHistoryJobImpactNamekey, nil];
    self.selectedJobScope = dict;
    self.jobScopeText = [self.selectedJobScope objectForKey:kCLCareerHistoryJobImpactNamekey];
    [self.tableView reloadData];
}

#pragma mark - CLBusinessDivDeleagte -
-(void)employmentDetailsController:(CLBusinessDivViewController *)controller didAddBusinessDiv:(NSMutableArray *)businessDivArray{
    self.selectedMultipleBusDiv = businessDivArray;
    [self businessDivTextForArray:self.selectedMultipleBusDiv];
    [self.tableView reloadData];
}

#pragma mark - WorkAchievment delegate method -
- (void)workAchievementController:(CLWorkAchievementViewController *)controller didAddAchievement:(CLWorkAchievementObject *)workAchObj{
    
    [self.workAchievmentsArray addObject:workAchObj];
    [self.tableView reloadData];
}
#pragma mark - KeyJobFacts delegate method -
- (void)keyJobController:(CLKeyJobFactsViewController *)controller didAddKeyJob:(CLCareerKeyJobFactsObject *)keyJobObj{
    
    self.keyJobFactsObj = keyJobObj;
    
}
#pragma mark - Salary Benefits delegate method -
-(void)salaryBenefitsController:(CLSalaryBenefitsViewController *)controller didAddSalaryBenefits:(CLCareerSalaryBenefitsObject *)salBenefitssObj{
 
    self.salBenefitsObj = salBenefitssObj;
}

#pragma mark - CLSelectLocationDelegate -
- (void)selectLocationControllerDidSelectLocations:(CLSelectLocationViewController*)controller forType:(LocationListingType)type withArray:(NSMutableArray *)locArray{
    
    //self.carrerHisObj.careerLocation =nil;
    //self.carrerHisObj.careerCountry =nil;
    self.selectedCompanyName=nil;
    self.companyNameText = @"";
    self.selectedMultipleBusDiv = nil;
    self.companyDescText = @"";
    self.multipleBusinessDivText = nil;
    self.selectedIndustry = nil;
    self.selectedJobScope = nil;
    self.jobScopeText = @"";
    self.selectedCountry=[locArray objectAtIndex:0];
    if ([self.selectedCountry objectForKey:kLocationCode] == nil) {
        self.companyLocationText = @"";
    }
    
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCareerHistoryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
}

-(void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController *)controller withDictonary:(NSMutableDictionary *)locDict{
    self.selectedCountry=locDict;
    if ([self.selectedCountry objectForKey:kLocationCode] == nil) {
        self.companyLocationText = @"";
    }
    
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCareerHistoryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];

}

#pragma mark - ClCompany name delegate -
-(void)selectCompanyNameDidSelectCompanyName:(CLSelectCompanyNameViewController *)controller withDict:(NSMutableDictionary *)companyDict companyDiv:(NSMutableArray *)companyDivisions isNew:(BOOL)isNewCompany{
    
    self.selectedMultipleBusDiv = nil;
    self.multipleBusinessDivText = nil;
    self.selectedIndustry = nil;
    
    
    if (companyDivisions.count>0 && [[companyDivisions objectAtIndex:0] count]>0) {
        self.selectedIndustry = [NSMutableDictionary dictionaryWithDictionary:[companyDivisions objectAtIndex:0]];
    }
    [self.companyDivisionArray removeAllObjects];
    self.companyDivisionArray = [[NSMutableArray alloc]initWithArray:companyDivisions];
    [self.companyDivisionArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:kCLNewEntryId,kCLSearchCompanyDivisionIdkey,kCLCompanyDivisionOther,kCLSearchCompanyDivisionNamekey, nil] atIndex:[self.companyDivisionArray count]];
    if (isNewCompany) {
        self.isNewCompny = YES;
    }else{
        self.isNewCompny = NO;
    }
    self.selectedCompanyName = companyDict;
    self.companyNameText = [companyDict objectForKeyNotNull:kCLCareerHistoryCompanyNamekey];
    [self.pickerView reloadAllComponents];
//    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    [self.tableView reloadSections:[[NSIndexSet alloc] initWithIndex:CLCareerHistoryIndex] withRowAnimation:UITableViewRowAnimationAutomatic];
    
}

#pragma mark - CLTappable cell delegate -
- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    switch (indexPath.section) {
        case CLCareerHistoryIndex:{
            int adjust = 0;
            if (self.isNewCompny) {
                adjust = 2;
            }
                if (indexPath.row == CLCareerCompanyNameIndex){
                self.companyNameText = @"";
                self.selectedCompanyName = nil;
            }
            else if(indexPath.row == CLCareerCompanyLocationIndex-adjust)
            {
                self.companyLocationText = @"";
//                [self.selectedCountry setObject:@"" forKey:@"jobLocationAdminArea"];
//                [self.selectedCountry setObject:@"" forKey:@"jobLocationCode"];
//                [self.selectedCountry setObject:@"" forKey:@"jobLocationName"];
                [self.selectedCountry removeObjectForKey:@"jobLocationAdminArea"];
                [self.selectedCountry removeObjectForKey:@"jobLocationCode"];
                [self.selectedCountry removeObjectForKey:@"jobLocationName"];
                self.carrerHisObj.careerLocation.locationName = @"";
                self.carrerHisObj.careerLocation.locationCode = @"";
            }
        }
        break;
        case CLCareerReportedToIndex:{
            if (indexPath.row == CLCareerEmployeementTypeIndex) {
                self.empTypeText =@"";
                self.selectedEmpType = nil;
            }
        }
        break;
            
        case CLCareerMoveReasonIndex:
        {
            NSIndexPath *reasonFormoveIndex;
            int rowAdjst = [self reasonForMoveRowUpdate];
            reasonFormoveIndex = [NSIndexPath indexPathForRow:indexPath.row+rowAdjst inSection:CLCareerMoveReasonIndex];
            
            if(reasonFormoveIndex.row == CLCareerLevelIndex)
            {
                self.selectedCareerLevel = nil;
                self.careerLevelText = @"";
            }
            else if(reasonFormoveIndex.row == CLCareerJobScopeIndex)
            {
                self.selectedJobScope = nil;
                self.jobScopeText = @"";
            }
        }
            break;
        default:
            break;
    }
    
    [self.tableView reloadData];

}

#pragma mark - CLSimpleTextCellDelegate Methods -
-(void)cellWillClearContent:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    int adjusttedIndex = 0;
    if (self.isNewCompny) {
        adjusttedIndex = 1;
        
    }
    if (indexPath.section==CLCareerHistoryIndex) {
        
        int rowAdjst = [self rowCountUpdateMethod]+1;
        
       
        if (indexPath.row+rowAdjst == CLCareerJobTitleIndex) {
            self.jobTitleText = @"";
        }
        else if (indexPath.row+rowAdjst == CLCareerBusinessDivisionIndex){
            self.businessDivisionText = @"";
            self.selectedcompanyDivision = nil;
        }
        else if (indexPath.row+rowAdjst == CLCareerFromDateIndex-adjusttedIndex){
            self.fromDate=nil;
            self.fromDateText = @"";
        }
        else if (indexPath.row+rowAdjst == CLCareerToDateIndex-adjusttedIndex){
            self.toDate=nil;
            self.toDateText = @"";
        }
        else if (indexPath.row+rowAdjst == CLCareerCompanyDescIndex-adjusttedIndex){
            self.companyDescText=@"";
        }
    }
    else if (indexPath.section == CLCareerMoveReasonIndex){
        int rowCount = [self reasonForMoveRowUpdate];
        switch (indexPath.row+rowCount) {
            case CLCareerJobScopeIndex:{
                self.selectedJobScope=nil;
                self.jobScopeText = @"";
                break;
            }
            default:
                break;
        }
    }else if (indexPath.section == CLCareerReportedToIndex){
        switch (indexPath.row) {
            case CLCareerPrimarySecondaryIndex:{
                self.primarySecondaryText =@"";
                self.isPrimary = YES;
                break;
            }case CLCareerLineManager:{
                self.reportedToText =@"";
                 break;
            }
            case CLCareerEmployeementContractTypeIndex:{
                self.selectedEmpContractType =nil;
                break;
            }
            default:
                self.timeSpendText =@"";
                break;
        }
    }
    
    [self.tableView reloadData];
}
- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    
    self.txtFirstResponder=textField;
    self.txtViewFirstResponder = nil;
    NSIndexPath *indexPath = cell.cellIndexPath;
    
    self.datePicker.tag = indexPath.section;
    
    int rowAdjst = [self rowCountUpdateMethod];
    int rowAdjstReasonForMove = [self reasonForMoveRowUpdate];
    if (indexPath.section == CLCareerMoveReasonIndex && indexPath.row+rowAdjstReasonForMove == CLCareerJobScopeIndex) {
        self.pickerView.tag = kCLJobScopePickerTag;
        [self.pickerView reloadAllComponents];
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
    }
    
    else if (indexPath.section == CLCareerHistoryIndex && indexPath.row == CLCareerBusinessDivisionIndex){
        self.pickerView.tag = kCLCompanyDivPickerTag;
        [self.pickerView reloadAllComponents];
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
    }else if (indexPath.section == CLCareerReportedToIndex && indexPath.row == CLCareerPrimarySecondaryIndex){
        self.pickerView.tag = kCLPrimarySecondaryPickerTag;
        [self.pickerView reloadAllComponents];
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
        
    }else if (indexPath.section == CLCareerReportedToIndex && indexPath.row == CLCareerEmployeementContractTypeIndex){
        self.pickerView.tag = kCLEmpContractTypePickerTag;
        [self.pickerView reloadAllComponents];
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
    }
    else if (indexPath.section == CLCareerHistoryIndex && indexPath.row+rowAdjst == CLCareerToDateIndex) {
        //NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDate *currentDate = [NSDate date];
        //NSDateComponents *comps = [[NSDateComponents alloc] init];
        //[comps setYear:30];
        //NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
        [self.datePicker setMaximumDate:currentDate];
    }else{
        [self.pickerView selectRow:0 inComponent:0 animated:NO];
        [self.datePicker setMaximumDate:[NSDate date]];
    }
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    
    int adjustedIndex = 0;
    if (self.isNewCompny) {
        adjustedIndex = 2;
    }
    
    int rowAdjst = [self rowCountUpdateMethod];
    if (indexPath.section == CLCareerHistoryIndex) {
        
        if (indexPath.row == CLCareerJobTitleIndex) {
            self.jobTitleText=text;
        }else if (indexPath.row ==CLCareerCountryIndex){
            self.countryText=text;
        }else if (indexPath.row ==CLCareerCompanyNameIndex){
            self.companyNameText=text;
        }
//        else if (indexPath.row ==CLCareerBusinessDivisionIndex){
//            self.businessDivisionText=text;
//        }
        else if (indexPath.row+rowAdjst ==CLCareerCompanyLocationIndex-adjustedIndex){
            self.companyLocationText=text;
        }else if (indexPath.row+rowAdjst ==CLCareerCompanyDescIndex-adjustedIndex){
            self.companyDescText=text;
        }else if (indexPath.row+rowAdjst ==CLCareerFromDateIndex-adjustedIndex){
            self.fromDateText=text;
        }else if (indexPath.row+rowAdjst ==CLCareerToDateIndex-adjustedIndex){
            self.toDateText=text;
        }
    }
    else if (indexPath.section == CLCareerMoveReasonIndex){
        int rowAdjst = [self reasonForMoveRowUpdate];
        switch (indexPath.row+rowAdjst) {
            case CLCareerReasonForMoveIndex:
                self.reasonForText=text;
                break;
            case CLCareerFunctionIndex:
                self.functionText=text;
                break;
            case CLCareerLevelIndex:
                self.careerLevelText=text;
                break;
            case CLCareerJobScopeIndex:
                self.jobScopeText=text;
                break;
                
            default:
                break;
        }
    }else if (indexPath.section == CLCareerExpGainedIndex){
        self.expGainedText = text;
    }else if (indexPath.section ==CLCareerRemarksIndex){
        self.remarkText = text;
    }else if (indexPath.section == CLCareerReportedToIndex){
        switch (indexPath.row) {
                
            case CLCareerLineManager:{
                self.reportedToText= text;
                break;
            }
            case CLCareerEmployeementContractTypeIndex:{
                self.empContratTypeText = text;
                break;
            }
                
            default:
                self.timeSpendText= text;
                
                break;
        }
    }
    
}
#pragma mark - CLSelectJobLevelDelegate -

- (void)selectJobLevelControllerDidSelectJobLevel:(CLSelectJobLevelDetailViewController*)controller withDictonary:(NSMutableDictionary *)jobLevelDict{
    
    self.careerLevelText = [jobLevelDict objectForKey:jobLevelDetailDictName];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:[jobLevelDict objectForKey:jobLevelDetailDictCode] forKey:kCLCareerHistoryJobLevelCodekey];
    [dict setObject:[jobLevelDict objectForKey:jobLevelDetailDictName] forKey:kCLCareerHistoryJobLevelNamekey];
    self.selectedCareerLevel = dict;
    [self.tableView reloadData];
    
}
#pragma mark - CLSelectEmployeement Type Delegate -

- (void)selectEmployeementType:(CLEmployeementTypeDetailsViewController *)controller withDictonary:(NSMutableDictionary *)selectedEmpTypeDict{
    
    if (self.selectedEmpType == nil) {
        self.selectedEmpType = [[NSMutableDictionary alloc]init];
    }
    NSString *empTyeName = [NSString stringWithFormat:@"%@-%@",[selectedEmpTypeDict objectForKey:kempTypeName],[selectedEmpTypeDict objectForKey:kempTypeDetailName]];
    [self.selectedEmpType setObject:[selectedEmpTypeDict objectForKey:kempTypeDetailId] forKey:kCLCareerHistoryEmploymentTypeIdkey];
    [self.selectedEmpType setObject:empTyeName forKey:kCLCareerHistoryEmploymentTypekey];
    
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:CLCareerEmployeementTypeIndex inSection:CLCareerReportedToIndex]] withRowAnimation:UITableViewRowAnimationAutomatic];
}


#pragma mark - CLSelectJobFunctionDelegate -

- (void)selectJobFunctionControllerDidSelectJobFunction:(CLSelectFunctionViewController*)controller withArray:(NSMutableArray *)jobFunctionArray{
    
    if([self.selectedFunctionArray count]==0){
        self.selectedFunctionArray=jobFunctionArray;
    }
    else{
        [self.selectedFunctionArray addObjectsFromArray:jobFunctionArray];
    }
    [self updateFuctionTextForArray:self.selectedFunctionArray];
    [self.tableView reloadData];
}

- (void)selectJobFunctionControllerDidDeleteJobFunction:(CLSelectFunctionCategoryViewController*)controller withArray:(NSMutableArray *)jobFunctionArray{
    
    self.selectedFunctionArray=jobFunctionArray;
    [self updateFuctionTextForArray:self.selectedFunctionArray];
    [self.tableView reloadData];
    
}
- (void)selectCareerMoveReason:(CLCareerMoveReasonViewController *)controller withSelectedReasons:(NSMutableArray *)careerMoveReasonArray{
    
    self.alreadySelectedReasonArray=careerMoveReasonArray;
    [self updateReasonTextForArray:self.alreadySelectedReasonArray];
    [self.tableView reloadData];
}

#pragma mark - CLProfilePhotoListingGridCellDelegate Methods -

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
        addDocumentActionSheet.tag=1;
        [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
        editDocumentActionSheet.tag=2;
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark - UIImagePickerController Delegate -

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
     if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
    }];
     }
     else{
         [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
     }
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLCareerHistoryObject addDocument:image forWorkHistory:self.carrerHisObj.wrkHisId andUser:[CLUserObject currentUser].userID withCaption:caption success:^(CLFileObject *fileObj) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        if (!self.carrerHisObj.documents) {
            self.carrerHisObj.documents=[[NSMutableArray alloc] init];
        }
        [self.carrerHisObj.documents addObject:fileObj];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        if (![error isEqualToString:@""]) {
            self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
            self.navigationItem.rightBarButtonItem.enabled=YES;
            [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        }
    }];
}
#pragma mark - UIActionsheet Delegates -

-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            documentController.disableCaption = YES;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}


//Remove Work Histroy Docs
-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    
    CLFileObject *documentObj=[self.carrerHisObj.documents objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting WH doc");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLCareerHistoryObject deleteWorkHistoryDocument:documentObj.fileId success:^{
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [self.carrerHisObj.documents removeObjectAtIndex:indexPath.row];
        [self.tableView reloadData];
    } failure:^(NSString *error) {
        [progressHUD hideWithAnimation:YES];
        self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
        self.navigationItem.rightBarButtonItem.enabled=YES;
        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }];
    
}
-(void)updateReasonTextForArray:(NSMutableArray*)ReasonArray{
    
    self.alreadySelectedReasonArray = [[NSMutableArray alloc]init];
    
    if([ReasonArray count]>0){
        NSMutableString *string=[[NSMutableString alloc] init];
        
        for (int i=0; i<[ReasonArray count]; i++) {
            
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            if ([[ReasonArray objectAtIndex:i] objectForKeyNotNull:kCLCareerHistoryReasonForMoveReasonIdkey]) {
                [dict setObject:[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveReasonIdkey] forKey:kreasonForMoveDictId];
            }
            
            [dict setObject:[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveOtherFlgkey] forKey:kreasonOtherFlag];
            
            if ([[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveOtherFlgkey] intValue] == 1) {
                
                [string appendString:[NSString stringWithFormat:@"%@(%@)|",kCLCompanyDivisionOther,[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveOtherTxtkey]]];
                [dict setObject:[NSString stringWithFormat:@"%@(%@)",kCLCompanyDivisionOther,[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveOtherTxtkey]] forKey:kreasonForMoveDictName];
                [dict setObject:[[ReasonArray objectAtIndex:i] objectForKey:kCLCareerHistoryReasonForMoveOtherTxtkey] forKey:kreasonOtherText];
            }else{
                
                [string appendString:[NSString stringWithFormat:@"%@|",[[ReasonArray objectAtIndex:i] objectForKey:kreasonForMoveDictName]]];
                [dict setObject:[[ReasonArray objectAtIndex:i] objectForKey:kreasonForMoveDictName] forKey:kreasonForMoveDictName];
            }
            if ([[ReasonArray objectAtIndex:i] objectForKeyNotNull:kreasonForMoveDictCode] && ![[[ReasonArray objectAtIndex:i] objectForKeyNotNull:kreasonOtherFlag] boolValue]) {
                
                [dict setObject:[[ReasonArray objectAtIndex:i] objectForKey:kreasonForMoveDictCode] forKey:kreasonForMoveDictCode];
            }
            
            if ([[ReasonArray objectAtIndex:i] objectForKey:@"id"]) {
                [dict setObject:[[ReasonArray objectAtIndex:i]objectForKey:@"id"] forKey:@"id"];
            }
            [self.alreadySelectedReasonArray addObject:dict];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.reasonForText=string;
    }
    else{
        self.reasonForText=nil;
    }
}
-(void)updateFuctionTextForArrayFromObj:(NSMutableArray*)functionArray{
    
    if([functionArray count]>0){
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[functionArray count]; i++) {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            
            [dict setObject:[[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionOtherFalgkey] stringValue] forKey:kjobFunctionOtherFlag];
            
            if ([[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionOtherFalgkey] intValue] == 1) {
                [string appendString:[NSString stringWithFormat:@"%@ (%@)|",[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionkey],[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionOtherTxtkey]]];
                [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionOtherTxtkey] forKey:kjobFunctionOtherText];
            }
            else{
                [string appendString:[NSString stringWithFormat:@"%@|",[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionkey]]];
            }
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionkey] forKey:kjobFunctionName];
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionJobIdkey] forKey:kjobFunctionCode];
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kCLCareerHistoryFunctionIdkey] forKey:kcareerJobFunctionId];
            [self.selectedFunctionArray addObject:dict];
            
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.functionText=string;
        
    }
    else{
        self.functionText=@"";
    }
}
-(void)updateFuctionTextForArray:(NSMutableArray*)functionArray{
    
    if([functionArray count]>0){
        
        self.selectedFunctionArray =functionArray;
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[functionArray count]; i++) {
            if ([[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"]) {
                [string appendString:[NSString stringWithFormat:@"%@ (%@)|",[[functionArray objectAtIndex:i] objectForKey:kjobFunctionName],[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherText]]];
            }
            else{
                [string appendString:[NSString stringWithFormat:@"%@|",[[functionArray objectAtIndex:i] objectForKey:kjobFunctionName]]];
            }
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.functionText=string;
    }
    else{
        self.functionText=@"";
    }
}
-(CGFloat)getHeightForTokenFieldWithText:(NSString*)text{
    
    [self.tokenTxtField setFont:[UIFont systemFontOfSize:13]];
    [self.tokenTxtField setPromptText:nil];
    [self.tokenTxtField removeAllTokens];
    [self.tokenTxtField addTokensWithTitleList:text];
    [self.tokenTxtField layoutTokensAnimated:NO];
    return self.tokenTxtField.bounds.size.height;
}
-(void)businessDivTextForArray:(NSMutableArray*)businessDivArray{
    if([businessDivArray count]>0){
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[businessDivArray count]; i++) {
            
            [string appendString:[NSString stringWithFormat:@"%@|",[[businessDivArray objectAtIndex:i] objectForKey:kCLCareerHistoryCompanyDivisionkey]]];
            
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.multipleBusinessDivText=string;
    }
    else{
        self.multipleBusinessDivText=nil;
    }
}
@end
