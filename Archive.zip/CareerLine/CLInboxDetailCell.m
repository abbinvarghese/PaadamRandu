//
//  CLInboxDetailCell.m
//  CareerLine
//
//  Created by CSG on 3/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxDetailCell.h"

@interface CLInboxDetailCell()

@property (weak, nonatomic) IBOutlet UILabel *lblMsgPostTime;
@property (weak, nonatomic) IBOutlet UILabel *lblPostByTitle;
@property (weak, nonatomic) IBOutlet UITextView *lblPostMsg;

@end

@implementation CLInboxDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLInboxDetailCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)updateCellContent{
    self.lblMsgPostTime.textColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.lblMsgPostTime.text=[self.msgDict objectForKey:kCLInboxDetailMsgTimekey];
    if ([[self.msgDict objectForKey:kCLInboxDetailMsgTypekey] isEqualToString:@"A"]) {
        self.lblPostByTitle.text=NSLocalizedString(@"Me", @"Text for title of message sent by me");
    }
    else{
        self.lblPostByTitle.text=self.cmpnyName;
    }
    self.lblPostMsg.attributedText=[self.msgDict objectForKey:kCLInboxDetailMsgTextkey];
}

@end
