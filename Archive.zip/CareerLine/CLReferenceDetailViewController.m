//
//  CLReferenceDetailViewController.m
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLReferenceDetailViewController.h"
#import "CLDocumentViewController.h"
#import "CLReferencesObject.h"
#import "CLUserObject.h"
#import <MobileCoreServices/MobileCoreServices.h>

@interface CLReferenceDetailViewController ()

typedef enum {
    CLReferenceRefferedByIndex = 0,
    CLReferenceDateIndex= 1,
    CLReferenceJobTitleIndex= 2,
    CLReferenceCompanyIndex= 3,
    CLReferenceDescIndex = 4,
    CLReferenceDocumentIndex = 5
} CLReferenceTableSectionIndex;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;

@property(strong,nonatomic)NSString *refferedbyText;
@property(strong,nonatomic)NSDate *date;
@property(strong,nonatomic)NSString *jobTitleText;
@property(strong,nonatomic)NSString *companyText;
@property(strong,nonatomic)NSString *descriptionText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@property (strong, nonatomic)CLFileObject *mediaPressed;
@property (strong, nonatomic)NSIndexPath *indexPathPressed;

@end

@implementation CLReferenceDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Reference", @"Reference edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"refferedbyTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"dateTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"jobTitleCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"companyCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"descriptionCellIdentifier"];
    [self.tableView registerClass:[CLProfilePhotoListingGridCell class] forCellReuseIdentifier:@"documentListingCellIdentifier"];
    
    self.descriptionHeight=[[NSNumber alloc] init];
    
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    UIDatePicker *datePickr=[[UIDatePicker alloc] init];
    datePickr.backgroundColor=[UIColor whiteColor];
    [datePickr setLocale:[NSLocale currentLocale]];
    [datePickr setMaximumDate:[NSDate date]];
    if ([CLUserObject currentUser].birthDate) {
        [datePickr setMinimumDate:[CLUserObject currentUser].birthDate];
        [datePickr setDate:[CLUserObject currentUser].birthDate];
    }
    else{
        [datePickr setDate:[NSDate dateWithTimeIntervalSince1970:0]];
    }
    [datePickr setDatePickerMode:UIDatePickerModeDate];
    [datePickr addTarget:self action:@selector(datePickerDateChanged:) forControlEvents:UIControlEventValueChanged];
    self.datePicker=datePickr;
    
    
    if (self.isEditMode) {
        self.refferedbyText=self.revObj.refferedBy;
        self.date=self.revObj.date;
        [self.datePicker setDate:self.date];
        self.jobTitleText=self.revObj.jobTitle;
        self.companyText=self.revObj.Company;
        self.descriptionText=self.revObj.testimonials;
    }
    else{
        self.refferedbyText=@"";
        self.date=nil;
        self.jobTitleText=@"";
        self.companyText=@"";
        self.descriptionText=@"";
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"Achievements modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddReferenceAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Achievements modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Reffered by validation..
    if ([self.refferedbyText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Referred by.", @"Error Message for null Referred By field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.refferedbyText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Referred By length.", @"Error Message for length of Referred By field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Date validation..
    if (self.date==nil) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select referral date.", @"Error Message for null date field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Job title validation..
    if ([self.jobTitleText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Job title.", @"Error Message for null Job title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.jobTitleText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Job title length.", @"Error Message for length of Job title field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //Company validation..
    if ([self.companyText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Organisation.", @"Error Message for null Company field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.companyText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Company length.", @"Error Message for length of Company field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.descriptionText = [self.descriptionText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    
    //Recommendation validation..
//    if ([self.descriptionText isEqualToString:@""]) {
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Recommendation.", @"Error Message for null Recommendation field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//        return isValid=NO;
//    }
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)saveReferenceForEdit:(BOOL)isEditMode{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLReviewObject saveReference:self.revObj.referenceId
                              forUser:[CLUserObject currentUser].userID refferedBy:self.refferedbyText
                                 date:self.date
                             jobTitle:self.jobTitleText
                              company:self.companyText testimonials:self.descriptionText editMode:isEditMode
                              success:^(NSString *referenceId){
                                             if (isEditMode) {
                                                 self.revObj.refferedBy=self.refferedbyText;
                                                 [self.revObj updateDate:self.date];
                                                 self.revObj.jobTitle=self.jobTitleText;
                                                 self.revObj.Company=self.companyText;
                                                 self.revObj.testimonials=self.descriptionText;
                                             }
                                             else{
                                                 self.revObj=[[CLReviewObject alloc] init];
                                                 self.revObj.referenceId=referenceId;
                                                 self.revObj.refferedBy=self.refferedbyText;
                                                 [self.revObj updateDate:self.date];
                                                 self.revObj.jobTitle=self.jobTitleText;
                                                 self.revObj.Company=self.companyText;
                                                 self.revObj.testimonials=self.descriptionText;
                                             }
                                             
                                             [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                                         }
                                         failure:^(NSString *error){
                                             if (![error isEqualToString:@""]) {
                                                 self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                                 self.navigationItem.rightBarButtonItem.enabled=YES;
                                                 [progressHUD hideWithAnimation:YES];
                                                 [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save reference. Please try again later.", @"Error message when reference cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                             }
                                         }];
}

-(void)addPickedImageToDocuments:(UIImage*)image withCaption:(NSString*)caption{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Uploading...", @"Text displayed in the loading indicator while uploading image");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLReviewObject addDocument:image forReference:self.revObj.referenceId andUser:[CLUserObject currentUser].userID andCaption:caption
                            success:^(CLFileObject *documentObj){
                                [progressHUD hideWithAnimation:YES];
                                self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                self.navigationItem.rightBarButtonItem.enabled=YES;
                                if (!self.revObj.documents) {
                                    self.revObj.documents=[[NSMutableArray alloc] init];
                                }
                                [self.revObj.documents addObject:documentObj];
                                [self.tableView reloadData];
                            }
                            failure:^(NSString *error) {
                                if (![error isEqualToString:@""]) {
                                    [progressHUD hideWithAnimation:YES];
                                    self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                    self.navigationItem.rightBarButtonItem.enabled=YES;
                                    [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                }
                            }];
}

-(void)removeDocumentAtIndexPath:(NSIndexPath *)indexPath{
    CLFileObject *documentObj=[self.revObj.documents objectAtIndex:indexPath.row];
    
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Deleting...", @"Text displayed in the loading indicator while deleting achievement");
    self.activityIndicator=progressHUD;
    [self updateProgressHudColor];
    [progressHUD showInView:self.view];
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    
    [CLReviewObject deleteDocument:documentObj.fileId
                               success:^(){
                                   [progressHUD hideWithAnimation:YES];
                                   self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                   self.navigationItem.rightBarButtonItem.enabled=YES;
                                   [self.revObj.documents removeObjectAtIndex:indexPath.row];
                                   [self.tableView reloadData];
                               }
                               failure:^(NSString *error){
                                   if (![error isEqualToString:@""]) {
                                       [progressHUD hideWithAnimation:YES];
                                       self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                       self.navigationItem.rightBarButtonItem.enabled=YES;
                                       [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                   }
                               }];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

#pragma mark IBActions

-(IBAction)bttnActionSaveReferenceAndDismissModal:(id)sender{
    [self.view endEditing:YES];
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveReferenceForEdit:YES];
    }
}

-(IBAction)bttnActionAddReferenceAndDismissModal:(id)sender{
    [self.view endEditing:YES];
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveReferenceForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)datePickerDateChanged:(UIDatePicker*)datePicker{
    NSDate *date=datePicker.date;
    self.date=date;
    
    CLSimpleTextCell *dateCell=(CLSimpleTextCell*)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:CLReferenceDateIndex]];
    [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    if(cell!=nil){
        if (cell.cellIndexPath.section==CLReferenceDateIndex) {
            if (self.date==nil || !([self.date compare:self.datePicker.date] == NSOrderedSame)) {
                self.date=self.datePicker.date;
                [self.tableView reloadRowsAtIndexPaths:@[cell.cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }
    }
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.isEditMode) {
        return 6;
    }
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLReferenceRefferedByIndex:{
            CLSimpleTextCell *referredCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"refferedbyTextCellIdentifier"];
            referredCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [referredCell setTextInputAccesoryView:self.keyboardResignView];
            [referredCell setPlaceHoldrText:NSLocalizedString(@"Referred by", @"Placeholder for Referred By")];
            [referredCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [referredCell setCellText:self.refferedbyText];
            [referredCell setCellIndexPath:indexPath];
            [referredCell setCellClearButtonMode:UITextFieldViewModeAlways];
            referredCell.delegate=self;
            return referredCell;
            break;
        }
        case CLReferenceDateIndex:{
            CLSimpleTextCell *dateCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"dateTextCellIdentifier"];
            dateCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [dateCell setTextInputView:self.datePicker];
            [dateCell setTextInputAccesoryView:self.keyboardResignView];
            [dateCell setPlaceHoldrText:NSLocalizedString(@"Date", @"Placeholder for date field")];
            [dateCell setCellText:[CLCommon getStringForDate:self.date andLocalFormat:@"MMMMdy"]];
            [dateCell setCellIndexPath:indexPath];
            dateCell.delegate=self;
            return dateCell;
            break;
        }
        case CLReferenceJobTitleIndex:{
            CLSimpleTextCell *jobTitleCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"jobTitleCellIdentifier"];
            jobTitleCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [jobTitleCell setTextInputAccesoryView:self.keyboardResignView];
            [jobTitleCell setPlaceHoldrText:NSLocalizedString(@"Job Title of Person Giving Referral", @"Placeholder for Job Title field")];
            [jobTitleCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [jobTitleCell setCellText:self.jobTitleText];
            [jobTitleCell setCellIndexPath:indexPath];
            [jobTitleCell setCellClearButtonMode:UITextFieldViewModeAlways];
            jobTitleCell.delegate=self;
            return jobTitleCell;
            break;
        }
        case CLReferenceCompanyIndex:{
            CLSimpleTextCell *companyCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"companyCellIdentifier"];
            companyCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [companyCell setTextInputAccesoryView:self.keyboardResignView];
            [companyCell setPlaceHoldrText:NSLocalizedString(@"Organisation", @"Placeholder for company field")];
            [companyCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [companyCell setCellText:self.companyText];
            [companyCell setCellIndexPath:indexPath];
            [companyCell setCellClearButtonMode:UITextFieldViewModeAlways];
            companyCell.delegate=self;
            return companyCell;
            break;
        }
        case CLReferenceDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"descriptionCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.descriptionText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Recommendations/References/Testimonials", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        case CLReferenceDocumentIndex:{
            CLProfilePhotoListingGridCell *cell = (CLProfilePhotoListingGridCell *)[self.tableView dequeueReusableCellWithIdentifier:@"documentListingCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            cell.indexPath=indexPath;
            cell.delegate=self;
            cell.photosLimit=-1;
            cell.placeHolderImageName=@"documentPlaceHolder";
            cell.photoUrls=self.revObj.documents;
            [cell updateCollectionViewContents];
            return cell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLReferenceRefferedByIndex:
            return NSLocalizedString(@"Referred By", @"Placeholder for Referred By");
            break;
        case CLReferenceDateIndex:
            return NSLocalizedString(@"Date", @"Placeholder for date field");
            break;
        case CLReferenceJobTitleIndex:
            return NSLocalizedString(@"Job Title of Person Giving Referral", @"Placeholder for Job Title field");
            break;
        case CLReferenceCompanyIndex:
            return NSLocalizedString(@"Company", @"Placeholder for company field");
            break;
        case CLReferenceDescIndex:
            return NSLocalizedString(@"Recommendations/References/Testimonials", @"Placeholder for description field");
            break;
        case CLReferenceDocumentIndex:
            return NSLocalizedString(@"Documents", @"Placeholder for Documents field");
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLReferenceDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.descriptionText];
        }
        return MAX(44, ansHeight+1);
    }
    else if(indexPath.section==CLReferenceDocumentIndex){
        return ((([UIScreen mainScreen].bounds.size.width-30)/2)+15)*(ceil((float)([self.revObj.documents count]+1)/2));
    }
    else{
        return 44;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.descriptionText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLReferenceRefferedByIndex:{
            self.refferedbyText=text;
            break;
        }
        case CLReferenceJobTitleIndex:
            self.jobTitleText=text;
            break;
        case CLReferenceCompanyIndex:
            self.companyText=text;
            break;
        case CLReferenceDescIndex:
            self.descriptionText=text;
            break;
        default:
            break;
    }
}

#pragma mark CLProfilePhotoListingGridCellDelegate Methods

- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath{
    //add document
    if ([CLCommon isOSversionLessThan8]) {
    UIActionSheet *addDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1"),NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2"), nil];
    addDocumentActionSheet.tag=1;
    [addDocumentActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"document selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Take Photo", @"document selection actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self addDocumentActionSheetDismissedWithIndex:0];
                                          }];
        
        UIAlertAction *choosePhotoAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Choose Photo", @"photo selection actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                            {
                                                [self addDocumentActionSheetDismissedWithIndex:1];
                                            }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:takePhotoAction];
        [actionSheetController addAction:choosePhotoAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject *)mediaObj sectionIndexPath:(NSIndexPath *)secIndexPath andRowIndexPath:(NSIndexPath *)rowIndexPath{
    if ([CLCommon isOSversionLessThan8]) {
    UIActionSheet *editDocumentActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"View Document", @"document edit actionsheet option 1"), NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2"), nil];
    editDocumentActionSheet.tag=2;
    self.mediaPressed=mediaObj;
    self.indexPathPressed=rowIndexPath;
    [editDocumentActionSheet showInView:self.view];
    }
    else{
        self.mediaPressed=mediaObj;
        self.indexPathPressed=rowIndexPath;
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"photo selection actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        UIAlertAction *viewDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"View Document", @"document edit actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self editDocumentActionSheetDismissedWithIndex:0];
                                        }];
        
        UIAlertAction *deleteDocAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Document", @"document edit actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                          {
                                              [self editDocumentActionSheetDismissedWithIndex:1];
                                          }];
        
        [actionSheetController addAction:cancelAction];
        [actionSheetController addAction:viewDocAction];
        [actionSheetController addAction:deleteDocAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerController Delegate

-(void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    if ([CLCommon isSizeLessThan5MBForImage:pickedImage]) {
    [CLCommon ImageSelectionWithCaptionWithImagePicker:picker withSuccess:^(NSString *captionTxt){
        [self addPickedImageToDocuments:pickedImage withCaption:captionTxt];
        
    }];
    }
    else{
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Size Of The Document Should Be Less Than 5MB", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
    
//    UIImage *pickedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//    if(!pickedImage) pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
//    
//    [self addPickedImageToDocuments:pickedImage];
//    
//    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark UIActionsheet Delegates

-(void)addDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //camera..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Camera found", @"camera error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 1:{
            //photos..
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
                UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
                imagePicker.mediaTypes = @[(NSString *) kUTTypeImage];
                imagePicker.allowsEditing = YES;
                imagePicker.delegate = self;
                imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            else{
                [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"No Photo Library found", @"photo library error") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            }
            break;
        }
        case 2:
            //cancel..
            break;
            
        default:
            break;
    }
}

-(void)editDocumentActionSheetDismissedWithIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            //view document code..
            CLDocumentViewController *documentController=[[CLDocumentViewController alloc] initWithNibName:@"CLDocumentViewController" bundle:[NSBundle mainBundle]];
            documentController.documentObj=self.mediaPressed;
            [self.navigationController pushViewController:documentController animated:YES];
            break;
        }
        case 1:{
            //delete document code..
            [self removeDocumentAtIndexPath:self.indexPathPressed];
            break;
        }
        case 2:
            //cancel
            break;
            
        default:
            break;
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    //add document
    if (actionSheet.tag==1) {
        [self addDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
    //edit document
    else if (actionSheet.tag==2){
        [self editDocumentActionSheetDismissedWithIndex:buttonIndex];
    }
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(referenceController:didAddReview:)]){
                [self.delegate referenceController:self didAddReview:self.revObj];
            }
        }];
    }
}

@end
