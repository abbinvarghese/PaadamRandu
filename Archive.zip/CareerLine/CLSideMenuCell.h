//
//  CLSideMenuCell.h
//  CareerLine
//
//  Created by CSG on 1/31/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSideMenuCell : UITableViewCell

//To setup the cell according to the current status and selected menu..
-(void)setupCellForIndexPath:(NSIndexPath*)indexPath selectedIndex:(CLSideMenuViewControllerIndex)selectedSideMenuIndex;

@end
