//
//  CLUserObject.m
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLUserObject.h"
#import "SSKeychain.h"
#import "AFHTTPRequestOperationManager+Timeout.h"
#import "NSDictionary+Additions.h"
#import "CLDocsObject.h"

#define kDebugMessages 1

#define kUserEmailKey @"userEmail"
#define kUserPasswordKey @"userPassword"
#define kCredentialsServiceKey @"careerLine"

@implementation CLUserObject

static NSOperationQueue *loginRequest;
static NSOperationQueue *registerRequest;
static NSOperationQueue *registerVerificationMailRequest;
static NSOperationQueue *forgotPassVerificationMailRequest;
static NSOperationQueue *forgotPassRequest;
static NSOperationQueue *updateUserDetailsRequest;
static NSOperationQueue *firstTimeUserDetailsRequest;
static NSOperationQueue *logoutUserRequest;
static NSOperationQueue *trafficStatusChangeRequest;
static NSOperationQueue *getCompanyDivForSearchStringrequest;
static NSOperationQueue *documentListingRequest;
static NSOperationQueue *resetPasswordRequest;
static NSOperationQueue *updateCaptionRequest;
static CLUserObject *sharedUser;

- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties..
    [encoder encodeObject:self.userID forKey:kCLLoginUserIDkey];
    [encoder encodeObject:self.firstName forKey:kCLLoginUserFirstNamekey];
    [encoder encodeObject:self.lastName forKey:kCLLoginUserLastNamekey];
    [encoder encodeObject:self.preferredName forKey:kCLLoginUserPreferredNamekey];
    [encoder encodeObject:self.email forKey:kCLLoginUserEmailkey];
    [encoder encodeObject:self.birthDate forKey:kCLLoginUserBirthDatekey];
    [encoder encodeObject:self.iconURL forKey:kCLLoginUserIconUrlkey];
    [encoder encodeObject:[NSNumber numberWithLong:self.unreadJobsCount] forKey:kCLLoginUserUnreadJobsCountkey];
    [encoder encodeObject:[NSNumber numberWithLong:self.unreadInboxCount] forKey:kCLLoginUserUnreadInboxCountkey];
    [encoder encodeObject:[NSNumber numberWithLong:self.formStatus] forKey:kCLLoginUserFormStatuskey];
    [encoder encodeObject:[NSNumber numberWithInt:self.trafficLightStatus] forKey:kCLLoginUserTrafficLightStatuskey];
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties..
        self.userID=[decoder decodeObjectForKey:kCLLoginUserIDkey];
        self.firstName=[decoder decodeObjectForKey:kCLLoginUserFirstNamekey];
        self.lastName=[decoder decodeObjectForKey:kCLLoginUserLastNamekey];
        self.preferredName=[decoder decodeObjectForKey:kCLLoginUserPreferredNamekey];
        self.email=[decoder decodeObjectForKey:kCLLoginUserEmailkey];
        self.birthDate=[decoder decodeObjectForKey:kCLLoginUserBirthDatekey];
        self.iconURL=[decoder decodeObjectForKey:kCLLoginUserIconUrlkey];
        self.formStatus=[[decoder decodeObjectForKey:kCLLoginUserFormStatuskey] longValue];
        self.unreadJobsCount=[[decoder decodeObjectForKey:kCLLoginUserUnreadJobsCountkey] longValue];
        self.unreadInboxCount=[[decoder decodeObjectForKey:kCLLoginUserUnreadInboxCountkey] longValue];
        self.trafficLightStatus=[[decoder decodeObjectForKey:kCLLoginUserTrafficLightStatuskey] intValue];
    }
    return self;
}

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    if ([[dictionary objectForKeyNotNull:@"country"] objectForKey:@"country"] != [NSNull null]) {
        self.country=[dictionary objectForKeyNotNull:@"country"];
    }
    else{
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        dict = [CLCommon getcountryFromDevice];
        NSMutableDictionary *dict2 = [[NSMutableDictionary alloc]init];
        [dict2 setObject:[dict objectForKey:@"jobLocationCountryCode"] forKey:@"countryCode"];
        [dict2 setObject:[dict objectForKey:@"jobLocationCountryName"] forKey:@"country"];
        self.country=dict2;
    }
    
    self.userID = [dictionary objectForKeyNotNull:kCLLoginUserIDkey];
    self.firstName = [dictionary objectForKeyNotNull:kCLLoginUserFirstNamekey];
    self.lastName=[dictionary objectForKeyNotNull:kCLLoginUserLastNamekey];
    self.preferredName=[dictionary objectForKeyNotNull:kCLLoginUserPreferredNamekey];
    self.email = [dictionary objectForKeyNotNull:kCLLoginUserEmailkey];
    self.birthDate = [CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLLoginUserBirthDatekey] andFormat:@"dd-MM-yyyy"];
    self.iconURL=[dictionary objectForKeyNotNull:kCLLoginUserIconUrlkey];
    self.unreadJobsCount=[[dictionary objectForKeyNotNull:kCLLoginUserUnreadJobsCountkey] integerValue];
    self.unreadInboxCount=[[dictionary objectForKeyNotNull:kCLLoginUserUnreadInboxCountkey] integerValue];
    self.formStatus = [[dictionary objectForKeyNotNull:kCLLoginUserFormStatuskey] integerValue];
    self.trafficLightStatus=[[dictionary objectForKeyNotNull:kCLLoginUserTrafficLightStatuskey] intValue];
    self.clWelcomeStatus = [dictionary objectForKeyNotNull:@"cl_welcome_stat"];
    return self;
}

+ (void)saveLoginCredentialsWithUsername:(NSString*)username password:(NSString*)password isUpdating:(BOOL)isUpdating{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:sharedUser];
    [[NSUserDefaults standardUserDefaults] setObject:encodedObject forKey:kCLUserDefaultUserDetailsDictKey];
    if(!isUpdating){
        [[NSUserDefaults standardUserDefaults] setObject:username forKey:kUserEmailKey];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if(!isUpdating){
        NSLog(@"%@",username);
        NSLog(@"%@",password);
        [SSKeychain setPassword:password forService:kCredentialsServiceKey account:kUserPasswordKey];
    }
}

+ (void)deleteLoginCredentials {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kCLUserDefaultUserDetailsDictKey];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserEmailKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [SSKeychain deletePasswordForService:kCredentialsServiceKey account:kUserPasswordKey];
}

+ (BOOL)isSessionValid {
    NSString *username = [[NSUserDefaults standardUserDefaults] objectForKey:kUserEmailKey];
    NSString *password = [SSKeychain passwordForService:kCredentialsServiceKey account:kUserPasswordKey];
    
    if (username && password) {
        return YES;
    } else {
        return NO;
    }
}

+ (void)logout {
    [CLUserObject deleteLoginCredentials];
    sharedUser = nil;
}

+ (CLUserObject *)currentUser{
    return sharedUser;
}

+(void)setCurrentUserFromUserDefaults{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *encodedObject = [defaults objectForKey:kCLUserDefaultUserDetailsDictKey];
    sharedUser = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
}

- (void)setCurrentUser {
    sharedUser = self;
}

+ (void)cancelPendingRequests {
    [loginRequest cancelAllOperations];
    loginRequest = nil;
}

+ (void)cancelUpdateUserDetailsPendingRequest {
    [firstTimeUserDetailsRequest cancelAllOperations];
    firstTimeUserDetailsRequest = nil;
}

+ (void)cancelFirstTimeLoginPendingRequest {
    [updateUserDetailsRequest cancelAllOperations];
    updateUserDetailsRequest = nil;
}

+ (void)registerUser:(NSString*)userName withFirstName:(NSString *)firstName lastName:(NSString*)lastName password:(NSString*)password success:(void (^)(NSString *userName, NSString *password))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *userName, NSString *password){};
    }
    
    NSDictionary *parameters = @{@"firstname":firstName, @"lastname":lastName, @"email": userName, @"password": password};
    
    [registerRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        registerRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceRegisterURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"register user JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success(userName,password);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method used to resend verification mail for registration...
+ (void)resendRegisterVerificationMailforUser:(NSString*)userName success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"email": userName};
    
    [registerVerificationMailRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        registerVerificationMailRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceRegisterVerificationMailURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"resend reg mail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method used to resend verification mail for forgot pass...
+ (void)resendForgotPassVerificationMailforUser:(NSString*)userName success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"user": userName};
    
    [forgotPassVerificationMailRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        forgotPassVerificationMailRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceForgotPassVerificationMailURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"resend forgot pass JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)forgotPassword:(NSString*)userName success:(void (^)(NSString *userName))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *userName){};
    }
    
    NSDictionary *parameters = @{@"user": userName};
    [forgotPassRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        forgotPassRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceForgotPasswordURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"forgot pass JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success(userName);
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)loginUser:(NSString*)userName password:(NSString*)password typeAutoLogin:(NSString *)autologin success:(void (^)(int successFlag, NSString *userName, NSString *password,int autosave, NSString *welcomeStat))success failure:(void (^)(NSString *error))failure {
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(int successFlag, NSString *userName, NSString *password,int autosave, NSString *welcomeStat){};
    }
    NSDictionary *parameters;
    if ([CLCommon sharedInstance].deviceTokenString !=nil) {
        parameters = @{@"user": userName, @"pswd": password, @"devtype":@"1", @"isAutoLogin":autologin , @"devid":[CLCommon sharedInstance].deviceTokenString};
    }else{
        parameters = @{@"user": userName, @"pswd": password, @"devtype":@"1", @"isAutoLogin":autologin , @"devid":@""};
    }
    [loginRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        loginRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceLoginURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"login JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                //welcome screen
                if([[response objectForKey:@"form_status"] intValue] ==0 || [[response objectForKey:@"form_status"] intValue]==1){
                    sharedUser = [[CLUserObject alloc] initWithDictionary:response];
                    int aut = [[response objectForKey:@"autosave"]intValue];
                    success(1,userName,password,aut,[response objectForKey:@"cl_welcome_stat"]);
                }
                //home screen
                else{
                    sharedUser = [[CLUserObject alloc] initWithDictionary:response];
                    [CLUserObject saveLoginCredentialsWithUsername:userName password:password isUpdating:NO];
                    success(2,userName,password,(int)[response objectForKey:@"autosave"],[response objectForKey:@"cl_welcome_stat"]);
                }
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ \nresponse string=%@ \n code=%ld \n desc=%@",operation.response,operation.responseString,(long)error.code,error.description);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)updateUserDetailsWithUserId:(NSString*)userId success:(void (^)(void))success failure:(void (^)(void))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [updateUserDetailsRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        updateUserDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceUpdateUserDetailsURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            //if (kDebugMessages) {
                NSLog(@"update user detailsJSON: %@", response);
            //}
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure();
            }
            else{
                if([[response objectForKey:@"form_status"] isEqualToString:@"1"]){
                    failure();
                }
                else{
                    sharedUser = [[CLUserObject alloc] initWithDictionary:response];
                    [CLUserObject saveLoginCredentialsWithUsername:nil password:nil isUpdating:YES];
                    success();
                }
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"update user :response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure();
        }];
    }
    else
    {
        failure();
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for saving user details for first time login...
+ (void)saveFirstTimeUserDetails:(NSString*)detailsJsonString forUserId:(NSString*)userId password:(NSString*)password success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters;
    
    NSLog(@"%@",detailsJsonString);
    if ([CLCommon sharedInstance].deviceTokenString !=nil) {
        parameters = @{@"user":userId, @"fields":detailsJsonString, @"devtype":@"1", @"devid":[CLCommon sharedInstance].deviceTokenString};
    }else{
        parameters = @{@"user":userId, @"fields":detailsJsonString, @"devtype":@"1", @"devid":@""};
    }
    
    [firstTimeUserDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        firstTimeUserDetailsRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceFirstTimeSaveUserDetailsURL] parameters:parameters timeoutInterval:500 success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"first time JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                sharedUser = [[CLUserObject alloc] initWithDictionary:response];
                [CLUserObject saveLoginCredentialsWithUsername:userId password:password isUpdating:NO];
                success();
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)logoutUser:(NSString*)userId success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId};
    
    [logoutUserRequest cancelAllOperations];
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        logoutUserRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceLogoutURL]
          parameters:parameters
             success:^(AFHTTPRequestOperation *operation, id responseObject) {
                 NSDictionary *response=(NSDictionary *)responseObject;
                 if (kDebugMessages) {
                     NSLog(@"logout JSON: %@", response);
                 }
                 if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                     failure([response objectForKey:@"message"]);
                 }
                 else{
                     [self logout];
                     success();
                 }
             }
             failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                 if (kDebugMessages) {
                     NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                 }
                 failure([CLCommon getMessageForErrorCode:error.code]);
             }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)changeTrafficLightStatus:(int)status withEmail:(NSString*)email success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": email, @"status": [NSString stringWithFormat:@"%d",status]};
    
    [trafficStatusChangeRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        trafficStatusChangeRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
//        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFFivePostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
//            NSDictionary *response=(NSDictionary *)responseObject;
//            if (kDebugMessages) {
//                NSLog(@"JSON: %@", response);
//            }
//            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
//                failure([response objectForKey:@"message"]);
//            }
//            else{
//                sharedUser = [[CLUserObject alloc] initWithDictionary:response];
//                [CLUserObject saveLoginCredentialsWithUsername:email password:[CLCommon sharedInstance].passWord isUpdating:NO];
//                success();
//            }
//            
//        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//            if (kDebugMessages) {
//                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
//            }
//            failure([CLCommon getMessageForErrorCode:error.code]);
//        }];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLCRFFivePostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                sharedUser = [[CLUserObject alloc] initWithDictionary:response];
                [CLUserObject saveLoginCredentialsWithUsername:email password:[CLCommon sharedInstance].passWord isUpdating:NO];
                
                success();
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);

        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(void)getCompanyDivListForSearchString:(NSString*)searchText companyId:(NSString *)companyID andBlackListString:(NSString*)blackListString success:(void (^)(NSMutableArray *companyDivList))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *locationList){};
    }
    
    NSDictionary *parameters = @{@"str": searchText, @"companyId": companyID, @"id":blackListString};
    [getCompanyDivForSearchStringrequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getCompanyDivForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceGetCompanyDivSearchString] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"companyDivisions JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *companyDivisions=[[NSMutableArray alloc] init];
                NSArray *results=[response objectForKey:@"results"];
                for (int i=0; i<[results count]; i++) {
                    NSDictionary *companyDiv=[results objectAtIndex:i];
                    [companyDivisions addObject:companyDiv];
                }
                success(companyDivisions);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}


//To Get Document List by user id
+ (void)listDocumentsForUserId:(NSString*)userId pageNumber:(int)page success:(void (^)(NSMutableArray *documentList,BOOL isLastPageReached, NSInteger documentCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure{
    
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *documentList,BOOL isLastPageReached, NSInteger documentCount,NSInteger currentPage, NSInteger pages){};
    }
    
    if (kDebugMessages) {
        NSLog(@"retreiving page:%d",page);
    }
    
    NSDictionary *parameters = @{@"user": userId,@"page": [NSNumber numberWithInt:page]};
    
    [documentListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        documentListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceDocumentListURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"list Documents JSON: %@", response);
            }
            
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                int currentPage=[[response objectForKeyNotNull:kCLJobListjobCurrentPagesKey] intValue];
                int totalPages=[[response objectForKeyNotNull:kCLJobListjobNoOfPagesKey] intValue];
                
                BOOL isLastPage=NO;
                (currentPage==totalPages) ? (isLastPage=YES) : (isLastPage=NO);
                NSMutableArray *docArray = [[NSMutableArray alloc]init];
                for (NSDictionary *dic in [response objectForKey:@"MyDocuments"]) {
                    CLDocsObject *docObj = [[CLDocsObject alloc]initWithDictionary:dic];
                    [docArray addObject:docObj];
                }
                
                success(docArray,isLastPage,[[response objectForKeyNotNull:@"count"]integerValue],[[response objectForKeyNotNull:@"cur_page"]integerValue], [[response objectForKeyNotNull:@"pages"]integerValue]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ \nresponse string=%@ \n code=%ld \n desc=%@",operation.response,operation.responseString,(long)error.code,error.description);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(void)updateCaption:(NSString*)captionString forDocId:(NSString*)docId success:(void (^)(void)) success ailure:(void (^)(NSString *error))failure{
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"id": docId, @"caption":captionString};
    [updateCaptionRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        updateCaptionRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceUpdateCaption] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"] || [[response objectForKey:@"message"] isEqualToString:@"Record not found."]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+(void)resetPasswordForUserName:(NSString*) userName withPassword :(NSString*)password andActiveCode :(NSString*) activeCode success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"username": userName, @"activeCode":activeCode, @"password": password};
    [resetPasswordRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        resetPasswordRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];

        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceResetPasswordURL]  parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
                    if (kDebugMessages) {
                        NSLog(@"JSON: %@", response);
                    }
                    if([[response objectForKey:@"ACK"] isEqualToString:@"failure"] || [[response objectForKey:@"message"] isEqualToString:@"Record not found."]){
                        failure([response objectForKey:@"message"]);
                    }
                    else{
                        success();
                    }

        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                            NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                        }
                        failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }

}

@end
