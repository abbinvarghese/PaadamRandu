//
//  CLAboutMeMediaViewController.h
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLHeightAdjustTextCell.h"
#import "CLMediaPresenceObject.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"

@class CLAboutMeMediaViewController;

//Delegate Methods...
@protocol CLMediaControllerDelegate <NSObject>

@optional
- (void)mediaController:(CLAboutMeMediaViewController *)controller didAddWebsite:(CLMediaPresenceObject*)mediaObj;

@end

@interface CLAboutMeMediaViewController : UITableViewController<CLSimpleTextCellDelegate,CLHeightAdjustTextCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate,HTProgressHUDDelegate,UIAlertViewDelegate>

@property(nonatomic,weak) id <CLMediaControllerDelegate> delegate;
@property(nonatomic,strong)CLMediaPresenceObject *mediaObj;
@property(nonatomic,assign)BOOL isEditMode;

@end
