//
//  CLInfoTelephoneViewController.m
//  CareerLine
//
//  Created by CSG on 8/14/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInfoTelephoneViewController.h"
#import "CLCoreDataHelper.h"

@interface CLInfoTelephoneViewController ()

typedef enum {
    CLTelephoneISDIndex = 0,
    CLTelephoneAreaCodeIndex= 1,
    CLTelephoneNumberIndex = 2,
    CLTelephoneTypeIndex = 3,
    CLTelephoneIsPrimaryIndex = 4,
    CLTelephoneTableSectionCount=5
} CLTelephoneTableSectionIndex;

@property (strong, nonatomic) UIPickerView *pickerView;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;

@property(strong,nonatomic)NSString *ISDCodeText;
@property(strong,nonatomic)NSString *areaCodeText;
@property(strong,nonatomic)NSString *contactNumberText;
@property(strong,nonatomic)NSMutableDictionary *contactType;
@property(assign,nonatomic)BOOL isPrimaryContact;

@property(nonatomic,strong)NSMutableArray *ISDCodeArray;    //[{kisdCountryCode,kisdCode}, {}, ..]
@property(nonatomic,strong)NSMutableArray *contactTypeArray;    //[{id,text}, {}, ..]

@end

@implementation CLInfoTelephoneViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Telephone", @"Telephone edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"isdTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"areaCodeTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"contactNumberTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"contactTypeTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"isPrimaryTextCellIdentifier"];
    
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    if (self.isEditMode) {
        self.ISDCodeText=self.telephoneObj.telephoneIsdCode;
        self.areaCodeText=self.telephoneObj.telephoneAreaCode;
        self.contactNumberText=self.telephoneObj.telephoneContactNumber;
        self.contactType=self.telephoneObj.contactType;
        self.isPrimaryContact=self.telephoneObj.isPrimaryContact;
    }
    else{
        
        self.ISDCodeText = [[CLCoreDataHelper sharedCLCoreDataHelper]getISDOfCurrentCountry:self.currentCountryCode];
        
        self.areaCodeText=@"";
        self.contactNumberText=@"";
        self.contactType=[[NSMutableDictionary alloc] init];
        self.contactType=self.telephoneObj.contactType;
        self.isPrimaryContact=NO;
    }
    
    self.ISDCodeArray=[[[CLCoreDataHelper sharedCLCoreDataHelper] getAllISDCodeFromDB]mutableCopy];
    
    self.contactTypeArray=[NSMutableArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:ContactTypeAlternativeHome],kCLProfileAboutMeTelephoneContactTypeIdkey,@"Alternative Home",kCLProfileAboutMeTelephoneContactTypeTextkey, nil], [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:ContactTypeAlternativeMobile],kCLProfileAboutMeTelephoneContactTypeIdkey,@"Alternative Mobile",kCLProfileAboutMeTelephoneContactTypeTextkey, nil], [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:ContactTypeBusiness],kCLProfileAboutMeTelephoneContactTypeIdkey,@"Business",kCLProfileAboutMeTelephoneContactTypeTextkey, nil], nil];
    
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveTelephoneAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddTelephoneAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
   
    if ([self.ISDCodeText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Country Code", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    
    CLTelephoneContactType type=[[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue];
    if (type==ContactTypeMobile || type==ContactTypeAlternativeMobile) {
        
    }
    else{
        if ([self.areaCodeText isEqualToString:@""]) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Area Code", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
        else if ([self.areaCodeText length]>5) {
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Area Code length.", @"Error Message for length") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
            return isValid=NO;
        }
    }
    
    
    if ([self.contactNumberText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Contact Number", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.contactNumberText length]>15) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please check Contact Number length.", @"Error Message for length") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    if (self.contactType==ContactTypeNone) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Contact Type.", @"Error Message for null field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    return isValid;
}

-(int)getRowToSelectForISDCode:(NSString *)isdCode{
    int row=0;
    for (row=0; row<[self.ISDCodeArray count]; row++)
    {
        ClCountries *details = [self.ISDCodeArray objectAtIndex:row];
        
        if ([details.isdcode isEqualToString:isdCode]) {
            break;
        }
    }
    return row;
}

-(int)getRowToSelectForLocation{
    int row=0;
    for (int i=0; i<[self.ISDCodeArray count]; i++)
    {
        ClCountries *details = [self.ISDCodeArray objectAtIndex:row];
        if ([details.cyCode isEqualToString:self.currentCountryCode])
        {
        //if ([[[self.ISDCodeArray objectAtIndex:i] objectForKey:kisdCountryCode] isEqualToString:self.currentCountryCode]) {
            row=i;
            break;
        }
    }
    return row;
}

-(void)saveTelephoneForEdit:(BOOL)isEdit{
    if (isEdit) {
        self.telephoneObj.telephoneIsdCode=self.ISDCodeText;
        self.telephoneObj.telephoneAreaCode=self.areaCodeText;
        self.telephoneObj.telephoneContactNumber=self.contactNumberText;
        [self.telephoneObj updateFormattedTelephoneNumber];
        self.telephoneObj.contactType=self.contactType;
        self.telephoneObj.isPrimaryContact=self.isPrimaryContact;
        
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(telephoneController:didEditTelephoneNumber:forType:)]){
            [self.delegate telephoneController:self didEditTelephoneNumber:self.telephoneObj forType:[[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue]];
        }
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        if (self.telephoneObj==nil) {
            self.telephoneObj=[[CLTelephoneObject alloc] init];
        }
        self.telephoneObj.telephoneIsdCode=self.ISDCodeText;
        self.telephoneObj.telephoneAreaCode=self.areaCodeText;
        self.telephoneObj.telephoneContactNumber=self.contactNumberText;
        [self.telephoneObj updateFormattedTelephoneNumber];
        self.telephoneObj.contactType=self.contactType;
        self.telephoneObj.isPrimaryContact=self.isPrimaryContact;
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(telephoneController:didAddTelephoneNumber:forType:)]){
                [self.delegate telephoneController:self didAddTelephoneNumber:self.telephoneObj forType:[[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue]];
            }
        }];
    }
}

#pragma mark IBActions

-(IBAction)bttnActionSaveTelephoneAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveTelephoneForEdit:YES];
    }
}

-(IBAction)bttnActionAddTelephoneAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveTelephoneForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    
    if (cell!=nil) {
        if(cell.cellIndexPath.section==CLTelephoneISDIndex){
            ClCountries *details = [self.ISDCodeArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            self.ISDCodeText=details.isdcode;
            //[cell setCellText:self.ISDCodeText];
            [self.tableView reloadData];
        }
        else if(cell.cellIndexPath.section==CLTelephoneTypeIndex){
            self.contactType=[self.contactTypeArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            if ([[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue]==ContactTypeAlternativeMobile) {
                self.areaCodeText=@"";
            }
            [self.tableView reloadData];
        }
    }
    
    
    [self.txtFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return CLTelephoneTableSectionCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLTelephoneISDIndex:{
            CLSimpleTextCell *isdCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"isdTextCellIdentifier"];
            isdCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [isdCell setTextInputView:self.pickerView];
            [isdCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [isdCell setPlaceHoldrText:NSLocalizedString(@"Country Code", @"Placeholder text")];
            [isdCell setCellText:self.ISDCodeText];
            [isdCell setCellIndexPath:indexPath];
            isdCell.delegate=self;
            return isdCell;
            break;
        }
        case CLTelephoneAreaCodeIndex:{
            CLSimpleTextCell *areaCodeCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"areaCodeTextCellIdentifier"];
            areaCodeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [areaCodeCell setTextInputAccesoryView:self.keyboardResignView];
            [areaCodeCell setPlaceHoldrText:NSLocalizedString(@"Area Code", @"Placeholder text")];
            [areaCodeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [areaCodeCell setKeyboardType:UIKeyboardTypeNumberPad];
            [areaCodeCell setCellText:self.areaCodeText];
            [areaCodeCell setCellIndexPath:indexPath];
            areaCodeCell.delegate=self;
            
            CLTelephoneContactType type=[[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue];
            if (type==ContactTypeMobile || type==ContactTypeAlternativeMobile) {
                [areaCodeCell disableCellField];
            }
            else{
                [areaCodeCell enableCellField];
            }
            
            return areaCodeCell;
            break;
        }
        case CLTelephoneNumberIndex:{
            CLSimpleTextCell *numberCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"contactNumberTextCellIdentifier"];
            numberCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [numberCell setTextInputAccesoryView:self.keyboardResignView];
            [numberCell setPlaceHoldrText:NSLocalizedString(@"Contact Number", @"Placeholder text")];
            [numberCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [numberCell setKeyboardType:UIKeyboardTypeNumberPad];
            [numberCell setCellText:self.contactNumberText];
            [numberCell setCellIndexPath:indexPath];
            numberCell.delegate=self;
            return numberCell;
            break;
        }
        case CLTelephoneTypeIndex:{
            CLSimpleTextCell *typeCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"contactTypeTextCellIdentifier"];
            typeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [typeCell setTextInputView:self.pickerView];
            [typeCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [typeCell setPlaceHoldrText:NSLocalizedString(@"Home / Mobile", @"Placeholder text")];
            [typeCell setCellText:[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey]];
            [typeCell setCellIndexPath:indexPath];
            typeCell.delegate=self;
            
            CLTelephoneContactType type=[[self.contactType objectForKey:kCLProfileAboutMeTelephoneContactTypeIdkey] intValue];
            if (type==ContactTypeMobile || type==ContactTypeHome) {
                [typeCell disableCellField];
            }
            else{
                [typeCell enableCellField];
            }
            
            return typeCell;
            break;
        }
        case CLTelephoneIsPrimaryIndex:{
            CLTextCheckBoxCell *isPrimaryCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"isPrimaryTextCellIdentifier"];
            isPrimaryCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [isPrimaryCell setTextInputAccesoryView:self.keyboardResignView];
            [isPrimaryCell setPlaceHoldrText:NSLocalizedString(@"", @"Placeholder")];
            [isPrimaryCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [isPrimaryCell setCellText:@"Set as Primary Contact"];
            [isPrimaryCell setCellTextColor:[UIColor darkGrayColor]];
            [isPrimaryCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
            [isPrimaryCell setCellIndexPath:indexPath];
            [isPrimaryCell disableCelltxtField];
            [isPrimaryCell checkBoxClick:self.isPrimaryContact];
            isPrimaryCell.textCheckBoxdelegate=self;
            return isPrimaryCell;
            break;
        }
        
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLTelephoneISDIndex:
            return NSLocalizedString(@"Country Code", @"Placeholder text");
            break;
        case CLTelephoneAreaCodeIndex:
            return NSLocalizedString(@"Area Code", @"Placeholder text");
            break;
        case CLTelephoneNumberIndex:
            return NSLocalizedString(@"Contact Number", @"Placeholder text");
            break;
        case CLTelephoneTypeIndex:
            return NSLocalizedString(@"Contact Type", @"Placeholder text");
            break;
        case CLTelephoneIsPrimaryIndex:
            return nil;
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

#pragma mark UIPickerView Methods

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView.tag==1) {
        return [self.ISDCodeArray count];
    }
    else if (pickerView.tag==2){
        return [self.contactTypeArray count];
    }
    else{
        return 0;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag==1)
    {
        ClCountries *details = [self.ISDCodeArray objectAtIndex:row];
        label.text= details.isdcode;
    }
    else if (pickerView.tag==2){
        label.text= [[self.contactTypeArray objectAtIndex:row] objectForKey:kCLProfileAboutMeTelephoneContactTypeTextkey];
    }
    
    return label;
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath=cell.cellIndexPath;
    if(indexPath.section==CLTelephoneISDIndex){
        if (self.telephoneObj.telephoneIsdCode!=nil && ![self.telephoneObj.telephoneIsdCode isEqualToString:@""]) {
            [self.pickerView selectRow:[self getRowToSelectForISDCode:self.telephoneObj.telephoneIsdCode] inComponent:0 animated:NO];
        }
        else{
            [self.pickerView selectRow:[self getRowToSelectForLocation] inComponent:0 animated:NO];
        }
        
        self.pickerView.tag=1;
    }
    else if (indexPath.section==CLTelephoneTypeIndex){
        self.pickerView.tag=2;
    }
    [self.pickerView reloadAllComponents];
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLTelephoneISDIndex:
            self.ISDCodeText=text;
            break;
        case CLTelephoneAreaCodeIndex:
            self.areaCodeText=text;
            break;
        case CLTelephoneNumberIndex:
            self.contactNumberText=text;
            break;
            
        default:
            break;
    }
}

#pragma mark CLTextCheckBoxCellDelegate Methods

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    self.isPrimaryContact=status;
}

@end
