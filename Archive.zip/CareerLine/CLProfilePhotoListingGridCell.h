//
//  CLProfilePhotoListingGridCell.h
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLFileObject.h"

@class CLProfilePhotoListingGridCell;

//Delegate Methods...
@protocol CLProfilePhotoListingGridCellDelegate <NSObject>

@optional
- (void)cellDidPressAddDetailButton:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath;
- (void)cellDidPressMediaItem:(UITableViewCell *)cell forMedia:(CLFileObject*)mediaObj sectionIndexPath:(NSIndexPath*)secIndexPath andRowIndexPath:(NSIndexPath*)rowIndexPath;

@end

@interface CLProfilePhotoListingGridCell : UITableViewCell<UICollectionViewDataSource,UICollectionViewDelegate>

@property(nonatomic,weak) id <CLProfilePhotoListingGridCellDelegate> delegate;
@property(nonatomic,assign)NSInteger photosLimit;
@property(nonatomic,strong)NSMutableArray *photoUrls;
@property(nonatomic,strong)NSIndexPath *indexPath;
@property(nonatomic,strong)NSString *placeHolderImageName;

-(void)updateCollectionViewContents;

@end
