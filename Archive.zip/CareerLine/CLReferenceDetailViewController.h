//
//  CLReferenceDetailViewController.h
//  CareerLine
//
//  Created by CSG on 7/29/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLHeightAdjustTextCell.h"
#import "CLSimpleTextCell.h"
#import "CLReferencesObject.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLReviewObject.h"

@class CLReferenceDetailViewController;

//Delegate Methods...
@protocol CLReferenceControllerDelegate <NSObject>

@optional
- (void)referenceController:(CLReferenceDetailViewController *)controller didAddReview:(CLReviewObject*)reviewObj;

@end

@interface CLReferenceDetailViewController : UITableViewController<CLSimpleTextCellDelegate,CLProfilePhotoListingGridCellDelegate,CLHeightAdjustTextCellDelegate,HTProgressHUDDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property(nonatomic,weak) id <CLReferenceControllerDelegate> delegate;
@property(nonatomic,assign)BOOL isEditMode;
@property(nonatomic,strong)CLReviewObject *revObj;

@end
