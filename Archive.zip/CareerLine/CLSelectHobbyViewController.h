//
//  CLSelectHobbyViewController.h
//  CareerLine
//
//  Created by CSG on 8/20/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CLSelectHobbyViewController;

//Delegate Methods...
@protocol CLSelectHobbyDelegate <NSObject>
@optional
- (void)hobbyController:(CLSelectHobbyViewController*)controller didSelectHobby:(NSMutableDictionary *)hobbyDict;
@end

@interface CLSelectHobbyViewController : UITableViewController

@property(nonatomic,weak) id <CLSelectHobbyDelegate> delegate;
@property(nonatomic,strong) NSMutableArray *alreadySelectedHobbies;

@end
