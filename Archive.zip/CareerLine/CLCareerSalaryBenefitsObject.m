//
//  CLCareerSalaryBenefitsObject.m
//  CareerLine
//
//  Created by RENJITH on 06/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerSalaryBenefitsObject.h"

@implementation CLCareerSalaryBenefitsObject

@end
