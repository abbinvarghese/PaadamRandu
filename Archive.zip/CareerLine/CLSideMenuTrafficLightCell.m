//
//  CLSideMenuTrafficLightCell.m
//  CareerLine
//
//  Created by CSG on 3/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSideMenuTrafficLightCell.h"

#define kCellBgColor [UIColor colorFromHexCode:@"#292929"]
#define kCellSelectedBgColor [UIColor colorFromHexCode:@"#1C1C1C"]

@interface CLSideMenuTrafficLightCell()

@property (weak, nonatomic) IBOutlet UIImageView *imgTrafficLightIcon;
@property (weak, nonatomic) IBOutlet UILabel *lblTrafficLightTitle;
@end

@implementation CLSideMenuTrafficLightCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLSideMenuTrafficLightCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setupCell:(NSIndexPath*)indexPath forLightStatus:(CLTrafficLightStatus)status selectedIndex:(int)selectedIndexPathRow{
    self.backgroundColor=kCellBgColor;
    [self.lblTrafficLightTitle setTextColor:[UIColor grayColor]];
    switch (indexPath.row) {
        case 0:
            [self.lblTrafficLightTitle setText:NSLocalizedString(@"Happy", @"Traffic light red color button text")];
            self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_happy_gray"];
            break;
        case 1:
            [self.lblTrafficLightTitle setText:NSLocalizedString(@"Open", @"Traffic light amber color button text")];
            self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_open_gray"];
            break;
        case 2:
            [self.lblTrafficLightTitle setText:NSLocalizedString(@"Active",  @"Traffic light green color button text")];
            self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_find_gray"];
            break;
        default:
            break;
    }
    
    if (indexPath.row==selectedIndexPathRow) {
        self.backgroundColor=kCellSelectedBgColor;
        switch (status) {
            case CLTrafficLightGreenColor:
                self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_find"];
                [self.lblTrafficLightTitle setTextColor:ColorCode_SideMenuTextGreen];
                break;
            case CLTrafficLightAmberColor:
                self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_open"];
                [self.lblTrafficLightTitle setTextColor:ColorCode_SideMenuTextAmber];
                break;
            case CLTrafficLightRedColor:
                self.imgTrafficLightIcon.image=[UIImage imageNamed:@"icon_happy"];
                [self.lblTrafficLightTitle setTextColor:ColorCode_SideMenuTextRed];
                break;
            default:
                break;
        }
    }
}

@end
