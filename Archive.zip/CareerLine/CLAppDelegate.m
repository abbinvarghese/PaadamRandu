//
//  CLAppDelegate.m
//  CareerLine
//
//  Created by CSG on 1/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAppDelegate.h"
#import "CLSideMenuViewController.h"
#import "CLLoginFlowViewController.h"
#import "CLHomeViewController.h"
#import "CLProfileViewController.h"
#import "CLDocumentsViewController.h"
#import "CLKnowledgeListViewController.h"
#import "CLJobsViewController.h"
#import "CLInboxViewController.h"
#import "CLComingSoonViewController.h"
#import "CLJobPreferencesViewController.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "MMDrawerVisualStateManager.h"
#import "UIImageView+WebCache.h"
#import "CLUserObject.h"
#import "CLGetStartedViewController.h"
#import "CLWelcomeScreenViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLLoginViewController.h"
#import "URLParser.h"
#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>
#import "CLResetPassworkController.h"
#import "GAI.h"

#import "CLPersonalProfileDetailsViewController.h"

/** Google Analytics configuration constants **/
//static NSString *const kGaPropertyId = @"UA-63737967-1"; // Sample for tesing.
static NSString *const kGaPropertyId = @"UA-55850461-3";
static NSString *const kTrackingPreferenceKey = @"allowTracking";
static BOOL const kGaDryRun = NO;
static int const kGaDispatchPeriod = 120;

@import AddressBook;

@interface CLAppDelegate ()
@property (strong, nonatomic) id<GAITracker> tracker;
@property (nonatomic,strong) CLSideMenuViewController *sideMenuCOntroller;
@end

@implementation CLAppDelegate
@synthesize loginNav,homeNav,jobsNav,inboxNav,statusNav,sideMenuCOntroller,comingSoonNav,profileNav,documentsNav,knowledgeNav;//,jobPreferencesNav;

#pragma mark AppDelegate Methods

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if ([CLUserObject isSessionValid]) {
        //To set the user details form cache..
        [CLUserObject setCurrentUserFromUserDefaults];
    }
    //Crashlytics api
    [Fabric with:@[CrashlyticsKit]];
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    NSLog(@"Documents folder: %@",[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    
    coreDataHelper = [CLCoreDataHelper sharedCLCoreDataHelper];
    
    //CLJobPreferencesViewController *jobPreferenceController = [[CLJobPreferencesViewController alloc]initWithNibName:@"CLJobPreferencesViewController" bundle:[NSBundle mainBundle]];
   // jobPreferencesNav=[[UINavigationController alloc] initWithRootViewController:jobPreferenceController];
    
    CLLoginFlowViewController *loginFlowController=[[CLLoginFlowViewController alloc] initWithNibName:@"CLLoginFlowViewController" bundle:[NSBundle mainBundle]];
    loginNav=[[UINavigationController alloc] initWithRootViewController:loginFlowController];
    
    CLHomeViewController *homeController=[[CLHomeViewController alloc] initWithNibName:@"CLHomeViewController" bundle:[NSBundle mainBundle]];
    homeNav=[[UINavigationController alloc] initWithRootViewController:homeController];
    //homeNav.navigationBar.translucent=NO;
    
    CLInboxViewController *inboxController=[[CLInboxViewController alloc] initWithNibName:@"CLInboxViewController" bundle:[NSBundle mainBundle]];
    inboxNav=[[UINavigationController alloc] initWithRootViewController:inboxController];
    
    CLJobsViewController *jobsController=[[CLJobsViewController alloc] initWithNibName:@"CLJobsViewController" bundle:[NSBundle mainBundle]];
    jobsNav=[[UINavigationController alloc] initWithRootViewController:jobsController];
    [self.jobsNav setToolbarHidden:NO animated:YES];
    
    CLProfileViewController *profController=[[CLProfileViewController alloc] initWithNibName:@"CLProfileViewController" bundle:[NSBundle mainBundle]];
    profileNav=[[UINavigationController alloc] initWithRootViewController:profController];
    
    CLDocumentsViewController *documentsController=[[CLDocumentsViewController alloc] initWithNibName:@"CLDocumentsViewController" bundle:[NSBundle mainBundle]];
    documentsNav=[[UINavigationController alloc] initWithRootViewController:documentsController];
    
    CLKnowledgeListViewController *knowledgeController=[[CLKnowledgeListViewController alloc] initWithNibName:@"CLKnowledgeListViewController" bundle:[NSBundle mainBundle]];
    knowledgeNav=[[UINavigationController alloc] initWithRootViewController:knowledgeController];
 
    CLComingSoonViewController *comingController=[[CLComingSoonViewController alloc] initWithNibName:@"CLComingSoonViewController" bundle:[NSBundle mainBundle]];
    comingSoonNav=[[UINavigationController alloc] initWithRootViewController:comingController];
    
    sideMenuCOntroller=[[CLSideMenuViewController alloc] initWithNibName:@"CLSideMenuViewController" bundle:[NSBundle mainBundle]];
    
    self.drawerController = [[MMDrawerController alloc]
                             initWithCenterViewController:self.knowledgeNav
                             leftDrawerViewController:self.sideMenuCOntroller
                             rightDrawerViewController:nil];
    
    [self.window setRootViewController:self.drawerController];
    [self.window makeKeyAndVisible];
    
    [self setUpBaseSettings];
    
    if(![CLUserObject isSessionValid]){
        //If no valid session found then present the login screen..
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [self.drawerController presentViewController:loginNav animated:YES completion:nil];
        });
    }
    else{
        //update interface according to the cached user...
        [self.sideMenuCOntroller updateSideMenuDetails];
        [self updateCurrentTrafficLightColorAndUpdateNav];
        
        //To refresh the user details and update the side menu...
        [self updateCurrentUserDetails];
    }
    
    //Accept push notification when app is not open
    NSDictionary *userInfo = [launchOptions objectForKey: UIApplicationLaunchOptionsRemoteNotificationKey];
    if (userInfo) {
        //Handle Push notification
        [self handleRemoteNotification:application withDict:userInfo];
    }
    
    [self initializeGoogleAnalytics];
    
    return YES;
}

- (void)initializeGoogleAnalytics
{
    [[GAI sharedInstance] setDispatchInterval:kGaDispatchPeriod];
    [[GAI sharedInstance] setDryRun:kGaDryRun];
    self.tracker = [[GAI sharedInstance] trackerWithTrackingId:kGaPropertyId];
}



-(BOOL) application: (UIApplication * ) application openURL: (NSURL * ) url sourceApplication: (NSString * ) sourceApplication annotation: (id) annotation {
    
    if ([url.scheme isEqualToString: @"careerline"] && [url.host isEqualToString:@"activation"]) {
        
        
        NSString *urlString = [url absoluteString];
        URLParser *parser = [[URLParser alloc] initWithURLString:urlString];
        
        NSString *encodedUserName = [parser valueForVariable:@"username"];
        
        NSString *encodedPass = [parser valueForVariable:@"password"];
        
        NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:encodedUserName options:0];
        NSString *decodedUserName = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
        
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Congratulations!", @"alert heading") message:NSLocalizedString(@"Your Account Has Been Activated.", @"alert messgae") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"title for cancel button") otherButtonTitles:nil, nil];
        
        UIAlertView *alertViewMessage = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Warning", @"alert heading") message:NSLocalizedString(@"Your are already logedin with another account, Please logout from current account and login with new credentials.", @"alert messgae") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"title for cancel button") otherButtonTitles:nil, nil];
        
        [alertView showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex) {
            //            NSString *urlString = [url absoluteString];
            //            NSString *userName;
            //
            //            NSArray *items = [urlString componentsSeparatedByString:@"="];
            //            if ([items count]>0) {
            //                userName = [items objectAtIndex:1];
            //            }
            //
            //            CLLoginViewController *loginController=[[CLLoginViewController alloc] initWithNibName:@"CLLoginViewController" bundle:[NSBundle mainBundle]];
            //            loginController.userEmail = userName;
            //            [self.loginNav pushViewController:loginController animated:YES];
            if ([CLUserObject isSessionValid]) {
                [alertViewMessage showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex) {
                    
                    
                }];
            }else{
                
                HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
                progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
                progressHUD.text=NSLocalizedString(@"Logging In...", @"Text displayed in the loading indicator while logging in");
                [progressHUD showInView:self.loginNav.visibleViewController.view];
                
                [CLUserObject loginUser:decodedUserName password:encodedPass typeAutoLogin:@"1" success:^(int successFlag, NSString *userName, NSString *password,int autosave, NSString *welcomeStat) {
                    
                    if(successFlag==2){
                        [progressHUD hideWithAnimation:YES];
                        [((CLSideMenuViewController*)self.drawerController.leftDrawerViewController) updateSideMenuDetails];
                        [self updateCurrentTrafficLightColorAndUpdateNav];
                        [self.loginNav dismissViewControllerAnimated:YES completion:nil];
                    }
                    else if (successFlag==1){
                        [progressHUD hideWithAnimation:YES];
                        //If traffic light is already set then we skip those steps till status setting..
//                        if ([CLUserObject currentUser].trafficLightStatus) {
//                            CLPersonalProfileDetailsViewController *welcomeScreen=[[CLPersonalProfileDetailsViewController alloc] initWithNibName:@"CLPersonalProfileDetailsViewController" bundle:[NSBundle mainBundle]];
//                            [CLCommon sharedInstance].userName=userName;
//                            [CLCommon sharedInstance].passWord=password;
//                            // welcomeScreen.isFirstTime=NO;
//                            self.loginNav.visibleViewController.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain target:nil action:nil];
//                            [self.loginNav pushViewController:welcomeScreen animated:YES];
//                            
//                            //                            CLPersonalProfileDetailsViewController *welcomeScreen=[[CLPersonalProfileDetailsViewController alloc] initWithNibName:@"CLPersonalProfileDetailsViewController" bundle:[NSBundle mainBundle]];
//                            //                            [CLCommon sharedInstance].userName=userName;
//                            //                            [CLCommon sharedInstance].passWord=password;
//                            //                            //welcomeScreen.isFirstTime=NO;
//                            //                            self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain target:nil action:nil];
//                            //                            [self.navigationController pushViewController:welcomeScreen animated:YES];
//                            
//                        }
//                        else{
//                            [progressHUD hideWithAnimation:YES];
                            CLWelcomeScreenViewController *welcomeScreen=[[CLWelcomeScreenViewController alloc] initWithNibName:@"CLWelcomeScreenViewController" bundle:[NSBundle mainBundle]];
                            welcomeScreen.isFirstTime=YES;
                            [CLCommon sharedInstance].userName=userName;
                            [CLCommon sharedInstance].passWord=password;
                            welcomeScreen.fromPageFlag=CLNavigationFromWelcomePage;
                            self.loginNav.visibleViewController.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain target:nil action:nil];
                            [self.loginNav pushViewController:welcomeScreen animated:YES];
//                        }
                    }
                    
                    
                } failure:^(NSString *error) {
                    [progressHUD hideWithAnimation:YES];
                    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:NSLocalizedString(@"Failed To Login. Try to Login Manually", @"alert messgae") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"title for cancel button") otherButtonTitles:nil, nil];
                    
                    [alertView showWithCompletion:^(UIAlertView *alertView, NSInteger buttonIndex){
                        [self.loginNav popToRootViewControllerAnimated:YES];
                    }];
                    
                }];
                
                
            }
            
        }];
        return YES;
        
    }
    else if ([url.scheme isEqualToString:@"careerline"] && [url.host isEqualToString:@"forgotpassword"]) {

        NSString *urlString = [url absoluteString];
        URLParser *parser = [[URLParser alloc] initWithURLString:urlString];
        
        NSString *encodedUserName = [parser valueForVariable:@"username"];
        
        NSString *activeCodes = [parser valueForVariable:@"activeCode"];
        NSString *activeCode = [NSString stringWithFormat:@"%@",activeCodes];
        
        NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:encodedUserName options:0];
        NSString *decodedUserName = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];

        
        CLResetPassworkController *resetPassController = [[CLResetPassworkController alloc]initWithNibName:@"CLResetPassworkController" bundle:[NSBundle mainBundle]];
        resetPassController.activeCode = activeCode;
        resetPassController.userID = decodedUserName;
        [self.loginNav pushViewController:resetPassController animated:YES];
        
        
        return YES;
    }
    
    NSLog(@"We were not opened with careerline.");
    return NO;
}
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSMutableString *deviceTok = [[NSMutableString alloc] initWithFormat:@"%@",deviceToken];
    [deviceTok replaceOccurrencesOfString:@"<" withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [deviceTok length])];
    [deviceTok replaceOccurrencesOfString:@">" withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [deviceTok length])];
    [deviceTok replaceOccurrencesOfString:@" " withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [deviceTok length])];
    [CLCommon sharedInstance].deviceTokenString=deviceTok;
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	NSLog(@"Failed to get token, error: %@", error);
    [CLCommon sharedInstance].deviceTokenString=@"";
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    //Handle Push notification
    [self handleRemoteNotification:application withDict:userInfo];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [self updateCurrentUserDetails];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark Utility Methods

-(void)updateCurrentUserDetails{
    if([CLUserObject isSessionValid]){
        [CLUserObject updateUserDetailsWithUserId:[CLUserObject currentUser].userID
                                          success:^{
                                              [self.sideMenuCOntroller updateSideMenuDetails];
                                              [self updateCurrentTrafficLightColorAndUpdateNav];
                                          }
                                          failure:nil];
    }
}

-(void)setUpBaseSettings{
    //to load db and its path..
    [[CLCommon sharedInstance] loadCareerLineDB];
    
    //to register for push notif..
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        //ios 8 and above..
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    } else {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge |UIRemoteNotificationTypeSound)];
    }
    
    //setting the global appearance changes..
    _window.tintColor=ColorCode_CareerLineGreen;
    [[UINavigationBar appearance] setBarTintColor:ColorCode_CareerLineGreen];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObject:[UIColor whiteColor] forKey:NSForegroundColorAttributeName]];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    [self.drawerController setShowsShadow:YES];
    [self.drawerController setMaximumRightDrawerWidth:200.0];
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModePanningCenterView];
    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    [self.drawerController
     setDrawerVisualStateBlock:^(MMDrawerController *drawerController, MMDrawerSide drawerSide, CGFloat percentVisible) {
         MMDrawerControllerDrawerVisualStateBlock block;
         block = [[MMDrawerVisualStateManager sharedManager]
                  drawerVisualStateBlockForDrawerSide:drawerSide];
         if(block){
             block(drawerController, drawerSide, percentVisible);
         }
     }];
    
    __weak CLAppDelegate *self_ = self;
    [self.drawerController setGestureCompletionBlock:^(MMDrawerController *drawerController, UIGestureRecognizer *gesture) {
        if (drawerController.openSide==MMDrawerSideLeft) {
            [self_ updateCurrentUserDetails];
        }
    }];
    
    [AFNetworkActivityIndicatorManager sharedManager].enabled=YES;
}

-(void)handleRemoteNotification:(UIApplication *)application withDict:(NSDictionary*)userInfo{
    NSLog(@"push dict=%@",userInfo);
    
    NSDictionary *aps = [NSDictionary dictionaryWithDictionary:[userInfo objectForKey:@"aps"]];
    
    //app opened from push notification..
    if (application.applicationState == UIApplicationStateInactive) {
        [self.sideMenuCOntroller pushNavigationForPushType:[[aps objectForKey:@"type"] intValue] pushId:[aps objectForKey:@"id"]];
    }
    //app is active when push comes..
    else if (application.applicationState == UIApplicationStateActive){
        [self.sideMenuCOntroller incrementBadgeForPushType:[[aps objectForKey:@"type"] intValue]];
    }
}

-(void)updateCurrentTrafficLightColorAndUpdateNav{
    switch ([CLUserObject currentUser].trafficLightStatus) {
        case CLTrafficLightGreenColor:
            [CLCommon sharedInstance].currentTrafficLightColor=ColorCode_SideMenuTextGreen;
            break;
        case CLTrafficLightAmberColor:
            [CLCommon sharedInstance].currentTrafficLightColor=ColorCode_SideMenuTextAmber;
            break;
        case CLTrafficLightRedColor:
            [CLCommon sharedInstance].currentTrafficLightColor=ColorCode_SideMenuTextRed;
        default:
            break;
    }
    [self updateNavBarColor];
}

-(void)updateNavBarColor{
    [[NSNotificationCenter defaultCenter] postNotificationName:kCLNotifCenterTrafficLightChanged object:nil];
    [self.statusNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.homeNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.jobsNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.inboxNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.profileNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.comingSoonNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.documentsNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    [self.knowledgeNav.navigationBar setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
    _window.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    [[UINavigationBar appearance] setBarTintColor:[CLCommon sharedInstance].currentTrafficLightColor];
}

-(void)setDrawerOpenGesturePanCenterView{
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModePanningCenterView];
}

-(void)setDrawerOpenGesturePanNavigationBar{
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
}

-(void)popAllControllersAndClearData{
  
    [self.homeNav popToRootViewControllerAnimated:NO];
    [self.jobsNav popToRootViewControllerAnimated:NO];
    [self.inboxNav popToRootViewControllerAnimated:NO];
    [self.profileNav popToRootViewControllerAnimated:NO];
    [self.documentsNav popToRootViewControllerAnimated:NO];
    [self.knowledgeNav popToRootViewControllerAnimated:NO];
    
    [((CLHomeViewController*)[self.homeNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    [((CLJobsViewController*)[self.jobsNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    [((CLInboxViewController*)[self.inboxNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    [((CLProfileViewController*)[self.profileNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    [((CLDocumentsViewController*)[self.documentsNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    [((CLKnowledgeListViewController*)[self.knowledgeNav.viewControllers objectAtIndex:0]) clearArraysAndReloadTable];
    
    [[SDImageCache sharedImageCache] clearMemory];
    [[SDImageCache sharedImageCache] clearDisk];
}


@end
