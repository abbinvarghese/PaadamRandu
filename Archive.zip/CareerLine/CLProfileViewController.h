//
//  CLProfileViewController.h
//  CareerLine
//
//  Created by RENJITH on 07/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfileObject.h"

@interface CLProfileViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate,UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>



@property (nonatomic,assign) BOOL isAboutMeReload;
@property (nonatomic,assign) BOOL isCareerReload;
@property (nonatomic,assign) BOOL isQualiftnReload;
@property (nonatomic,assign) BOOL isReferenceReload;
@property (nonatomic,assign) BOOL isPortfolioReload;
@property (nonatomic,assign) BOOL isJobPreferenceReload;

-(void)clearArraysAndReloadTable;
@end
