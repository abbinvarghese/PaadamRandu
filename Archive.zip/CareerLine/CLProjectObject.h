//
//  CLProjectObject.h
//  CareerLine
//
//  Created by Pravin on 10/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLFileObject.h"

@interface CLProjectObject : NSObject

@property(nonatomic,strong)NSString *projectId;
@property(nonatomic,strong)NSString *projectTitle;
@property(nonatomic,strong)NSDate *date;
@property(nonatomic,strong)NSString *formattedDateString;
@property(nonatomic,strong)NSString *projectDescription;
@property(nonatomic,strong)NSMutableDictionary *careerSelected;
@property(nonatomic,strong)NSMutableArray *documents;       //[(CLFileObject),(CLFileObject),...]


//init data with dictionary..
- (id)initWithDictionary:(NSDictionary*)dictionary;

//to update formatted date..
-(void)updateDate:(NSDate*)date;

//Method for saving project of a particular user...
+ (void)saveProject:(CLProjectObject*)projObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *projId))success failure:(void (^)(NSString *error))failure;

//Method for deleting project for a particular user...
+ (void)deleteProject:(NSString*)projId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure;

//Method for uploading project document for a particular user...
+ (void)addDocument:(UIImage*)image forProject:(NSString*)projId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure;

//Method for deleting project document for a particular user...
+ (void)deleteDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure;

@end
