//
//  CLTextCheckBoxCell.m
//  CareerLine
//
//  Created by RENJITH on 12/08/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTextCheckBoxCell.h"

@interface CLTextCheckBoxCell()

@property (weak, nonatomic) IBOutlet UITextField *txtField;
@property (nonatomic,assign) BOOL statusCheckBox;
//@property (weak, nonatomic) IBOutlet UIButton *checkBoxBtn;
@property (weak, nonatomic) IBOutlet UISwitch *checkBoxSwitch;
@property (weak, nonatomic) IBOutlet UIView *disableView;

- (IBAction)textFieldDidChangeEditing:(id)sender;
- (IBAction)checkBoxSwitchAction:(id)sender;
@end


@implementation CLTextCheckBoxCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLTextCheckBoxCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(NSString*)getEnteredText{
    return self.txtField.text;
}

-(void)setCellFont:(UIFont*)font{
    self.txtField.font=font;
}

-(void)setCellTextColor:(UIColor*)color{
    self.txtField.textColor=color;
}

-(void)setSwitchColor:(UIColor*)color{
    [self.checkBoxSwitch setOnTintColor:color];
}

-(void)setCellText:(NSString*)text{
    self.txtField.text=text;
}

-(void)setPlaceHoldrText:(NSString *)text{
    self.txtField.placeholder=text;
}

-(void)setCellCapitalization:(UITextAutocapitalizationType)capitalizationMode{
    self.txtField.autocapitalizationType=capitalizationMode;
}

-(void)setTextInputView:(id)picker{
    self.txtField.inputView=picker;
}

-(void)setTextInputAccesoryView:(id)view{
    self.txtField.inputAccessoryView=view;
}

-(BOOL)isCellFirstResponder{
    if ([self.txtField isFirstResponder]) {
        return YES;
    }
    else{
        return NO;
    }
}

-(void)disableCellField{
    self.txtField.enabled=NO;
    self.backgroundColor=[UIColor colorFromHexCode:@"#CCEDEB"];
}

-(void)enableCellField{
    self.txtField.enabled=YES;
    self.backgroundColor=[UIColor whiteColor];
}

-(void)setKeyboardType :(UIKeyboardType)type{
    self.txtField.keyboardType = type;
}

-(void)disableCelltxtField{
    self.txtField.enabled=NO;
}
-(void)changeCelltxtFieldColor:(NSString *)hexCode{
    self.txtField.enabled=NO;
    self.disableView.backgroundColor=[UIColor colorFromHexCode:hexCode];
}

-(void)enableCelltxtField{
    self.txtField.enabled=YES;
    self.disableView.backgroundColor=[UIColor clearColor];
}

-(void)resignCellFirstResponder{
    [self.txtField resignFirstResponder];
}

-(void)checkBoxClick:(BOOL)status{
    self.statusCheckBox = status;
    if (status) {
        [self.checkBoxSwitch setOn:YES];
    }else{
        [self.checkBoxSwitch setOn:NO];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (self.textCheckBoxdelegate!= nil && [self.textCheckBoxdelegate respondsToSelector:@selector(textCheckBoxCellWillBeginEditing:forTextField:)]){
		[self.textCheckBoxdelegate textCheckBoxCellWillBeginEditing:self forTextField:self.txtField];
	}
    return YES;
}

- (IBAction)textFieldDidChangeEditing:(UITextField*)sender {
    if (self.textCheckBoxdelegate!= nil && [self.textCheckBoxdelegate respondsToSelector:@selector(textCheckBoxCellTextDidChange:forIndexPath:withText:)]){
		[self.textCheckBoxdelegate textCheckBoxCellTextDidChange:self forIndexPath:self.cellIndexPath withText:sender.text];
	}
}

- (IBAction)checkBoxSwitchAction:(UIButton *)button {
    if (self.statusCheckBox) {
        self.statusCheckBox = NO;
        [self.checkBoxSwitch setOn:NO];
    }else{
        self.statusCheckBox = YES;
        [self.checkBoxSwitch setOn:YES];
    }
    if (self.textCheckBoxdelegate!= nil && [self.textCheckBoxdelegate respondsToSelector:@selector(textCheckBoxBgChange:withStatus:)]){
        [self.textCheckBoxdelegate textCheckBoxBgChange:self withStatus:self.statusCheckBox];
		
	}
}
@end
