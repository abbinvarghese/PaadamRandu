//
//  CLPersonalProfileDetailsViewController.h
//  CareerLine
//
//  Created by CSG on 2/6/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectNationalityViewController.h"
#import "CLSelectEducationViewController.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSimpleTextCell.h"
#import "CLSelectLocationViewController.h"

@interface CLPersonalProfileDetailsViewController : UITableViewController<CLTappableCellDelegate,CLSimpleTextCellDelegate,CLSelectNationalityDelegate,CLSelectEducationDelegate,UIPickerViewDataSource,UIPickerViewDelegate,CLSelectLocationDelegate,UIActionSheetDelegate>

@property(nonatomic)BOOL fromLoginPage;

@end