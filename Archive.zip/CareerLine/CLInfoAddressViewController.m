//
//  CLInfoAddressViewController.m
//  CareerLine
//
//  Created by CSG on 8/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInfoAddressViewController.h"

@interface CLInfoAddressViewController ()

typedef enum {
//    CLLocationApartmentIndex = 0,
//    CLLocationFloorIndex= 1,
//    CLLocationHouseNumberIndex = 2,
    CLLocationStreetIndex = 0,
    CLLocationLocIndex = 1,
    CLLocationPincodeIndex = 2,
    CLLocationIsCommIndex=3
} CLLocationTableSectionIndex;

@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;

//@property(strong,nonatomic)NSString *apartmentText;
//@property(strong,nonatomic)NSString *floorText;
//@property(strong,nonatomic)NSString *houseNoText;
@property(strong,nonatomic)NSString *streetText;
@property(strong,nonatomic)NSString *pincodeText;
@property(strong,nonatomic)NSMutableDictionary *locationDict;
@property(nonatomic,assign)BOOL isCommnAddress;

@end

@implementation CLInfoAddressViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Address", @"Address edit page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"apartmentTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"floorTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"houseNoTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"streetTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"pincodeTextCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTappableTextCell class] forCellReuseIdentifier:@"locationTextCellIdentifier"];
    [self.tableView registerClass:[CLTextCheckBoxCell class] forCellReuseIdentifier:@"commAddressTextCellIdentifier"];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    
    if (self.isEditMode) {
//        self.apartmentText=self.locationObj.locationApartment;
//        self.floorText=self.locationObj.locationfloor;
//        self.houseNoText=self.locationObj.locationHouseNumber;
        self.streetText=self.locationObj.locationAddress;
        self.pincodeText=self.locationObj.locationPincode;
        self.locationDict=[NSMutableDictionary dictionaryWithObjectsAndKeys:self.locationObj.locationCode,kLocationCode,self.locationObj.locationName,kLocationName,self.locationObj.countryCode,kLocationCountryCode, nil];
        self.isCommnAddress=self.locationObj.isCommunicationAddress;
    }
    else{
//        self.apartmentText=@"";
//        self.floorText=@"";
//        self.houseNoText=@"";
        self.streetText=@"";
        self.pincodeText=@"";
        self.locationDict=[[NSMutableDictionary alloc] init];
        self.isCommnAddress=NO;
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    if([self.txtFirstResponder isFirstResponder])
        [self.txtFirstResponder resignFirstResponder];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveLocationAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddLocationAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //Home Location validation..
    if ([self.locationDict count]==0) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please select Home Location", @"Error Message for null Home Location") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.streetText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Address", @"Error Message for null Address") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.pincodeText isEqualToString:@""]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter Postal Code", @"Error Message for null Postal Code") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }else if ([self.pincodeText length] >10){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Postal Code length should less than 10", @"Error Message for Postal Code length") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    return isValid;
}

-(void)saveAddressForEdit:(BOOL)isEdit{
    if (isEdit) {
//        self.locationObj.locationApartment=self.apartmentText;
//        self.locationObj.locationfloor=self.floorText;
//        self.locationObj.locationHouseNumber=self.houseNoText;
        self.locationObj.locationAddress=self.streetText;
        self.locationObj.locationCode=[self.locationDict objectForKey:kLocationCode];
        if ([self.locationDict objectForKey:kLocationAdminArea]) {
            self.locationObj.locationName=[NSString stringWithFormat:@"%@, %@, %@",[self.locationDict objectForKey:kLocationName],[self.locationDict objectForKey:kLocationAdminArea],[self.locationDict objectForKey:kLocationCountryName]];
        }
        else{
            self.locationObj.locationName=[self.locationDict objectForKey:kLocationName];
        }
        self.locationObj.locationPincode=self.pincodeText;
        self.locationObj.countryCode =[self.locationDict objectForKey:kLocationCountryCode];
        [self.locationObj updateFormattedAddress];
        self.locationObj.isCommunicationAddress=self.isCommnAddress;
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(addressController:didEditAddress:)]){
            [self.delegate addressController:self didEditAddress:self.locationObj];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        self.locationObj=[[CLLocationObject alloc] init];
//        self.locationObj.locationApartment=self.apartmentText;
//        self.locationObj.locationfloor=self.floorText;
//        self.locationObj.locationHouseNumber=self.houseNoText;
        self.locationObj.locationAddress=self.streetText;
        self.locationObj.locationCode=[self.locationDict objectForKey:kLocationCode];
        self.locationObj.locationName=[NSString stringWithFormat:@"%@, %@, %@",[self.locationDict objectForKey:kLocationName],[self.locationDict objectForKey:kLocationAdminArea],[self.locationDict objectForKey:kLocationCountryName]];
        self.locationObj.locationPincode=self.pincodeText;
        self.locationObj.countryCode =[self.locationDict objectForKey:kLocationCountryCode];
        [self.locationObj updateFormattedAddress];
        self.locationObj.isCommunicationAddress=self.isCommnAddress;
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(addressController:didAddAddress:)]){
                [self.delegate addressController:self didAddAddress:self.locationObj];
            }
        }];
    }
}

#pragma mark IBActions

-(IBAction)bttnActionSaveLocationAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveAddressForEdit:YES];
    }
}

-(IBAction)bttnActionAddLocationAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.txtFirstResponder resignFirstResponder];
        [self saveAddressForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
//        case CLLocationApartmentIndex:{
//            CLSimpleTextCell *apartmentCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"apartmentTextCellIdentifier"];
//            apartmentCell.selectionStyle=UITableViewCellSelectionStyleNone;
//            [apartmentCell setTextInputAccesoryView:self.keyboardResignView];
//            [apartmentCell setPlaceHoldrText:NSLocalizedString(@"Apartment", @"Placeholder text")];
//            [apartmentCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//            [apartmentCell setCellText:self.apartmentText];
//            [apartmentCell setCellIndexPath:indexPath];
//            apartmentCell.delegate=self;
//            return apartmentCell;
//            break;
//        }
//        case CLLocationFloorIndex:{
//            CLSimpleTextCell *floorCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"floorTextCellIdentifier"];
//            floorCell.selectionStyle=UITableViewCellSelectionStyleNone;
//            [floorCell setTextInputAccesoryView:self.keyboardResignView];
//            [floorCell setPlaceHoldrText:NSLocalizedString(@"Floor", @"Placeholder text")];
//            [floorCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//            [floorCell setCellText:self.floorText];
//            [floorCell setCellIndexPath:indexPath];
//            floorCell.delegate=self;
//            return floorCell;
//            break;
//        }
//        case CLLocationHouseNumberIndex:{
//            CLSimpleTextCell *houseCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"houseNoTextCellIdentifier"];
//            houseCell.selectionStyle=UITableViewCellSelectionStyleNone;
//            [houseCell setTextInputAccesoryView:self.keyboardResignView];
//            [houseCell setPlaceHoldrText:NSLocalizedString(@"House Number", @"Placeholder text")];
//            [houseCell setCellCapitalization:UITextAutocapitalizationTypeWords];
//            [houseCell setCellText:self.houseNoText];
//            [houseCell setCellIndexPath:indexPath];
//            houseCell.delegate=self;
//            return houseCell;
//            break;
//        }
        case CLLocationStreetIndex:{
            CLSimpleTextCell *streetCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"streetTextCellIdentifier"];
            streetCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [streetCell setTextInputAccesoryView:self.keyboardResignView];
            [streetCell setPlaceHoldrText:NSLocalizedString(@"Address", @"Placeholder text")];
            [streetCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [streetCell setCellText:self.streetText];
            [streetCell setCellIndexPath:indexPath];
            streetCell.delegate=self;
            return streetCell;
            break;
        }
        case CLLocationLocIndex:{
            CLSimpleTappableTextCell *currLoccell = (CLSimpleTappableTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"locationTextCellIdentifier"];
            [currLoccell setPlaceHoldrText:NSLocalizedString(@"Where Do You Live?", @"Placeholder for Home Location field")];
            currLoccell.delegate=self;
            currLoccell.selectionStyle = UITableViewCellSelectionStyleNone;
            if ([self.locationDict count]!=0) {
                [currLoccell setCellCloseBtnOption:YES];
                if ([self.locationDict objectForKey:kLocationAdminArea]) {
                    [currLoccell setCellText:[NSString stringWithFormat:@"%@, %@, %@",[self.locationDict objectForKey:kLocationName],[self.locationDict objectForKey:kLocationAdminArea],[self.locationDict objectForKey:kLocationCountryName]]];
                }
                else{
                    [currLoccell setCellText:[self.locationDict objectForKey:kLocationName]];
                }
            }
            else{
                [currLoccell setCellText:@""];
            }
            [currLoccell setCellIndexPath:indexPath];
            return currLoccell;
            break;
        }
        case CLLocationPincodeIndex:{
            CLSimpleTextCell *pincodeCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"pincodeTextCellIdentifier"];
            pincodeCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [pincodeCell setTextInputAccesoryView:self.keyboardResignView];
            [pincodeCell setPlaceHoldrText:NSLocalizedString(@"Postal/Zip code", @"Placeholder text")];
            [pincodeCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [pincodeCell setKeyboardType:UIKeyboardTypeNumberPad];
            [pincodeCell setCellText:self.pincodeText];
            [pincodeCell setCellIndexPath:indexPath];
            pincodeCell.delegate=self;
            return pincodeCell;
            break;
        }
        case CLLocationIsCommIndex:{
            CLTextCheckBoxCell *iscommCell = (CLTextCheckBoxCell *)[self.tableView dequeueReusableCellWithIdentifier:@"commAddressTextCellIdentifier"];
            iscommCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [iscommCell setTextInputAccesoryView:self.keyboardResignView];
            [iscommCell setPlaceHoldrText:NSLocalizedString(@"", @"Placeholder")];
            [iscommCell setCellCapitalization:UITextAutocapitalizationTypeWords];
            [iscommCell setCellText:@"Set as Communication Address"];
            [iscommCell setCellTextColor:[UIColor darkGrayColor]];
            [iscommCell setSwitchColor:[CLCommon sharedInstance].currentTrafficLightColor];
            [iscommCell setCellIndexPath:indexPath];
            [iscommCell disableCelltxtField];
            [iscommCell checkBoxClick:self.isCommnAddress];
            iscommCell.textCheckBoxdelegate=self;
            return iscommCell;
            break;
        }
            
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
//        case CLLocationApartmentIndex:
//            return NSLocalizedString(@"Apartment", @"Placeholder Text");
//            break;
//        case CLLocationFloorIndex:
//            return NSLocalizedString(@"Floor", @"Placeholder Text");
//            break;
//        case CLLocationHouseNumberIndex:
//            return NSLocalizedString(@"House Number", @"Placeholder Text");
//            break;
        case CLLocationStreetIndex:
            return NSLocalizedString(@"Address", @"Placeholder Text");
            break;
        case CLLocationLocIndex:
            return NSLocalizedString(@"Home Location", @"Placeholder Text");
            break;
        case CLLocationPincodeIndex:
            return NSLocalizedString(@"Zip code", @"Placeholder Text");
            break;
        case CLLocationIsCommIndex:
            return nil;
            break;
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
//        case CLLocationApartmentIndex:
//            self.apartmentText=text;
//            break;
//        case CLLocationFloorIndex:
//            self.floorText=text;
//            break;
//        case CLLocationHouseNumberIndex:
//            self.houseNoText=text;
//            break;
        case CLLocationStreetIndex:
            self.streetText=text;
            break;
        case CLLocationLocIndex:
            break;
        case CLLocationPincodeIndex:
            self.pincodeText=text;
            break;
        case CLLocationIsCommIndex:
            break;
            
        default:
            break;
    }
}

#pragma mark CLTappableCellDelegate Methods


- (void)tappableCellWillClearContent:(CLSimpleTappableTextCell *)cell forIndexPath:(NSIndexPath *)indexPath forTextField:(UITextField *)textField{
    [cell setCellCloseBtnOption:YES];
    if (indexPath.section == CLLocationLocIndex) {
        self.locationDict = nil;
    }
    [self.tableView reloadData];
}


- (void)cellDidTapCellTextField:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath{
    if (self.isCurrentAddress) {
        
    }
    else{
        if (indexPath.section==CLLocationLocIndex) {
            CLSelectLocationViewController *selectLocation=[[CLSelectLocationViewController alloc] initWithNibName:@"CLSelectLocationViewController" bundle:[NSBundle mainBundle]];
            
            selectLocation.locationListType=2;
            selectLocation.delegate=self;
            UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectLocation];
            [self presentViewController:nav animated:YES completion:nil];
        }
    }
}

#pragma mark CLSelectLocationDelegate

- (void)selectLocationControllerDidSelectHomeLocation:(CLSelectLocationViewController*)controller withDictonary:(NSMutableDictionary *)locDict{
    self.locationDict=locDict;
    [self.tableView reloadData];
}


#pragma mark CLTextCheckBoxCellDelegate Methods

-(void)textCheckBoxBgChange:(UITableViewCell *)cell withStatus:(BOOL)status{
    self.isCommnAddress=status;
}

@end
