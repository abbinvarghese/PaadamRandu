//
//  CLCareerObject.h
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLCareerHistoryObject.h"

@interface CLCareerObject : NSObject

@property(nonatomic,strong)NSString *summary;
@property(nonatomic,strong)CLCareerHistoryObject *history;
@property(nonatomic,strong)NSMutableArray *careerHistory;
+ (void)cancelCareerListingPendingRequest;
+ (void)careerListingForUser:(NSString *)userId success:(void (^)(CLCareerObject *careerObj))success failure:(void (^)(NSString *error))failure;
+(void)editCareerSummaryForUser:(NSString *)userId careerSummary:(NSString*)summary success:(void(^)(NSString *succcesMsg))success failure:(void(^)(NSString *error))failure;
@end
