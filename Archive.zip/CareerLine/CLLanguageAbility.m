//
//  CLLanguageAbility.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLLanguageAbility.h"

@implementation CLLanguageAbility

@end
