//
//  CLLocationLoaderCell.h
//  CareerLine
//
//  Created by Abbin on 07/05/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLLocationLoaderCell : UITableViewCell

-(void)startActivityIndicator;
-(void)hideActivityIndicator;

@end
