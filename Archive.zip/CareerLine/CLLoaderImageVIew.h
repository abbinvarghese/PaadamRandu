//
//  CLLoaderImageVIew.h
//  CareerLine
//
//  Created by CSG on 8/28/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLLoaderImageVIew : UIImageView

-(void)setImageWithUrlString:(NSString *)url;
-(void)setImageWithUrlString:(NSString *)url andPlaceHolderName:(NSString*)placeHolderName;

@end
