//
//  CLAddIncentivesViewController.h
//  CareerLine
//
//  Created by RENJITH on 14/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLTextCheckBoxCell.h"
#import "CLFrequencyViewController.h"
#import "CLCurrencyViewController.h"
#import "CLIncentiveListViewController.h"
@class CLAddIncentivesViewController;

@protocol CLAddIncentiveDelegate <NSObject>

@optional
- (void)incentiveController:(CLAddIncentivesViewController *)controller didAddOrChangeIncentive:(NSMutableDictionary*)incentiveDict isEdit:(BOOL )isEdit;
@end

@interface CLAddIncentivesViewController : UITableViewController<CLSimpleTextCellDelegate,CLTappableCellDelegate,CLTextCheckBoxCellDelegate,CLFrequencyDelegate,CLCurrencyDelegate,CLIncentiveBonusDelegate>


@property (nonatomic ,weak) id <CLAddIncentiveDelegate> delegate;
@property (nonatomic ,assign) BOOL isEdit;
@property(nonatomic,strong)NSMutableDictionary *selectedIncentiveForEdit;
@property(nonatomic ,retain) NSMutableDictionary *selectedIncentiveCurrency;

@end
