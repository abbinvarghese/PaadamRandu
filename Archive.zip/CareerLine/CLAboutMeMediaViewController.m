//
//  CLAboutMeMediaViewController.m
//  CareerLine
//
//  Created by CSG on 7/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAboutMeMediaViewController.h"
#import "CLUserObject.h"
#import "HTProgressHUDFadeZoomAnimation.h"

@interface CLAboutMeMediaViewController ()

typedef enum {
    CLMediaWebsiteNameIndex = 0,
    CLMediaWebsiteUrlIndex= 1,
    CLMediaWebsiteDescIndex= 2
} CLMediaTableSectionIndex;

@property (strong, nonatomic) UIPickerView *pickerView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignView;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardResignViewWithCancel;
@property(strong ,nonatomic) UITextField *txtFirstResponder;
@property(strong ,nonatomic) UITextView *txtViewFirstResponder;

@property(strong, nonatomic) NSArray *websiteNameArray;
@property(strong,nonatomic)NSString *websiteNameText;
@property(strong,nonatomic)NSString *websiteUrlText;
@property(strong,nonatomic)NSString *websiteDescText;
@property(nonatomic,strong)NSNumber *descriptionHeight;

@end

@implementation CLAboutMeMediaViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Website", @"Websites page title");
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"websiteNameCellIdentifier"];
    [self.tableView registerClass:[CLSimpleTextCell class] forCellReuseIdentifier:@"websiteUrlCellIdentifier"];
    [self.tableView registerClass:[CLHeightAdjustTextCell class] forCellReuseIdentifier:@"websiteDescCellIdentifier"];
    self.descriptionHeight=[[NSNumber alloc] init];
    if (!self.isEditMode) {
        [self setLeftNavigationButton];
    }
    [self setRightNavigationButton];
    self.keyboardResignView.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.keyboardResignViewWithCancel.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    
    self.websiteNameArray=[NSArray arrayWithObjects:@"Website",@"Facebook",@"Twitter",@"Blog",@"Google+",@"Other", nil];
    
    UIPickerView *picker=[[UIPickerView alloc] init];
    picker.tag=1;
    picker.delegate=self;
    picker.dataSource=self;
    picker.backgroundColor=[UIColor whiteColor];
    self.pickerView=picker;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.isEditMode) {
        self.websiteNameText=self.mediaObj.websiteName;
        [self.pickerView selectRow:[self getIndexForSelectedText:self.websiteNameText] inComponent:0 animated:NO];
        self.websiteUrlText=self.mediaObj.websiteUrl;
        self.websiteDescText=self.mediaObj.websiteDescription;
    }
    else{
        self.websiteNameText=@"";
        self.websiteUrlText=@"";
        self.websiteDescText=@"";
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    if([self.txtFirstResponder isFirstResponder])
        [self.txtFirstResponder resignFirstResponder];
    if([self.txtViewFirstResponder isFirstResponder])
        [self.txtViewFirstResponder resignFirstResponder];

}

-(int)getIndexForSelectedText:(NSString *)text{
    int selectedIndex=0;
    for (int i=0; i<[self.websiteNameArray count]; i++) {
        if ([[self.websiteNameArray objectAtIndex:i] isEqualToString:text]) {
            selectedIndex=i;
            break;
        }
    }
    return selectedIndex;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UIPickerView Methods

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView.tag==1) {
        return [self.websiteNameArray count];
    }
    else{
        return 0;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [CLCommon sharedInstance].currentTrafficLightColor;
    label.textAlignment=NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    if (pickerView.tag==1) {
        label.text= [self.websiteNameArray objectAtIndex:row];
    }
    return label;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case CLMediaWebsiteNameIndex:{
            CLSimpleTextCell *nameCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"websiteNameCellIdentifier"];
            nameCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [nameCell setTextInputView:self.pickerView];
            [nameCell setTextInputAccesoryView:self.keyboardResignViewWithCancel];
            [nameCell setPlaceHoldrText:NSLocalizedString(@"Website Type", @"Placeholder for Website Name field")];
            [nameCell setCellText:self.websiteNameText];
            [nameCell setCellIndexPath:indexPath];
            nameCell.delegate=self;
            return nameCell;
            break;
        }
        case CLMediaWebsiteUrlIndex:{
            CLSimpleTextCell *urlCell = (CLSimpleTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"websiteUrlCellIdentifier"];
            urlCell.selectionStyle=UITableViewCellSelectionStyleNone;
            [urlCell setTextInputAccesoryView:self.keyboardResignView];
            [urlCell setPlaceHoldrText:NSLocalizedString(@"Website URL", @"Placeholder for URL field")];
            [urlCell setCellCapitalization:UITextAutocapitalizationTypeNone];
            [urlCell setCellText:self.websiteUrlText];
            [urlCell setCellIndexPath:indexPath];
            urlCell.delegate=self;
            return urlCell;
            break;
        }
        case CLMediaWebsiteDescIndex:{
            CLHeightAdjustTextCell *descCell = (CLHeightAdjustTextCell *)[self.tableView dequeueReusableCellWithIdentifier:@"websiteDescCellIdentifier"];
            descCell.selectionStyle=UITableViewCellSelectionStyleNone;
            descCell.text=self.websiteDescText;
            [descCell updateCellContents];
            if(self.descriptionHeight==nil){
                self.descriptionHeight=[NSNumber numberWithInt:kintialTextViewHeight];
            }
            [descCell setTextInputAccesoryView:self.keyboardResignView];
            [descCell setPlaceHoldrText:NSLocalizedString(@"Anything Else You Want to Say about This?", @"Placeholder for description field")];
            [descCell setCellCapitalization:UITextAutocapitalizationTypeSentences];
            [descCell setCellIndexPath:indexPath];
            descCell.delegate=self;
            return descCell;
            break;
        }
        default:
            return nil;
            break;
    }
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case CLMediaWebsiteNameIndex:
            return NSLocalizedString(@"Type", @"Placeholder for Website field");
            break;
        case CLMediaWebsiteUrlIndex:
            return NSLocalizedString(@"URL", @"Placeholder for URL field");
            break;
        case CLMediaWebsiteDescIndex:
            return NSLocalizedString(@"Description", @"Placeholder for Description field");
            break;
            
        default:
            return nil;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==CLMediaWebsiteDescIndex) {
        CGFloat ansHeight;
        if((self.descriptionHeight!=nil) && ([self.descriptionHeight floatValue]>kintialTextViewHeight)){
            ansHeight= [self.descriptionHeight floatValue];
        }
        else{
            ansHeight= [self getTextViewSizeForText:self.websiteDescText];
        }
        return MAX(44, ansHeight+1);
    }
    else{
        return 44;
    }
}

#pragma mark CLHeightAdjustTextCellDelegate Methods

- (void)heightCellWillBeginEditing:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath forTextView:(UITextView*)textView{
    self.txtViewFirstResponder=textView;
    [self scrollToCursorForIndexPath:indexPath];
}

- (void)heightCellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString*)text{
    CLHeightAdjustTextCell *heightCell=(CLHeightAdjustTextCell*)cell;
    self.descriptionHeight=[heightCell getTextViewHeight];
    self.websiteDescText=heightCell.text;
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
    [self scrollToCursorForIndexPath:indexPath];
}


#pragma mark CLSimpleTextCellDelegate Methods

- (void)cellWillBeginEditing:(CLSimpleTextCell *)cell forTextField:(UITextField *)textField{
    self.txtFirstResponder=textField;
    NSIndexPath *indexPath=cell.cellIndexPath;
    if(indexPath.section==CLMediaWebsiteNameIndex){
        self.pickerView.tag=1;
    }
    [self.pickerView reloadAllComponents];
}

- (void)cellTextDidChange:(UITableViewCell *)cell forIndexPath:(NSIndexPath*)indexPath withText:(NSString *)text{
    switch (indexPath.section) {
        case CLMediaWebsiteNameIndex:{
            self.websiteNameText=text;
            break;
        }
        case CLMediaWebsiteUrlIndex:{
            self.websiteUrlText=text;
            break;
        }
        case CLMediaWebsiteDescIndex:{
            self.websiteDescText=text;
            break;
        }
            
        default:
            break;
    }
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    if (self.isEditMode) {
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"media modal save button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveMediaAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
    else{
        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Save", @"media modal add button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionAddMediaAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;
    }
}

-(void)setLeftNavigationButton{
    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"media modal cancel button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionDismissModal:)];
    self.navigationItem.leftBarButtonItem=leftNavBttn;
}

-(CLSimpleTextCell*)getCellForFirstResponder{
    CLSimpleTextCell *cell=nil;
    if ([CLCommon isOSversionLessThan8]) {
        if([self.txtFirstResponder.superview.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview.superview;
        }
    }
    else{
        if([self.txtFirstResponder.superview.superview isKindOfClass:[CLSimpleTextCell class]]){
            cell=(CLSimpleTextCell*)self.txtFirstResponder.superview.superview;
        }
    }
    
    return (CLSimpleTextCell*)cell;
}

- (void)scrollToCursorForIndexPath: (NSIndexPath*)indexPath {
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(CGFloat)getTextViewSizeForText:(NSString*)text{
    UITextView *txtView=[[UITextView alloc] init];
    txtView.font=[UIFont systemFontOfSize:14];
    txtView.text=text;
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    return MAX(kintialTextViewHeight, [txtView sizeThatFits:maximumLabelSize].height);
}

-(BOOL)isFieldsValid{
    BOOL isValid=YES;
    //website Name validation..
    if ([self.websiteNameText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter The Website Name.", @"Error Message for null website name field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.websiteNameText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Website Name Length.", @"Error Message for length of name field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    //website url..
    if ([self.websiteUrlText isEqualToString:@""]) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter The Website URL.", @"Error Message for null website url field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if ([self.websiteUrlText length]>300) {
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Check Website URL Length.", @"Error Message for length of url field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    else if (![CLCommon validateUrl:self.websiteUrlText]){
        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Enter a valid Website URL", @"Error Message for length of url field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
        return isValid=NO;
    }
    
    self.websiteDescText = [self.websiteDescText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    return isValid;
}

-(void)hideProgressHud:(HTProgressHUD*)hud withText:(NSString*)text AFterDelay:(float)seconds{
    hud.delegate=self;
    [hud setText:text];
    [hud hideAfterDelay:seconds animated:YES];
}

-(void)saveMediaPresenceForEdit:(BOOL)isEditMode{
    HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
    progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
    progressHUD.text=NSLocalizedString(@"Saving...", @"Text displayed in the loading indicator while saving");
    progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    progressHUD.hudView.alpha=0.9;
    [progressHUD showInView:self.navigationController.view animated:YES];
    
    self.isEditMode?(self.navigationItem.hidesBackButton=YES):(self.navigationItem.leftBarButtonItem.enabled=NO);
    self.navigationItem.rightBarButtonItem.enabled=NO;
    [CLMediaPresenceObject saveMediaPresence:self.mediaObj.mediaPresenceId forUser:[CLUserObject currentUser].userID websitetitle:self.websiteNameText websiteUrl:self.websiteUrlText remarks:self.websiteDescText editMode:isEditMode
                                         success:^(NSString *mediaId){
                                             if (isEditMode) {
                                                 self.mediaObj.websiteName=self.websiteNameText;
                                                 self.mediaObj.websiteUrl=self.websiteUrlText;
                                                 self.mediaObj.websiteDescription=self.websiteDescText;
                                             }
                                             else{
                                                 self.mediaObj=[[CLMediaPresenceObject alloc] init];
                                                 self.mediaObj.mediaPresenceId=mediaId;
                                                 self.mediaObj.websiteName=self.websiteNameText;
                                                 self.mediaObj.websiteUrl=self.websiteUrlText;
                                                 self.mediaObj.websiteDescription=self.websiteDescText;
                                             }
                                             
                                             [self hideProgressHud:progressHUD withText:NSLocalizedString(@"Saved.", @"loading indicator SAVED text") AFterDelay:1];
                                         }
                                         failure:^(NSString *error){
                                             if (![error isEqualToString:@""]) {
                                                 self.isEditMode?(self.navigationItem.hidesBackButton=NO):(self.navigationItem.leftBarButtonItem.enabled=YES);
                                                 self.navigationItem.rightBarButtonItem.enabled=YES;
                                                 [progressHUD hideWithAnimation:YES];
                                                 [CLCommon showAlertwithTitle:@"Error" alertString:NSLocalizedString(@"Couldn't save Website details. Please try again later.", @"Error message when website cannot be saved") cancelbuttonName:NSLocalizedString(@"OK", @"alert ok button title")];
                                             }
                                         }];
}

#pragma mark IBActions

-(IBAction)bttnActionSaveMediaAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveMediaPresenceForEdit:YES];
    }
}

-(IBAction)bttnActionAddMediaAndDismissModal:(id)sender{
    if([self isFieldsValid]){
        [self.view endEditing:YES];
        [self.txtFirstResponder resignFirstResponder];
        [self saveMediaPresenceForEdit:NO];
    }
}

-(IBAction)bttnActionDismissModal:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bttnActionKeyboardDoneClicked:(id)sender {
    CLSimpleTextCell *cell=[self getCellForFirstResponder];
    if (cell!=nil) {
        NSIndexPath *indexpath=cell.cellIndexPath;
        if(indexpath.section==CLMediaWebsiteNameIndex){
            if ([[self.websiteNameArray objectAtIndex:[self.pickerView selectedRowInComponent:0]] isEqualToString:@"Other"])  //if other option is choosen
            {
                if([CLCommon isOSversionLessThan8])
                {
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"Please Tell Us",@"other message") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel",@"cancel btn title") otherButtonTitles:NSLocalizedString(@"OK",@"ok btn title"), nil] ;
                    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
                    [alertView show];
                }
                else
                {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                                   message: NSLocalizedString(@"Please Tell Us",@"other message")
                                                                            preferredStyle: UIAlertControllerStyleAlert];
                    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                        
                    }];
                    UIAlertAction *okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"ok btn title") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                        UITextField *textField = alert.textFields[0];
                        NSString *cutString = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        self.websiteNameText = cutString;
                        [cell setCellText:self.websiteNameText];
                        [self.tableView reloadData];
                    }];
                    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel",@"cancel btn title")
                                                                           style: UIAlertActionStyleDefault
                                                                         handler: nil];
                    [alert addAction: cancelAction];
                    [alert addAction: okAction];
                    [self presentViewController:alert animated:YES completion:nil];

                }
            }
            else{
                self.websiteNameText=[self.websiteNameArray objectAtIndex:[self.pickerView selectedRowInComponent:0]];
            }
            
            [cell setCellText:self.websiteNameText];
            [self.tableView reloadData];
        }
    }
    [cell resignCellFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

- (IBAction)bttnActionKeyboardCancelClicked:(id)sender {
    [self.txtFirstResponder resignFirstResponder];
    [self.txtViewFirstResponder resignFirstResponder];
}

#pragma mark HTProgressHUD delegates

- (void)progressHUD:(HTProgressHUD *)progressHUD wasHiddenInView:(UIView *)view{
    if (self.isEditMode) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:^(){
            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(mediaController:didAddWebsite:)]){
                [self.delegate mediaController:self didAddWebsite:self.mediaObj];
            }
        }];
    }
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        UITextField *textField = [alertView textFieldAtIndex:0];
        NSString *cutString = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        self.websiteNameText = cutString;
        [self.tableView reloadData];
    }
    else{
        //cancel button. Do nothing
    }
}

@end
