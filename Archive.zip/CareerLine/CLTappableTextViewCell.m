//
//  CLTappableTextViewCell.m
//  CareerLine
//
//  Created by CSG on 2/21/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLTappableTextViewCell.h"
#import "TIToken.h"

@interface CLTappableTextViewCell()
@property (weak, nonatomic) IBOutlet TITokenField *txtTokenField;
@property (weak, nonatomic) IBOutlet UIView *tapView;
@property(strong,nonatomic) IBOutlet UITapGestureRecognizer *singleTap;

- (IBAction)bttnActionSelectNationality:(id)sender;

@end

@implementation CLTappableTextViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"CLTappableTextViewCell" owner:self options:nil];
        
        if ([arrayOfViews count] < 1) {
            return nil;
        }
        
        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UITableViewCell class]]) {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        [self.txtTokenField setPromptText:nil];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (IBAction)bttnActionSelectNationality:(id)sender {
    self.tapView.backgroundColor=ColorCode_CareerLineGreen;
    self.tapView.alpha=0.2;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(changeColorOfTapView) object:nil];
    [self performSelector:@selector(changeColorOfTapView) withObject:nil afterDelay:0.2];
    
    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(cellDidTapCellTextField:forIndexPath:)]){
		[self.delegate cellDidTapCellTextField:self forIndexPath:self.cellIndexPath];
	}
}

-(void)disableCellField{
    self.txtTokenField.enabled=NO;
    self.txtTokenField.backgroundColor=[UIColor colorFromHexCode:@"#CCEDEB"];
    self.backgroundColor=[UIColor colorFromHexCode:@"#CCEDEB"];
}

-(void)changeColorOfTapView{
    self.tapView.backgroundColor=[UIColor clearColor];
}

-(NSString*)getEnteredText{
    return [self.txtTokenField.tokenTitles componentsJoinedByString:@",\n"];
}

-(void)setCellText:(NSString*)text{
    [self.txtTokenField removeAllTokens];
    self.txtTokenField.text=@"";
    self.txtTokenField.text=text;
    self.txtTokenField.adjustsFontSizeToFitWidth = YES;
    [self.txtTokenField tokenizeText];
    
    [self.txtTokenField layoutTokensAnimated:NO];
}

-(void)setCellFont:(UIFont*)font{
    self.txtTokenField.font=font;
}

-(void)setCellPlaceHolderText:(NSString*)text{
    [self.txtTokenField setPlaceholder:text];
}

@end
