//
//  CLPhotoBrowserViewController.h
//  CareerLine
//
//  Created by CSG on 7/23/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLPhotoBrowserViewController : UIViewController<UIPageViewControllerDataSource>

@property(nonatomic,strong) NSArray *photos;
@property(nonatomic,assign) NSInteger startingIndex;

@end
