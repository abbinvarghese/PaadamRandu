//
//  CLInboxDetailTableViewController.m
//  CareerLine
//
//  Created by CSG on 3/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLInboxDetailTableViewController.h"
#import "CLInboxQuestionnaireViewController.h"
#import "CLSideMenuViewController.h"
#import "CLInboxDetailCell.h"
#import "CLInboxQuestionaireCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"

#define kCellDetailTextFont [UIFont systemFontOfSize:11]

@interface CLInboxDetailTableViewController ()

@property (strong, nonatomic) IBOutlet UIView *sectionHeaderView;
@property (strong, nonatomic) IBOutlet UIView *sectionFooterView;
@property (weak, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (weak, nonatomic) IBOutlet UILabel *lblJobPosition;
@property (weak, nonatomic) IBOutlet UITextView *txtReplyView;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaceHolder;
@property (strong, nonatomic) IBOutlet UIToolbar *keyboardToolbar;
@property (strong,nonatomic) UIActivityIndicatorView *activityIndicator;

@property(nonatomic,assign)BOOL isDataLoaded;

- (IBAction)bttnActionKeyboardCancel:(id)sender;
- (IBAction)bttnActionReply:(id)sender;
@end

@implementation CLInboxDetailTableViewController

-(void)loadView {
    [super loadView];
    self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [self.activityIndicator setHidesWhenStopped:YES];
    [self.view addSubview:self.activityIndicator];
    self.activityIndicator.center = CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height / 2);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=self.inbox.inboxJob.companyDetails.companyName;
    [self setupTableviewController];
    [self updateHeaderDetails];
    
    self.isDataLoaded=NO;
    [self retreiveInboxDetailMessages];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SharedAppDelegate setDrawerOpenGesturePanNavigationBar];
    if ([self.inbox.msgsArray count]>0) {
        [self.tableView reloadData];
        //[self scrollTableViewToBottom];
    }
    if (self.isFromQuestionnaireSubmission) {
        [self retreiveInboxDetailMessages];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    //if inbox is unread then decrement badge and set the inbox as read..
    if (self.inbox.inboxThreadReadStatus==0) {
        self.inbox.inboxThreadReadStatus=1;
        [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) decrementBadgeForPageType:CLInboxControllerIndex];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLInboxObject cancelInboxDetailPendingRequests];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setupTableviewController{
    self.clearsSelectionOnViewWillAppear = YES;
    //self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
    self.keyboardToolbar.tintColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.txtReplyView.inputAccessoryView=self.keyboardToolbar;
    self.tableView.tableHeaderView= self.sectionHeaderView;
    [self.tableView registerClass:[CLInboxDetailCell class] forCellReuseIdentifier:@"inboxDetailCellIdentifier"];
    [self.tableView registerClass:[CLInboxQuestionaireCell class] forCellReuseIdentifier:@"inboxQuestionaireCellIdentifier"];
}

-(void)updateHeaderDetails{
    self.lblCompanyName.text=self.inbox.inboxJob.companyDetails.companyName;
    self.lblJobPosition.text=self.inbox.inboxJob.jobTitle;
}

-(void)scrollTableViewToBottom{
    ///scroll the tableview to bottom..
    if (self.tableView.contentSize.height > self.tableView.frame.size.height)
    {
        CGPoint offset = CGPointMake(0, self.tableView.contentSize.height - self.tableView.frame.size.height);
        [self.tableView setContentOffset:offset animated:YES];
    }
}

-(void)retreiveInboxDetailMessages{
    [self.activityIndicator startAnimating];
    
    [CLInboxObject inboxDetailsForinboxId:self.inbox.inboxId
                                  success:^(CLInboxObject *inboxObj){
                                      [self.activityIndicator stopAnimating];
                                      self.isDataLoaded=YES;
                    // FIXME: change temporary fix for read status once backend corrected..
                                      int readStatus=self.inbox.inboxThreadReadStatus;
                                      self.inbox=inboxObj;
                                      self.inbox.inboxThreadReadStatus=readStatus;
                                      [self updateHeaderDetails];
                                      [self.tableView reloadData];
                                      if (!self.isFromQuestionnaireSubmission) {
                                          [self scrollTableViewToBottom];
                                      }
                                      self.isFromQuestionnaireSubmission=NO;
                                  }
                                  failure:^(NSString *error){
                                      self.isFromQuestionnaireSubmission=NO;
                                      [self.activityIndicator stopAnimating];
                                      if (![error isEqualToString:@""]) {
                                          [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"")];
                                      }
                                  }];
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    if([self.inbox.msgsArray count]>0){
        [self.tableView reloadData];
    }
}

#pragma mark IBActions

- (IBAction)bttnActionKeyboardCancel:(id)sender {
    [self.txtReplyView resignFirstResponder];
}


- (IBAction)bttnActionReply:(id)sender {
//    if (![self.txtReplyView.text isEqualToString:@""]) {
//        [self.txtReplyView resignFirstResponder];
//        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
//        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
//        progressHUD.text=NSLocalizedString(@"Sending...", @"Text displayed in the loading indicator while sending reply in inbox");
//        progressHUD.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
//        progressHUD.hudView.alpha=0.9;
//        [progressHUD showInView:self.navigationController.view];
//        
//        [CLInboxObject postReplyforInboxId:self.inbox.inboxId withMessage:self.txtReplyView.text
//                                   success:^(CLInboxObject *inboxObj){
//                                       if ([self.navigationController.visibleViewController isEqual:self]) {
//                                           [progressHUD hideWithAnimation:YES];
//                                           self.txtReplyView.text=@"";
//                                           self.lblPlaceHolder.hidden=NO;
//                                           self.isDataLoaded=YES;
//                        // FIXME: change temporary fix for read status once backend corrected..
//                                           int readStatus=self.inbox.inboxThreadReadStatus;
//                                           self.inbox=inboxObj;
//                                           self.inbox.inboxThreadReadStatus=readStatus;
//                                           [self updateHeaderDetails];
//                                           [self.tableView reloadData];
//                                           [self scrollTableViewToBottom];
//                                       }
//                                   }
//                                   failure:^(NSString *error){
//                                        [progressHUD hideWithAnimation:YES];
//                                       if (![error isEqualToString:@""]) {
//                                           [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"")];
//                                       }
//                                   }];
//    }
//    else{
//        [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please enter your message.", @"Error Message for null reply field") cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
//    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isDataLoaded) {
        if (self.inbox.isQuestionnairePresent) {
            return [self.inbox.msgsArray count]+1;
        }
    }
    return [self.inbox.msgsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.inbox.isQuestionnairePresent) {
        if (indexPath.row==1) {
            CLInboxQuestionaireCell *cell = (CLInboxQuestionaireCell *)[self.tableView dequeueReusableCellWithIdentifier:@"inboxQuestionaireCellIdentifier"];
            cell.selectionStyle=UITableViewCellSelectionStyleGray;
            cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
            if (self.inbox.isQuestionnaireSubmitted) {
                cell.daysLeft=NSLocalizedString(@"Submitted", @"Questionnaire submitted message");
            }
            else{
                cell.daysLeft=self.inbox.questionnaireDueDate;
            }
            [cell updateCellContent];
            return cell;
        }
    }
    CLInboxDetailCell *cell = (CLInboxDetailCell *)[self.tableView dequeueReusableCellWithIdentifier:@"inboxDetailCellIdentifier"];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.cmpnyName=self.inbox.inboxJob.companyDetails.companyName;
    if (indexPath.row==0) {
        cell.msgDict=[self.inbox.msgsArray objectAtIndex:indexPath.row];
    }
    else{
        cell.msgDict=[self.inbox.msgsArray objectAtIndex:indexPath.row-1];
    }
    [cell updateCellContent];
    return cell;
}

#pragma mark - Table view delegate


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.inbox.isQuestionnairePresent) {
        if (indexPath.row==1) {
            return 60;
        }
    }
    NSDictionary *dict=nil;
    if (indexPath.row==0) {
        dict=[self.inbox.msgsArray objectAtIndex:indexPath.row];
    }
    else{
        dict=[self.inbox.msgsArray objectAtIndex:indexPath.row-1];
    }
    NSAttributedString *detailText=[dict objectForKey:kCLInboxDetailMsgTextkey];
    CGRect expectedDetailtextFrame=[detailText boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin context:nil];
    return MAX(114, expectedDetailtextFrame.size.height+105);
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (self.isDataLoaded) {
        if (self.inbox.isQuestionnairePresent && self.inbox.isQuestionnaireSubmitted) {
            return self.sectionFooterView;
        }
    }
    return nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (self.isDataLoaded) {
        if (self.inbox.isQuestionnairePresent && self.inbox.isQuestionnaireSubmitted) {
            return 68;
        }
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.inbox.isQuestionnairePresent) {
        if (indexPath.row==1) {
            CLInboxQuestionnaireViewController *inboxQuestionnaireController=[[CLInboxQuestionnaireViewController alloc] initWithNibName:@"CLInboxQuestionnaireViewController" bundle:[NSBundle mainBundle]];
            inboxQuestionnaireController.inboxId=self.inbox.inboxId;
            inboxQuestionnaireController.questionnaire=self.inbox.questionnaireArray;
            inboxQuestionnaireController.isSubmitted=self.inbox.isQuestionnaireSubmitted;
            [self.navigationController pushViewController:inboxQuestionnaireController animated:YES];
        }
    }
}

#pragma mark UITextView Delegates

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.lblPlaceHolder.hidden = YES;
}

-(void)textViewDidChange:(UITextView*)textView{
    self.lblPlaceHolder.hidden = ([textView.text length] > 0);
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.lblPlaceHolder.hidden = ([textView.text length] > 0);
}

@end
