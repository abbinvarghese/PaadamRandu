//
//  DBClient.m
//  CareerLine
//
//  Created by CSG on 2/12/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "DBClient.h"
#import <sqlite3.h>
#import "CLCommon.h"

@implementation DBClient

static sqlite3 *database;

//+(NSMutableArray*)getAllNationalityListFromDBnotIn:(NSString*)blackListString{
//    NSMutableArray *nationalityList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        if(blackListString.length>0){
//            queryString=[NSString stringWithFormat:@"select cy_code,cy_nationality FROM cl_countries WHERE cy_code NOT IN (%@) AND cy_nationality IS NOT NULL AND cy_nationality!='' ORDER BY cy_nationality ASC",blackListString];
//        }
//        else{
//            queryString=@"select cy_code,cy_nationality FROM cl_countries WHERE cy_nationality IS NOT NULL AND cy_nationality!='' ORDER BY cy_nationality ASC";
//        }
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *cy_code = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *cy_nationality = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                //NSNumber *gender_legal = [NSNumber numberWithInt:sqlite3_column_int(compiledStatement, 2)];
//                
//                [nationalityList addObject:[NSDictionary dictionaryWithObjectsAndKeys:cy_code,knationalityDictCode,cy_nationality,knationalityDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return nationalityList;
//}


//+(NSMutableArray *)getNationalityListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString{
//    NSMutableArray *list=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK)
//    {
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select cy_code,cy_nationality FROM cl_countries WHERE cy_nationality IS NOT NULL AND cy_nationality!='' AND  cy_nationality LIKE ? ORDER BY cy_nationality ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select cy_code,cy_nationality FROM cl_countries WHERE cy_nationality IS NOT NULL AND cy_nationality!='' AND cy_nationality LIKE '%@' AND cy_code NOT IN (%@) ORDER BY cy_nationality ASC",[NSString stringWithFormat:@"%@%%",keyword],blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *cy_code = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *cy_nationality = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                //NSNumber *gender_legal = [NSNumber numberWithInt:sqlite3_column_int(compiledStatement, 2)];
//                
//                [list addObject:[NSDictionary dictionaryWithObjectsAndKeys:cy_code,knationalityDictCode,cy_nationality,knationalityDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return list;
//}

//To get all the education list ..
//+(NSMutableArray*)getAllEducationListFromDBForCountry:(NSString*)cyCode{
//    if (![cyCode isEqualToString:@"IND"] || ![cyCode isEqualToString:@"XXX"]) {
//        cyCode = @"xxx";
//    }
//    NSMutableArray *educationList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=[NSString stringWithFormat:@"select id,cy_eq_name FROM tb_cy_edu_equilent WHERE cycode='%@' ORDER BY id ASC",cyCode];
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *educationId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *eduName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [educationList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:educationId,keducationDictCode,eduName,keducationDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return educationList;
//}

//To get all the ISD Code..
//+(NSMutableArray*)getAllISDCodeFromDB{
//    NSMutableArray *codeList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select cy_code,isdcode FROM cl_countries WHERE isdcode IS NOT NULL AND isdcode!='' ORDER BY isdcode ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *cycode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *isdCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [codeList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:cycode,kisdCountryCode,isdCode,kisdCode, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return codeList;
//}

//To get all the Gender list..
//+(NSMutableArray*)getAllGenderListFromDB{
//    NSMutableArray *genderList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select cl_gender,cl_gender_name FROM tb_gender ORDER BY cl_gender_name ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *genderId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *gendertitle = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [genderList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:genderId,kGenderOptionId,gendertitle,kGenderOptionTitle, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return genderList;
//}

//To get all the Employment status..
//+(NSMutableArray*)getAllEmpStatusFromDB{
//    NSMutableArray *empStatusList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select cl_es_code,cl_es_name FROM tb_emp_status ORDER BY cl_es_code ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *groupcode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *groupname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [empStatusList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:groupcode,kemploymentStatusIdKey,groupname,kemploymentStatusTitleKey, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return empStatusList;
//}

//To get all the Employment type..
//+(NSMutableArray*)getAllEmpTypeFromDB{
//    NSMutableArray *empTypeList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select id,type_employment FROM tb_type_employment ORDER BY type_employment ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *typeId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *typename = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [empTypeList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:typeId,kemploymentTypeIdKey,typename,kemploymentTypeNameKey, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return empTypeList;
//}

//To get all the Employment contract type..
//+(NSMutableArray*)getAllEmpContractTypeFromDB{
//    NSMutableArray *empContractTypeList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select id,contract_type FROM tb_emp_contract_type ORDER BY contract_type ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *typeId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *typename = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [empContractTypeList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:typeId,kemploymentContractTypeIdKey,typename,kemploymentContractTypeNameKey, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return empContractTypeList;
//}

////To get all the Employment job scope type..
//+(NSMutableArray*)getAllEmpJobScopeFromDB:(NSString*)countryCode{
//    NSMutableArray *jobScopeList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=[NSString stringWithFormat:@"select id,job_impact_group FROM tb_jobimpact_group where cy_code='%@' ORDER BY id DESC",countryCode];
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *scopeId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *scopename = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [jobScopeList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:scopeId,kemploymentJobScopeIdKey,scopename,kemploymentJobScopeNameKey, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobScopeList;
//}

//+(NSMutableArray*)getJoScopeGroupedForSector:(NSMutableDictionary*)sectorDict{
//    NSMutableArray *jobScopeArray = [[NSMutableArray alloc]init];
//    NSString *jobScopeCode = [sectorDict objectForKey:kCLTargetJobsJobScopeCodeKey];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select id,jobimpact_group,jobimpact FROM tb_jobimpact WHERE jobimpact_group=%@ ORDER BY id DESC",jobScopeCode];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                NSString *scopeId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *groupid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *jobimpact = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [jobScopeArray addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:scopeId,kCLTargetJobsJobScopeCodeKey,groupid,kCLTargetJobsJobImpactGroupKey,jobimpact,kCLTargetJobsJobScopeKey, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobScopeArray;
//}

//+(NSString*)getIndustryGroupNamefrom:(NSString*)groupCode{
//    NSString *GroupName;
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select indgroupname FROM tb_indgroup WHERE indgroupcode='%@'",groupCode];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                GroupName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return GroupName;
//}

//+(NSString*)getISDOfCurrentCountry:(NSString*)cyCode{
//    NSString *ISD;
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select isdcode FROM cl_countries WHERE cy_code='%@'",cyCode];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                ISD = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return ISD;
//
//}

//+(NSString*)getCountryCodeForCountry :(NSString*)country{
//    NSString *GroupName;
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select cy_code FROM cl_countries WHERE cy_name='%@'",country];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                GroupName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return GroupName;
//
//}

//+(NSMutableDictionary*)getNationalityFromCountryCode :(NSString*)cyCode{
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select cy_nationality FROM cl_countries WHERE cy_code='%@'",cyCode];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                NSString *GroupName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                [dict setObject:GroupName forKey:@"nationalityName"];
//                [dict setObject:cyCode forKey:@"nationalityCode"];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return dict;
//
//}

//+(NSString*)getIndustrySectionNameFrom:(NSString*)sectionCode{
//    NSString *sectionName;
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement = nil;
//        NSString *queryString = [NSString stringWithFormat:@"select indsectname FROM tb_indsector WHERE indsectcode='%@'",sectionCode];
//        sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK){
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW){
//                sectionName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return sectionName;
//}

//+(NSMutableArray*)getAllJobLevelGroupFromDB{
//    NSMutableArray *jobLevelGroupList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select groupcode,groupname FROM tb_level_group ORDER BY groupcode ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *groupcode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *groupname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [jobLevelGroupList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:groupcode,kjobLevelGroupDictCode,groupname,kjobLevelGroupDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobLevelGroupList;
//}

//+(NSMutableArray*)getAllJobLevelDetailForJobGroup:(NSDictionary *)jobGroup{
//    NSMutableArray *jobLevelList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select level_code,level_name,lvl_description FROM tb_level where lvl_group_code=? ORDER BY level_code ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            sqlite3_bind_text( compiledStatement, 1, [[jobGroup objectForKey:kjobLevelGroupDictCode] UTF8String], -1, SQLITE_TRANSIENT);
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *jobLevelcode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *jobLevelname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *jobLevelDesc = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [jobLevelList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:jobLevelcode,jobLevelDetailDictCode,jobLevelname,jobLevelDetailDictName,jobLevelDesc,jobLevelDetailDictDesc, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobLevelList;
//}



//
//+(NSMutableArray*)getAllCountryDetailsForCurrency:(NSString*)string{
//    NSMutableArray *jobFuncCatList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=[NSString stringWithFormat:@"select cy_name,cy_code,cy_currencycode FROM cl_countries where cy_currencycode IS NOT NULL AND isdcode!='' AND cy_name LIKE '%@' ORDER BY cy_name ASC",[NSString stringWithFormat:@"%@%%",string]];
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *catid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *catname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *catnamee = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [jobFuncCatList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:catid,kjobPreferenceCountryName,catname,kjobPreferenceCountryCode, catnamee , kjobPreferenceCurrencyCode, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobFuncCatList;
//}

//+(NSMutableArray*)getAllJobFunctionsCategory{
//    NSMutableArray *jobFuncCatList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select id,fn_category FROM tb_function_cat ORDER BY fn_category ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *catid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *catname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [jobFuncCatList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:catid,kjobFunctionCategoryCode,catname,kjobFunctionCategoryName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return jobFuncCatList;
//}

//+(NSMutableArray*)getAllJobFunctionsForCategory:(NSString*)catId notIn:(NSString*)blackListString{
//    NSMutableArray *jobFuncList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            NSString *queryString=[NSString stringWithFormat:@"select * FROM tb_function where fn_cat_code LIKE '%@' ORDER BY other_flag ASC",catId];
//            sqlStatement = [queryString UTF8String];
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select * FROM tb_function where fn_cat_code LIKE '%@' AND fncode NOT IN (%@) ORDER BY other_flag ASC",catId,blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *fncode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *fncatcode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *fnname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                NSString *fnOtherFlag = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
//                
//                [jobFuncList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:fncode,kjobFunctionCode,fnname,kjobFunctionName,fncatcode,kjobFunctionCategoryCode,fnOtherFlag,kjobFunctionOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return jobFuncList;
//}

//+(NSMutableArray *)getJobFunctionsForSearchString:(NSString*)keyword notIn:(NSString*)blackListString{
//    NSMutableArray *jobFuncList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK)
//    {
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select * FROM tb_function WHERE fnname LIKE ? ORDER BY fnname ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select * FROM tb_function where fnname LIKE '%@' AND fncode NOT IN (%@) ORDER BY fnname ASC",[NSString stringWithFormat:@"%@%%",keyword],blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *fncode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *fnname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [jobFuncList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:fncode,kjobFunctionDictCode,fnname,kjobFunctionDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return jobFuncList;
//}

//+(NSMutableArray*)getAllIndustrySectorsFromDB:(id)sender notIn:(NSString *)blackListString{
//    NSMutableArray *industrySectors=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//       const char *sqlStatement =nil;
//        
//        if(blackListString.length==0){
//            NSString *queryString=@"select indsectcode,indsectname FROM tb_indsector ORDER BY indsectcode ASC";
//            sqlStatement = [queryString UTF8String];
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select indsectcode,indsectname FROM tb_indsector WHERE indsectcode NOT IN (%@) ORDER BY indsectcode ASC",blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//       // queryString=@"select indsectcode,indsectname FROM tb_indsector ORDER BY indsectcode ASC";
//        //const char *sqlStatement = [queryString UTF8String];
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *indsectcodeString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *indsectnameString = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [industrySectors addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:indsectcodeString,kIndSectDictCode,indsectnameString,kIndSectDictName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return industrySectors;
//}



//+(NSMutableArray*)getIndustriesGroupedForSector:(NSMutableDictionary*)sectorDict{
//    NSMutableArray *industryGrouped=[[NSMutableArray alloc] init];
//    NSString *indsectcode=[sectorDict objectForKey:kIndSectDictCode];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        //To get the group headings...
//        const char *sqlStatement = "select indsectcode,indgroupcode,indgroupname FROM tb_indgroup where indsectcode=? ORDER BY indgroupname ASC";
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            sqlite3_bind_text( compiledStatement, 1, [indsectcode UTF8String], -1, SQLITE_TRANSIENT);
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *indsectCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *indsectGrpCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *indsectGrpName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [industryGrouped addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:indsectCode,kIndSectDictCode,indsectGrpCode,kIndustryGrpDictCode,indsectGrpName,kIndustryGrpDictName,@"0",kIndGrpOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//        
        //To get the content of headings..
//        for (int i=0; i<[industryGrouped count]; i++) {
//            NSMutableArray *industryMain=[[NSMutableArray alloc] init];
//            
//            const char *sqlStatement = "select indmaincode,indmainname FROM tb_industrymain where indgroupcode=? ORDER BY indmaincode ASC";
//            sqlite3_stmt *compiledStatement;
//            if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//                sqlite3_bind_text( compiledStatement, 1, [[[industryGrouped objectAtIndex:i] objectForKey:kIndSectDictCode] UTF8String], -1, SQLITE_TRANSIENT);
//                while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                    NSString *indmaincode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                    NSString *indmainname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                    
//                    [industryMain addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:indmaincode,kIndGroupDictCode,indmainname,kIndGroupDictName, nil]];
//                }
//            }
//            sqlite3_finalize(compiledStatement);
//            
//            NSMutableDictionary *groupedDict=[industryGrouped objectAtIndex:i];
//            [groupedDict setObject:industryMain forKey:kIndustryMainArrayCode];
//        }
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return industryGrouped;
//}

//+(NSMutableArray*)getMainIndustriesListForGroup:(NSMutableDictionary*)groupDict notIn:(NSString*)blackListString{
//    NSMutableArray *industryMainList=[[NSMutableArray alloc] init];
//    NSString *indGroupedcode= [groupDict objectForKey:kIndustryGrpDictCode];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select indgroupcode,indname,indcode FROM tb_industry where indgroupcode=? ORDER BY indname ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select indgroupcode,indname,indcode FROM tb_industry where indgroupcode='%@' AND indcode NOT IN (%@) ORDER BY indname ASC",indGroupedcode,blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [indGroupedcode UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *industryGrpCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *industryname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *industryCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [industryMainList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:industryGrpCode,kIndustryGrpDictCode,industryname,kIndustryDictName,industryCode,kIndustryDictCode,@"0",kIndOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return industryMainList;
//}

//+(NSMutableArray*)getAllIndustriesFromDBnotIn:(NSString*)blackListString{
//    NSMutableArray *industryMainList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select indcode,indname,inddescription FROM tb_industry ORDER BY indname ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select indcode,indname,inddescription FROM tb_industry where indcode NOT IN (%@) ORDER BY indname ASC",blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *industryCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *industryname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *industrydesc=@"";
//                if (sqlite3_column_text(compiledStatement, 2)!=NULL) {
//                     industrydesc = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                }
//               
//                
//                [industryMainList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:industryCode,kIndustryDictCode,industryname,kIndustryDictName,industrydesc,kIndustryDictDesc, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return industryMainList;
//}

//+(NSMutableArray*)getMainIndustriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString{
//    NSMutableArray *industryMainList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select indcode,indname,inddescription FROM tb_industry where indname LIKE ? ORDER BY indname ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select indcode,indname,inddescription FROM tb_industry where indname LIKE '%@' AND indcode NOT IN (%@) ORDER BY indname ASC",[NSString stringWithFormat:@"%%%@%%",keyword],blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%%%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *industryCode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *industryname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *industrydesc=@"";
//                if (sqlite3_column_text(compiledStatement, 2)!=NULL) {
//                    industrydesc = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                }
//                
//                [industryMainList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:industryCode,kIndustryDictCode,industryname,kIndustryDictName,industrydesc,kIndustryDictDesc, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return industryMainList;
//}

//To get all locations..
//+(NSMutableArray*)getAllLocationsFromDB{
//    NSMutableArray *locationsList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name,tb_location.ADM1_FULL_NAME FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code ORDER BY tb_location.loc_code ASC LIMIT 0, 10";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *loccode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *locname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *cycode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                NSString *cyname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
//                NSString *locAdminArea = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
//                
//                [locationsList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName,locAdminArea,kLocationAdminArea, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return locationsList;
//}

//To get all locations for country code..
//+(NSMutableArray*)getAllLocationsForCountryCode:(NSString*)code notIn:(NSString*)blackListString{
//    NSMutableArray *locationsList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code where tb_location.cy_code=? ORDER BY tb_location.loc_code ASC LIMIT 0, 10";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code where tb_location.loc_code NOT IN (%@) AND tb_location.cy_code='%@' ORDER BY tb_location.loc_code ASC LIMIT 0, 10",blackListString,code];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [code UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *loccode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *locname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *cycode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                NSString *cyname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
//                
//                [locationsList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return locationsList;
//}

//To get all locations for search string..
//+(NSMutableArray*)getLocationsForSearchString:(NSString*)keyword{
//    NSMutableArray *locationsList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        sqlStatement = "select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name,tb_location.ADM1_FULL_NAME FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code where tb_location.loc_name LIKE ? ORDER BY tb_location.loc_code ASC LIMIT 0, 10";
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *loccode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *locname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *cycode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                NSString *cyname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
//                NSString *locAdminArea = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
//                
//                [locationsList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName,locAdminArea,kLocationAdminArea, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return locationsList;
//}

//To get all locations for country code and searchString..
//+(NSMutableArray*)getLocationsForCountryCode:(NSString*)code andSearchString:(NSString*)keyword notIn:(NSString*)blackListString{
//    NSMutableArray *locationsList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code where tb_location.loc_name LIKE ? AND tb_location.cy_code=? ORDER BY tb_location.loc_code ASC LIMIT 0, 10";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select tb_location.loc_code,tb_location.loc_name,tb_location.cy_code,cl_countries.cy_name FROM tb_location LEFT JOIN cl_countries ON tb_location.cy_code = cl_countries.cy_code where tb_location.loc_name LIKE '%@' AND tb_location.cy_code='%@' AND tb_location.loc_code NOT IN (%@) ORDER BY tb_location.loc_code ASC LIMIT 0, 10",[NSString stringWithFormat:@"%@%%",keyword],code,blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//                sqlite3_bind_text( compiledStatement, 2, [code UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *loccode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *locname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *cycode = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                NSString *cyname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
//                
//                [locationsList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:loccode,kLocationCode,locname,kLocationName,cycode,kLocationCountryCode,cyname,kLocationCountryName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return locationsList;
//}

//To get all the Countries from DB except those contained in blackListString..
//+(NSMutableArray*)getAllCountriesListFromDBnotIn:(NSString*)blackListString{
//    NSMutableArray *countryList=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        if(blackListString.length>0){
//            queryString=[NSString stringWithFormat:@"select cy_code,cy_name FROM cl_countries WHERE cy_code NOT IN (%@) AND gr_type='C' ORDER BY cy_name ASC",blackListString];
//        }
//        else{
//            queryString=@"select cy_code,cy_name FROM cl_countries WHERE gr_type='C' ORDER BY cy_name ASC";
//        }
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *cy_code = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *cy_name = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [countryList addObject:[NSDictionary dictionaryWithObjectsAndKeys:cy_code,kLocationCountryCode,cy_name,kLocationCountryName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return countryList;
//}

//To get the Countries based on the searchString from DB except those contained in blackListString..
//+(NSMutableArray *)getCountriesListForSearchString:(NSString*)keyword notIn:(NSString*)blackListString{
//    NSMutableArray *list=[[NSMutableArray alloc] init];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK)
//    {
//        const char *sqlStatement =nil;
//        if(blackListString.length==0){
//            sqlStatement = "select cy_code,cy_name FROM cl_countries WHERE cy_name LIKE ? AND gr_type='C' ORDER BY cy_name ASC";
//        }
//        else{
//            NSString *queryString=[NSString stringWithFormat:@"select cy_code,cy_name FROM cl_countries WHERE cy_name LIKE '%@' AND cy_code NOT IN (%@) AND gr_type='C' ORDER BY cy_name ASC",[NSString stringWithFormat:@"%@%%",keyword],blackListString];
//            sqlStatement = [queryString UTF8String];
//        }
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            if(blackListString.length==0){
//                sqlite3_bind_text( compiledStatement, 1, [[NSString stringWithFormat:@"%@%%",keyword] UTF8String], -1, SQLITE_TRANSIENT);
//            }
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *cy_code = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *cy_name = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [list addObject:[NSDictionary dictionaryWithObjectsAndKeys:cy_code,kLocationCountryCode,cy_name,kLocationCountryName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return list;
//}



//TODO: remove gender dependency
//+(NSMutableArray *)getSalutationsListforNationality:(NSMutableString*)nationalityString{
//    NSMutableArray *salutationList=[[NSMutableArray alloc] init];
//    
//    //international salutaions should be listed always..
//    [nationalityString appendString:@",\"INT\""];
//    
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK)
//    {
//        
//        //query to get salutation list according to nationality..
//        //NSString *queryString=nil;
////        if([genderDict count]>0){
////            queryString=[NSString stringWithFormat:@"select cl_salutation,cl_salutationid FROM tb_salutation WHERE cl_gender LIKE '%@' AND cl_cycode IN (%@)",[genderDict objectForKey:kGenderOptionId],nationalityString];
////        }
////        else{
//            NSString *queryString=[NSString stringWithFormat:@"select cl_salutation,cl_salutationid FROM tb_salutation WHERE cl_cycode IN (%@)",nationalityString];
//        //}
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *salutationId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *salutationTitle = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                
//            //Process the salutaion array to remove duplicates(if duplicates present then take the first one)..
//                //checking whether the retreived title present in already added salutation array..
//                BOOL isSameSalutationTitlePresent=NO;
//                for (int i=0; i<[salutationList count]; i++) {
//                    NSString *tempTitle=[[salutationList objectAtIndex:i] objectForKey:kSalutationOptionTitle];
//                    if ([salutationTitle isEqualToString:tempTitle]) {
//                        isSameSalutationTitlePresent=YES;
//                    }
//                }
//                //if same title not present then add to salutation array..
//                if (!isSameSalutationTitlePresent) {
//                    [salutationList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:salutationId,kSalutationOptionId,salutationTitle,kSalutationOptionTitle, nil]];
//                }
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    
//    return salutationList;
//}

//To get all career move reasons list ..
//+(NSMutableArray*)getAllCareerMoveListFromDB{
//    NSMutableArray *resonForCareerMoveList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select rfm_id,rfm FROM tb_rfm ORDER BY rfm_id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *rfmId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *rfmName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                if ([rfmName isEqualToString:@"Other"]) {
//                    [resonForCareerMoveList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:rfmId,kreasonForMoveDictId,rfmName,kreasonForMoveDictName,@"1",kreasonOtherFlag, nil]];
//                }else{
//                     [resonForCareerMoveList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:rfmId,kreasonForMoveDictId,rfmName,kreasonForMoveDictName,@"0",kreasonOtherFlag, nil]];
//                }
//               
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return resonForCareerMoveList;
//}
//+(NSMutableArray*)getAllEmpTypeGroupFromDB{
//    NSMutableArray *empTypeGroupList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select id,type_employment_group FROM tb_type_employment_group ORDER BY id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *empGroupId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *empGroupName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [empTypeGroupList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:empGroupId,kempTypeId,empGroupName,kempTypeName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return empTypeGroupList;
////}
//+(NSMutableArray*)getAllEmpTypeDetailForGroup:(NSDictionary *)empTypeGroup{
//    NSMutableArray *empTypeDetailslList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select id,type_employment,type_employment_sub FROM tb_type_employment_sub where type_employment=? ORDER BY id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            sqlite3_bind_text( compiledStatement, 1, [[empTypeGroup objectForKey:kempTypeId] UTF8String], -1, SQLITE_TRANSIENT);
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *empTypeDetailId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *empTypeGroupId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                NSString *empTypeDetailName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
//                
//                [empTypeDetailslList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:empTypeDetailId,kempTypeDetailId,empTypeGroupId,kempTypeGroupId,empTypeDetailName,kempTypeDetailName, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return empTypeDetailslList;
//}
//+(NSMutableArray*)getAllBenefitsListFromDB{
//    NSMutableArray *benefitsList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select * FROM tb_benefits ORDER BY id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *benefitsId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *benefitsName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [benefitsList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:benefitsId,kBenefitsId,benefitsName,kBenefitsName,@"0",kBenefitsOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return benefitsList;
//}
//+(NSMutableArray*)getAllFrequencyListFromDB{
//    NSMutableArray *frequencyList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select * FROM tb_frequency ORDER BY id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *freqId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *freqName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [frequencyList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:freqId,kFrequencyId,freqName,kFrequencyName,@"0",kFrequencyOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return frequencyList;
//}
//+(NSMutableArray*)getAllowanceAndLoadingListFromDB{
//    NSMutableArray *allowanceLoadingList=[[NSMutableArray alloc] init];
//    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
//        NSString *queryString=nil;
//        queryString=@"select * FROM tb_allowances_loadings ORDER BY id ASC";
//        const char *sqlStatement = [queryString UTF8String];
//        
//        sqlite3_stmt *compiledStatement;
//        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
//            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
//                NSString *allowanceId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
//                NSString *allowanceName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
//                
//                [allowanceLoadingList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:allowanceId,kAllowanceAndLoadingId,allowanceName,kAllowanceAndLoadingName,@"0",kAllowanceAndLoadingOtherFlag, nil]];
//            }
//        }
//        sqlite3_finalize(compiledStatement);
//    }
//    else{
//        NSLog(@"Error open db");
//    }
//    sqlite3_close(database);
//    return allowanceLoadingList;
//}
+(NSMutableArray*)getIncentiveBonusListFromDB{
    NSMutableArray *incentiveList=[[NSMutableArray alloc] init];
    if (sqlite3_open([[[CLCommon sharedInstance] dbPath] UTF8String], &database) == SQLITE_OK){
        NSString *queryString=nil;
        queryString=@"select * FROM tb_incentive_bonus ORDER BY id ASC";
        const char *sqlStatement = [queryString UTF8String];
        
        sqlite3_stmt *compiledStatement;
        if(sqlite3_prepare_v2(database, sqlStatement, -1, &compiledStatement, NULL) == SQLITE_OK) {
            while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
                NSString *incentiveId = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
                NSString *incentiveName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
                
                [incentiveList addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:incentiveId,kIncentiveBonusId,incentiveName,kIncentiveBonusName,@"0",kIncentiveBonusOtherFlag, nil]];
            }
        }
        sqlite3_finalize(compiledStatement);
    }
    else{
        NSLog(@"Error open db");
    }
    sqlite3_close(database);
    return incentiveList;
}
@end
