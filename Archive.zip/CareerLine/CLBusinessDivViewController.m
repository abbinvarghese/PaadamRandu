//
//  CLBusinessDivViewController.m
//  CareerLine
//
//  Created by RENJITH on 05/02/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLBusinessDivViewController.h"
#import "CLSelectBusinessDivViewController.h"

#define kSectionFooterBgColor [UIColor whiteColor]

@interface CLBusinessDivViewController ()

@property (nonatomic, strong) NSMutableArray *selectedBusDivArray;
@end

@implementation CLBusinessDivViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeInteractive;
    self.title=NSLocalizedString(@"Select Business Division", @"select business division page title");

    self.selectedBusDivArray= [[NSMutableArray alloc] initWithArray:self.alreadySelectedBusDivision];
    [self setRightNavigationButton];
    
}

-(void)viewDidAppear:(BOOL)animated
{
    if ([self.selectedBusDivArray count]>0)
    {
        [self.tableView setEditing:YES animated:YES];
    }
}

-(void)setRightNavigationButton{

        UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Business division modal done button title") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSaveBussinessDivAndDismissModal:)];
        self.navigationItem.rightBarButtonItem=rightNavBttn;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)bttnActionSaveBussinessDivAndDismissModal:(id)sender{
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(employmentDetailsController:didAddBusinessDiv:)]){
            [self.delegate employmentDetailsController:self didAddBusinessDiv:self.selectedBusDivArray];
        }
    }];
   
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    // Return the number of rows in the section.
    return [self.selectedBusDivArray count];
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
   
     return NSLocalizedString(@"Business Division", @"Placeholder for Business Division title");
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
        return 44;
 
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleTextCellIdentifier"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"titleTextCellIdentifier"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
    }

    cell.textLabel.text=[[self.selectedBusDivArray objectAtIndex:indexPath.row] objectForKey:@"companyDivision"];
    return cell;
    
}

- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
        UIView *sectionFooter=[[UIView alloc] initWithFrame:CGRectZero];
        sectionFooter.backgroundColor=kSectionFooterBgColor;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
        button.tag=section;
        button.translatesAutoresizingMaskIntoConstraints=YES;
        [button addTarget:self action:@selector(bttnActionShowAddDetailModal:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"" forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 11, self.tableView.bounds.size.width, 22);
        [sectionFooter addSubview:button];
        
        return sectionFooter;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
        return 44;
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
        return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {

            [self.selectedBusDivArray removeObjectAtIndex:indexPath.row];
            if(indexPath.row==0 && [self.selectedBusDivArray count]==0){
                [self.tableView reloadData];
            }
            else{
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        
    }
}
#pragma mark Add busineddDiv delegate

-(void)businessDivController:(CLSelectBusinessDivViewController *)controller didSelectBusDiv:(NSMutableDictionary *)selectedBusDivDict{
    [self.selectedBusDivArray addObject:selectedBusDivDict];
    [self.tableView reloadData];
}

-(IBAction)bttnActionShowAddDetailModal:(UIButton*)sender{
    CLSelectBusinessDivViewController *selectBusinessDiv=[[CLSelectBusinessDivViewController alloc] initWithStyle:UITableViewStyleGrouped];
    selectBusinessDiv.alreadySelectedBusDiv = self.selectedBusDivArray;
   // selectBusinessDiv.completeBusinessDiv = self.completeBusinessDiv;
    selectBusinessDiv.selectedCompany = self.selectedCompany;
    selectBusinessDiv.delegate= self;
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:selectBusinessDiv];
    [self presentViewController:nav animated:YES completion:nil];
}

@end
