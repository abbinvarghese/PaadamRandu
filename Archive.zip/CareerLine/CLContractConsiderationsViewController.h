//
//  CLContractConsiderationsViewController.h
//  CareerLine
//
//  Created by Abbin on 07/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLContractPreferencesViewController.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLHeightAdjustTextCell.h"

@interface CLContractConsiderationsViewController : UITableViewController<contractPreferenceDelegate,CLSimpleTextCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate,HTProgressHUDDelegate,CLHeightAdjustTextCellDelegate,UIAlertViewDelegate>

@end
