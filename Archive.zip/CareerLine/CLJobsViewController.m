//
//  CLJobsViewController.m
//  CareerLine
//
//  Created by CSG on 1/16/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLJobsViewController.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "CLSideMenuViewController.h"
#import "CLJobsListingCell.h"
#import "CLJobsDetailViewController.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLUserObject.h"
#import "CLJobsObject.h"

@interface CLJobsViewController ()<UINavigationControllerDelegate>


@property (weak, nonatomic) IBOutlet UITableView *jobListingTable;
@property(nonatomic,strong)UIRefreshControl *refreshControl;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *barBttnJobFilter;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorMsg;
@property (strong, nonatomic)HTProgressHUD *activityIndicator;
@property (strong, nonatomic) IBOutlet UIView *tblFooterView;

@property(nonatomic,assign)JobsFilterOptions selectedFilterButton;
@property(nonatomic,strong)NSMutableArray *jobsArray;
@property(nonatomic,assign)NSInteger unreadCount;
@property(nonatomic,assign)int nextPageToLoad;                  //holds the next page number to load..
@property(nonatomic,assign)BOOL shouldPaginate;                 //whether pagination web-service request should be called..
@property(nonatomic)BOOL isLastPageReached;              //whether last page reached(received from backend)..
@property(nonatomic,assign)BOOL isRetreivingDataForPagination;  //whether pagination webservice is curremtly loading..

- (IBAction)bttnActionJobFilterChange:(id)sender;
@end

@implementation CLJobsViewController
@synthesize jobsArray,refreshControl;

#pragma mark UIViewController Methods

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    self.title=NSLocalizedString(@"Jobs", @"Jobs page title");
    self.nextPageToLoad=1;
    self.shouldPaginate=YES;
    self.isRetreivingDataForPagination=NO;
    self.lblErrorMsg.hidden=YES;
    self.selectedFilterButton=FilterAllJobs;
    
    [self setupLeftMenuButton];
    [self.jobListingTable registerClass:[CLJobsListingCell class] forCellReuseIdentifier:@"jobsListingCellIdentifier"];
    [self addButtonsToToolbar];
    [self setUpRefreshControl];
}

-(void)viewWillAppear:(BOOL)animated{
    [SharedAppDelegate setDrawerOpenGesturePanCenterView];
    if([self.jobsArray count]>0){
        [self.jobListingTable reloadData];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(trafficLightChangeNotifReceived:) name:kCLNotifCenterTrafficLightChanged object:nil];
    self.lblErrorMsg.hidden=YES;
    if(([self.jobsArray count]<=0) || (self.unreadCount!=[CLUserObject currentUser].unreadJobsCount)){
        [self retrieveJobsListWithSelectedFilter:self.selectedFilterButton forPagination:NO];
    }
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCLNotifCenterTrafficLightChanged object:nil];
    [CLJobsObject cancelJobListingPendingRequests];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableView Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.jobsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CLJobsListingCell *cell = (CLJobsListingCell *)[self.jobListingTable dequeueReusableCellWithIdentifier:@"jobsListingCellIdentifier"];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    cell.job=[jobsArray objectAtIndex:indexPath.row];
    [cell updateCellContent];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //self.selectedCell=(CLJobsListingCell*)[self.jobListingTable cellForRowAtIndexPath:indexPath];
    CLJobsDetailViewController *jobsDetailController=[[CLJobsDetailViewController alloc] initWithNibName:@"CLJobsDetailViewController" bundle:[NSBundle mainBundle]];
    jobsDetailController.isFromPushNotifications=NO;
    jobsDetailController.job=[self.jobsArray objectAtIndex:indexPath.row];
    if (jobsDetailController.job.jobUnreadStatus==1) {
        self.unreadCount--;
    }
    [self.navigationController pushViewController:jobsDetailController animated:YES];
}

#pragma mark Utility Functions

-(void)clearArraysAndReloadTable{
    [self.jobsArray removeAllObjects];
    [self.jobListingTable reloadData];
}

-(void)setUpRefreshControl{
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.jobListingTable;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshJobList:) forControlEvents:UIControlEventValueChanged];
    tableViewController.refreshControl = self.refreshControl;
}

-(void)refreshJobList:(id)sender{
    [self retrieveJobsListWithSelectedFilter:self.selectedFilterButton forPagination:NO];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRefreshControlLoading) object:nil];
    [self performSelector:@selector(endRefreshControlLoading) withObject:self afterDelay:1];
}

-(void)endRefreshControlLoading{
    [self.refreshControl endRefreshing];
}

-(void)addButtonsToToolbar{
    UIBarButtonItem *jobFilterButton=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"All Jobs", @"Job filter button title in job listing page") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionJobFilterChange:)];
    UIBarButtonItem *firstFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *secondFlexibleSpace=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [self setToolbarItems:[NSArray arrayWithObjects:firstFlexibleSpace,jobFilterButton,secondFlexibleSpace, nil] animated:YES];
    self.barBttnJobFilter=jobFilterButton;
}

-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(void)updateProgressHudColor{
    self.activityIndicator.hudView.backgroundColor=[CLCommon sharedInstance].currentTrafficLightColor;
    self.activityIndicator.hudView.alpha=0.9;
}

-(void)gotoJobsDetailViewFromPushWithJobId:(NSString*)jobId{
    NSLog(@"push notif gotoJobsDetail function invoked...");
    CLJobsDetailViewController *jobsDetailController=[[CLJobsDetailViewController alloc] initWithNibName:@"CLJobsDetailViewController" bundle:[NSBundle mainBundle]];
    jobsDetailController.isFromPushNotifications=YES;
    
    CLJobsObject *jobsObj=[[CLJobsObject alloc] init];
    jobsObj.jobID=jobId;
    jobsDetailController.job=jobsObj;
    [self.navigationController pushViewController:jobsDetailController animated:NO];
}

-(void)retrieveJobsListWithSelectedFilter:(JobsFilterOptions)selectedFilter forPagination:(BOOL)paginate{
    if (paginate) {
        self.isRetreivingDataForPagination=YES;
        [CLJobsObject listJobsForUserId:[CLUserObject currentUser].userID
                         selectedFilter:self.selectedFilterButton
                             pageNumber:self.nextPageToLoad
                                success:^(NSMutableArray *jobs,BOOL lastPage, NSInteger unreadJobsCount){
                                    self.unreadCount=unreadJobsCount;
                                    self.isRetreivingDataForPagination=NO;
                                    self.isLastPageReached=lastPage;
                                    self.nextPageToLoad++;
                                    [self.jobsArray addObjectsFromArray:jobs];
                                    [self.jobListingTable reloadData];
                                    
                                    if (self.isLastPageReached) {
                                        self.jobListingTable.tableFooterView=nil;
                                        self.shouldPaginate=NO;
                                    }
                                    else{
                                        self.jobListingTable.tableFooterView=self.tblFooterView;
                                        self.shouldPaginate=YES;
                                    }
                                }
                                failure:^(NSString *error){
                                    if (![error isEqualToString:@""]) {
                                        self.isRetreivingDataForPagination=NO;
                                        if (self.isLastPageReached) {
                                            self.jobListingTable.tableFooterView=nil;
                                            self.shouldPaginate=NO;
                                        }
                                        else{
                                            self.jobListingTable.tableFooterView=self.tblFooterView;
                                            self.shouldPaginate=YES;
                                        }
                                    }
                                }];
    }
    else{
        [self.activityIndicator hideWithAnimation:YES];
        HTProgressHUD *progressHUD = [[HTProgressHUD alloc] init];
        progressHUD.animation=[HTProgressHUDFadeZoomAnimation animation];
        progressHUD.text=NSLocalizedString(@"Loading Jobs...", @"Text displayed in the loading indicator while loading jobs");
        self.activityIndicator=progressHUD;
        [self updateProgressHudColor];
        self.nextPageToLoad=1;
        [self.activityIndicator showInView:self.view];
        [CLJobsObject listJobsForUserId:[CLUserObject currentUser].userID
                         selectedFilter:self.selectedFilterButton
                             pageNumber:self.nextPageToLoad
                                success:^(NSMutableArray *jobs,BOOL lastPage, NSInteger unreadJobsCount){
                                    self.unreadCount=unreadJobsCount;
                                    self.isLastPageReached=lastPage;
                                    self.nextPageToLoad++;
                                    [self.activityIndicator hideWithAnimation:YES];
                                    self.jobsArray=jobs;
                                    [self.jobListingTable reloadData];
                                    if ([self.jobsArray count]==0) {
                                        self.jobListingTable.tableFooterView=nil;
                                        self.lblErrorMsg.hidden=NO;
                                    }
                                    else{
                                        if (self.isLastPageReached) {
                                            self.jobListingTable.tableFooterView=nil;
                                            self.shouldPaginate=NO;
                                        }
                                        else{
                                            self.jobListingTable.tableFooterView=self.tblFooterView;
                                            self.shouldPaginate=YES;
                                        }
                                        self.lblErrorMsg.hidden=YES;
                                    }
                                    
                                    //update side menu badge count..
                                    [((CLSideMenuViewController*)SharedAppDelegate.drawerController.leftDrawerViewController) updateBadge:unreadJobsCount andSaveUserForPageType:CLJobsControllerIndex];
                                }
                                failure:^(NSString *error){
                                    if (![error isEqualToString:@""]) {
                                        [self.activityIndicator hideWithAnimation:YES];
                                        [CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:error cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
                                        if ([self.jobsArray count]==0) {
                                            self.jobListingTable.tableFooterView=nil;
                                            self.lblErrorMsg.hidden=NO;
                                        }
                                        else{
                                            if (self.isLastPageReached) {
                                                self.jobListingTable.tableFooterView=nil;
                                                self.shouldPaginate=NO;
                                            }
                                            else{
                                                self.jobListingTable.tableFooterView=self.tblFooterView;
                                                self.shouldPaginate=YES;
                                            }
                                            self.lblErrorMsg.hidden=YES;
                                        }
                                    }
                                }];
    }
}

#pragma mark UIScrollView Delegates

-(void)scrollViewDidScroll: (UIScrollView*)scrollView
{
    float scrollViewHeight = scrollView.frame.size.height;
    float scrollContentSizeHeight = scrollView.contentSize.height;
    float scrollOffset = scrollView.contentOffset.y;
    
    if (self.shouldPaginate && !self.isRetreivingDataForPagination) {
        if ((scrollOffset + scrollViewHeight >= scrollContentSizeHeight) && (scrollContentSizeHeight>0))
        {
            [self retrieveJobsListWithSelectedFilter:self.selectedFilterButton forPagination:YES];
            self.shouldPaginate=NO;
        }
    }
}

#pragma mark IBActions

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)bttnActionJobFilterChange:(id)sender {
    if ([CLCommon isOSversionLessThan8]) {
        UIActionSheet *jobFilterActionSheet=[[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"job filtering actionsheet cancel button") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"All Jobs", @"job filtering actionsheet option 1"),NSLocalizedString(@"Accepted", @"job filtering actionsheet option 3"),NSLocalizedString(@"Declined", @"job filtering actionsheet option 4"),NSLocalizedString(@"Bookmarked", @"job filtering actionsheet option 2"), nil];
        [jobFilterActionSheet showInView:self.view];
    }
    else{
        UIAlertController *actionSheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *allJobsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"All Jobs", @"job filtering actionsheet option 1") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                        {
                                            [self actionSheet:nil didDismissWithButtonIndex:FilterAllJobs];
                                        }];
        
        UIAlertAction *acceptedJobsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Accepted", @"job filtering actionsheet option 3") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                             {
                                                 [self actionSheet:nil didDismissWithButtonIndex:FilterAccepted];
                                             }];
        
        UIAlertAction *declinedJobsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Declined", @"job filtering actionsheet option 4") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                             {
                                                 [self actionSheet:nil didDismissWithButtonIndex:FilterDeclined];
                                             }];
        
        UIAlertAction *bookmarkedJobsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Bookmarked", @"job filtering actionsheet option 2") style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
                                               {
                                                   [self actionSheet:nil didDismissWithButtonIndex:FilterBookmarked];
                                               }];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", @"job filtering actionsheet cancel button") style:UIAlertActionStyleCancel handler:nil];
        
        [actionSheetController addAction:allJobsAction];
        [actionSheetController addAction:acceptedJobsAction];
        [actionSheetController addAction:declinedJobsAction];
        [actionSheetController addAction:bookmarkedJobsAction];
        [actionSheetController addAction:cancelAction];
        actionSheetController.view.tintColor = [CLCommon sharedInstance].currentTrafficLightColor;
        
        [self presentViewController:actionSheetController animated:YES completion:nil];
    }
}

#pragma mark NSNotification Methods

-(void)trafficLightChangeNotifReceived:(NSNotification*) notification{
    [self updateProgressHudColor];
    if([self.jobsArray count]>0){
        [self.jobListingTable reloadData];
    }
}

#pragma mark UIActionSheet Delegate

-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case FilterAllJobs:
            self.selectedFilterButton=FilterAllJobs;
            [self.barBttnJobFilter setTitle:NSLocalizedString(@"All Jobs", @"job filtering actionsheet option 1")];
            break;
        case FilterBookmarked:
            self.selectedFilterButton=FilterBookmarked;
            [self.barBttnJobFilter setTitle:NSLocalizedString(@"Bookmarked", @"job filtering actionsheet option 2")];
            break;
        case FilterAccepted:
            self.selectedFilterButton=FilterAccepted;
            [self.barBttnJobFilter setTitle:NSLocalizedString(@"Accepted", @"job filtering actionsheet option 3")];
            break;
        case FilterDeclined:
            self.selectedFilterButton=FilterDeclined;
            [self.barBttnJobFilter setTitle:NSLocalizedString(@"Declined", @"job filtering actionsheet option 4")];
            break;
        case 4:
            //Cancel
            return;
            break;
        default:
            break;
    }
    self.lblErrorMsg.hidden=YES;
    [self.activityIndicator hideWithAnimation:NO];
    [self retrieveJobsListWithSelectedFilter:self.selectedFilterButton forPagination:NO];
}

- (void)willPresentActionSheet:(UIActionSheet *)actionSheet
{
    for (UIView *subview in actionSheet.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            
            UIButton *button = (UIButton *)subview;
            [button setTitleColor:[CLCommon sharedInstance].currentTrafficLightColor forState:UIControlStateNormal];
        }
    }
}


@end
