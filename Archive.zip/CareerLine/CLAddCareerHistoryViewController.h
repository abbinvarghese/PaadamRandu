//
//  CLAddCareerHistoryViewController.h
//  CareerLine
//
//  Created by RENJITH on 22/07/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSimpleTextCell.h"
#import "CLSimpleTappableTextCell.h"
#import "CLSelectLocationViewController.h"
#import "CLSelectCompanyNameViewController.h"
#import "CLTextCheckBoxCell.h"
#import "CLCareerHistoryObject.h"
#import "CLCareerMoveReasonViewController.h"
#import "CLSelectFunctionViewController.h"
#import "CLSelectFunctionCategoryViewController.h"
#import "CLSelectJobLevelGroupViewController.h"
#import "CLTappableTextViewCell.h"
#import "HTProgressHUD.h"
#import "HTProgressHUDFadeZoomAnimation.h"
#import "CLProfilePhotoListingGridCell.h"
#import "CLEmployeementTypeDetailsViewController.h"
#import "CLWorkAchievementViewController.h"
#import "CLKeyJobFactsViewController.h"
#import "CLSalaryBenefitsViewController.h"
#import "CLJobScopeViewController.h"
#import "CLBusinessDivViewController.h"
#import "CLIndustrySectorViewController.h"

@class CLAddCareerHistoryViewController;
 
@protocol CLAddCareerDelegate <NSObject>

@optional
-(void)addWorkHistory:(CLAddCareerHistoryViewController *)controller didAddWorkHistory:(CLCareerHistoryObject *)careerHistoryObj;

@end

@interface CLAddCareerHistoryViewController : UITableViewController<CLSimpleTextCellDelegate,CLTappableCellDelegate,CLSelectLocationDelegate,CLSelectCompanyNameDelegate,CLTextCheckBoxCellDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UIAlertViewDelegate,CLCareerMoveReasonDelegate,CLEditJobFunctionDelegate,CLAddJobFunctionDelegate,CLSelectJobLevelDelegate,HTProgressHUDDelegate,CLProfilePhotoListingGridCellDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,CLSelectEmpTypeDelegate,CLWorkAchievementControllerDelegate,CLHeightAdjustTextCellDelegate,CLKeyJobFactsControllerDelegate,CLSalaryBeneftsDelegate,jobScopeDelegate,JobScopeSelectionDelegate,CLBusinessDivDelegate,CLSelectIndustryDelegate,CLEditIndustryDelegate,CLSelectOtherIndustryGroup,CLTextCheckBoxCellDelegate>

@property (nonatomic, weak) id <CLAddCareerDelegate> delegate;
@property (nonatomic, assign)BOOL isEditMode;
@property (nonatomic, retain) CLCareerHistoryObject *carrerHisObj;
@end
