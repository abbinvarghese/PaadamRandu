//
//  CLKnowledgeDetailsPage.h
//  CareerLine
//
//  Created by Abbin on 20/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLKnowledgeDetailsPage : UIViewController<UIScrollViewDelegate>

@property(nonatomic,retain) NSString *knowledgeRecId;
@property(nonatomic,retain) NSString *ktype;

@end
