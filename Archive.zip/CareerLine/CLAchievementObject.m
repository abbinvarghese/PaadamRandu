//
//  CLAchievements.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLAchievementObject.h"
#import "NSDictionary+Additions.h"
#import "NSDate+Utilities.h"
#import "AFHTTPRequestOperationManager.h"

#define kDebugMessages 0

@implementation CLAchievementObject

static NSOperationQueue *saveAchievementRequest;
static NSOperationQueue *deleteAchievementRequest;
static NSOperationQueue *deleteAchievementDocRequest;
static NSOperationQueue *uploadAchDocumentRequest;


- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    
    self.achievementId=[dictionary objectForKeyNotNull:kCLProfileAboutMeAchievementIdkey];
    self.achievementTitle=[dictionary objectForKeyNotNull:kCLProfileAboutMeAchievementTitlekey];
    //self.achievementDate=[CLCommon getDateForString:[dictionary objectForKeyNotNull:kCLProfileAboutMeAchievementDatekey] andFormat:@"dd-MM-yyyy"];
    //self.achievementDate=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    
    self.achievementDate=[NSDate getDateForDay:[dictionary objectForKeyNotNull:kCLProfileDaykey] month:[dictionary objectForKeyNotNull:kCLProfileMonthkey] year:[dictionary objectForKeyNotNull:kCLProfileYearkey]];
    if ([dictionary objectForKeyNotNull:kCLProfileDaykey] && ![[dictionary objectForKeyNotNull:kCLProfileDaykey] isEqualToString:@""]) {
        self.formattedDateString=[CLCommon getStringForDate:self.achievementDate andLocalFormat:@"MMMMdy"];
    }
    else{
        self.formattedDateString=[CLCommon getStringForDate:self.achievementDate andLocalFormat:@"MMMMy"];
    }
    
    self.achievementDescription=[dictionary objectForKeyNotNull:kCLProfileAboutMeAchievementDescriptionkey];
    
    self.achievementDocs=[[NSMutableArray alloc] init];
    NSMutableArray *fileUrls=[dictionary objectForKeyNotNull:kCLProfileAboutMeAchievementFilesArraykey];
    for (int i=0; i<[fileUrls count]; i++) {
        [self.achievementDocs addObject:[[CLFileObject alloc] initWithDictionary:[fileUrls objectAtIndex:i]]];
    }
    
    return self;
}

-(void)updateDate:(NSDate*)date{
    self.achievementDate=date;
    self.formattedDateString=[CLCommon getStringForDate:self.achievementDate andLocalFormat:@"MMMMdy"];
}

+ (void)savePersonalAchievement:(NSString*)achievementId forUser:(NSString*)userId title:(NSString*)title date:(NSString *)date remarks:(NSString*)remarks editMode:(BOOL)isEditMode success:(void (^)(NSString *mediaId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *achievementId){};
    }
    
    NSDictionary *parameters =nil;
    if (isEditMode) {
        parameters = @{@"user": userId, @"pa_id": achievementId, @"title":title, @"date":date, @"remarks":remarks};
    }
    else{
        parameters = @{@"user": userId, @"title":title, @"date":date, @"remarks":remarks};
    }
    
    if (kDebugMessages) {
        NSLog(@"saveAchievement Params JSON: %@", parameters);
    }
    
    [saveAchievementRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveAchievementRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeSaveAchievementURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"save achievement JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAboutMeSaveAchievementIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

+ (void)deletePersonalAchievement:(NSString*)achievementId forUser:(NSString*)userId success:(void (^)(NSString *achievementId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *achievementId){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"pa_id": achievementId};
    
    [deleteAchievementRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteAchievementRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeDeleteAchievementURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete achievement JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLProfileAboutMeDeleteAchievementIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading achievement document for a particular user...
+ (void)addDocument:(UIImage*)image forAchievement:(NSString*)achId andUser:(NSString *)userId andCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"pa_id": achId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadAchDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadAchDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeSaveAchievementDocURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"ClDocs" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@" achievement document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for deleting work achievement document for a particular user...
+ (void)deleteDocument:(NSString*)documentId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": documentId};
    
    [deleteAchievementDocRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteAchievementDocRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
    
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL,kCLWebServiceProfileAboutMeDeleteAchievementDocURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete  achievement document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
