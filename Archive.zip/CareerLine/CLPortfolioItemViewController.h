//
//  CLPortfolioItemViewController.h
//  CareerLine
//
//  Created by Pravin on 10/7/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLProfilePhotoListingGridCell.h"
#import "CLItemObject.h"
#import "CLSimpleTextCell.h"
#import "HTProgressHUD.h"
#import "CLHeightAdjustTextCell.h"

@class CLPortfolioItemViewController;

//Delegate Methods...
@protocol CLItemsControllerDelegate <NSObject>

@optional
- (void)itemsController:(CLPortfolioItemViewController *)controller didAddItem:(CLItemObject*)itemObj;

@end

@interface CLPortfolioItemViewController : UITableViewController<CLSimpleTextCellDelegate,HTProgressHUDDelegate,
CLProfilePhotoListingGridCellDelegate
,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLHeightAdjustTextCellDelegate>

@property(nonatomic,weak) id <CLItemsControllerDelegate> delegate;
@property(nonatomic,strong)CLItemObject *itemObj;
@property(nonatomic,assign)BOOL isEditMode;

@end
