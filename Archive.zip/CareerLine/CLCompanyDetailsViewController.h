//
//  CLCompanyDetailsViewController.h
//  CareerLine
//
//  Created by CSG on 6/30/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLCompanyObject.h"

@interface CLCompanyDetailsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

//Company details object...
@property(nonatomic,strong)CLCompanyObject *company;
@end
