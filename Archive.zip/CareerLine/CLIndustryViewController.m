//
//  CLIndustryViewController.m
//  CareerLine
//
//  Created by RENJITH on 22/11/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLIndustryViewController.h"
#import "CLCoreDataHelper.h"

#define kIndustryOtherText NSLocalizedString(@"Other",@"Other text title")

@interface CLIndustryViewController ()

@property (nonatomic,strong) NSMutableArray *indusrtyArray;
@property(nonatomic,strong) NSString *blackListString;
@property(nonatomic,strong) NSString *selectedTitle;
@property (nonatomic ,strong) NSMutableDictionary *otherDict;
@property (nonatomic,strong) NSMutableArray *selectedIndusrtyArray;
@end

@implementation CLIndustryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.title=[self.selectedIndustryDict objectForKey:kIndustryGrpDictName];
    
    self.selectedGroupCode = [self.selectedIndustryDict objectForKey:kIndustryGrpDictCode];
    
    _selectedTitle = @"Done";
    
    self.selectedIndusrtyArray = [[NSMutableArray alloc]init];
    
    if(self.singleSelection == NO)
    {
        if ([self.selectedindustries count]>0)
        {
            NSMutableString *string=[[NSMutableString alloc] init];
            
            for (NSMutableDictionary *dict in self.selectedindustries)
            {
                if ([[dict objectForKey:kCLTargetJobsNewindustry] count])
                {
                    NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsNewindustry] mutableCopy];
                    
                    for (NSMutableDictionary *dict in result)
                    {
                        NSString *grpCode =  [dict objectForKey:kIndustryGrpDictCode];
                        
                        if([self.selectedGroupCode isEqualToString:grpCode])
                        {
                            _selectedTitle = @"Done";
                            self.indusrtyArray= [[NSMutableArray alloc]init];
                            break;
                        }
                        
                    }

                }
                
                if(self.indusrtyArray == nil)
                {
                    if ([[dict objectForKey:kCLTargetJobsMainindustry] count])
                    {
                        NSMutableArray *result = [[dict valueForKeyPath:kCLTargetJobsMainindustry]mutableCopy];
                        
                        for (NSMutableDictionary *dict in result)
                        {
                            NSString *grpCode =  [dict objectForKey:kIndustryGrpDictCode];
                            
                            if([self.selectedGroupCode isEqualToString:grpCode])
                            //if ([[dict objectForKey:kIndustryDictName] isEqualToString:@""] && ![[dict objectForKey:kIndGrpOtherFlag] boolValue])
                            {
                                [string appendString:[NSString stringWithFormat:@"%@,",[dict objectForKey:kIndustryDictCode]]];
                                //break;
                            }
                        }
                        
                        if(string.length)
                        {
                            [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
                            self.blackListString=string;
                            _selectedTitle = @"Done";
                        }
                    }
                }
            }
        }
        else
        {
//            _selectedTitle = @"Select All";
//             self.indusrtyArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getMainIndustriesListForGroup:self.selectedIndustryDict notIn:self.blackListString];
        }
        
        
        
        if(self.indusrtyArray == nil)
        {
            if(self.blackListString.length || [self isAllSectSelected])
                _selectedTitle = @"Done";
            else
                _selectedTitle = @"Select All";
            
            if ([self isAllSectSelected]) {
                self.indusrtyArray = [[NSMutableArray alloc]init];
            }
            else{
                self.indusrtyArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getMainIndustriesListForGroup:self.selectedIndustryDict notIn:self.blackListString];
            }
            
        }

    }
    else
    {
        if ([self.selectedindustries count]>0)
        {
            NSMutableString *string=[[NSMutableString alloc] init];
            for (int i=0; i<[self.selectedindustries count]; i++)
            {
                [string appendString:[NSString stringWithFormat:@"%@,",[[self.selectedindustries objectAtIndex:i] objectForKey:kIndustryDictCode]]];
            }
            [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
            self.blackListString=string;
        }
        
         self.indusrtyArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getMainIndustriesListForGroup:self.selectedIndustryDict notIn:self.blackListString];
    }
    
    if ([self doWeNeedOtherDict]) {
        self.otherDict = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[self.selectedIndustryDict objectForKey:kIndustryGrpDictCode],kIndustryGrpDictCode,@"0",kIndustryDictCode,[NSString stringWithFormat:@"%@ - %@",kIndustryOtherText,[self.selectedIndustryDict objectForKey:kIndustryGrpDictName]],kIndustryDictName,@"1",kIndOtherFlag, nil];
    }
    
    
    
    if (!self.singleSelection && self.otherDict)
    {
        [self.indusrtyArray addObject:self.otherDict];
    }
    
    [self rightNavigationButton];
}

-(BOOL)isAllSectSelected{
    if (self.selectedindustries.count>0) {
        for (NSMutableDictionary *dict in [[self.selectedindustries objectAtIndex:0]objectForKey:@"IndSect"]) {
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"industrySectCode"]] isEqualToString:[NSString stringWithFormat:@"%@",[self.selectedIndustryDict objectForKey:@"industrySectCode"]]]) {
                return YES;
            }
        }
    }
    return NO;
}

-(BOOL)doWeNeedOtherDict{
    if (self.selectedindustries.count > 0) {
        if ([[self.selectedindustries objectAtIndex:0]objectForKey:@"OtherIndustry"]) {
            for (NSMutableDictionary *dict in [[self.selectedindustries objectAtIndex:0]objectForKey:@"OtherIndustry"]) {
                if ([[dict objectForKey:@"industryGroupCode"] isEqualToString:self.selectedGroupCode] && [[NSString stringWithFormat:@"%@",[dict objectForKey:@"industryOther"]] isEqualToString:@"1"]) {
                    return NO;
                }
            }
        }
        else if ([[self.selectedindustries objectAtIndex:0]objectForKey:@"Industry"]){
            for (NSMutableDictionary *dict in [[self.selectedindustries objectAtIndex:0]objectForKey:@"Industry"]) {
                if ([[dict objectForKey:@"industryGroupCode"] isEqualToString:self.selectedGroupCode] && [[NSString stringWithFormat:@"%@",[dict objectForKey:@"industryOther"]] isEqualToString:@"1"]) {
                    return NO;
                }
            }
        }
        
        
    }
    return YES;
}

#pragma mark Utility Methods

-(void)rightNavigationButton
{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(_selectedTitle, @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

//-(void)setRightNavigationButton{
//    
//    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
//    self.navigationItem.rightBarButtonItem=rightNavBttn;
//}

-(NSMutableArray*)addIndustryGroupNameto:(NSMutableArray*)array
{
    for (NSMutableDictionary *dict in array)
    {
        NSString *industryGroupCode = [dict objectForKey:kCLTargetJobsIndustryGroupCode];
        NSString *groupName = [[CLCoreDataHelper sharedCLCoreDataHelper] getIndustryGroupNamefrom:industryGroupCode];
        [dict setValue:groupName forKey:kCLTargetJobsindustryGroupNameKey];
    }
    return array;
}

#pragma mark IBaction
-(void)bttnActionSelectionDone:(id)sender
{
    if([_selectedTitle isEqualToString:@"Select All"])// || _isAllSelected == YES
    {
        if (self.selectedIndusrtyArray.count <= 0)
        {
            NSInteger count = [self.indusrtyArray count] - 1;
            NSArray *tempArray = [self.indusrtyArray subarrayWithRange:NSMakeRange(0, count)];
            [self.selectedIndusrtyArray addObjectsFromArray:tempArray];
            [self addIndustryGroupNameto:self.selectedIndusrtyArray];
            
             NSMutableArray *industryArray = [self.selectedindustries mutableCopy];
            
            for(NSMutableDictionary *arrDict in [self.selectedIndusrtyArray mutableCopy])
            {
                if([industryArray count])
                {
                    for(NSMutableDictionary *maindict in self.selectedindustries)
                    {
                        NSMutableArray *result = [[maindict valueForKeyPath:kCLTargetJobsNewindustry]mutableCopy];
                        
                        if([result count])
                        {
//                            NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [arrDict objectForKey:@"industryGroupCode"], @"industryGroupCode", [arrDict objectForKey:@"industryGroupName"], @"industryGroupName", nil];

                            [result addObject:arrDict];
                            
                            NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                           // newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            [newDict1 setValue:result forKey:kCLTargetJobsNewindustry];
                            [industryArray removeAllObjects];
                            [industryArray addObject:newDict1];
//
//                            
//                            NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
//                            [newDict setValue:result forKey:kCLTargetJobsNewindustry];
//                            [industryArray removeAllObjects];
//                            [industryArray addObject:newDict];
                        }
                        else
                        {
//                            NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [arrDict  objectForKey:@"industryGroupCode"], @"industryGroupCode", [arrDict objectForKey:@"industryGroupName"], @"industryGroupName", nil];
                            
                            NSMutableArray *result = [[NSMutableArray alloc]init];
                            [result addObject:arrDict];
                            
//                            NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
//                            [newDict setValue:result forKey:kCLTargetJobsNewindustry];
                            
                            NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            //newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                            [newDict1 setValue:result forKey:kCLTargetJobsNewindustry];
                            
                            [industryArray removeAllObjects];
                            [industryArray addObject:newDict1];

                        }
                    }
                }
                else
                {
//                    NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: [arrDict  objectForKey:@"industryGroupCode"], @"industryGroupCode", [arrDict objectForKey:@"industryGroupName"], @"industryGroupName", nil];
                    
                    NSMutableArray *result = [[NSMutableArray alloc]init];
                    [result addObject:arrDict];
                    
                    NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
                    [newDict setValue:result forKey:kCLTargetJobsNewindustry];
                    [industryArray removeAllObjects];
                    [industryArray addObject:newDict];

                }
                
//                [self.selectedindustries removeAllObjects];
//                self.selectedindustries = [industryArray mutableCopy];
            }
            [self.selectedindustries removeAllObjects];
            self.selectedindustries = [industryArray mutableCopy];
            
            [self.tableView setEditing:NO animated:NO];
            [self dismissViewControllerAnimated:YES completion:^(void){
                
                if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectIndustryControllerDidSelectIndustry:withArray: andListArray:)]){
                    [self addIndustryGroupNameto:self.selectedIndusrtyArray];
                    
                    //NSString *newTitle = [self.selectedIndustryDict objectForKey:kIndustryGrpDictName];
                    
                    [self.delegate selectIndustryControllerDidSelectIndustry:self withArray:self.selectedIndusrtyArray andListArray:self.selectedindustries];
                }
            }];
        }
        else if (self.selectedIndusrtyArray.count > 0)
        {
            [self.tableView setEditing:NO animated:NO];
            [self dismissViewControllerAnimated:YES completion:^(void){
                
                if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectIndustryControllerDidSelectIndustry:withArray:andListArray:)]){
                    [self addIndustryGroupNameto:self.selectedIndusrtyArray];
                    [self.delegate selectIndustryControllerDidSelectIndustry:self withArray:self.selectedIndusrtyArray andListArray:self.selectedindustries];
                }
            }];
        }
        else{
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select an Industry", @"alert message") cancelbuttonName:NSLocalizedString(@"OK", @"ok button string")];
        }

    }
    else
    {
        if (self.selectedIndusrtyArray.count >0)
        {
            [self.tableView setEditing:NO animated:NO];
            [self dismissViewControllerAnimated:YES completion:^(void){
                
            [self addIndustryGroupNameto:self.selectedIndusrtyArray];
                
            NSMutableArray *industryArray = [self.selectedindustries mutableCopy];
                
            for(NSMutableDictionary *arrDict in [self.selectedIndusrtyArray mutableCopy])
            {
                NSInteger isOther = [[arrDict objectForKey:@"industryOther"]integerValue];
                
                if(isOther == 1)
                {
                    if([industryArray count])
                    {
                        for(NSMutableDictionary *thedict in self.selectedindustries)
                        {
                            NSMutableArray *result = [[thedict valueForKeyPath:@"OtherIndustry"]mutableCopy];
                            
                            if([result count])
                            {
                                [result addObject:arrDict];
                                
                                NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                //newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict1 setValue:result forKey:@"OtherIndustry"];
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict1];
                            
//                                NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
//                                [newDict setValue:result forKey:@"OtherIndustry"];
//                                [industryArray removeAllObjects];
//                                [industryArray addObject:newDict];
                            }
                            else
                            {
                                NSMutableArray *result = [[NSMutableArray alloc]init];
                                [result addObject:arrDict];
                                
                                NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                               // newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict1 setValue:result forKey:@"OtherIndustry"];
                                
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict1];

                                
//                                 NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
//                                [newDict setValue:result forKey:@"OtherIndustry"];
                                //[industryArray removeAllObjects];
                               //  [industryArray addObject:newDict];
                            }
                        }
                    }
                    else
                    {
                        NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
                        [newDict setValue:self.selectedIndusrtyArray forKey:@"OtherIndustry"];
                        [industryArray removeAllObjects];
                        [industryArray addObject:newDict];
                    }
                    
                    [self.selectedindustries removeAllObjects];
                    self.selectedindustries = [industryArray mutableCopy];
                }
                else
                {
                    if([industryArray count])
                    {
                        for(NSMutableDictionary *thedict in self.selectedindustries)
                        {
                            NSMutableArray *result = [[thedict valueForKeyPath:kCLTargetJobsMainindustry]mutableCopy];
                            
                            if([result count])
                            {
//                                NSString *indSectCode = [arrDict objectForKey:@"indsectcode"];
//                                NSString *indName = [NSString stringWithFormat:@"%@(%@)",[arrDict objectForKey:@"industryGroupName"], [arrDict objectForKey:@"industry"]];
//                                
//                                NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: indName, @"industry", [arrDict objectForKey:@"industryCode"], @"industryCode", [arrDict objectForKey:@"industryGroupCode"], @"industryGroupCode", indSectCode, @"industrySectCode", nil];
                                
                                [result addObject:arrDict];
                                
                                NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                //newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict1 setValue:result forKey:kCLTargetJobsMainindustry];
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict1];
                                
//                                NSMutableDictionary *newDict = [[industryArray objectAtIndex:0]mutableCopy];
//                                [newDict setValue:result forKey:kCLTargetJobsMainindustry];
//                                [industryArray removeAllObjects];
//                                [industryArray addObject:newDict];
                            }
                            else
                            {
                                NSMutableArray *result = [[NSMutableArray alloc]init];
//                                NSString *indSectCode = [arrDict objectForKey:@"indsectcode"];
//                                NSString *indName = [NSString stringWithFormat:@"%@(%@)",[arrDict objectForKey:@"industryGroupName"], [arrDict objectForKey:@"industry"]];
//                                
//                                NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: indName, @"industry", [arrDict objectForKey:@"industryCode"], @"industryCode", [arrDict objectForKey:@"industryGroupCode"], @"industryGroupCode", indSectCode, @"industrySectCode", nil];
                                
                                [result addObject:arrDict];
                                
                                NSMutableDictionary *newDict1 = [[industryArray objectAtIndex:0]mutableCopy];
                                [newDict1 setValue:result forKey:kCLTargetJobsMainindustry];
                                
                                [industryArray removeAllObjects];
                                [industryArray addObject:newDict1];

                                
//                                 NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
//                                [newDict setValue:result forKey:kCLTargetJobsMainindustry];
                                //[industryArray removeAllObjects];
                               //  [industryArray addObject:newDict];
                            }
                        }
                    }
                    else
                    {
                        NSMutableArray *result = [[NSMutableArray alloc]init];

//                        NSString *indSectCode = [arrDict objectForKey:@"indsectcode"];
//                        NSString *indName = [NSString stringWithFormat:@"%@(%@)",[arrDict objectForKey:@"industryGroupName"], [arrDict objectForKey:@"industry"]];
//                        
//                        NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: indName, @"industry", [arrDict objectForKey:@"industryCode"], @"industryCode", [arrDict objectForKey:@"industryGroupCode"], @"industryGroupCode", indSectCode, @"industrySectCode", nil];
                        
                        [result addObject:arrDict];
                        
                        
                        NSMutableDictionary *newDict = [[NSMutableDictionary alloc]init];
                        [newDict setValue:result forKey:kCLTargetJobsMainindustry];
                        [industryArray removeAllObjects];
                        [industryArray addObject:newDict];
                    }
                }
                
                [self.selectedindustries removeAllObjects];
                self.selectedindustries = [industryArray mutableCopy];
            }
            
//            [self.selectedindustries removeAllObjects];
//            self.selectedindustries = [industryArray mutableCopy];

            if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectIndustryControllerDidSelectIndustry:withArray: andListArray:)]){
                //[self addIndustryGroupNameto:self.selectedIndusrtyArray];
                [self.delegate selectIndustryControllerDidSelectIndustry:self withArray:self.selectedIndusrtyArray andListArray:self.selectedindustries];
            }
            }];
        }
        else{
            [CLCommon showAlertwithTitle:nil alertString:NSLocalizedString(@"Please Select an Industry", @"alert message") cancelbuttonName:NSLocalizedString(@"OK", @"ok button string")];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.indusrtyArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:1];
    }
    
    NSMutableDictionary *industry=[self.indusrtyArray objectAtIndex:indexPath.row];
    
    if ([self selectedDictInIndustryArray:industry])
    {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.textLabel.text=[industry objectForKey:kIndustryDictName];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([[[self.indusrtyArray objectAtIndex:indexPath.row] objectForKey:kIndOtherFlag] boolValue] && ![self selectedDictInIndustryArray:[self.indusrtyArray objectAtIndex:indexPath.row]]) {
            if([CLCommon isOSversionLessThan8])
            {
                UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];

                enterFuncAlert.tag=88;
                enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
                [enterFuncAlert show];
            }else{
                // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                               message: NSLocalizedString(@"Enter Your Other Option:", @"Enter Your Other Option")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    
                }];
                UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction * action){
                                                                     //Do Some action here
                                                                     UITextField *textField = alert.textFields[0];
                                                                     NSString *otherFuncText = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                     if (![CLCommon doesItHaveSpace:otherFuncText]) {
                                                                         
                                                                         _selectedTitle = @"Done";
                                                                         self.navigationItem.rightBarButtonItem.title = @"        Done";
                                                                         
                                                                         [self.otherDict removeObjectForKey:kIndustryDictName];
                                                                         [self.otherDict removeObjectForKey:kIndOtherFlag];
                                                                         [self.otherDict setObject:otherFuncText forKey:kIndustryDictName];
                                                                         [self.otherDict setObject:@"1" forKey:kIndOtherFlag];
                                                                         [self.selectedIndusrtyArray addObject:self.otherDict];
                                                                         [self.tableView reloadData];

                                                                     }
                                                                     else{
                                                                         [textField resignFirstResponder];
                                                                     }
                                                                     
                                                                     
                                                                     
                                                                 }];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                       style: UIAlertActionStyleDefault
                                                                     handler: nil];
                
                [alert addAction: cancelAction];
                [alert addAction: okAction];
                [self presentViewController:alert animated:YES completion:nil];
            }
            
        }else{
            if (self.singleSelection) {
                
                [self dismissViewControllerAnimated:YES completion:^(void){
                    
                    if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectIndustryControllerDidSelectIndustry:withArray: andListArray:)]){
                        [self.selectedIndusrtyArray addObject:[self.indusrtyArray objectAtIndex:indexPath.row]];
                        [self addIndustryGroupNameto:self.selectedIndusrtyArray];
                        [self.delegate selectIndustryControllerDidSelectIndustry:self withArray:self.selectedIndusrtyArray andListArray:self.selectedindustries];
                    }
                }];
            }
            else{
                if ([self selectedDictInIndustryArray:[self.indusrtyArray objectAtIndex:indexPath.row]]) {
                    int index = [self getCurrentArrayIndex:[self.indusrtyArray objectAtIndex:indexPath.row]];
                    [self.selectedIndusrtyArray removeObjectAtIndex:index];
                    
                    if ([[[self.indusrtyArray objectAtIndex:indexPath.row] objectForKey:kIndOtherFlag] boolValue]) {
                        
                        [self.otherDict removeObjectForKey:kIndustryDictName];
                        [self.otherDict setObject:[NSString stringWithFormat:@"%@ -%@",kIndustryOtherText,[self.selectedIndustryDict objectForKey:kIndSectDictName]] forKey:kIndustryDictName];
                    }
                }
                else
                {
                    [self.selectedIndusrtyArray addObject:[self.indusrtyArray objectAtIndex:indexPath.row]];
                }
                
                NSMutableArray *copyArr = [self.indusrtyArray mutableCopy];
                NSMutableArray *discardedItems = [NSMutableArray array];
                
                for (NSMutableDictionary *dict in self.indusrtyArray)
                {
                    if ([self.selectedIndusrtyArray containsObject:dict])
                        [discardedItems addObject:dict];
                }
                
                [copyArr removeObjectsInArray:discardedItems];
                
                if([copyArr count] == 1 && [copyArr count] != 0)
                {
                    NSMutableDictionary *dict = [copyArr objectAtIndex:0];
                    NSString *fnName = [dict objectForKey:@"industry"];
                    
                    if ([fnName rangeOfString:@"Other"].location == NSNotFound)
                    {
                        self.isAllSelected = NO;
                    } else
                    {
                        self.isAllSelected = YES;
                    }
                    
                }
                else
                {
                    if([copyArr count] == 0)
                        self.isAllSelected = YES;
                }

                
                
                
                
                if ([self.selectedIndusrtyArray count] == 0)
                    self.navigationItem.rightBarButtonItem.title = _selectedTitle = @"Select All";
                else
                {
                    _selectedTitle = @"Done";
                    self.navigationItem.rightBarButtonItem.title = @"        Done";
                }
                
                
                [self.tableView reloadData];
            }
        }
    });
}

-(int)getCurrentArrayIndex:(NSDictionary *)dict{
    
    int index = 0;
    for (int i=0;i< [self.selectedIndusrtyArray count];i++) {
        if ([[dict objectForKey:kIndOtherFlag] boolValue]) {
            if ([[[self.selectedIndusrtyArray objectAtIndex:i] objectForKey:kIndOtherFlag] isEqualToString:[dict objectForKey:kIndOtherFlag]]) {
                index = i;
                break;
            }else{
                index = i;
                
            }
        }else{
            if ([[[self.selectedIndusrtyArray objectAtIndex:i] objectForKey:kIndustryDictName] isEqualToString:[dict objectForKey:kIndustryDictName]]) {
                index = i;
                break;
            }else{
                index = i;
            }
        }
    }
    return index;
}

-(BOOL)selectedDictInIndustryArray:(NSDictionary *)dict{
    
    BOOL results = NO;
    for (NSMutableDictionary *dictFromArray in self.selectedIndusrtyArray) {
        
        if ([[dict objectForKey:kIndOtherFlag] boolValue]) {
            
            if ([[dictFromArray objectForKey:kIndOtherFlag] isEqualToString:[dict objectForKey:kIndOtherFlag]]) {
                results = YES;
                break;
            }else{
                results = NO;
            }
        }else{
            if ([[dictFromArray objectForKey:kIndustryDictName] isEqualToString:[dict objectForKey:kIndustryDictName]]) {
                results = YES;
                break;
            }else{
                results = NO;
                
            }
        }
    }
    return results;
}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //ENter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            NSString *otherFuncText = [[[alertView textFieldAtIndex:0] text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if (![CLCommon doesItHaveSpace:otherFuncText]) {
                [self.otherDict removeObjectForKey:kIndustryDictName];
                [self.otherDict removeObjectForKey:kIndOtherFlag];
                [self.otherDict setObject:@"1" forKey:kIndOtherFlag];
                [self.otherDict setObject:otherFuncText forKey:kIndustryDictName];
                [self.selectedIndusrtyArray addObject:self.otherDict];
                [self.tableView reloadData];
            }
            
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}


@end

