//
//  CLCareerHistoryObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerHistoryObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager.h"
#import "CLConstants.h"
#import <objc/runtime.h>

#define kDebugMessages 0

@implementation CLCareerHistoryObject

static NSOperationQueue *getCompanyNameForSearchStringrequest;
static NSOperationQueue *saveWorkHistoryRequest;
static NSOperationQueue *deleteWrkHistoryRequest;
static NSOperationQueue *deleteDocumentRequest;
static NSOperationQueue *uploadQDocumentRequest;

+ (void)cancelWorkHistoryPendingRequest {
    [saveWorkHistoryRequest cancelAllOperations];
    saveWorkHistoryRequest = nil;
}
+ (void)cancelGetCompanyNameRequest{
    [getCompanyNameForSearchStringrequest cancelAllOperations];
    getCompanyNameForSearchStringrequest = nil;
}

- (id)initWithDictionary:(NSDictionary*)dictionary {
    self = [super init];
    if (self == nil) return nil;
    self.durationCurrent = [[dictionary objectForKeyNotNull:kCLCareerHistoryCareerDurationCurrentkey] boolValue];
    self.selfEmployed =[[dictionary objectForKeyNotNull:@"selfEmployed"] boolValue];
    NSString *duratnFromDateStr = [dictionary objectForKeyNotNull:kCLCareerHistoryCareerDurationFromkey];
    NSString *duratnToDateStr = [dictionary objectForKeyNotNull:kCLCareerHistoryCareerDurationTokey];
    
    if (![duratnFromDateStr isEqualToString:@""]) {
        if (self.durationCurrent) {
            NSMutableString *fromDateStr = [[NSMutableString alloc]init];
            NSArray *fromDateArray = [duratnFromDateStr componentsSeparatedByString:@"-"];
            if ([[fromDateArray objectAtIndex:0] isEqualToString:@""]) {
                [fromDateStr appendString:@"01"];
                [fromDateStr appendString:@"-"];
                [fromDateStr appendString:[fromDateArray objectAtIndex:1]];
                [fromDateStr appendString:@"-"];
                [fromDateStr appendString:[fromDateArray objectAtIndex:2]];
                self.durationFrom = [CLCommon getDateForString:fromDateStr andFormat:@"dd-MM-yyyy"];
            }else{
                self.durationFrom = [CLCommon getDateForString:duratnFromDateStr andFormat:@"dd-MM-yyyy"];
            }
            
        }else{
            NSMutableString *fromDateStr = [[NSMutableString alloc]init];
            NSArray *fromDateArray = [duratnFromDateStr componentsSeparatedByString:@"-"];
            if ([[fromDateArray objectAtIndex:0] isEqualToString:@""]) {
                [fromDateStr appendString:@"01"];
                [fromDateStr appendString:@"-"];
                [fromDateStr appendString:[fromDateArray objectAtIndex:1]];
                [fromDateStr appendString:@"-"];
                [fromDateStr appendString:[fromDateArray objectAtIndex:2]];
                self.durationFrom = [CLCommon getDateForString:fromDateStr andFormat:@"dd-MM-yyyy"];
            }else{
                self.durationFrom = [CLCommon getDateForString:duratnFromDateStr andFormat:@"dd-MM-yyyy"];
            }
            
            NSMutableString *toDateStr = [[NSMutableString alloc]init];
            if (![duratnToDateStr isEqualToString:@""]) {
                NSArray *toDateArray = [duratnToDateStr componentsSeparatedByString:@"-"];
                if ([[toDateArray objectAtIndex:0] isEqualToString:@""]) {
                    [toDateStr appendString:@"01"];
                    [toDateStr appendString:@"-"];
                    [toDateStr appendString:[toDateArray objectAtIndex:1]];
                    [toDateStr appendString:@"-"];
                    [toDateStr appendString:[toDateArray objectAtIndex:2]];
                    self.durationTo = [CLCommon getDateForString:toDateStr andFormat:@"dd-MM-yyyy"];
                }else{
                    self.durationTo = [CLCommon getDateForString:duratnToDateStr andFormat:@"dd-MM-yyyy"];
                }
            }
            
        }
        
    }
    
    self.wrkHisId = [dictionary objectForKeyNotNull:kCLCareerHistoryIdkey];
    self.companyName = [dictionary objectForKeyNotNull:kCLCareerHistoryCompanyNamekey];
    if ([[self.companyName objectForKey:kCLCareerHistoryCompanyNamekey] isEqualToString:@""]) {
        self.isDesc = YES;
        self.companyDesc = [[dictionary objectForKeyNotNull:kCLCareerHistoryOtherCompanykey] objectForKeyNotNull:kCLCareerHistoryCompanyDesckey];
    }
    self.otherCompanyName = [dictionary objectForKeyNotNull:kCLCareerHistoryOtherCompanykey];
    self.jobTitle = [dictionary objectForKeyNotNull:kCLCareerHistoryJobTitlekey];
    
    self.industry = [dictionary objectForKeyNotNull:@"industry"];
    
    //keyJobFacts section
    CLCareerKeyJobFactsObject *newKeyJobFacts = [[CLCareerKeyJobFactsObject alloc]init];
    newKeyJobFacts.jobFacts = [dictionary objectForKeyNotNull:kCLCareerHistoryKeyJobFactskey];
    newKeyJobFacts.jobAccountabilities = [dictionary objectForKeyNotNull:kCLCareerHistoryJobAcntbiltskey];
    newKeyJobFacts.keyPerformance = [dictionary objectForKeyNotNull:kCLCareerHistoryJobPerformancekey];
    newKeyJobFacts.permanentReportDirect = [dictionary objectForKeyNotNull:kCLCareerHistoryPermanentDirectkey];
    newKeyJobFacts.permanentReportInDirect = [dictionary objectForKeyNotNull:kCLCareerHistoryPermanentInDirectkey];
    newKeyJobFacts.tempReportDirect = [dictionary objectForKeyNotNull:kCLCareerHistoryTempDirectkey];
    newKeyJobFacts.tempReportInDirect = [dictionary objectForKeyNotNull:kCLCareerHistoryTempInDirectkey];
    newKeyJobFacts.budgetResponsibility = [dictionary objectForKeyNotNull:kCLCareerHistoryBudgetResponsibilitykey];
    
    
    self.keyJobFacts =   newKeyJobFacts;
    self.isOtherCompany = [[dictionary objectForKeyNotNull:@"isOtherCompany"] boolValue];
    //keyJobFacts section
    CLCareerSalaryBenefitsObject *newSalBenefits = [[CLCareerSalaryBenefitsObject alloc]init];
    
    newSalBenefits.salary = [dictionary objectForKeyNotNull:kCLCareerHistorySalarykey];
    newSalBenefits.salaryBasis = [dictionary objectForKeyNotNull:kCLCareerHistorySalaryBasiskey];
    newSalBenefits.currency = [dictionary objectForKeyNotNull:kCLCareerHistorySalaryCurrencykey];
    
    newSalBenefits.allowanceObjArray = [[NSMutableArray alloc]init];
    NSMutableArray *array = [dictionary objectForKeyNotNull:kCLCareerHistoryAllowancekey];
    for (int i=0; i<[array count]; i++) {
        [newSalBenefits.allowanceObjArray addObject:[array objectAtIndex:i]];
    }
    newSalBenefits.incentiveObjArray = [[NSMutableArray alloc]init];
    NSMutableArray *incentiveArray = [dictionary objectForKeyNotNull:kCLCareerHistoryIncentivekey];
    for (int i=0; i<[incentiveArray count]; i++) {
        [newSalBenefits.incentiveObjArray addObject:[incentiveArray objectAtIndex:i]];
    }
    newSalBenefits.longTermIncentives = [dictionary objectForKeyNotNull:kCLCareerHistoryLongIncentivekey];
    newSalBenefits.longTermFrequency = [dictionary objectForKeyNotNull:kCLCareerHistoryLongFrequencykey];
    newSalBenefits.longTermGrossSal = [dictionary objectForKeyNotNull:kCLCareerHistoryLongGrossSalkey];
    newSalBenefits.longTermActualVal = [dictionary objectForKeyNotNull:kCLCareerHistoryLongActualValkey];
    newSalBenefits.longTermCurrency = [dictionary objectForKeyNotNull:kCLCareerHistoryLongCurrencykey];
    
    newSalBenefits.benefits = [[NSMutableArray alloc]init];
    NSMutableArray *benefitsArray = [dictionary objectForKeyNotNull:kCLCareerHistoryBenefitskey];
    
    for (int i=0; i<[benefitsArray count]; i++) {
        [newSalBenefits.benefits addObject:[benefitsArray objectAtIndex:i]];
    }
    
    self.salBenefitObj = newSalBenefits;
    
    //work Achievement section
    self.majorAchievements=[[NSMutableArray alloc] init];
    NSMutableArray *achievementsArray=[dictionary objectForKeyNotNull:kCLCareerHistoryMajorAchievementskey];
    for (int i=0; i<[achievementsArray count]; i++) {
        [self.majorAchievements addObject:[[CLWorkAchievementObject alloc]initWithDictionary:[achievementsArray objectAtIndex:i]]];
    }
    
    self.reasonForMove = [dictionary objectForKeyNotNull:kCLCareerHistoryReasonForMovekey];
    self.careerHisFunction = [dictionary objectForKeyNotNull:kCLCareerHistoryFunctionkey];
    self.careerAllownces = [dictionary objectForKeyNotNull:kCLCareerHistoryAllowancekey];
    self.careerIncentives = [dictionary objectForKeyNotNull:kCLCareerHistoryIncentivekey];
    self.careerProjects = [dictionary objectForKeyNotNull:kCLCareerHistoryProjectskey];
    //if (![[dictionary objectForKeyNotNull:@"businessDivision"] isEqualToString:@""]) {
       self.multBusinessDiv = [dictionary objectForKeyNotNull:kCLCareerHistoryBusinessDivisionkey];
  //  }
    self.companyDivisions = [dictionary objectForKeyNotNull:kCLCareerHistoryCompanyDivisionskey];
    self.companyDivision = [dictionary objectForKeyNotNull:kCLCareerHistoryDivisionkey];
    self.companyBusinessDivision = [dictionary objectForKeyNotNull:kCLCareerHistoryBusinessDivisionkey];
    self.jobLevel = [dictionary objectForKeyNotNull:kCLCareerHistoryJobLevelkey];
    self.jobImpact = [dictionary objectForKeyNotNull:kCLCareerHistoryJobImpactkey];
    
    
    //Reported to section
    self.reportedTo = [dictionary objectForKeyNotNull:kCLCareerHistoryReportTokey];
    self.timeSpend = [dictionary objectForKeyNotNull:kCLCareerHistoryTimeSpentkey];
    self.isJobTypePrimary = [[dictionary objectForKeyNotNull:kCLCareerHistoryJobTypekey] boolValue];
    self.jobType = [dictionary objectForKeyNotNull:kCLCareerHistoryJobTypeTxtkey];
    self.employmentType = [dictionary objectForKeyNotNull:kCLCareerHistoryEmploymentTypekey];
    self.employmentContractType = [dictionary objectForKeyNotNull:kCLCareerHistoryEmploymentContractTypekey];
    
    
    self.department = [dictionary objectForKeyNotNull:kCLCareerHistoryDepartmentkey];
    self.salaryAmount = [dictionary objectForKeyNotNull:kCLCareerHistorySalarykey];
    
    self.remarksAbtJob = [dictionary objectForKeyNotNull:kCLCareerHistoryRemarkskey];
    self.experiencesGained = [dictionary objectForKeyNotNull:kCLCareerHistoryExperiencesGainedkey];
    
    self.documents=[[NSMutableArray alloc] init];
    NSMutableArray *files=[dictionary objectForKeyNotNull:kCLCareerHistoryDocskey];
    for (int i=0; i<[files count]; i++) {
        [self.documents addObject:[[CLFileObject alloc] initWithDictionary:[files objectAtIndex:i]]];
    }
    
    self.careerCountry = [[CLLocationObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLCareerHistoryCountrykey]];
    self.careerLocation = [[CLLocationObject alloc] initWithDictionary:[dictionary objectForKeyNotNull:kCLCareerHistoryLocationkey]];
    
    return self;
}

+(void)getCompanyNameListForSearchString:(NSString*)searchText withCountry:(NSString *)countryName success:(void (^)(NSMutableArray *companyNameList))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *locationList){};
    }
    
    NSDictionary *parameters=nil;
    if (countryName) {
        parameters = @{@"str":searchText,@"cycode": countryName};
    }
    else{
        parameters = @{@"str":searchText};
    }
    
    
    [getCompanyNameForSearchStringrequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        getCompanyNameForSearchStringrequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceCompanyNameSearchURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"company list JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                NSMutableArray *companyNames=[[NSMutableArray alloc] init];
                NSArray *results=[response objectForKey:@"results"];
                for (int i=0; i<[results count]; i++) {
                    NSMutableDictionary *hobDetail=[[NSMutableDictionary alloc]initWithDictionary:[results objectAtIndex:i]];
                    if ([[hobDetail objectForKey:@"industry"] isKindOfClass:[NSString class]]) {
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                        [hobDetail setValue:dict forKey:@"industry"];
                    }
                    [companyNames addObject:hobDetail];
                }
                success(companyNames);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}
//Method for deleting Wrk history for a particular user...
+ (void)deleteWrkHistory:(NSString*)wrkHisId forUser:(NSString*)userId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"user": userId, @"id": wrkHisId};
    
    [deleteWrkHistoryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteWrkHistoryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWorkHistoryDeletekey] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete Wrk history JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}
//Method for saving work history of a particular user...
+ (void)saveWorkHistory:(CLCareerHistoryObject*)careerHisObj forUser:(NSString*)userId editMode:(BOOL)isEditMode success:(void (^)(NSString *wrkHisId))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSString *wrkHisId){};
    }
    NSDictionary *parameters =nil;
    
    if (isEditMode) {
        parameters = @{@"user": userId, @"id": careerHisObj.wrkHisId, @"fields":[CLCareerHistoryObject jsonStringForObject:careerHisObj]};
    }
    else{
        parameters = @{@"user": userId, @"fields":[CLCareerHistoryObject jsonStringForObject:careerHisObj]};
    }
    NSLog(@"%@",[CLCareerHistoryObject jsonStringForObject:careerHisObj]);
    [saveWorkHistoryRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        saveWorkHistoryRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLWebServiceCareerPostURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"saveWorkHistoryRequest JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success([response objectForKey:kCLCareerHistoryIdkey]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}
+(NSString*)jsonStringForObject:(CLCareerHistoryObject*)careerHisObj{
    
    NSMutableDictionary *careerHisDict=[[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *insideDict=[[NSMutableDictionary alloc] init];
    
    [insideDict setObject:careerHisObj.jobTitle forKey:kCLCareerHistoryJobTitlekey];
    
    if ([[careerHisObj.companyName objectForKey:kCLCareerHistoryCompanyNameIdkey] isEqualToString:@""] || [[careerHisObj.companyName objectForKey:kCLCareerHistoryCompanyNameIdkey] isEqualToString:@"0"]) {
        
        NSMutableDictionary *otherCompanyDict=[[NSMutableDictionary alloc] init];
        if ([careerHisObj.otherCompanyName objectForKeyNotNull:kCLCareerHistoryOtherCompanyIdkey] ) {
            [otherCompanyDict setObject:[careerHisObj.otherCompanyName objectForKey:kCLCareerHistoryOtherCompanyIdkey] forKey:kCLCareerHistoryOtherCompanyIdkey];
        }
        if (careerHisObj.companyDesc !=nil) {
            [otherCompanyDict setObject:careerHisObj.companyDesc forKey:kCLCareerHistoryCompanyDesckey];
        }
        [otherCompanyDict setObject:[careerHisObj.otherCompanyName objectForKey:kCLCareerHistoryCompanyNamekey] forKey:kCLCareerHistoryCompanyNamekey];
        
        if(careerHisObj.careerLocation.locationCode.length)
            [otherCompanyDict setObject:careerHisObj.careerLocation.locationCode forKey:kCLCareerHistoryOtherCompanyLockey];
        
        [otherCompanyDict setObject:careerHisObj.careerCountry.countryCode forKey:kCLCareerHistoryOtherCompanyCountrykey];
        
        if ([careerHisObj.otherCompanyName objectForKey:kCLCareerHistoryBusinessDivisionkey] !=nil) {
            [otherCompanyDict setObject:[careerHisObj.otherCompanyName objectForKey:kCLCareerHistoryBusinessDivisionkey] forKey:kCLCareerHistoryBusinessDivisionkey];
        }
        else{
            [otherCompanyDict setObject:@"" forKey:kCLCareerHistoryBusinessDivisionkey];
        }
        [insideDict setObject:otherCompanyDict forKey:kCLCareerHistoryOtherCompanykey];
    }else{
        if (careerHisObj.companyDivision !=nil) {
            [insideDict setObject:careerHisObj.companyDivision forKey:kCLCareerHistoryDivisionkey];
        }
        [insideDict setObject:careerHisObj.companyName forKey:kCLCareerHistoryCompanyNamekey];
        if (careerHisObj.companyBusinessDivision !=nil) {
            [insideDict setObject:careerHisObj.companyBusinessDivision forKey:kCLCareerHistoryBusinessDivisionkey];
        }
    }
    if (careerHisObj.multBusinessDiv !=nil) {
         [insideDict setObject:careerHisObj.multBusinessDiv forKey:kCLCareerHistoryBusinessDivisionkey];
    }
    if (careerHisObj.industry !=nil) {
        [insideDict setObject:careerHisObj.industry forKey:@"industry"];
    }
    if (![[careerHisObj.jobImpact objectForKey:kCLCareerHistoryJobImpactIdkey] isEqualToString:@""]) {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:[careerHisObj.jobImpact objectForKey:kCLCareerHistoryJobImpactIdkey] forKey:kCLCareerHistoryJobImpactIdkey];
        
        [dict setObject:[careerHisObj.jobImpact objectForKey:kCLCareerHistoryJobImpactNamekey] forKey:kCLCareerHistoryJobImpactNamekey];
        [insideDict setObject:dict forKey:kCLCareerHistoryJobImpactkey];
    }
    if (careerHisObj.careerCountry) {
//        if (![careerHisObj.careerCountry.locationName isEqualToString:@""]) {
            NSMutableDictionary *countryDict=[[NSMutableDictionary alloc] init];
        if (careerHisObj.careerCountry.locationName) {
            [countryDict setObject:careerHisObj.careerCountry.locationName forKey:kCLProfileAboutMeLocNamekey];
        }
            [countryDict setObject:careerHisObj.careerCountry.countryCode forKey:kCLQlfitnEducationLocationCountrykey];
            [insideDict setObject:countryDict forKey:kCLCareerHistoryCountrykey];
//        }
    }
    if (careerHisObj.careerLocation) {
        if (careerHisObj.careerLocation.locationCode !=nil) {
            NSMutableDictionary *locationDict=[[NSMutableDictionary alloc] init];
            [locationDict setObject:careerHisObj.careerLocation.locationCode forKey:kCLQlfitnEducationLocationCodekey];
            [locationDict setObject:careerHisObj.careerLocation.locationName forKey:kCLProfileAboutMeLocNamekey];
            [insideDict setObject:locationDict forKey:kCLCareerHistoryLocationkey];
        }
    }
    if (!careerHisObj.durationCurrent) {
        [insideDict setObject:careerHisObj.reasonForMove forKey:kCLCareerHistoryReasonForMovekey];
    }else{
         [insideDict setObject:@"" forKey:kCLCareerHistoryReasonForMovekey];
    }
    
    
    if ([careerHisObj.careerHisFunction count]>0) {
        [insideDict setObject:[self updateFuctionTextForArray:careerHisObj.careerHisFunction] forKey:kCLCareerHistoryFunctionkey];
    }
    if (![[careerHisObj.jobLevel objectForKey:kCLCareerHistoryJobLevelCodekey] isEqualToString:@""]) {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setObject:[careerHisObj.jobLevel objectForKey:kCLCareerHistoryJobLevelCodekey] forKey:kCLCareerHistoryJobLevelCodekey];
        [dict setObject:[careerHisObj.jobLevel objectForKey:kCLCareerHistoryJobLevelNamekey] forKey:kCLCareerHistoryJobLevelNamekey];
        [insideDict setObject:dict forKey:kCLCareerHistoryJobLevelkey];
    }
    
    if (careerHisObj.durationCurrent) {
        [insideDict setObject:@"1" forKey:kCLCareerHistoryCareerDurationCurrentkey];
    }else{
        [insideDict setObject:@"0" forKey:kCLCareerHistoryCareerDurationCurrentkey];
    }
    
    if (careerHisObj.selfEmployed) {
        [insideDict setObject:@"1" forKey:@"selfEmployed"];
    }
    else{
        [insideDict setObject:@"0" forKey:@"selfEmployed"];
    }
    
    if (careerHisObj.durationFrom) {
        [insideDict setObject:[CLCommon getStringForDate:careerHisObj.durationFrom andExactFormat:@"dd-MM-yyyy"] forKey:kCLCareerHistoryCareerDurationFromkey];
    }
    if (careerHisObj.durationTo && !careerHisObj.durationCurrent) {
        [insideDict setObject:[CLCommon getStringForDate:careerHisObj.durationTo andExactFormat:@"dd-MM-yyyy"] forKey:kCLCareerHistoryCareerDurationTokey];
    }else{
        [insideDict setObject:@"" forKey:kCLCareerHistoryCareerDurationTokey];
    }
    
    if (careerHisObj.isJobTypePrimary) {
        [insideDict setObject:@"1" forKey:kCLCareerHistoryJobTypekey];
        [insideDict setObject:NSLocalizedString(@"Primary", @"Primary text value") forKey:kCLCareerHistoryJobTypeTxtkey];
        
    }else{
        [insideDict setObject:@"0" forKey:kCLCareerHistoryJobTypekey];
        [insideDict setObject:NSLocalizedString(@"Secondary", @"Secondary text value") forKey:kCLCareerHistoryJobTypeTxtkey];
    }
    if (![careerHisObj.reportedTo isEqualToString:@""]) {
        [insideDict setObject:careerHisObj.reportedTo forKey:kCLCareerHistoryReportTokey];
    }
    
    if (careerHisObj.employmentType!=nil) {
        [insideDict setObject:careerHisObj.employmentType forKey:kCLCareerHistoryEmploymentTypekey];
    }
    if (careerHisObj.employmentContractType!=nil) {
        [insideDict setObject:careerHisObj.employmentContractType forKey:kCLCareerHistoryEmploymentContractTypekey];
    }
   
    [insideDict setObject:careerHisObj.timeSpend forKey:kCLCareerHistoryTimeSpentkey];
    
    //new val obj
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSMutableArray *achievementsArray=careerHisObj.majorAchievements;
    for (int i=0; i<[achievementsArray count]; i++) {
        [array addObject:[[CLWorkAchievementObject alloc]getDictFromObject:[achievementsArray objectAtIndex:i]]];
    }
    
    [insideDict setObject:array forKey:kCLCareerHistoryMajorAchievementskey];

    if (careerHisObj.salBenefitObj.salary!=nil) {
        [insideDict setObject:careerHisObj.salBenefitObj.salary forKey:kCLCareerHistorySalarykey];
    }
    if (careerHisObj.salBenefitObj.salaryBasis !=nil) {
        NSMutableDictionary *Dict = [[NSMutableDictionary alloc]initWithDictionary:careerHisObj.salBenefitObj.salaryBasis];
//        if ([Dict objectForKey:@"frequency"]) {
//            [Dict setObject:[Dict objectForKey:@"frequency"] forKey:@"salaryBasis"];
//            [Dict removeObjectForKey:@"frequency"];
//        }
        [insideDict setObject:Dict forKey:kCLCareerHistorySalaryBasiskey];
    }
    if (careerHisObj.salBenefitObj.currency !=nil) {
        [insideDict setObject:careerHisObj.salBenefitObj.currency forKey:kCLCareerHistorySalaryCurrencykey];
    }
    if ([careerHisObj.salBenefitObj.allowanceObjArray count] >0) {
        [insideDict setObject:careerHisObj.salBenefitObj.allowanceObjArray forKey:kCLCareerHistoryAllowancekey];
    }
    if ([careerHisObj.salBenefitObj.incentiveObjArray count] >0) {
        [insideDict setObject:careerHisObj.salBenefitObj.incentiveObjArray forKey:kCLCareerHistoryIncentivekey];
    }
    if (careerHisObj.salBenefitObj.longTermIncentives !=nil) {
        [insideDict setObject:careerHisObj.salBenefitObj.longTermIncentives forKey:kCLCareerHistoryLongIncentivekey];
    }
    if (careerHisObj.salBenefitObj.longTermFrequency !=nil) {
        [insideDict setObject:careerHisObj.salBenefitObj.longTermFrequency forKey:kCLCareerHistoryLongFrequencykey];
    }
    if (careerHisObj.salBenefitObj.longTermCurrency !=nil) {
        [insideDict setObject:careerHisObj.salBenefitObj.longTermCurrency forKey:kCLCareerHistoryLongCurrencyPostkey];
    }
    if (careerHisObj.salBenefitObj.longTermGrossSal !=nil) {
       [insideDict setObject:careerHisObj.salBenefitObj.longTermGrossSal forKey:kCLCareerHistoryLongGrossSalkey];
    }
    if (careerHisObj.salBenefitObj.longTermActualVal !=nil) {
     [insideDict setObject:careerHisObj.salBenefitObj.longTermActualVal forKey:kCLCareerHistoryLongActualValkey];
    }

    if (careerHisObj.salBenefitObj.benefits!=nil) {
         [insideDict setObject:careerHisObj.salBenefitObj.benefits forKey:kCLCareerHistoryBenefitskey];
    }

    if (careerHisObj.keyJobFacts.jobFacts!=nil) {
       [insideDict setObject:careerHisObj.keyJobFacts.jobFacts forKey:kCLCareerHistoryKeyJobFactskey];
    }
    if (careerHisObj.keyJobFacts.jobAccountabilities!=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.jobAccountabilities forKey:kCLCareerHistoryJobAcntbiltskey];
    }
    if (careerHisObj.keyJobFacts.keyPerformance!=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.keyPerformance forKey:kCLCareerHistoryJobPerformancekey];
    }
 
    if (careerHisObj.keyJobFacts.permanentReportDirect !=nil) {
         [insideDict setObject:careerHisObj.keyJobFacts.permanentReportDirect forKey:kCLCareerHistoryPermanentDirectkey];
    }
    if (careerHisObj.keyJobFacts.permanentReportInDirect !=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.permanentReportInDirect forKey:kCLCareerHistoryPermanentInDirectkey];
    }
    if (careerHisObj.keyJobFacts.tempReportDirect !=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.tempReportDirect forKey:kCLCareerHistoryTempDirectkey];
    }
    if (careerHisObj.keyJobFacts.tempReportInDirect !=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.tempReportInDirect forKey:kCLCareerHistoryTempInDirectkey];
    }
    if (careerHisObj.keyJobFacts.budgetResponsibility !=nil) {
        [insideDict setObject:careerHisObj.keyJobFacts.budgetResponsibility forKey:kCLCareerHistoryBudgetResponsibilitykey];
    }
  
    [insideDict setObject:careerHisObj.remarksAbtJob forKey:kCLCareerHistoryRemarkskey];
    [insideDict setObject:careerHisObj.experiencesGained forKey:kCLCareerHistoryExperiencesGainedkey];
   
    [careerHisDict setObject:insideDict forKey:kCLCareerHistorykey];
    return [CLCommon jsonStringWithPrettyPrint:NO foDict:careerHisDict];
}

+(NSMutableArray *)updateFuctionTextForArray:(NSMutableArray*)functionArray{
    NSMutableArray *selectedFunctionArray = [[NSMutableArray alloc]init];
    if([functionArray count]>0){
        
        for (int i=0; i<[functionArray count]; i++) {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
            if ([[functionArray objectAtIndex:i] objectForKeyNotNull:kcareerJobFunctionId]) {
                [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kcareerJobFunctionId] forKey:kcareerJobFunctionId];
            }
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherFlag] forKey:kCLCareerHistoryFunctionOtherFalgkey];
            if ([[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"]) {
                [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kjobFunctionOtherText] forKey:kCLCareerHistoryFunctionOtherTxtkey];
            }
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kjobFunctionCode] forKey:kCLCareerHistoryFunctionJobIdkey];
            [dict setObject:[[functionArray objectAtIndex:i] objectForKey:kjobFunctionName] forKey:kCLCareerHistoryFunctionkey];
            [selectedFunctionArray addObject:dict];
        }
    }
    return selectedFunctionArray;
}
//Add this utility method in your class.
+ (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    unsigned count;
    objc_property_t *properties = class_copyPropertyList([obj class], &count);
    
    for (int i = 0; i < count; i++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[i])];
        [dict setObject:[obj valueForKey:key] forKey:key];
    }
    
    free(properties);
    
    return [NSDictionary dictionaryWithDictionary:dict];
}
//Method for deleting qualification document for a particular user...
+ (void)deleteWorkHistoryDocument:(NSString*)documentId success:(void (^)())success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    
    NSDictionary *parameters = @{@"id": documentId};
    
    [deleteDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        deleteDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLCareerDeleteDocumentURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"delete Wh document JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method for uploading qualification document for a particular user...
+ (void)addDocument:(UIImage*)image forWorkHistory:(NSString*)docId andUser:(NSString *)userId withCaption:(NSString*)caption success:(void (^)(CLFileObject *fileObj))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLFileObject *fileObj){};
    }
    
    NSDictionary *parameters = @{@"user": userId,@"id": docId, @"file_caption": caption};
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    [uploadQDocumentRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        uploadQDocumentRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager POST:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL1,kCLCareerAddDocumentURL] parameters:parameters
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"ClWorkhistory" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
    }
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSDictionary *response=(NSDictionary *)responseObject;
                  if (kDebugMessages) {
                      NSLog(@"Work history document upload JSON: %@", response);
                  }
                  if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                      failure([response objectForKey:@"message"]);
                  }
                  else{
                      success([[CLFileObject alloc] initWithDictionary:response]);
                  }
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (kDebugMessages) {
                      NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
                  }
                  failure([CLCommon getMessageForErrorCode:error.code]);
              }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
