//
//  CLCareerMoveReasonViewController.m
//  CareerLine
//
//  Created by RENJITH on 23/09/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLCareerMoveReasonViewController.h"

#define kCellTextFontSize 12
#define kOtherTxt NSLocalizedString(@"Other","Other text title")
#define kOtherTxtId @"13"
#define kOtherFlagTrue @"1"
#define kOtherFlagFalse @"0"
#define kFoundIndex @"foundIndex"
#define kIsContained @"isContain"

@interface CLCareerMoveReasonViewController ()

@property (nonatomic ,strong) NSMutableArray *careerMoveReasonArray;
@property (nonatomic ,retain) NSMutableArray *selectedReasonsArray;
@property (nonatomic ,retain) NSMutableDictionary *otherReason;
@property (nonatomic ,retain) NSString *otherTxtFromDb;
@end

@implementation CLCareerMoveReasonViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=NSLocalizedString(@"Select Reason", @"Select Reason page title");
    self.selectedReasonsArray = [[NSMutableArray alloc]init];
    self.otherReason = [[NSMutableDictionary alloc]init];
    
    [self setRightNavigationButton];
    self.tableView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeInteractive;
    
    self.careerMoveReasonArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllCareerMoveListFromDB];
    if ([self.alreadySelectedReasons count]>0) {
        self.selectedReasonsArray = self.alreadySelectedReasons;
    }
    [self setIntialOtherTxtValuesInArray];
}

-(void)setIntialOtherTxtValuesInArray{
    
    NSString *otherTxt;
    NSString *otherFlag;
    NSString *reasonId;
    for (NSMutableDictionary *dict in self.selectedReasonsArray) {
        if ([[dict objectForKey:kreasonOtherFlag] boolValue]) {
            otherTxt =[NSString stringWithFormat:@"%@",[dict objectForKey:kreasonOtherText]];
            otherFlag = kOtherFlagTrue;
            reasonId = [dict objectForKey:kreasonForMoveDictCode];
            break;
            
        }else{
            otherTxt = @"";
            otherFlag = kOtherFlagFalse;
        }
    }
    self.otherReason = [[NSMutableDictionary alloc]init];
    if ([otherFlag boolValue]) {
        
        [self.careerMoveReasonArray removeObjectAtIndex:[self.careerMoveReasonArray count]-1];
        NSString *str = [NSString stringWithFormat:@"%@(%@)",kOtherTxt,otherTxt];
        [self.otherReason setObject:str forKey:kreasonForMoveDictName];
        [self.otherReason setObject:reasonId forKey:kreasonForMoveDictCode];
        [self.otherReason setObject:otherTxt forKey:kreasonOtherText];
        [self.otherReason setObject:otherFlag forKey:kreasonOtherFlag];
        [self.careerMoveReasonArray addObject:self.otherReason];
    }
} 

-(void)setRightNavigationButton{
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

#pragma mark - IBActions
-(void)bttnActionSelectionDone:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:^(void){
        
        if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectCareerMoveReason:withSelectedReasons:)]){
            [self.delegate selectCareerMoveReason:self withSelectedReasons:self.selectedReasonsArray];
        }
        
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.careerMoveReasonArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.textLabel.font=[UIFont systemFontOfSize:kCellTextFontSize];
        cell.textLabel.numberOfLines=0;
    }
    
    NSMutableDictionary *careerMove=[self.careerMoveReasonArray objectAtIndex:indexPath.row];
    NSMutableDictionary *resultDict =[self selectedReasonContainsDict:careerMove];
    if([[resultDict objectForKey:kIsContained] boolValue]){
        
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    cell.textLabel.text=[careerMove objectForKey:kreasonForMoveDictName];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSMutableDictionary *resultDict =[self selectedReasonContainsDict:[self.careerMoveReasonArray objectAtIndex:indexPath.row]];
    
    if([[resultDict objectForKey:kIsContained] boolValue]){
        [self.selectedReasonsArray removeObjectAtIndex:[[resultDict objectForKey:kFoundIndex] intValue]];
        
        if ([[[self.careerMoveReasonArray objectAtIndex:indexPath.row] objectForKey:kreasonOtherFlag] boolValue]) {
            self.careerMoveReasonArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllCareerMoveListFromDB];
        }
        [self.tableView reloadData];
    }
    else{
        
        if([[[self.careerMoveReasonArray objectAtIndex:indexPath.row] objectForKey:kreasonOtherFlag] boolValue]){
            self.otherTxtFromDb = [[self.careerMoveReasonArray objectAtIndex:indexPath.row] objectForKey:kreasonForMoveDictName];
            
            if([CLCommon isOSversionLessThan8])
            {
                UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle: NSLocalizedString(@"Enter Your Other Reason:", @"Enter Your Other Function") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];
                enterFuncAlert.tag=88;
                enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
                [enterFuncAlert show];
            }else{
                // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                               message: NSLocalizedString(@"Enter Your Other Reason:", @"Enter Your Other Function")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    
                }];
                UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction * action){
                                                                     //Do Some action here
                                                                     UITextField *textField = alert.textFields[0];
                                                                     NSString *otherFuncText = textField.text;
                                                                     
                                                                     if (![otherFuncText isEqualToString:@""]) {
                                                                         [self.careerMoveReasonArray removeObjectAtIndex:[self.careerMoveReasonArray count]-1];
                                                                         
                                                                         NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                                                                         NSString *str = [NSString stringWithFormat:@"%@(%@)",kOtherTxt,otherFuncText];
                                                                         [dict setObject:str forKey:kreasonForMoveDictName];
                                                                         [dict setObject:kOtherTxtId forKey:kreasonForMoveDictCode];
                                                                         [dict setObject:otherFuncText forKey:kreasonOtherText];
                                                                         [dict setObject:kOtherFlagTrue forKey:kreasonOtherFlag];
                                                                         [self.careerMoveReasonArray addObject:dict];
                                                                         [self.selectedReasonsArray addObject:dict];
                                                                         [self.tableView reloadData];
                                                                     }
                                                                 }];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                       style: UIAlertActionStyleDefault
                                                                     handler: nil];
                
                [alert addAction: cancelAction];
                [alert addAction: okAction];
                [self presentViewController:alert animated:YES completion:nil];
            }
        }else{
            
            [self.selectedReasonsArray addObject:[self.careerMoveReasonArray objectAtIndex:indexPath.row]];
        }
        [self.tableView reloadData];
    }
}

#pragma mark UIAlertView Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //ENter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            NSString *otherFuncText = [[alertView textFieldAtIndex:0] text];
            if (![otherFuncText isEqualToString:@""]) {
                [self.careerMoveReasonArray removeObjectAtIndex:[self.careerMoveReasonArray count]-1];
                
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                NSString *str = [NSString stringWithFormat:@"%@(%@)",kOtherTxt,otherFuncText];
                [dict setObject:str forKey:kreasonForMoveDictName];
                [dict setObject:kOtherTxtId forKey:kreasonForMoveDictCode];
                [dict setObject:otherFuncText forKey:kreasonOtherText];
                [dict setObject:kOtherFlagTrue forKey:kreasonOtherFlag];
                [self.careerMoveReasonArray addObject:dict];
                [self.selectedReasonsArray addObject:dict];
                [self.tableView reloadData];
            }
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}

#pragma mark - Table view delegate

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *expectedText=nil;
    NSDictionary *cellDict=nil;
    
    cellDict=[self.careerMoveReasonArray objectAtIndex:indexPath.row];
    
    expectedText=[NSString stringWithFormat:@"%@",[cellDict objectForKey:kreasonForMoveDictName]];
    
    
    CGRect expectedQuestextFrame = [expectedText boundingRectWithSize:CGSizeMake(300, FLT_MAX)
                                                              options:NSStringDrawingUsesLineFragmentOrigin
                                                           attributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                       [UIFont systemFontOfSize:kCellTextFontSize], NSFontAttributeName,
                                                                       nil]
                                                              context:nil];
    
    return MAX(44, ceil(expectedQuestextFrame.size.height)+27);
}

-(NSMutableDictionary *)selectedReasonContainsDict:(NSMutableDictionary*)cellDict{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    int index =0;
    BOOL isContains=NO;
    NSMutableDictionary *selectedDict=nil;
    for (int i=0; i<[self.selectedReasonsArray count]; i++) {
        selectedDict=[self.selectedReasonsArray objectAtIndex:i];
        
        if ([[cellDict objectForKey:kreasonOtherText] isEqualToString:[selectedDict objectForKey:kreasonOtherText]]) {
            
            index = i;
            isContains=YES;
            break;
        }else
            if([[cellDict objectForKey:kreasonForMoveDictName] isEqualToString:[selectedDict objectForKey:kreasonForMoveDictName]]){
                index = i;
                isContains=YES;
                break;
            }
    }
    [dict setObject:[NSNumber numberWithBool:isContains] forKey:kIsContained];
    [dict setObject:[NSNumber numberWithInt:index] forKey:kFoundIndex];
    return dict;
}

@end
