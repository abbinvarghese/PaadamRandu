//
//  CLKnowledgeDetailObject.m
//  CareerLine
//
//  Created by Abbin on 20/03/15.
//  Copyright (c) 2015 CSG. All rights reserved.
//

#import "CLKnowledgeDetailObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager+Timeout.h"

#define kDebugMessages 1

@implementation CLKnowledgeDetailObject

static NSOperationQueue *knowledgeDetailsRequest;

-(id)initWithDictionary:(NSDictionary*)dictionary{
    NSLog(@"%@",dictionary);
    self = [super init];
    if (self == nil) return nil;
    
    self.edition = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"Edition"];
    self.isbnTen = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"ISBN_ten"];
    self.isbnThirteen = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"ISBN_thirteen"];
    self.newsAgencyName = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"NewsAgencyName"];
    self.NewsAgencyUrl = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"NewsAgencyUrl"];
    self.PublicationDate = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"PublicationDate"];
    self.published = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"Published"];
    self.Publishedon = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"Publishedon"];
    self.SEO = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"SEO"];
    self.Validity = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"Validity"];;
    self.volume =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"Volume"];
    self.author = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"author"];
    self.authorName = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"authorName"];
    self.bodyContent = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"bodyContent"];
    self.bookmarks = [[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"bookmark"]boolValue];
    self.certification = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"certification"];
    self.company = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"company"];
    self.contact = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"contact"];
    self.country = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"country"];
    self.date = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"date"];
    self.discription = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"description"];
    self.education = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"education"];
    self.email = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"email"];
    self.fax = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"fax"];
    self.imageURL = [NSURL URLWithString:[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"imageurl"]];
    self.mainImageWidth = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"width"];
    self.mainImageHeight = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"height"];
    self.isLiked = [[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"isLike"]boolValue];
    self.knowledgeID = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"kn_id"];
    self.languages = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"languages"];
    self.likes = [NSString stringWithFormat:@"%@",[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"likes"]];
    self.location =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"location"];
    self.mediaLink =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"mediaLink"];
    self.metaTags =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"metaTags"];
    self.orgUrl =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"orgUrl"];
    self.studioTitle=[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"studioTitle"];
    self.subject=[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"subject"];
    self.summary = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"summary"];
    self.telephone = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"telephone"];
    self.theme =[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"theme"];
    self.title = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"title"];
    self.type = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"type"];
    self.url = [NSURL URLWithString:[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"url"]];
    
    
    
    
    
    self.objID = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"id"];
    self.subType = [[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"subtype"];
    
    
    
    
    
    
    
    
    if ([[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"]) {
        self.fileUrl = [[[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"] objectAtIndex:0]objectForKey:@"file_url"];
    }
    
    if (![[[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"] objectAtIndex:0]objectForKey:@"file_urlWidth"]) {
            self.secondImageWidth = [[[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"] objectAtIndex:0]objectForKey:@"file_urlWidth"];
    }
    if (![[[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"] objectAtIndex:0]objectForKey:@"file_urlHeight"]) {
        self.secondImageHeight = [[[[dictionary objectForKeyNotNull:@"Details"] objectForKeyNotNull:@"attachDoc"] objectAtIndex:0]objectForKey:@"file_urlHeight"];

    }
    return self;
}


+(void)getknowledgeDetailForUser:(NSString*)userId andKnowledgeID:(NSString*)knowledgeID type:(NSString*)type success:(void (^)(CLKnowledgeDetailObject*knowledgeDetailObj))success failure:(void (^)(NSString *error))failure{
    
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(CLKnowledgeDetailObject*knowledgeDetailObj){};
    }
    
    NSDictionary *parameter = @{@"user": userId, @"kn_id": knowledgeID,@"ktype":type};
    
    [knowledgeDetailsRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        knowledgeDetailsRequest= manager.operationQueue;
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];

        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceKnowledgeDetailsURL] parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject){
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"Knowledge detail JSON: %@", response);
            }
            
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                CLKnowledgeDetailObject *detailsObj = [[CLKnowledgeDetailObject alloc]initWithDictionary:response];
                success(detailsObj);
            }
            
        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

@end
