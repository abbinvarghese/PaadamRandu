//
//  CLKnowledgeObject.m
//  CareerLine
//
//  Created by CSG on 7/4/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLKnowledgeObject.h"
#import "NSDictionary+Additions.h"
#import "AFHTTPRequestOperationManager+Timeout.h"



#define kDebugMessages 1
@implementation CLKnowledgeObject

static NSOperationQueue *knowledgeListingRequest;
static NSOperationQueue *bookMarkKnowledgeRequest;

-(id)initWithDictionary:(NSDictionary*)dictionary{
    NSLog(@"%@",dictionary);
    self = [super init];
    if (self == nil) return nil;
    if ([[dictionary objectForKeyNotNull:@"knowledgeTitle"]isEqualToString:@"Why the evolution of creative leaders really matters (Part 1) "]) {
        
    }
    self.author=[dictionary objectForKeyNotNull:@"author"];
    self.isBookMarked = [[dictionary objectForKeyNotNull:kCLKnowledgeBookmarkKey] boolValue];
    self.companyName=[dictionary objectForKeyNotNull:@"companyName"];
    self.dateCreated=[dictionary objectForKeyNotNull:@"dateCreated"];
    self.eventDate=[dictionary objectForKeyNotNull:@"eventDate"];
    self.Id = [dictionary objectForKeyNotNull:kCLKnowledgeRecIDKey];
    self.imgUrl = [dictionary objectForKeyNotNull:kCLKnowledgeImageUrlKey];
    self.isLiked = [[dictionary objectForKeyNotNull:kCLKnowledgeLikeKey] boolValue];
    self.knowledgeId = [dictionary objectForKeyNotNull:kCLKnowledgeIdKey];
    self.likeCount = [dictionary objectForKeyNotNull:kCLKnowledgeLikeCountKey];
    self.title = [dictionary objectForKeyNotNull:kCLKnowledgeTitleKey];
    self.newsCompany=[dictionary objectForKeyNotNull:kCLKnowledgenewsCompany];
    self.publishedCreated=[dictionary objectForKeyNotNull:kCLKnowledgepublishedCreated];
    self.type = [dictionary objectForKeyNotNull:kCLKnowledgeTypeKey];
    self.volDate=[dictionary objectForKeyNotNull:@"type"];
    self.location=[dictionary objectForKeyNotNull:@"location"];
    
    self.subType = [dictionary objectForKeyNotNull:kCLKnowledgeSubTypeKey];
    self.category = [dictionary objectForKeyNotNull:kCLKnowledgeCatKey];
    self.keyWords = [dictionary objectForKeyNotNull:kCKnowledgeKeyWord];
    self.desc = [dictionary objectForKeyNotNull:kCLKnowledgeDesc];
    
    if ([[dictionary objectForKey:@"width"] isKindOfClass:[NSNumber class]]) {
        
        self.imgHeight = [dictionary objectForKeyNotNull:kCLKnowledgeImgHeightKey];
        self.imgWidth = [dictionary objectForKeyNotNull:kCLKnowledgeImgWidthKey];
        NSLog(@"%@ %@",self.imgHeight,self.imgWidth );
    }
    else{
        self.imgHeight=0;
        self.imgWidth = 0;
    }

    return self;
}

-(NSString*)formatDateFromString:(NSString*)string{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString = [dateFormatter dateFromString:string];
    NSString *stringDate = [CLCommon getStringForDate:dateFromString andLocalFormat:@"MMMMdy"];
    return stringDate;
}
+ (void)cancelknowledgeListingPendingRequests {
    [knowledgeListingRequest cancelAllOperations];
    knowledgeListingRequest = nil;
}
+ (void)cancelknowledgeBookmarkListingPendingRequests {
    [bookMarkKnowledgeRequest cancelAllOperations];
    bookMarkKnowledgeRequest = nil;
}

//To Get Knowledge List by user id
+ (void)listKnowledgeForUserId:(NSString*)userId searchString:(NSString *)str pageNumber:(int)page flagOrType:(int)selectedFilter success:(void (^)(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure{
    
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages){};
    }
    
    if (kDebugMessages) {
        NSLog(@"retreiving page:%d",page);
    }
    NSDictionary *parameters;
    if (selectedFilter == 0) {
        parameters = @{@"user": userId,@"page": [NSNumber numberWithInt:page],@"str": str};
    }
    else if (selectedFilter == 1){
        parameters=@{@"user": userId,@"page": [NSNumber numberWithInt:page],@"str": str,@"ktype":@"W"};
    }
    else if (selectedFilter == 2){
        parameters=@{@"user": userId,@"page": [NSNumber numberWithInt:page],@"str": str,@"flag":@"PR"};
    }
    else if (selectedFilter == 3){
        parameters=@{@"user": userId,@"page": [NSNumber numberWithInt:page],@"str": str,@"flag":@"BM"};
    }
    
    [knowledgeListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        knowledgeListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceGetWakeURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"list Knowledge JSON: %@", response);
            }
            
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                int currentPage=[[response objectForKeyNotNull:kCLJobListjobCurrentPagesKey] intValue];
                int totalPages=[[response objectForKeyNotNull:kCLJobListjobNoOfPagesKey] intValue];
                
                BOOL isLastPage=NO;
                (currentPage==totalPages) ? (isLastPage=YES) : (isLastPage=NO);
                NSMutableArray *knowledgeArray = [[NSMutableArray alloc]init];
                for (NSDictionary *dic in [response objectForKey:kCLWebServiceKnowledgeListKey]) {
                    
                    CLKnowledgeObject *knowledgeObj = [[CLKnowledgeObject alloc] initWithDictionary:dic];
                    [knowledgeArray addObject:knowledgeObj];
                }
                success(knowledgeArray,isLastPage,[response objectForKeyNotNull:kCLWebServiceKnowledgeListCountKey],[[response objectForKeyNotNull:kCLWebServiceKnowledgeListCurrentPageKey]integerValue], [[response objectForKeyNotNull:kCLWebServiceKnowledgeListPagesKey]integerValue]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ \nresponse string=%@ \n code=%ld \n desc=%@",operation.response,operation.responseString,(long)error.code,error.description);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//To Get bookmarked Knowledge List by user id
+ (void)listBookmarkedKnowledgeForUserId:(NSString*)userId searchString:(NSString *)str pageNumber:(int)page success:(void (^)(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages))success failure:(void (^)(NSString *error))failure{
    
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(NSMutableArray *knowledgeList,BOOL isLastPageReached, NSString *knowledgeCount,NSInteger currentPage, NSInteger pages){};
    }
    
    if (kDebugMessages) {
        NSLog(@"retreiving page:%d",page);
    }
    
    NSDictionary *parameters = @{@"user": userId,@"page": [NSNumber numberWithInt:page],@"str": str};
    
    [knowledgeListingRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        knowledgeListingRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceKnowledgeBookmarkListURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            NSLog(@"%@",response);
            if (kDebugMessages) {
                NSLog(@"list bookmarkeds Knowledge JSON: %@", response);
            }
            
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                int currentPage=[[response objectForKeyNotNull:kCLJobListjobCurrentPagesKey] intValue];
                int totalPages=[[response objectForKeyNotNull:kCLJobListjobNoOfPagesKey] intValue];
                
                BOOL isLastPage=NO;
                (currentPage==totalPages) ? (isLastPage=YES) : (isLastPage=NO);
                NSMutableArray *knowledgeArray = [[NSMutableArray alloc]init];
                for (NSDictionary *dic in [response objectForKey:kCLWebServiceKnowledgeListKey]) {
                    
                    CLKnowledgeObject *knowledgeObj = [[CLKnowledgeObject alloc] initWithDictionary:dic];
                    [knowledgeArray addObject:knowledgeObj];
                }
                success(knowledgeArray,isLastPage,[response objectForKeyNotNull:kCLWebServiceKnowledgeListCountKey],[[response objectForKeyNotNull:kCLWebServiceKnowledgeListCurrentPageKey]integerValue], [[response objectForKeyNotNull:kCLWebServiceKnowledgeListPagesKey]integerValue]);
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ \nresponse string=%@ \n code=%ld \n desc=%@",operation.response,operation.responseString,(long)error.code,error.description);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method used to Bookmark knowledge...
+ (void)bookMarkKnowledgeforUser:(NSString*)knowledgeRecId type:(NSString*)type success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"kn_id": knowledgeRecId,@"type":type,@"user":[CLUserObject currentUser].userID};
    
    [bookMarkKnowledgeRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        bookMarkKnowledgeRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceKnowledgeBookmarkURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"BookMark JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}

//Method used to Like knowledge...
+ (void)likeKnowledge:(NSString*)knowledgeId forUser:(NSString *)userId type:(NSString*)kType success:(void (^)(void))success failure:(void (^)(NSString *error))failure{
    // calling a nil block will crash, so convert it to an empty block, which is safe to call, but does nothing
    if (failure == nil) {
        failure = ^(NSString *error){};
    }
    if (success == nil) {
        success = ^(){};
    }
    NSDictionary *parameters = @{@"kn_id": knowledgeId, @"user":userId,@"type":kType};
    
    [bookMarkKnowledgeRequest cancelAllOperations];
    
    if([CLCommon isNetworkConnected])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        bookMarkKnowledgeRequest=manager.operationQueue;
        manager.responseSerializer=[AFJSONResponseSerializer serializer];
        
        [CLCommon initialiseHeaderForWeb:manager.requestSerializer];
        
        [manager GET:[NSString stringWithFormat:@"%@%@",kCLWebServiceBaseURL2,kCLWebServiceKnowledgeLikeURL] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSDictionary *response=(NSDictionary *)responseObject;
            if (kDebugMessages) {
                NSLog(@"resend reg mail JSON: %@", response);
            }
            if([[response objectForKey:@"ACK"] isEqualToString:@"failure"]){
                failure([response objectForKey:@"message"]);
            }
            else{
                success();
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            if (kDebugMessages) {
                NSLog(@"response=%@ response string=%@",operation.response,operation.responseString);
            }
            failure([CLCommon getMessageForErrorCode:error.code]);
        }];
    }
    else
    {
        failure([CLCommon getMessageForErrorCode:-1004]);
        //[CLCommon showAlertwithTitle:NSLocalizedString(@"Error", @"error") alertString:kNetworkNotReachableErr cancelbuttonName:NSLocalizedString(@"OK", @"ok")];
    }
}


@end
