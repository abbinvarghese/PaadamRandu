//
//  CLCollectionProfileAddDetailCell.h
//  CareerLine
//
//  Created by CSG on 7/9/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLCollectionProfileAddDetailCell : UICollectionViewCell


@end
