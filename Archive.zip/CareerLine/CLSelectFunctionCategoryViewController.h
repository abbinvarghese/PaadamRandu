//
//  CLSelectFunctionCategoryViewController.h
//  CareerLine
//
//  Created by Pravin on 9/19/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLSelectFunctionViewController.h"

@class CLSelectFunctionCategoryViewController;

//Delegate Methods...
@protocol CLEditJobFunctionDelegate <NSObject>

@optional
- (void)selectJobFunctionControllerDidDeleteJobFunction:(CLSelectFunctionCategoryViewController*)controller withArray:(NSMutableArray *)jobFunctionArray;
- (void)selectJobFunctionControllerDidDeleteJobFunction:(CLSelectFunctionCategoryViewController*)controller withArray:(NSMutableArray *)jobFunctionArray andDict:(NSMutableDictionary*)dict;

@optional
-(void)selectJobFunctionControllerDidSelectJobFromCatogory:(CLSelectFunctionCategoryViewController*)controller withArray:(NSMutableArray*)jobFunctionArray andSelectAllInfo:(NSMutableDictionary*)dict;

@end

@interface CLSelectFunctionCategoryViewController : UITableViewController

@property(nonatomic,weak) id <CLEditJobFunctionDelegate> delegate;
@property(nonatomic,strong)NSMutableArray *alreadySelectedFunctions;
@property(nonatomic,retain) NSMutableDictionary *selectedFunctionDict;
@property(nonatomic)BOOL enableSelectOption;

@end
