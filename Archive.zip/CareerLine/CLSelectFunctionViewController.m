//
//  CLSelectFunctionViewController.m
//  CareerLine
//
//  Created by CSG on 2/17/14.
//  Copyright (c) 2014 CSG. All rights reserved.
//

#import "CLSelectFunctionViewController.h"

#define kSectionHeaderFont [UIFont systemFontOfSize:12]

@interface CLSelectFunctionViewController ()

@property(nonatomic,strong)NSMutableArray *jobFunctionArray;
@property(nonatomic,strong)NSMutableArray *selectedJobFunctionArray;
@property(nonatomic,strong)NSMutableDictionary *otherJobFunction;
@property(nonatomic,strong)NSString *blackListString;
@property(nonatomic)BOOL selectAll;
@property(nonatomic)BOOL isAllSelected;
@property(nonatomic)BOOL isOtherSelected;
@end

@implementation CLSelectFunctionViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=NSLocalizedString(@"Select Functions", @"Title for select function page");
    
    
    self.selectedJobFunctionArray=[[NSMutableArray alloc] init];
    
    if ([self.alreadySelectedFunctions count]>0) {
        NSMutableString *string=[[NSMutableString alloc] init];
        for (int i=0; i<[self.alreadySelectedFunctions count]; i++) {
            [string appendString:[NSString stringWithFormat:@"%@,",[[self.alreadySelectedFunctions objectAtIndex:i] objectForKey:kjobFunctionCode]]];
        }
        [string deleteCharactersInRange:NSMakeRange([string length]-1, 1)];
        self.blackListString=string;
    }
    
    if (self.allFunctionSelected) {
        self.jobFunctionArray = [[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobFunctionsForCategoryIncaseAllFunctionIsSelected:[self.selectedJobFuncCategoryDict objectForKey:kjobFunctionCategoryCode] notIn:self.blackListString];
    }
    else{
        self.jobFunctionArray=[[CLCoreDataHelper sharedCLCoreDataHelper] getAllJobFunctionsForCategory:[self.selectedJobFuncCategoryDict objectForKey:kjobFunctionCategoryCode] notIn:self.blackListString];
    }
    
    
    [self setRightNavigationButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Utility Methods

-(void)setRightNavigationButton{
    NSString *buttonText = nil;
    
    if (self.enableSelectOption)
    {
        if (self.selectedJobFunctionArray.count == 0 && (self.jobFunctionArray.count == 1 && [[[self.jobFunctionArray objectAtIndex:0]objectForKey:kCLJobPreferenceJobFunctionOtherFlag]boolValue])) {
            buttonText = @"Done";
            self.selectAll = NO;
        }
        
        else if ([self doWeNeedSelectAll]){
            buttonText = @"Done";
            self.selectAll = NO;
        }
        else if (self.selectedJobFunctionArray.count == 0 && (self.jobFunctionArray.count > 1 )){
            buttonText = @"Select All";
            self.selectAll = YES;
        }
        else{
            buttonText = @"Done";
            self.selectAll = NO;
        }
    }
    else{
        buttonText = @"Done";
        self.selectAll = NO;
    }
    UIBarButtonItem *rightNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(buttonText, @"Text for done button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionSelectionDone:)];
    self.navigationItem.rightBarButtonItem=rightNavBttn;
}

-(BOOL)doWeNeedSelectAll{
    for (NSMutableDictionary *dict in [self.selectedFunctionDict objectForKey:@"function"]) {
        if ([dict objectForKey:@"jobFunctionGroupCode"]) {
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"jobFunctionGroupCode"]] isEqualToString:[NSString stringWithFormat:@"%@",[self.selectedJobFuncCategoryDict objectForKey:@"jobFunctionGroupCode"]]]) {
                return YES; //yes means no in this instance :)
            }
        }else{
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"functionGroupCode"]] isEqualToString:[NSString stringWithFormat:@"%@",[self.selectedJobFuncCategoryDict objectForKey:@"jobFunctionGroupCode"]]]) {
                return YES; //yes means no in this instance :)
            }
        }
        
    }
    return NO;
}

//-(void)setLeftNavigationButton{
//    UIBarButtonItem *leftNavBttn=[[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", @"Text for cancel button to dismiss modal") style:UIBarButtonItemStylePlain target:self action:@selector(bttnActionCancelModal:)];
//    self.navigationItem.leftBarButtonItem=leftNavBttn;
//}

-(BOOL)selectedFunctionsContainsDict:(NSDictionary*)cellDict{
    BOOL isContains=NO;
    NSDictionary *selectedDict=nil;
    for (int i=0; i<[self.selectedJobFunctionArray count]; i++) {
        selectedDict=[self.selectedJobFunctionArray objectAtIndex:i];
        if([[cellDict objectForKey:kjobFunctionCode] isEqualToString:[selectedDict objectForKey:kjobFunctionCode]]){
            isContains=YES;
            break;
        }
    }
    return isContains;
}

-(int)indexOfDictInSelectedFunctions:(NSDictionary*)cellDict{
    int index=0;
    NSDictionary *selectedDict=nil;
    for (int i=0; i<[self.selectedJobFunctionArray count]; i++) {
        selectedDict=[self.selectedJobFunctionArray objectAtIndex:i];
        if([[cellDict objectForKey:kjobFunctionCode] isEqualToString:[selectedDict objectForKey:kjobFunctionCode]]){
            index=i;
            break;
        }
    }
    return index;
}

-(NSMutableArray*)addFnGroupNameto:(NSMutableArray*)array
{
    for (NSMutableDictionary *dict in array)
    {
        NSString *GroupCode = [dict objectForKey:@"jobFunctionGroupCode"];
        NSString *groupName = [[CLCoreDataHelper sharedCLCoreDataHelper] getFunctionGroupNamefrom:GroupCode];
        [dict setValue:groupName forKey:@"functionGroupName"];
    }
    return array;
}

#pragma mark IBaction

-(void)bttnActionSelectionDone:(id)sender{
    if (self.selectAll)
    {
        self.isAllSelected = YES;
        for (NSMutableDictionary *dict in self.jobFunctionArray) {
            if (![[dict objectForKey:kCLJobPreferenceJobFunctionOtherFlag]boolValue]) {
                [self.selectedJobFunctionArray addObject:dict];
                
//                [self addFnGroupNameto:self.selectedJobFunctionArray];
            }
        }
        [self.tableView reloadData];
        [self setRightNavigationButton];
    }
    else
    {
        [self.tableView setEditing:NO animated:NO];
        [self dismissViewControllerAnimated:YES completion:^(void)
         {
             if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidSelectJobFunction:withArray: andSelectAllInfo:)])
             {
                 if(self.enableSelectOption)
                 {
                     NSMutableArray *fnCatArray1 = [[self.selectedFunctionDict valueForKeyPath:kCLTargetJobsNewFnCategory]mutableCopy];
                     NSMutableArray *fnCatArray2 = [[self.selectedFunctionDict valueForKeyPath:@"function"]mutableCopy];
                     NSMutableArray *fnCatArray3 = [[self.selectedFunctionDict valueForKeyPath:@"OtherFunction"]mutableCopy];
                     
                     if(self.isAllSelected)
                     {
                         NSString *catCode = nil;
                         NSString *fnGrpName = nil;
                         
                         for(NSMutableDictionary *dict in self.selectedJobFunctionArray)
                         {
                             catCode = [dict objectForKey:@"jobFunctionGroupCode"];
                             break;
                         }
                         
                         NSString *fnGrp = [[CLCoreDataHelper sharedCLCoreDataHelper] getFunctionGroupNamefrom:catCode];
                         fnGrpName = [NSString stringWithFormat:@"All - %@",fnGrp];
                         
                         NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: catCode, @"functionCategoryCode", fnGrpName, @"functionCategory", fnGrp, @"functionGroupName", nil];
                         
                         [fnCatArray1 addObject:innerDict];
                         [self.selectedFunctionDict setObject:fnCatArray1 forKey:kCLTargetJobsNewFnCategory];
                         
                         if(self.isOtherSelected)
                         {
                             for(NSMutableDictionary *dict in self.selectedJobFunctionArray)
                             {
                                 NSString *otherJob = [dict objectForKey:@"jobFunction"];
                                 if(otherJob.length)
                                 {
                                     [fnCatArray3 addObject:dict];
                                     [self.selectedFunctionDict setObject:fnCatArray3 forKey:@"OtherFunction"];
                                 }
                             }
                         }
                         
                         NSMutableArray *newArr = [fnCatArray2 mutableCopy];
                         for(NSMutableDictionary *dict in fnCatArray2)
                         {
                             NSString *groupCde = [dict objectForKey:@"jobFunctionGroupCode"];
                             
                             if([catCode isEqualToString:groupCde])
                             {
                                 [newArr removeObject:dict];
                                 //[fnCatArray2 addObject:innerDict];
                                 [self.selectedFunctionDict setObject:newArr forKey:@"function"];
                             }
                         }
                     }
                     else
                     {
                         NSString *fnCode = nil;
                         NSString *fnGrpName = nil;
                         
                         for(NSMutableDictionary *dict in self.selectedJobFunctionArray)
                         {
                             NSString *otherJob = [dict objectForKey:@"jobFunction"];
                             if(otherJob.length)
                             {
                                 [fnCatArray3 addObject:dict];
                                 [self.selectedFunctionDict setObject:fnCatArray3 forKey:@"OtherFunction"];
                             }
                             else
                             {
                                 NSString *catCode = [dict objectForKey:@"jobFunctionGroupCode"];
                                 fnGrpName = [NSString stringWithFormat:@"%@(%@)",[[CLCoreDataHelper sharedCLCoreDataHelper] getFunctionGroupNamefrom:catCode], [dict objectForKey:@"function"]];
                                 fnCode = [dict objectForKey:@"jobFunctionCode"];
                                 
                                 
                                 NSMutableDictionary * innerDict = [NSMutableDictionary dictionaryWithObjectsAndKeys: fnCode, @"functionCode", fnGrpName, @"function", catCode, @"jobFunctionGroupCode", nil];
                                 
                                 [fnCatArray2 addObject:innerDict];
                                 [self.selectedFunctionDict setObject:fnCatArray2 forKey:@"function"];
                                 
                             }
                         }
                         
                     }
                     
                     [self.delegate selectJobFunctionControllerDidSelectJobFunction:self withArray:self.selectedJobFunctionArray andSelectAllInfo:self.selectedFunctionDict];
                 }
             }
             
             if (self.delegate!= nil && [self.delegate respondsToSelector:@selector(selectJobFunctionControllerDidSelectJobFunction:withArray:)])
             {
                 [self.delegate selectJobFunctionControllerDidSelectJobFunction:self withArray:self.selectedJobFunctionArray];
             }
         }];
    }
    
}

//-(void)bttnActionCancelModal:(id)sender{
//    [self dismissViewControllerAnimated:YES completion:nil];
//}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.jobFunctionArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
        [cell.textLabel setNumberOfLines:0];
    }
    
    NSMutableDictionary *jobFuncDict=[self.jobFunctionArray objectAtIndex:indexPath.row];
    if ([self selectedFunctionsContainsDict:[self.jobFunctionArray objectAtIndex:indexPath.row]]) {
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
        if([[[self.jobFunctionArray objectAtIndex:indexPath.row] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"])
        {
            if (!self.enableSelectOption)
            {
                cell.textLabel.text=[NSString stringWithFormat:@"%@",[[self.selectedJobFunctionArray objectAtIndex:[self indexOfDictInSelectedFunctions:jobFuncDict]] objectForKey:kjobFunctionOtherText]];
            }
            else{
                cell.textLabel.text=[NSString stringWithFormat:@"%@",[[self.selectedJobFunctionArray objectAtIndex:[self indexOfDictInSelectedFunctions:jobFuncDict]] objectForKey:kCLJobPreferenceFinctionsKey]];
            }
            
        }
        else{
            cell.textLabel.text=[jobFuncDict objectForKey:kjobFunctionName];
        }
    }
    else{
        cell.accessoryType=UITableViewCellAccessoryNone;
        cell.textLabel.text=[jobFuncDict objectForKey:kjobFunctionName];
    }
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if([self selectedFunctionsContainsDict:[self.jobFunctionArray objectAtIndex:indexPath.row]]){
         self.isAllSelected = NO;
        [self.selectedJobFunctionArray removeObjectIdenticalTo:[self.jobFunctionArray objectAtIndex:indexPath.row]];
        [self.tableView reloadData];
    }
    else{
        if([[[self.jobFunctionArray objectAtIndex:indexPath.row] objectForKey:kjobFunctionOtherFlag] isEqualToString:@"1"])
        {
            self.otherJobFunction=[self.jobFunctionArray objectAtIndex:indexPath.row];
            if([CLCommon isOSversionLessThan8])
            {
                
                UIAlertView *enterFuncAlert=[[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"Enter Your Other Function:", @"Enter Your Other Function") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Done", @"Done"), nil];
                enterFuncAlert.tag=88;
                enterFuncAlert.alertViewStyle=UIAlertViewStylePlainTextInput;
                [enterFuncAlert textFieldAtIndex:0].autocapitalizationType = UITextAutocapitalizationTypeWords;
                [enterFuncAlert show];
            }else{
                // nil titles break alert interface on iOS 8.0, so we'll be using empty strings
                UIAlertController *alert = [UIAlertController alertControllerWithTitle: @""
                                                                               message: NSLocalizedString(@"Enter Your Other Function:", @"Enter Your Other Function")
                                                                        preferredStyle: UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                }];
                UIAlertAction* okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Done", @"Done") style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction * action){
                                                                     //Do Some action here
                                                                     
                                                                     UITextField *textField = alert.textFields[0];
                                                                     NSString *otherFuncText = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                                                     
                                                                     if (![otherFuncText isEqualToString:@""] && ![CLCommon doesItHaveSpace:otherFuncText]) {
                                                                         if (self.enableSelectOption) {
                                                                             self.isOtherSelected = YES;
                                                                             [self.otherJobFunction setObject:[self.otherJobFunction objectForKey:kCLJobPreferenceFinctionsKey] forKey:kCLJobPreferenceJobFunctionKey];
                                                                             [self.otherJobFunction removeObjectForKey:kCLJobPreferenceFinctionsKey];
                                                                             [self.otherJobFunction setObject:otherFuncText forKey:kCLJobPreferenceFinctionsKey];
                                                                         }
                                                                         else{
                                                                             [self.otherJobFunction setObject:otherFuncText forKey:kjobFunctionOtherText];
                                                                         }
                                                                     [self.selectedJobFunctionArray addObject:self.otherJobFunction];
                                                                     [self setRightNavigationButton];
                                                                     }
                                                                     self.otherJobFunction=nil;
                                                                     [self.tableView reloadData];
                                                                 }];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel")
                                                                       style: UIAlertActionStyleDefault
                                                                     handler: nil];
                
                [alert addAction: cancelAction];
                [alert addAction: okAction];
                [self presentViewController:alert animated:YES completion:nil];
            }
            
        }
        else{
            [self.selectedJobFunctionArray addObject:[self.jobFunctionArray objectAtIndex:indexPath.row]];
            
            NSMutableArray *copyArr = [self.jobFunctionArray mutableCopy];
            NSMutableArray *discardedItems = [NSMutableArray array];
            
            for (NSMutableDictionary *dict in self.jobFunctionArray)
            {
                if ([self.selectedJobFunctionArray containsObject:dict])
                    [discardedItems addObject:dict];
            }
            
            [copyArr removeObjectsInArray:discardedItems];
            
            if([copyArr count] == 1 && [copyArr count] != 0)
            {
                NSMutableDictionary *dict = [copyArr objectAtIndex:0];
                NSString *fnName = [dict objectForKey:@"function"];
                
                if ([fnName rangeOfString:@"Other"].location == NSNotFound)
                {
                    self.isAllSelected = NO;
                } else
                {
                    self.isAllSelected = YES;
                }
                
            }
            else
            {
                if([copyArr count] == 0)
                    self.isAllSelected = YES;
            }
            
            [self.tableView reloadData];
        }
    }
    [self setRightNavigationButton];
}


#pragma mark UIAlertView Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //ENter custom message alert...
    if(alertView.tag==88){
        if(buttonIndex==0){
            //cancel clicked do nothing...
        }
        else{
            NSString *otherFuncText = [[[alertView textFieldAtIndex:0] text] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if (![otherFuncText isEqualToString:@""] && ![CLCommon doesItHaveSpace:otherFuncText]) {
                if (self.enableSelectOption) {
                    self.isOtherSelected = YES;
                    [self.otherJobFunction setObject:[self.otherJobFunction objectForKey:kCLJobPreferenceFinctionsKey] forKey:kCLJobPreferenceJobFunctionKey];
                    [self.otherJobFunction removeObjectForKey:kCLJobPreferenceFinctionsKey];
                    [self.otherJobFunction setObject:otherFuncText forKey:kCLJobPreferenceFinctionsKey];
                }
                else{
                    [self.otherJobFunction setObject:otherFuncText forKey:kjobFunctionOtherText];
                }
               
                [self.selectedJobFunctionArray addObject:self.otherJobFunction];
                [self setRightNavigationButton];
            }
            self.otherJobFunction=nil;
            [self.tableView reloadData];
        }
    }
}
-(void)willPresentAlertView:(UIAlertView *)alertView{
    if(alertView.tag==88){
        alertView.tintColor=ColorCode_CareerLineGreen;
        [[alertView textFieldAtIndex:0] setKeyboardType:UIKeyboardTypeAlphabet];
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView{
    if(alertView.tag==88){
        NSString *inputText = [[alertView textFieldAtIndex:0] text];
        if( [inputText length] >= 100 || [inputText length] < 1)
        {
            return NO;
        }
        else
        {
            return YES;
        }
    }
    return YES;
}


@end
